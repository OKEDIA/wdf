// React Imports

// Next.js Imports

// Firebase Imports

// Helpers
import { logger } from "../logging";

// Other libraries or utilities
import { mongoDbAdmin } from "@okedia/shared/database";

// Types
import { DeleteResult, ObjectId } from "mongodb";
import {
	LookupProps,
	MongoDocumentProps,
	PipelineStage,
} from "@okedia/shared/types/mongoTypes";
import {
	PaginitedMongoResponse,
	PaginitionDocumentResult,
	PaginitionQuery,
	UnpaginitedMongoResponse,
} from "../types/documentResponses";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Creates a new document in the specified MongoDB collection.
 *
 * @template T - The type of the document to be created.
 * @param {MongoDocumentProps<T>} params - The parameters for creating the document.
 * @param {string} params.collectionName - The name of the collection where the document will be created.
 * @param {string} params.documentName - The name (or ID) of the document to be created.
 * @param {T} params.body - The body of the document to be created.
 * @returns {Promise<UnpaginitedMongoResponse<T>>} - A promise that resolves to the created document.
 * @throws {Error} - Throws an error if the document creation fails.
 */
async function create<T>({
	collectionName,
	documentName,
	body,
}: MongoDocumentProps<T>): Promise<UnpaginitedMongoResponse<T>> {
	const objectId = new ObjectId(documentName);
	logger.info(
		`Creating a document in collection: ${collectionName}, with ID: ${objectId}`
	);

	const bodyToSend = {
		_id: objectId,
		id: objectId.toString(),
		...convertToObjectIdIfNeeded(body),
		created: objectId.getTimestamp(),
	};

	const newDoc = await mongoDbAdmin
		.collection(collectionName)
		.insertOne(bodyToSend)
		.then((res) => res)
		.catch((error) => {
			logger.error(
				{
					error,
					collectionName,
					documentName,
					document: bodyToSend,
				},
				`Error creating document: ${error.message}`
			);
			throw error;
		});

	return {
		...bodyToSend,
		_id: newDoc.insertedId,
	} as UnpaginitedMongoResponse<T>;
}

/**
 * Finds documents in a MongoDB collection with optional pagination, filtering, and expansion.
 *
 * @template T - The type of the documents to be returned.
 *
 * @param {Object} params - The parameters for the find function.
 * @param {string} params.collectionName - The name of the MongoDB collection to query.
 * @param {Object} params.paginition - The pagination options.
 * @param {number} params.paginition.limit - The maximum number of documents to return.
 * @param {number} params.paginition.startAfter - The number of documents to skip.
 * @param {Function} params.paginition.callback - A callback function to handle pagination results.
 * @param {LookupProps[]} [params.expand] - Optional array of lookup properties for expanding documents.
 * @param {Record<string, any>} params.filter - The filter criteria for querying documents.
 *
 * @returns {Promise<PaginitedMongoResponse<T> | UnpaginitedMongoResponse<T>>} - A promise that resolves to the found documents, either paginated or unpaginated.
 */
async function find<T>({
	collectionName,
	paginition,
	filter,
	expand,
}: {
	collectionName: string;
	paginition: {
		limit: number;
		startAfter: number;
		callback: (props: PaginitionQuery) => PaginitionDocumentResult;
	};
	expand?: LookupProps[];
	filter: Record<string, any>;
}): Promise<PaginitedMongoResponse<T> | UnpaginitedMongoResponse<T>> {
	logger.info(`Finding documents in collection: ${collectionName}`);

	// Initialize the filter object
	const mongoFilter = getMongoDbReadyFilter(filter);

	function getMongoDbReadyFilter(
		filter: Record<string, any> | any[]
	): Record<string, any> {
		const mongoFilter: Record<string, any> = {};

		function convertBracketToDotNotation(key: string): string {
			// Converts a key with bracket notation to dot notation
			// E.g. intro.stageName[0].name => intro.stageName.0.name
			// This is for mongoDb filter compatibility

			return key.replace(/\[(\d+)\]/g, ".$1");
		}

		if (Array.isArray(filter)) {
			mongoFilter.$and = filter
				.filter((f) => f !== undefined)
				.map((f) => getMongoDbReadyFilter(f));
		} else {
			Object.keys(filter || {}).forEach((key) => {
				const value = filter[key];
				const dotNotationKey = convertBracketToDotNotation(key);

				if (
					typeof value === "object" &&
					value !== null &&
					!Array.isArray(value)
				) {
					mongoFilter[dotNotationKey] = getMongoDbReadyFilter(value);
				} else if (typeof value === "string") {
					// Check if the string is a valid ObjectId
					if (ObjectId.isValid(value.trim())) {
						mongoFilter[dotNotationKey] = convertToObjectIdIfNeeded(value);
					} else {
						// Use case-insensitive regex for non-ObjectId strings
						mongoFilter[dotNotationKey] = {
							$regex: new RegExp(value, "i"),
						};
					}
				} else {
					mongoFilter[dotNotationKey] = convertToObjectIdIfNeeded(value);
				}
			});
		}
		console.log(mongoFilter);
		return mongoFilter;
	}

	logger.debug(mongoFilter, `Created Filter Object`);

	// Count documents matching the filter
	const count = await mongoDbAdmin
		.collection(collectionName)
		.countDocuments(mongoFilter);

	const basePipeline: PipelineStage[] = [
		{ $match: mongoFilter },
		{ $sort: { _id: -1 } },
		{ $skip: paginition.startAfter || 0 },
		{ $limit: paginition.limit },
	];

	if (expand) {
		expand.forEach(({ from, localField, foreignField, as }) => {
			basePipeline.push({
				$lookup: {
					from,
					localField,
					foreignField,
					as,
				},
			});
		});
	}

	const foundDocs = await (() => {
		if (expand) {
			return mongoDbAdmin
				.collection(collectionName)
				.aggregate(basePipeline)
				.toArray()
				.catch((error) => {
					logger.error(
						{
							error,
							collectionName,
							filter: mongoFilter,
						},
						`Error finding documents: ${error.message}`
					);
				});
		} else {
			return mongoDbAdmin
				.collection(collectionName)
				.find(mongoFilter)
				.limit(paginition.limit)
				.skip(
					Number.isInteger(paginition.startAfter) ? paginition.startAfter : 0
				)
				.sort({ _id: -1 })
				.toArray()
				.catch((error) => {
					logger.error(
						{
							error,
							collectionName,
							filter: mongoFilter,
						},
						`Error finding documents: ${error.message}`
					);
				});
		}
	})();

	const parsedDocs = JSON.parse(JSON.stringify(foundDocs));

	if (paginition.limit === 1) {
		logger.debug(
			`Returning ${parsedDocs?.length} of ${count} documents with pagination. Maximum limit: ${paginition.limit} due to paginition.`
		);
		return parsedDocs?.[0] as UnpaginitedMongoResponse<T>;
	}

	logger.debug(
		`Returning ${parsedDocs?.length} of ${count} documents with pagination`
	);

	return {
		data: parsedDocs as T[],
		paginition: paginition.callback({
			body: parsedDocs,
			idSelector: "id",
			count,
		}),
	} as PaginitedMongoResponse<T>;
}

/**
 * Retrieves a document from a MongoDB collection, with optional expansion of related documents.
 *
 * @template T - The type of the document to be retrieved.
 * @param {Object} params - The parameters for the get function.
 * @param {string} params.collectionName - The name of the collection to retrieve the document from.
 * @param {string | ObjectId} params.documentName - The name or ObjectId of the document to retrieve.
 * @param {LookupProps[]} [params.expand] - Optional array of lookup properties to expand related documents.
 * @returns {Promise<UnpaginitedMongoResponse<T>>} - A promise that resolves to the retrieved document.
 */
async function get<T>({
	collectionName,
	documentName,
	expand,
}: {
	collectionName: string;
	documentName: string | ObjectId;
	expand?: LookupProps[];
}): Promise<UnpaginitedMongoResponse<T>> {
	const objectId = new ObjectId(documentName);
	const basePipeline: PipelineStage[] = [];
	logger.info(
		`Getting document from collection: ${collectionName}, with ID: ${objectId.toString()}`
	);

	if (expand) {
		logger.debug(
			`Expanding document with lookups: ${expand.map((e) => e.as).join(", ")}`
		);
		expand.forEach(({ from, localField, foreignField, as }) => {
			basePipeline.push({
				$lookup: {
					from,
					localField,
					foreignField,
					as,
				},
			});
		});
	}

	const foundDoc = await (() => {
		if (expand) {
			return mongoDbAdmin
				.collection(collectionName)
				.aggregate(basePipeline)
				.toArray()
				.then((docs) => docs[0])
				.catch((error) => {
					logger.error(
						{
							error,
							documentName,
							collectionName,
							expand: expand,
						},
						`Error finding expanded document: ${error.message}`
					);
				});
		} else {
			return mongoDbAdmin
				.collection(collectionName)
				.findOne({ _id: objectId })
				.catch((error) => {
					logger.error(
						{
							error,
							documentName,
							collectionName,
							expand: expand,
						},
						`Error finding document: ${error.message}`
					);
				});
		}
	})();

	const parsedDoc = JSON.parse(JSON.stringify(foundDoc));
	logger.info(`Returning document: ${parsedDoc?._id.toString()}`);
	return parsedDoc as UnpaginitedMongoResponse<T>;
}

/**
 * Updates a document in a MongoDB collection.
 *
 * @template T - The type of the document to be updated.
 * @param {MongoDocumentProps<T>} params - The parameters for the update operation.
 * @param {string} params.documentName - The name of the document to be updated.
 * @param {string} params.collectionName - The name of the collection containing the document.
 * @param {T} params.body - The new data to update the document with.
 * @returns {Promise<UnpaginitedMongoResponse<T>>} - A promise that resolves to the updated document.
 * @throws {Error} - Throws an error if the document update fails.
 */
async function update<T>({
	documentName,
	collectionName,
	body,
}: MongoDocumentProps<T>): Promise<UnpaginitedMongoResponse<T>> {
	const objectId = new ObjectId(documentName);
	logger.info(
		`Updating document ${documentName} in collection: ${collectionName}`
	);

	const dataToUpdate = {
		...convertToObjectIdIfNeeded(body),
		updated: new Date(),
	};

	const updatedDoc = await mongoDbAdmin
		.collection(collectionName)
		.updateOne(
			{ _id: objectId },
			{
				$set: dataToUpdate,
			}
		)
		.catch((error) => {
			logger.error(
				{
					error,
					documentName,
					collectionName,
					body: dataToUpdate,
				},
				`Error updating document: ${error.message}`
			);
			throw error;
		});

	if (updatedDoc.acknowledged) {
		logger.info(`Successfully updated document: ${documentName}`);
		return body as unknown as UnpaginitedMongoResponse<T>;
	} else {
		throw new Error("Document update failed.");
	}
}

async function remove({
	documentName,
	collectionName,
}: MongoDocumentProps<undefined>): Promise<DeleteResult> {
	const objectId = new ObjectId(documentName);
	logger.warn(
		`Removing document ${documentName} from collection: ${collectionName}`
	);

	return await mongoDbAdmin
		.collection(collectionName)
		.deleteOne({ _id: objectId })
		.catch((error) => {
			logger.error(
				{
					error,
					documentName,
					collectionName,
				},
				`Error removing document: ${error.message}`
			);
			throw error;
		});
}

// Recursively converts ObjectId-like strings to ObjectId

/**
 * Converts string values that are valid MongoDB ObjectIds to ObjectId instances.
 * This function processes strings, arrays, and objects recursively.
 *
 * @param data - The data to be converted. It can be a string, array, or object.
 * @returns The converted data where valid ObjectId strings are replaced with ObjectId instances.
 *
 * @example
 * ```typescript
 * const result = convertToObjectIdIfNeeded("507f1f77bcf86cd799439011");
 * // result is an ObjectId instance
 *
 * const resultArray = convertToObjectIdIfNeeded(["507f1f77bcf86cd799439011", "invalidId"]);
 * // resultArray is an array with the first element as an ObjectId instance and the second as "invalidId"
 *
 * const resultObject = convertToObjectIdIfNeeded({ id: "507f1f77bcf86cd799439011", name: "John" });
 * // resultObject is { id: ObjectId("507f1f77bcf86cd799439011"), name: "John" }
 * ```
 */
function convertToObjectIdIfNeeded(data: any): any {
	if (data instanceof ObjectId) {
		// Return the value as is if it's already an ObjectId
		return data;
	} else if (typeof data === "string" && ObjectId.isValid(data.trim())) {
		// Convert single string values that are valid ObjectIds
		return new ObjectId(data.trim());
	} else if (Array.isArray(data)) {
		// Process each element in the array and convert if needed
		return data.map((item) => convertToObjectIdIfNeeded(item));
	} else if (typeof data === "object" && data !== null) {
		// Process object properties
		const convertedObject: Record<string, any> = {};
		Object.keys(data).forEach((key) => {
			const value = data[key];
			if (key === "id") {
				// Never update the value of key "id"
				convertedObject[key] = value;
			} else if (value instanceof ObjectId) {
				// Return the value as is if it's already an ObjectId
				convertedObject[key] = value;
			} else if (typeof value === "string" && ObjectId.isValid(value.trim())) {
				// Convert single string values that are valid ObjectIds
				convertedObject[key] = new ObjectId(value.trim());
			} else {
				// Recurse for nested objects and arrays
				convertedObject[key] = convertToObjectIdIfNeeded(value);
			}
		});
		return convertedObject;
	}
	// Return the value as is if it's neither an object, array, nor a valid ObjectId string
	return data;
}

const documentHelpers = {
	create,
	find,
	get,
	update,
	remove,
	convertToObjectIdIfNeeded,
};

export { documentHelpers };
