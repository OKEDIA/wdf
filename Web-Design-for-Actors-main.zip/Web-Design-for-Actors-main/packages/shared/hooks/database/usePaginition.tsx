// React Imports
import { useCallback, useEffect, useState } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities
import { useDatabase } from "@okedia/shared/hooks";

// Types
import { ObjectId } from "bson";
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

interface PaginitionProps<T> {
	initialCount: number;
	pageLimit: number;
	initialData?: T;
	onDataChange: (data: T) => void;
	onReady?: () => void;
	onFilter?: (data: T) => T;
	endpointUrl: string | { [key: string]: string };
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Custom hook for handling client-side paginition to expand entries MongoDB ObjectID's and
 * replace the reference with the actual document.
 *
 * @param {Object} props - The properties for the pagination hook.
 * @param {number} [props.initialCount=0] - The initial count of items to display.
 * @param {number} [props.pageLimit=initialCount] - The number of items to fetch per page.
 * @param {Array} props.initialData - The initial data to paginate.
 * @param {Function} props.onDataChange - Callback function to handle data changes.
 * @param {Function} [props.onReady] - Optional callback function to be called when the pagination is ready.
 * @param {Function} [props.onFilter] - Optional callback function to filter the data.
 * @param {string} props.endpointUrl - The endpoint URL for fetching item data.
 *
 * @returns {Object} - The pagination state and handler.
 * @returns {number} currentCount - The current count of items displayed.
 * @returns {boolean} hasMore - Flag indicating if there are more items to load.
 * @returns {Function} handlePaginition - Function to handle pagination.
 */
export function usePaginition<T>({
	initialCount = 0,
	pageLimit = initialCount,
	initialData,
	onDataChange,
	onReady,
	onFilter,
	endpointUrl,
}: PaginitionProps<T[]> ) {
	const db = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);
	const [ currentCount, setCurrentCount ] = useState( 0 );
	const [ hasMore, setHasMore ] = useState( true );
	
	const getItemData = useCallback(
		async (itemId: string, key = "/profiles/"): Promise<any> => {
			try {
				const baseUrl =
					typeof endpointUrl === "string"
						? endpointUrl
						: endpointUrl[key || ""];
				if (!baseUrl) {
					throw new Error(`No endpoint URL found for key: ${key}`);
				}
				const response = await db.get(`${baseUrl}${itemId}`);
				return response;
			} catch (error) {
				console.error(
					`Error fetching data for item ${itemId} with key ${key}:`,
					error
				);
				return itemId;
			}
		},
		[db, endpointUrl]
	);

	const processItem = useCallback(
		async (item: any, parentKey?: string): Promise<any> => {
			if (!item) return item;

			if (typeof item === "string" && ObjectId.isValid(item)) {
				const keyToUse = parentKey || "profiles";
				return await getItemData(item, keyToUse);
			} else if (Array.isArray(item)) {
				return await Promise.all(
					item.map((child) => processItem(child, parentKey))
				);
			} else if (typeof item === "object" && item !== null) {
				const updatedObject: { [key: string]: any } = {};
				for (const key in item) {
					if (Object.prototype.hasOwnProperty.call(item, key)) {
						updatedObject[key] = await processItem(item[key], key);
					}
				}
				return updatedObject;
			}

			return item;
		},
		[getItemData]
	);

	const handlePaginition = useCallback(async () => {
		const startIndex = 0;
		let endIndex = currentCount + pageLimit;
		let paginatedData = initialData?.slice(startIndex, endIndex) || [];

		if (onFilter) {
			paginatedData = onFilter(paginatedData);
			endIndex = startIndex + paginatedData.length;
		}

		const updatedData = await Promise.all(
			paginatedData.map((item) => processItem(item))
		);

		onDataChange([
			...(initialData ?? []).slice(0, startIndex),
			...updatedData,
			...(initialData ?? []).slice(endIndex),
		]);

		setCurrentCount((prevCount) => {
			if (onFilter) {
				return paginatedData.length + 1;
			}
			return Math.min(prevCount + pageLimit, initialData?.length ?? 0);
		});

		setHasMore(() => {
			if (onFilter) {
				const validResultsCount = onFilter(initialData || []).length;
				return endIndex < validResultsCount;
			}
			return currentCount < ((initialData?.length ?? -1 )+ 1);
		});
	}, [
		currentCount,
		pageLimit,
		initialData,
		onFilter,
		onDataChange,
		processItem,
	]);

	useEffect(() => {
		handlePaginition().then(() => onReady?.());
	}, []);

	return {
		currentCount,
		hasMore,
		handlePaginition,
	};
}
