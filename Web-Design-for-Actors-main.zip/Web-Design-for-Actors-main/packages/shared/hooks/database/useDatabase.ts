"use client";

import { useMemo, useState } from "react";
import { InternalApiResponse } from "../../types/documentResponses";

export interface UseDatabaseReturns {
	get: <T>(url: string, request?: Partial<RequestInit>) => Promise<T>;
	post: <T>(
		url: string,
		body: any,
		request?: Partial<RequestInit>
	) => Promise<T>;
	patch: <T>(
		url: string,
		body: any,
		request?: Partial<RequestInit>
	) => Promise<T>;
	deleter: <T>(url: string, request?: Partial<RequestInit>) => Promise<T>;
	loading: boolean;
}

export function useDatabase(
	baseUrl: string,
	responseType = "application/json"
): UseDatabaseReturns {
	const [loading, setLoading] = useState(true);

	async function handleResponse<T>(
		httpResponse: Response
	): Promise<InternalApiResponse<T>> {
		if (!httpResponse.ok) {
			const message = `Unexpected Error connecting to ${httpResponse.url}: ${httpResponse.statusText}`;
			throw new Error(message || `Unexpected Error: ${httpResponse.status}`);
		}

		const contentType = httpResponse.headers.get("content-type") || "";

		if (!responseType.startsWith(contentType)) {
			return {
				success: false,
				message: `Unexpected response type ${contentType}. Expected ${responseType}`,
			};
		}

		if (contentType && contentType.includes("application/json")) {
			return await httpResponse.json();
		} else {
			return { success: true, response: (await httpResponse.text()) as T };
		}
	}

	function handleError(e: any, reject: (reason?: any) => void): void {
		console.error(e);
		reject(e);
	}

	async function get<T>(
		url: string,
		request?: Partial<RequestInit>
	): Promise<T> {
		setLoading(true);

		return new Promise((resolve, reject) => {
			fetch(baseUrl + url, {
				cache: "force-cache",
				method: "get",
				headers: {
					"Content-Type": "application/json",
				},
				...request,
			})
				.then(handleResponse<T>)
				.then((responseData) => {
					if (responseData.success) {
						resolve(responseData.response);
					} else {
						reject(new Error(responseData.message || "Request failed"));
					}
				})
				.catch((e) => handleError(e, reject));
		}).finally(() => setLoading(false)) as T;
	}

	async function post<T>(
		url: string,
		body: any,
		request?: Partial<RequestInit>
	): Promise<T> {
		setLoading(true);

		return new Promise((resolve, reject) => {
			fetch(baseUrl + url, {
				method: "post",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify(body),
				...request,
			})
				.then(handleResponse<T>)
				.then((responseData) => {
					if (responseData.success) {
						resolve(responseData.response);
					} else {
						reject(new Error(responseData.message || "Request failed"));
					}
				})
				.catch((e) => handleError(e, reject));
		}).finally(() => setLoading(false)) as T;
	}

	async function patch<T>(
		url: string,
		body: any,
		request?: Partial<RequestInit>
	): Promise<T> {
		setLoading(true);

		return new Promise((resolve, reject) => {
			fetch(baseUrl + url, {
				method: "PATCH",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify(body),
				...request,
			})
				.then(handleResponse<T>)
				.then((responseData) => {
					if (responseData.success) {
						resolve(responseData.response);
					} else {
						reject(new Error(responseData.message || "Request failed"));
					}
				})
				.catch((e) => handleError(e, reject));
		}).finally(() => setLoading(false)) as T;
	}

	async function deleter<T>(
		url: string,
		request?: Partial<RequestInit>
	): Promise<T> {
		setLoading(true);

		return new Promise((resolve, reject) => {
			fetch(baseUrl + url, {
				method: "DELETE",
				headers: {
					"Content-Type": "application/json",
				},
				...request,
			})
				.then(handleResponse<T>)
				.then((responseData) => {
					if (responseData.success) {
						resolve(responseData.response);
					} else {
						reject(new Error(responseData.message || "Request failed"));
					}
				})
				.catch((e) => handleError(e, reject));
		}).finally(() => setLoading(false)) as T;
	}

	const apiMethods = useMemo(
		() => ({ get, post, patch, deleter, loading }),
		[loading]
	);

	return apiMethods;
}
