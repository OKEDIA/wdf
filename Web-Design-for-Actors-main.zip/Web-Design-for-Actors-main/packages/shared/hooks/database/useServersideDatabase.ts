// React Imports

import { RequestCookies } from "next/dist/compiled/@edge-runtime/cookies";

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * A custom hook for interacting with a database via HTTP requests.
 *
 * @param {string} baseUrl - The base URL for the API.
 * @param {string} type - The type of authentication to use ("plesk" or "whmcs").
 *
 * @returns {Object} An object containing `get` and `post` methods for making HTTP requests.
 *
 * @example
 * const { get, post } = useDatabase('https://api.example.com', 'plesk');
 *
 * // Example usage of get method
 * get({ url: '/endpoint' }).then(data => console.log(data));
 *
 * // Example usage of post method
 * post({ url: '/endpoint', body: { key: 'value' } }).then(data => console.log(data));
 *
 * @template T
 * @typedef {Object} GetParams
 * @property {string} url - The endpoint URL to send the GET request to.
 *
 * @template T
 * @typedef {Object} PostParams
 * @property {string} url - The endpoint URL to send the POST request to.
 * @property {any} body - The body of the POST request.
 */
export function useServersideDatabase(
	baseUrl: string,
	type: "plesk" | "whmcs" | "vercel" | "screenshot" | "sendy" | "",
	responseType = "application/json",
	cookies?: RequestCookies
) {
	let urlAuth: string = "";
	let pleskAuth: string | undefined = undefined;
	let bearerToken: string | undefined = undefined;
	let screenshotAuth: string | undefined = undefined;

	if (type === "plesk") {
		pleskAuth = process.env.NEXT_PLESK_API_KEY;
	} else if (type === "whmcs") {
		urlAuth = `&identifier=${process.env.WHMCS_IDENTIFIER}&secret=${process.env.WHMCS_SECRET}`;
	} else if (type === "vercel") {
		bearerToken = process.env.VERCEL_API_KEY;
	} else if (type === "screenshot") {
		screenshotAuth = process.env.SCREENSHOT_API_KEY;
	}

	/**
	 * Handles the response from a fetch request.
	 *
	 * @param response - The response object from the fetch request.
	 * @param resolve - A function that resolves a promise with the response data.
	 * @throws Will throw an error if the response status is not in the range of 200-299.
	 * @throws Will throw an error if the response data is not valid.
	 */
	function handleResponse(
		response: Response,
		resolve: (value: any | PromiseLike<any>) => void
	) {
		const contentType = response.headers.get("content-type") || "";

		if (!response.ok) {
			const error = new Error(`${response.statusText}: ${response.url}`);

			Error.captureStackTrace(error, handleResponse);

			throw error;
		}

		if (!contentType.startsWith(responseType)) {
			throw new Error(
				`Unexpected response type ${contentType}. Expected ${responseType}. ${response.url}`
			);
		}

		if (contentType && contentType.includes("application/json")) {
			resolve(response.json());
		} else {
			resolve(response.text());
		}
	}

	/**
	 * Asynchronously fetches data from the specified URL and returns a promise that resolves with the data.
	 *
	 * @template T - The type of the data to be returned.
	 * @param {Object} params - The parameters for the request.
	 * @param {string} params.url - The URL to fetch data from.
	 * @returns {Promise<T>} A promise that resolves with the fetched data.
	 */
	async function get<T>({ url }: { url: string }): Promise<T> {
		return new Promise((resolve, reject) => {
			return fetch(baseUrl + urlAuth + url, {
				method: "get",
				headers: {
					...(type !== "sendy" && { "Content-Type": "application/json" }),
					"X-API-Key": pleskAuth
						? pleskAuth
						: screenshotAuth
						? screenshotAuth
						: "",
					Authorization: bearerToken ? `Bearer ${bearerToken}` : "",
					Cookie:
						typeof cookies === "string" ? cookies : cookies?.toString() ?? "",
				},
			})
				.then((httpResponse) => handleResponse(httpResponse, resolve) as T)
				.catch((e: unknown) => {
					console.log(e);
					reject(e);
				});
		});
	}

	/**
	 * Sends a POST request to the specified URL with the given body.
	 *
	 * @template T - The expected response type.
	 * @param {Object} params - The parameters for the POST request.
	 * @param {string} params.url - The URL to send the POST request to.
	 * @param {any} params.body - The body of the POST request.
	 * @returns {Promise<T>} A promise that resolves with the response of type T.
	 */
	async function post<T>({
		url,
		body,
	}: {
		url: string;
		body: any;
	}): Promise<T> {
		return new Promise(async (resolve, reject) => {
			return fetch(baseUrl + url + urlAuth, {
				method: "POST",
				headers: {
					...(type !== "sendy" && { "Content-Type": "application/json" }),
					"X-API-Key": pleskAuth
						? pleskAuth
						: screenshotAuth
						? screenshotAuth
						: "",
					Authorization: bearerToken ? `Bearer ${bearerToken}` : "",
					Cookie:
						typeof cookies === "string" ? cookies : cookies?.toString() ?? "",
				},
				body: type === "sendy" ? body : JSON.stringify(body),
			})
				.then((httpResponse) => handleResponse(httpResponse, resolve))
				.catch((e: unknown) => {
					console.log(e);
					reject(e);
				});
		});
	}

	/**
	 * Sends a POST request to the specified URL with the given body.
	 *
	 * @template T - The expected response type.
	 * @param {Object} params - The parameters for the POST request.
	 * @param {string} params.url - The URL to send the POST request to.
	 * @param {any} params.body - The body of the POST request.
	 * @returns {Promise<T>} A promise that resolves with the response of type T.
	 */
	async function patch<T>({
		url,
		body,
	}: {
		url: string;
		body: any;
	}): Promise<T> {
		return new Promise((resolve, reject) => {
			return fetch(baseUrl + urlAuth + url, {
				method: "PATCH",
				headers: {
					...(type !== "sendy" && { "Content-Type": "application/json" }),
					"X-API-Key": pleskAuth
						? pleskAuth
						: screenshotAuth
						? screenshotAuth
						: "",
					Authorization: bearerToken ? `Bearer ${bearerToken}` : "",
					Cookie:
						typeof cookies === "string" ? cookies : cookies?.toString() ?? "",
				},
				body: type === "sendy" ? body : JSON.stringify(body),
			})
				.then((httpResponse) => handleResponse(httpResponse, resolve))
				.catch((e: unknown) => {
					console.log(e);
					reject(e);
				});
		});
	}

	/**
	 * Sends a DELETE request to the specified URL and returns a promise that resolves with the response.
	 *
	 * @template T - The type of the response expected from the DELETE request.
	 * @param {Object} params - The parameters for the DELETE request.
	 * @param {string} params.url - The URL to send the DELETE request to.
	 * @returns {Promise<T>} A promise that resolves with the response of type T.
	 */
	async function deleter<T>({ url }: { url: string }): Promise<T> {
		return new Promise((resolve, reject) => {
			return fetch(baseUrl + urlAuth + url, {
				method: "DELETE",
				headers: {
					...(type !== "sendy" && { "Content-Type": "application/json" }),
					"X-API-Key": pleskAuth
						? pleskAuth
						: screenshotAuth
						? screenshotAuth
						: "",
					Authorization: bearerToken ? `Bearer ${bearerToken}` : "",
					Cookie:
						typeof cookies === "string" ? cookies : cookies?.toString() ?? "",
				},
			})
				.then((httpResponse) => handleResponse(httpResponse, resolve))
				.catch((e: unknown) => {
					console.log(e);
					reject(e);
				});
		});
	}

	return { get, post, patch, deleter };
}
