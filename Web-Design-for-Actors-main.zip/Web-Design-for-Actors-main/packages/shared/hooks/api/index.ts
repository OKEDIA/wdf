import { useGlobalQueryParams } from "./useGlobalQueryParams";

export { useGlobalQueryParams };
