// React Imports

import {
	PaginitionDocumentResult,
	PaginitionQuery,
} from "../../types/documentResponses";
import { LookupProps } from "../../types/mongoTypes";

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

const supportedParamKeys = [
	"page",
	"limit",
	"sort",
	"filter",
	"groupBy",
	"count",
	"afterId",
	"expand",
];

function globalQueryParams(urlSearchParams: URLSearchParams) {
	const filteredParams: { [key: string]: string } = {};

	urlSearchParams.forEach((value, key) => {
		if (supportedParamKeys.includes(key)) {
			filteredParams[key] = value;
		}
	});
	return filteredParams;
}

export function useGlobalQueryParams(urlSearchParams: URLSearchParams) {
	function parse() {
		const filteredParams = globalQueryParams(urlSearchParams);
		return {
			page: stringToNumber(filteredParams.page),
			limit:
				stringToNumber(filteredParams.limit) ??
				parseInt(process.env.NEXT_PUBLIC_PAGINITION_LIMIT as string, 10),
			sort: filteredParams.sort,
			filter: uriToObject(filteredParams.filter),
			groupBy: filteredParams.groupBy,
			count: stringToBool(filteredParams.count),
			afterId: filteredParams.afterId,
			expand: filteredParams.expand
				? (JSON.parse(
						decodeURIComponent(filteredParams.expand as string)
				  ) as LookupProps[])
				: undefined,
		};
	}

	function paginitionResult({
		body,
		idSelector,
		count,
	}: PaginitionQuery): PaginitionDocumentResult {
		const filteredParams = parse();
		const lastId = body.length > 0 ? body[body.length - 1][idSelector] : null;

		return {
			lastId: lastId,
			limit: filteredParams.limit,
			count: count,
		};
	}

	function mongoQuery() {
		const filteredParams = parse();
		const limit = filteredParams.limit;
		const skip = ((filteredParams.page ?? 1) - 1) * limit;

		return {
			paginition: { limit, startAfter: skip, callback: paginitionResult },
			filter: filteredParams.afterId
				? { ...filteredParams.filter, _id: { $gt: filteredParams.afterId } }
				: filteredParams.filter,
			expand: filteredParams.expand,
		};
	}

	function stripeQuery() {
		const filteredParams = parse();

		let filters = filteredParams.filter
			.map((q: any) => {
				const key = Object.keys(q)[0];
				const value = Object.values(q)[0];
				return key.startsWith("metadata[")
					? `metadata["${key.slice(9, -1)}"]:"${value}"`
					: `${key}:"${value}"`;
			})
			.join(" AND ");

		return { filters };
	}

	function defaultPaginition() {
		const filteredParams = parse();
		const limit = filteredParams.limit;
		const skip = ((filteredParams.page ?? 1) - 1) * limit;

		return {
			paginition: { limit, startAfter: skip, callback: paginitionResult },
			filter: filteredParams.afterId
				? { ...filteredParams.filter, _id: { $gt: filteredParams.afterId } }
				: filteredParams.filter,
		};
	}

	return {
		parse,
		paginitionResult,
		mongoQuery,
		stripeQuery,
		defaultPaginition,
	};
}

function stringToNumber(s: string): number | null {
	if (s === undefined || s === null) {
		return null;
	}

	if (s === "") {
		return null;
	}

	if (isNaN(Number(s))) {
		return null;
	}

	return Number(s);
}

function uriToObject(uri: string) {
	if (!uri) {
		return null;
	}

	return JSON.parse(decodeURIComponent(uri));
}

function bothOrNone(a: string, b: string) {
	if (a && b) {
		return { a, b };
	}
}

function stringToBool(s: string) {
	if (s === "true") {
		return true;
	}

	if (s === "false") {
		return false;
	}

	return undefined;
}
