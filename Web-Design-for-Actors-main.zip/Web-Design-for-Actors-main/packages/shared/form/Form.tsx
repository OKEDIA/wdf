// React Imports
import React, {
	ChangeEvent,
	Fragment,
	memo,
	RefObject,
	useEffect,
	useMemo,
	useRef,
	useState,
} from "react";

// Next.js Imports

// Lower Order Components
import "@mantine/tiptap/styles.css";

// UI Components & Icons
import {
	Badge,
	Button,
	ButtonGroup,
	Fieldset,
	Flex,
	GridCol,
	InputDescription,
	InputLabel,
	MantineTheme,
	Tooltip,
	useMantineTheme,
	useMatches,
} from "@mantine/core";
import {
	IconArrowWaveRightDown,
	IconPlus,
	IconTrash,
} from "@tabler/icons-react";
import "cropperjs/dist/cropper.css";

import Cropper, { ReactCropperElement } from "react-cropper";

// Context & Helpers

// Other libraries or utilities
import { Controller, RegisterOptions, useFieldArray } from "react-hook-form";
import usePopup, {
	UsePopupReturns,
} from "../../../apps/web-design-for/src/app/_hooks/usePopup";
import useStorage, {
	UseStorageReturns,
} from "../../../apps/web-design-for/src/app/_hooks/useStorage";

// Types
import { checkIsEmpty, getFromObjectByPath } from "../helpers";
import { returnObjectWithEmptyValues } from "../helpers/object";
import { sanitiseHtml, stripHTML } from "../helpers/string/sanitise/client";
import { useDatabase } from "../hooks";
import { UseDatabaseReturns } from "../hooks/database/useDatabase";
import {
	components,
	errorTextMap,
	FieldComponent,
	fileTypeMap,
	FormProps,
	Input,
	patternMap,
} from "../types/formTypes";
import { l10nType } from "../types/l10n";
import { StateSetter } from "../types/stateTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export interface FormPropsOptions {
	isHorizontal?: boolean;
	isDisabled?: boolean;
	brand?: l10nType["id"];
}

interface ExtendedFormProps extends FormProps {
	options: ExtendedFormPropsOptions;
}

interface ExtendedFormPropsOptions extends FormPropsOptions {
	isStepForm?: boolean;
}

interface ExtendedSectionProperties extends Input {
	sectionIndex?: number;
	sectionId: string;
}

interface SectionProps {
	children: (
		arrayHelpers: ReturnType<typeof useFieldArray>,
		sectionIndex: number
	) => React.ReactNode;
	formProperties: ExtendedFormProps;
	sectionProperties: ExtendedSectionProperties;
	utilities: Utilities;
}

interface FieldRowsProps {
	arrayHelpers: ReturnType<typeof useFieldArray>;
	children: (
		fieldProperties: FieldComponent<any>,
		sectionId: string,
		key: string
	) => React.ReactNode;
	sectionProperties: ExtendedSectionProperties;
	formProperties: ExtendedFormProps;
	utilities: Utilities;
}

interface GetFieldSetPropsProps {
	arrayHelpers: ReturnType<typeof useFieldArray>;
	sectionProperties: ExtendedSectionProperties;
	options: ExtendedFormPropsOptions;
	theme: MantineTheme;
	index: number;
	isNestedFieldset: boolean;
	collapsed?: { state: boolean; setter: StateSetter<boolean> };
}

interface GetFieldSetPropsReturns {
	calculated: {
		isDynamicField: boolean;
		isOptionalDynamicField: boolean;
		isLastEntry: boolean;
		isOnlyEntry: boolean;
		isMaximumEntries: boolean;
		dynamicFieldLength: number;
		arrayIndex: number;
		isNestedFieldset: boolean;
		hasNoValues: boolean;
		hasEmptyValues: boolean;
		collapsed?: { state: boolean; setter: StateSetter<boolean> };
	};
	variant: "default" | "unstyled";
	mb: string;
	disabled: boolean;
	radius: string;
	styles: Record<string, any>;
	display: Record<string, any>;
}

interface FieldSetsProps {
	children: React.ReactNode;
	sectionProperties: ExtendedSectionProperties;
	formProperties: ExtendedFormProps;
	fieldsetProperties: GetFieldSetPropsReturns;
	arrayHelpers: ReturnType<typeof useFieldArray>;
}

interface NestedFieldRowsProps {
	sectionProperties: ExtendedSectionProperties;
	formProperties: ExtendedFormProps;
	utilities: Utilities;
	children: (
		fieldProperties: FieldComponent<any>,
		sectionId: string,
		key: string
	) => React.ReactNode;
	fieldProperties: FieldComponent<any>;
}

interface CropperProps {
	file: File;
	cropperRef: RefObject<ReactCropperElement> | RefObject<null>;
}

interface FileUploadProps {
	field: FieldComponent;
	onChange: any;
	cropperPopup: any;
}

interface FileUploadWithCropper extends FileUploadProps, CropperProps {
	storage: UseStorageReturns;
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

interface Utilities {
	storage: UseStorageReturns | undefined;
	cropperPopup: Readonly<UsePopupReturns>;
	cropperRef: Readonly<React.RefObject<ReactCropperElement | null>>;
	theme: Readonly<MantineTheme>;
	database: Readonly<UseDatabaseReturns>;
}

export default function Form({
	formFields,
	formInstance,
	commonFormDataMap,
	stepConfig,
	options,
}: FormProps) {
	const theme = useMantineTheme();
	const isStepForm = (stepConfig && typeof stepConfig === "object") || false;
	const storage = useStorage();
	const cropperPopup = usePopup();
	const cropperRef = useRef(null);
	const database = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);

	const utilities: Utilities = {
		storage,
		cropperPopup,
		cropperRef,
		theme,
		database,
	};
	const calculatedOptions = { ...options, isStepForm };
	const calculatedFormProps: ExtendedFormProps = {
		formFields,
		formInstance,
		stepConfig,
		commonFormDataMap,
		options: calculatedOptions as ExtendedFormPropsOptions,
	};

	// Watch only the specific fields inside universalValues
	if (commonFormDataMap) {
		const watchedValues = Object.values(commonFormDataMap)
			.flat()
			.map((path) => formInstance.watch(path));

		useEffect(() => {
			Object.entries(commonFormDataMap).forEach(([key, path]) => {
				formInstance.setValue(
					`commonFormDataValues.${key}`,
					getFromObjectByPath(formInstance.getValues(), path)
				); // Update values only when watched fields change
			});
		}, [...watchedValues]); // Effect triggers ONLY when these specific fields change
	}

	return formFields.map((sectionProperties, sectionIndex) => {
		if (stepConfig) {
			const groupFields = stepConfig.stepFields?.[sectionProperties.inputGroup];

			if (!groupFields || !groupFields.includes(sectionProperties.id)) {
				return null;
			}
		}

		const calculatedSectionId = `${sectionProperties.inputGroup}.${sectionProperties.id}`;
		return (
			<Section
				key={calculatedSectionId}
				sectionProperties={{
					...sectionProperties,
					sectionId: calculatedSectionId,
					sectionIndex: sectionIndex,
				}}
				formProperties={calculatedFormProps}
				utilities={utilities}
			>
				{(arrayHelpers, sectionIndex) => (
					<FieldRows
						arrayHelpers={arrayHelpers}
						sectionProperties={{
							...sectionProperties,
							sectionIndex,
							sectionId: `${sectionProperties.inputGroup}.${sectionProperties.id}[${sectionIndex}]`,
						}}
						formProperties={calculatedFormProps}
						utilities={utilities}
					>
						{(fieldProperties, sectionId, key) => (
							<FieldColumns
								key={key}
								formProperties={calculatedFormProps}
								fieldProperties={{ ...fieldProperties }}
								sectionProperties={{ ...sectionProperties, sectionId }}
								utilities={utilities}
							/>
						)}
					</FieldRows>
				)}
			</Section>
		);
	});
}

function getFieldSetProps({
	arrayHelpers,
	sectionProperties,
	options,
	theme,
	index,
	isNestedFieldset,
	collapsed,
}: GetFieldSetPropsProps): GetFieldSetPropsReturns {
	const isDynamicField: boolean =
		(sectionProperties.dynamicFieldCount ?? 0) > 1;
	const isOptionalDynamicField: boolean =
		isDynamicField && (sectionProperties?.optionalDynamicField ?? false);
	const dynamicFieldLength: number = !isNestedFieldset
		? arrayHelpers.fields.length
		: sectionProperties.dynamicFieldCount ?? 0;
	const isLastEntry: boolean = index === dynamicFieldLength - 1;
	const isMaximumEntries: boolean =
		arrayHelpers.fields.length === sectionProperties.dynamicFieldCount;
	const isOnlyEntry: boolean = arrayHelpers.fields.length <= 1;
	const hasNoValues: boolean = arrayHelpers.fields?.length <= 0;
	const hasEmptyValues: boolean = checkIsEmpty(
		arrayHelpers.fields.map(({ id, ...rest }) => rest)
	);

	const caluclatedMarginBottom = (function () {
		if (isDynamicField && !isOnlyEntry && !isLastEntry) {
			return "7px";
		} else if (isDynamicField && isLastEntry) {
			return "100px";
		} else {
			return "0px";
		}
	})();

	return {
		calculated: {
			isDynamicField,
			isOptionalDynamicField,
			isLastEntry,
			isOnlyEntry,
			isMaximumEntries,
			dynamicFieldLength,
			arrayIndex: index,
			isNestedFieldset,
			hasNoValues,
			hasEmptyValues,
			collapsed,
		},
		variant: isDynamicField && !isOnlyEntry ? "default" : "unstyled",
		mb: caluclatedMarginBottom,
		disabled: options?.isDisabled ?? false,
		radius: "sm",
		styles: {
			root: {
				columnGap: theme.spacing.sm,
				flexWrap: "wrap",
				display: options.isHorizontal ? "flex" : "inline",
				minWidth: "100%",
			},
			legend: {
				marginLeft: isDynamicField ? "-15px" : "unset",
			},
		},
		display: {
			base: "block",
			lg: options.isStepForm ? "block" : "flex",
		},
	};
}

function EmptyFieldset({
	sectionProperties,
	formProperties,
	fieldsetProperties,
	children,
}: FieldSetsProps) {
	const { calculated } = fieldsetProperties;
	const getMarginBottom = () => {
		if (
			calculated.isDynamicField &&
			!calculated.isOnlyEntry &&
			!calculated.isLastEntry
		) {
			return "7px";
		} else if (calculated.isDynamicField && calculated.isLastEntry) {
			return "100px";
		} else {
			return "50px";
		}
	};

	return (
		<Fieldset
			{...fieldsetProperties}
			mb={getMarginBottom()}
		>
			<GridCol
				style={{ alignContent: "center" }}
				span={{ base: 24, lg: 6 }}
				py="sm"
			>
				<FieldSetTitle
					label={sectionProperties.label}
					helpText={sectionProperties.helpText}
					justifyCenter={formProperties.options.isStepForm ?? false}
					isRequired={false}
				>
					{" "}
				</FieldSetTitle>
			</GridCol>
			<GridCol
				span={{ base: 24, lg: 17 }}
				py="sm"
			>
				<Flex
					rowGap="lg"
					columnGap="lg"
					wrap="wrap"
					align="stretch"
					justify="center"
					w="100%"
				>
					{children}
				</Flex>
			</GridCol>
		</Fieldset>
	);
}

function Section({
	children,
	formProperties,
	sectionProperties,
	utilities,
}: SectionProps) {
	const arrayHelpers = useFieldArray({
		control: formProperties.formInstance.control,
		name: sectionProperties.sectionId,
	}); // values, append, remove, etc

	const { calculated } = getFieldSetProps({
		arrayHelpers,
		sectionProperties,
		options: formProperties.options,
		theme: utilities.theme as MantineTheme,
		index: -1,
		isNestedFieldset: false,
	});

	const [collapseDown, setCollapseDown] = useState<boolean>(
		calculated.isDynamicField &&
			calculated.hasEmptyValues &&
			calculated.isOnlyEntry
	);

	if (collapseDown) {
		return (
			<EmptyFieldset
				sectionProperties={sectionProperties}
				formProperties={formProperties}
				arrayHelpers={arrayHelpers}
				fieldsetProperties={getFieldSetProps({
					arrayHelpers,
					sectionProperties,
					options: formProperties.options,
					theme: utilities.theme as MantineTheme,
					index: -1,
					isNestedFieldset: false,
					collapsed: { state: collapseDown, setter: setCollapseDown },
				})}
			>
				<Button
					variant="light"
					styles={{ label: { overflow: "inherit" } }}
					onClick={() => setCollapseDown(false)}
					type="button"
				>
					Add {sectionProperties.label}
				</Button>
			</EmptyFieldset>
		);
	}

	return arrayHelpers.fields.map((_, fieldsetIndex) => {
		return (
			<FieldSets
				key={`${sectionProperties.sectionId}.${fieldsetIndex}`}
				sectionProperties={sectionProperties}
				fieldsetProperties={getFieldSetProps({
					arrayHelpers,
					sectionProperties,
					options: formProperties.options,
					theme: utilities.theme as MantineTheme,
					index: fieldsetIndex,
					isNestedFieldset: false,
					collapsed: { state: collapseDown, setter: setCollapseDown },
				})}
				formProperties={formProperties}
				arrayHelpers={arrayHelpers}
			>
				{children(arrayHelpers, fieldsetIndex)}
			</FieldSets>
		);
	});
}

function FieldSets({
	children,
	sectionProperties,
	formProperties,
	fieldsetProperties,
	arrayHelpers,
}: FieldSetsProps) {
	const {
		isDynamicField,
		isOnlyEntry,
		dynamicFieldLength,
		arrayIndex,
		isMaximumEntries,
		isNestedFieldset,
		isLastEntry,
		isOptionalDynamicField,
		collapsed,
	} = fieldsetProperties.calculated;
	const hasRequiredField = sectionProperties.fieldComponents.some(
		(field: FieldComponent<any>) => field.validators?.required
	);

	const emptyValues = returnObjectWithEmptyValues({
		obj: arrayHelpers.fields.map(({ id, ...rest }) => rest)[0],
	});

	const getMarginBottom = () => {
		if (isDynamicField && !isOnlyEntry && !isLastEntry) {
			return "7px";
		} else if (isDynamicField && isLastEntry) {
			return "100px";
		} else {
			return "50px";
		}
	};

	return (
		<Fragment>
			<Fieldset
				{...fieldsetProperties}
				mb={getMarginBottom()}
			>
				<GridCol
					style={{ alignContent: "center" }}
					span={{ base: 24, lg: 6 }}
					py="sm"
				>
					<FieldSetTitle
						isRequired={hasRequiredField}
						label={sectionProperties.label}
						helpText={sectionProperties.helpText}
						justifyCenter={formProperties.options.isStepForm ?? false}
					>
						{isDynamicField && !isOnlyEntry && (
							<Badge
								autoContrast
								ml="xs"
								mt="-3px"
								variant="gradient"
								gradient={{
									to: "branding.7",
									from: "branding.3",
									deg: 140,
								}}
							>{`${arrayIndex + 1} of ${dynamicFieldLength}`}</Badge>
						)}
					</FieldSetTitle>
				</GridCol>
				<GridCol
					span={{ base: 24, lg: 14 }}
					py="sm"
				>
					<Flex
						rowGap="lg"
						columnGap="lg"
						wrap="wrap"
						align="stretch"
					>
						{children}
					</Flex>
				</GridCol>
				<GridCol
					span={{ base: 12, lg: 1 }}
					style={{
						display: "flex",
						alignItems: "center",
						justifyContent: "flex-end",
					}}
				>
					<ButtonGroup pt="lg">
						{isDynamicField && (
							<Tooltip
								label={
									isOnlyEntry
										? `Cannot remove only item as this section is required`
										: "Remove this item"
								}
								disabled={isOptionalDynamicField}
							>
								<Button
									styles={{ label: { overflow: "inherit" } }}
									onClick={() => {
										if (isOnlyEntry && isOptionalDynamicField) {
											arrayHelpers.update(0, emptyValues);
											return collapsed?.setter(true);
										}
										arrayHelpers.remove(arrayIndex);
									}}
									disabled={isOnlyEntry && !isOptionalDynamicField}
									type="button"
									variant="light"
								>
									<IconTrash
										stroke={2}
										size="1.3em"
									/>
								</Button>
							</Tooltip>
						)}
						{isDynamicField && (
							<Tooltip
								label={
									isMaximumEntries
										? `Maximum of ${sectionProperties.dynamicFieldCount} Entries Reached`
										: "Add Another"
								}
							>
								<Button
									styles={{ label: { overflow: "inherit" } }}
									onClick={() =>
										arrayHelpers.insert(arrayIndex + 1, emptyValues)
									}
									disabled={isMaximumEntries}
									type="button"
								>
									<IconPlus
										stroke={2}
										size="1.3rem"
									/>
								</Button>
							</Tooltip>
						)}
					</ButtonGroup>
				</GridCol>
			</Fieldset>
			{!isNestedFieldset && dynamicFieldLength > 1 && isLastEntry === false && (
				<IconArrowWaveRightDown
					stroke={1}
					size="3rem"
					color="#ced4db"
					style={{
						transform: "rotate(50deg)",
						marginTop: "-100%",
						top: "13.5px",
						left: "47%",
						position: "relative",
					}}
				/>
			)}
		</Fragment>
	);
}

function FieldSetTitle({
	isRequired,
	label,
	helpText,
	justifyCenter,
	children,
}: {
	isRequired: boolean;
	label: string;
	helpText: string;
	justifyCenter: boolean;
	children: React.ReactNode;
}) {
	return (
		<Fragment>
			<InputLabel
				style={{
					display: "flex",
					alignItems: "center",
					justifyContent: justifyCenter ? "center" : undefined,
				}}
				required={isRequired}
			>
				{label ?? undefined}
				{children}
			</InputLabel>
			<InputDescription
				style={{ textAlign: justifyCenter ? "center" : "unset" }}
			>
				{helpText ?? undefined}
			</InputDescription>
		</Fragment>
	);
}

function FieldRows({
	arrayHelpers,
	children,
	sectionProperties,
	formProperties,
	utilities,
}: FieldRowsProps) {
	const fields =
		(sectionProperties.sectionIndex !== undefined
			? arrayHelpers.fields[sectionProperties.sectionIndex]
			: {}) || {};

	return Object.keys(fields).map((fieldKey, columnIndex) => {
		if (fieldKey === "id") return null;

		const valueFromArrayHelpers =
			sectionProperties.sectionIndex !== undefined
				? arrayHelpers.fields[sectionProperties.sectionIndex][fieldKey]
				: undefined;

		if (
			Array.isArray(valueFromArrayHelpers) &&
			valueFromArrayHelpers.some((item) => typeof item === "object")
		) {
			const field = sectionProperties.fieldComponents[columnIndex];
			if (!field || !field.fieldComponents) return null;

			const { fieldComponents, ...nestedFieldSectionProps } = field;
			return (
				<NestedFieldRows
					key={`nestedRow-${sectionProperties.sectionId}.${sectionProperties.sectionIndex}[${columnIndex}]`}
					sectionProperties={{
						...sectionProperties,
						...nestedFieldSectionProps,
						fieldComponents: fieldComponents,
						sectionId: `${sectionProperties.sectionId}.${fieldKey}`,
						sectionIndex: columnIndex,
					}}
					formProperties={formProperties}
					utilities={utilities}
					fieldProperties={field}
				>
					{(field, sectionId, nestedColumnIndex) => {
						const key = `unknownchild-${nestedColumnIndex}`;

						return children(field, sectionId, key);
					}}
				</NestedFieldRows>
			);
		}
		const field = sectionProperties.fieldComponents[columnIndex];
		if (!field) return null;

		const key = `${sectionProperties.sectionId}.${columnIndex}.${fieldKey}`;

		return children(field, sectionProperties.sectionId, key); // Ensure children is called with columnIndex
	});
}

function NestedFieldRows({
	sectionProperties,
	formProperties,
	utilities,
	children,
	fieldProperties,
}: NestedFieldRowsProps) {
	const arrayHelpers = useFieldArray({
		control: formProperties.formInstance.control,
		name: sectionProperties.sectionId,
	});

	return (
		<FieldSets
			sectionProperties={{
				...sectionProperties,
				...fieldProperties,
			}}
			fieldsetProperties={getFieldSetProps({
				arrayHelpers,
				sectionProperties,
				options: { ...formProperties.options, isHorizontal: false },
				theme: utilities.theme as MantineTheme,
				index: arrayHelpers.fields.length - 1,
				isNestedFieldset: true,
			})}
			formProperties={formProperties}
			arrayHelpers={arrayHelpers}
		>
			{arrayHelpers.fields.map((_, nestedIndex) => {
				const nestedSectionId = `${sectionProperties.sectionId}[${nestedIndex}]`;
				const calculatedSectionProperties = {
					...sectionProperties,
					sectionIndex: nestedIndex,
					sectionId: nestedSectionId,
				};

				return (
					<Fieldset
						key={`nestedFieldset_${sectionProperties.sectionId}.${nestedIndex}`}
						variant="filled"
						flex={{
							md: `0 0 ${
								arrayHelpers.fields.length === 1
									? "100%"
									: fieldProperties.attributes?.width
									? fieldProperties.attributes?.width
									: "48%"
							}`,
							base: `0 0 100%`,
						}}
					>
						<FieldRows
							arrayHelpers={arrayHelpers}
							sectionProperties={calculatedSectionProperties}
							formProperties={formProperties}
							utilities={utilities}
						>
							{(field, sectionId, columnIndex) => {
								return children(field, nestedSectionId, columnIndex);
							}}
						</FieldRows>
					</Fieldset>
				);
			})}
		</FieldSets>
	);
}

function staticFieldProps({
	fieldProperties,
}: {
	fieldProperties: FieldComponent<any>;
}) {
	function generateRightSection() {
		if (fieldProperties.append) {
			return (
				<Badge
					mr="xs"
					variant="light"
				>
					{fieldProperties.append}
				</Badge>
			);
		}
	}

	return {
		name: fieldProperties.id,
		// labelPosition: "left",
		size: fieldProperties.attributes?.size ?? "sm",
		rightSection: generateRightSection(),
		rightSectionWidth: fieldProperties.append ? "auto" : undefined,
		styles: {
			root: {
				minWidth: "100%", // Sets all fields to take the maximum amount of width available
				justifyContent: "space-around", // Ensure all fields are aligned especially ratings
				alignItems: "center", // Ensure all fields are aligned especially ratings
			},
		},
	};
}

function calculatedValidationRules({
	fieldProperties,
}: {
	fieldProperties: FieldComponent<any>;
}): {
	rules: RegisterOptions;
	props: Record<string, any>;
} {
	const validators = fieldProperties.validators as Record<string, any>; // Type assertion here
	const validationRules: Partial<RegisterOptions> = {};
	const props: Record<string, any> = {};

	if (!validators) {
		return { rules: validationRules, props };
	}

	Object.keys(validators).forEach((rule) => {
		const validatorKey = rule as keyof typeof validators; // Type assertion for validatorKey
		const validatorValue = validators[validatorKey];

		if (validatorKey === "accept") {
			const acceptTypeKey = validatorValue as keyof typeof fileTypeMap;
			return (props.accept = fileTypeMap[acceptTypeKey]);
		}

		if (validatorKey === "pattern") {
			const patternKey = validatorValue as keyof typeof patternMap;
			const pattern = patternMap[patternKey];

			if (pattern) {
				return (validationRules.pattern = {
					value: pattern.regex,
					message: pattern.defaultMessage ?? errorTextMap.pattern,
				});
			}
		}

		return (validationRules[validatorKey as keyof RegisterOptions] = {
			value: validatorValue,
			message: errorTextMap[validatorKey as keyof typeof errorTextMap],
		});
	});

	return { rules: validationRules, props };
}

function generateLiveHelpText({
	value,
	validation,
	fieldProperties,
}: {
	value: string | number;
	validation: { rules: RegisterOptions };
	fieldProperties: FieldComponent<any>;
}) {
	const cleanStrippedValue = stripHTML(value as string);

	if (validation.rules.maxLength) {
		if (
			fieldProperties.validators?.maxLength &&
			typeof cleanStrippedValue === "string" &&
			cleanStrippedValue.length > fieldProperties.validators.maxLength
		) {
			return `Too many characters used. Maximum ${fieldProperties.validators?.maxLength}.`;
		} else if (typeof cleanStrippedValue === "string") {
			return `${cleanStrippedValue.length} of ${fieldProperties.validators?.maxLength} characters used.`;
		}
	}

	if (validation.rules.minLength) {
		if (
			fieldProperties.validators?.minLength &&
			typeof cleanStrippedValue === "string" &&
			cleanStrippedValue.length < fieldProperties.validators.minLength
		) {
			return `Enter ${
				fieldProperties.validators?.minLength - cleanStrippedValue.length
			} more characters.`;
		}
	}

	if (validation.rules.min && validation.rules.max) {
		return `Between ${fieldProperties.validators?.min} and ${fieldProperties.validators?.max} allowed.`;
	}

	if (validation.rules.min) {
		return `Minimum ${fieldProperties.validators?.min}`;
	}

	if (validation.rules.max) {
		return `Maximum ${fieldProperties.validators?.max}`;
	}
}

async function handleFileUpload({
	file,
	field,
	onChange,
	cropperPopup,
	cropperRef,
	storage,
}: FileUploadWithCropper) {
	if (field.component === "upload" && field.attributes?.forceCrop) {
		cropperPopup.setModalConfig({
			opened: true,
			title: "Crop your Image",
			body: (
				<Cropper
					src={URL.createObjectURL(file)}
					ref={cropperRef as React.RefObject<ReactCropperElement>}
					className="cropper"
					aspectRatio={41 / 32}
					style={{ height: "75vh", width: "100%" }}
					viewMode={2}
					movable={false}
					rotatable={false}
					scalable
					zoomable={false}
					autoCropArea={1}
				/>
			),
			submit: "Confirm",
			onSubmit: async () => {
				const croppedFile = await getCroppedFile({
					file,
					cropperRef,
				});
				await storage?.upload({ file: croppedFile, onChange });
			},
			forceAction: true,
		});
	} else {
		await storage?.upload({ file, onChange });
	}
}

function handleChange(
	{
		e,
		fieldProperties,
	}: {
		e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>;
		fieldProperties: FieldComponent;
	},
	callbackFn: (e: any) => void
) {
	if (!e.currentTarget) {
		return callbackFn(e);
	}

	const { value } = e.currentTarget;
	const maxLength = fieldProperties.validators?.maxLength;
	const newValue =
		maxLength && sanitiseHtml(value).length > maxLength
			? sanitiseHtml(value).slice(0, maxLength)
			: sanitiseHtml(value);

	e.currentTarget.value = newValue;
	callbackFn({
		...e,
		currentTarget: { ...e.currentTarget, value: newValue },
	});
}

async function getCroppedFile({
	file,
	cropperRef,
}: CropperProps): Promise<File> {
	const cropper = cropperRef.current?.cropper;

	const blob: Blob = await new Promise((resolve, reject) => {
		cropper?.getCroppedCanvas().toBlob((blob) => {
			blob
				? resolve(blob)
				: reject(new Error("Failed to create blob from cropped image."));
		}, file.type);
	});

	return new File([blob], file.name, {
		type: file.type || "image/jpeg",
		lastModified: file.lastModified,
	});
}

const FieldColumns = memo(function FieldColumns({
	formProperties,
	fieldProperties,
	sectionProperties,
	utilities,
}: {
	formProperties: ExtendedFormProps;
	fieldProperties: FieldComponent<any>;
	sectionProperties: ExtendedSectionProperties;
	utilities: Utilities;
}) {
	const validation = useMemo(
		() => calculatedValidationRules({ fieldProperties }),
		[fieldProperties]
	);

	const componentKeyFromComponent =
		fieldProperties.component as keyof typeof components;
	const Component = components[componentKeyFromComponent] ?? components.text;
	const fieldName = `${sectionProperties.sectionId}.${
		fieldProperties.id ?? "value"
	}`;
	const isDateField = useMemo(
		() =>
			fieldProperties.component === "datetime" ||
			fieldProperties.component === "time" ||
			fieldProperties.component === "date",
		[fieldProperties.component]
	);

	const flex = useMatches({
		base: "100%",
		md: `1 1 calc(${fieldProperties.attributes?.width ?? "50%"} - ${
			utilities?.theme?.spacing.lg
		})`,
	});
	return (
		<div
			style={{
				display: fieldProperties.attributes?.hidden ? "none" : "flex",
				justifyContent: "center",
				flex,
				alignItems: "stretch",
				backgroundColor:
					fieldProperties.attributes?.size === "sm" ? "red" : undefined,
			}}
		>
			<Controller
				control={formProperties.formInstance.control}
				rules={validation.rules}
				name={fieldName}
				render={({
					field: { onChange, onBlur, value },
					fieldState: { error },
				}) => {
					const cleanValue = sanitiseHtml(value);
					if (value?.length > 0 && isDateField) {
						value = new Date(value);
					}

					return (
						<Component
							value={isDateField ? value : cleanValue}
							onBlur={onBlur}
							error={error?.message}
							{...staticFieldProps({ fieldProperties })}
							dbqueryparams={{
								dbQueryParams: fieldProperties?.dbQueryParams,
								sectionProperties: sectionProperties,
								formInstance: formProperties.formInstance,
								fieldName: fieldName,
								sectionName: sectionProperties.sectionId,
							}}
							source={fieldProperties?.source}
							size="md"
							autosize="true"
							{...fieldProperties?.attributes}
							{...validation.props}
							selected={typeof cleanValue === "boolean" && cleanValue === true}
							checked={typeof cleanValue === "boolean" && cleanValue === true}
							validators={fieldProperties.validators}
							brand={formProperties.options.brand}
							design="default" // TODO: DYNAMICALLY SET WEBSITE TEMPLATE
							description={generateLiveHelpText({
								value: cleanValue,
								validation,
								fieldProperties,
							})}
							data={fieldProperties.attributes?.options ?? null} // Select Box Options
							onChange={async (e) => {
								if (fieldProperties.component === "upload") {
									const target = e as File;
									if (utilities.storage) {
										return await handleFileUpload({
											file: target,
											field: fieldProperties,
											onChange,
											cropperPopup: utilities.cropperPopup,
											cropperRef: utilities.cropperRef,
											storage: utilities.storage,
										});
									}
								} else {
									const target = e as ChangeEvent<
										HTMLInputElement | HTMLTextAreaElement
									>;
									return handleChange({ e: target, fieldProperties }, onChange);
								}
							}}
						/>
					);
				}}
			/>
			{utilities.storage?.ConfirmOverwriteModal && (
				<utilities.storage.ConfirmOverwriteModal />
			)}
			<utilities.cropperPopup.Element />
		</div>
	);
});
