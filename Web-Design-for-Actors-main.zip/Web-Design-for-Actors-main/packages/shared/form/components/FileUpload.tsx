// React Imports
import React, { Fragment, useState } from "react";

import {
	ActionIcon,
	Box,
	FileInputProps,
	Flex,
	Group,
	InputWrapper,
	Text,
} from "@mantine/core";
import { Dropzone } from "@mantine/dropzone";

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import { IconPhoto, IconUpload, IconX } from "@tabler/icons-react";
import FilePreview from "../../../../apps/web-design-for/src/app/dashboard/_components/FilePreview";
// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

interface FileUploadProps extends FileInputProps {
	dbqueryparams: any;
	value: any;
	attributes: any;
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function FileUpload(props: FileUploadProps) {
	const { value, onChange, onBlur, placeholder } = props;
	const [isLoading, setIsLoading] = useState(false);

	return (
		<InputWrapper
			label={props.label}
			description={props.description}
			error={props.error}
			required={props.required}
			w="100%"
			inputContainer={(children) => {
				return (
					<Box pos="relative">
						{value && !isLoading && (
							<ActionIcon
								color="dark"
								variant="subtle"
								pos="absolute"
								top={3}
								right={3}
								style={{ zIndex: 1 }}
								size="lg"
								onClick={() => {
									props.dbqueryparams?.formInstance?.setValue(
										props.dbqueryparams?.fieldName,
										null,
										{ shouldValidate: true }
									);
								}}
							>
								<IconX />
							</ActionIcon>
						)}

						{children}
					</Box>
				);
			}}
		>
			<Dropzone
				onDrop={(files) => {
					setIsLoading(true);
					onChange &&
						(onChange(files[0]) as unknown as Promise<any>).then(() =>
							setIsLoading(false)
						);
				}}
				onReject={(files) => console.log("rejected files", files)}
				maxSize={5 * 1024 ** 2}
				maxFiles={props?.attributes?.maxFiles ?? 1}
				multiple={
					(props?.attributes?.maxFiles && props?.attributes?.maxFiles > 1) ??
					false
				}
				accept={props.accept?.split(",")}
				loading={isLoading}
				name={props.name}
				styles={{ inner: { height: "100%" }, root: { width: "100%" } }}
				onBlur={(e) =>
					onBlur?.(e as unknown as React.FocusEvent<HTMLButtonElement>)
				}
			>
				<Group
					justify="center"
					gap="xl"
					mih={220}
					style={{ pointerEvents: "none" }}
					h="100%"
				>
					<Dropzone.Accept>
						<IconUpload
							size={52}
							color="var(--mantine-color-blue-6)"
							stroke={1.5}
						/>
					</Dropzone.Accept>
					<Dropzone.Reject>
						<IconX
							size={52}
							color="var(--mantine-color-red-6)"
							stroke={1.5}
						/>
					</Dropzone.Reject>
					{!value && (
						<Fragment>
							<Dropzone.Idle>
								<IconPhoto
									size={52}
									color="var(--mantine-color-dimmed)"
									stroke={1.5}
								/>
							</Dropzone.Idle>
							<div>
								<Text
									size="xl"
									inline
								>
									{placeholder
										? placeholder
										: "Drag files here or click to select files"}
								</Text>
								<Text
									size="sm"
									c="dimmed"
									inline
									mt={7}
								>
									Drag files here or click to select files. Each file should not
									exceed 5Mb.
								</Text>
							</div>{" "}
						</Fragment>
					)}

					{value && value !== null && (
						<Flex
							h="100%"
							direction="column"
							align="center"
						>
							<Text
								size="md"
								inline
								c="gray"
								p="md"
							>
								Drag files here or click to select files.
							</Text>
							<Group
								justify="center"
								align="flex-end"
								styles={{ root: { alignContent: "flex-end" } }}
								h="100%"
								display="flex"
							>
								<div>
									<FilePreview
										fileUrl={value.downloadUrl}
										props={{ height: "50%", width: "50%" }}
									/>
								</div>
								<div>{value.name && <Text>{value.name}</Text>}</div>
							</Group>
						</Flex>
					)}
				</Group>
			</Dropzone>
		</InputWrapper>
	);
}
