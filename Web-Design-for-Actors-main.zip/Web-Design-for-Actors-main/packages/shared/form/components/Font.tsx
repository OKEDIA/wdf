import { Group, Select, SelectProps, Text } from "@mantine/core";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { useDatabase } from "../../hooks";
import { FontsResponse } from "../../types/websiteTypes";

interface SelectInputProps extends SelectProps {}

export function Font(props: SelectInputProps) {
	const { value, onChange, onBlur } = props;
	const fontsPerPage = 10;
	const db = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);
	const [fonts, setFonts] = useState<FontsResponse["items"]>([]);
	const [count, setCount] = useState(fontsPerPage);
	const [searchValue, setSearchValue] = useState("");
	const viewport = useRef<HTMLDivElement>(null);
	const addedFontsRef = useRef<Set<string>>(new Set());
	const [scrollPosition, onScrollPositionChange] = useState({ x: 0, y: 0 });

	// Fetch fonts from the database
	useEffect(() => {
		db.get<FontsResponse>("/fonts").then((res) => {
			setFonts(res?.items || []);
			if (value) {
				setSearchValue(value);
				const selectedFont = res?.items?.find(
					(font) => encodeURIComponent(font.family) === value
				);
				if (selectedFont && !addedFontsRef.current.has(selectedFont.family)) {
					downloadFonts([selectedFont]);
				}
			}
		});
	}, [value]);

	// Download fonts dynamically
	const downloadFonts = (fontList: FontsResponse["items"]) => {
		fontList?.forEach((font) => {
			if (!addedFontsRef.current.has(font.family)) {
				const style = document.createElement("style");
				style.innerHTML = `
					@font-face {
						font-family: '${font.family}';
						src: url(${font.menu});
					}
				`;
				document.head.appendChild(style);
				addedFontsRef.current.add(font.family);
			}
		});
	};

	// Filter and slice fonts based on search and count
	const filteredFonts = useMemo(() => {
		const filtered = searchValue
			? fonts?.filter((font) =>
					font.family.toLowerCase().includes(searchValue.toLowerCase())
			  )
			: fonts;
		return filtered?.slice(0, count);
	}, [fonts, searchValue, count]);

	// Download fonts in the current view
	useEffect(() => {
		downloadFonts(filteredFonts);
	}, [filteredFonts]);

	// Handle infinite scroll
	useEffect(() => {
		const isNearBottom =
			scrollPosition.y + (viewport.current?.clientHeight ?? 0) >=
			(viewport.current?.scrollHeight ?? 0) - 50;

		if (isNearBottom) {
			setCount((prevLimit) => prevLimit + fontsPerPage);
		}
	}, [scrollPosition]);

	// Map fonts to dropdown options
	const fontOptions = useMemo(
		() =>
			filteredFonts?.map((font) => ({
				value: encodeURIComponent(font.family),
				label: font.family,
			})),
		[filteredFonts]
	);

	// Custom component to preview the font
	const renderSelectOption: SelectProps["renderOption"] = ({ option }) => (
		<Group
			flex="1"
			gap="xs"
		>
			<Text
				styles={{
					root: {
						fontFamily:
							fonts?.find((font) => font.family === option.label)?.family ||
							"inherit",
					},
				}}
			>
				{option.label}
			</Text>
		</Group>
	);

	return (
		<Select
			{...props}
			value={value}
			onChange={onChange}
			onBlur={onBlur}
			data={fontOptions}
			renderOption={renderSelectOption}
			searchable
			searchValue={searchValue}
			onSearchChange={setSearchValue}
			scrollAreaProps={{
				viewportRef: viewport,
				onScrollPositionChange: onScrollPositionChange,
			}}
			placeholder={props.placeholder}
		/>
	);
}
