"use client";

// React Imports
import React, { ChangeEventHandler, useState } from "react";

// Next.js Imports

// Lower Order Components
import OfficePaste from "@intevation/tiptap-extension-office-paste";
import CharacterCount from "@tiptap/extension-character-count";
import Placeholder from "@tiptap/extension-placeholder";
import TextAlign from "@tiptap/extension-text-align";
import Underline from "@tiptap/extension-underline";
import Youtube from "@tiptap/extension-youtube";
import StarterKit from "@tiptap/starter-kit";

// UI Components & Icons
import {
	Button,
	Flex,
	Input,
	LoadingOverlay,
	NumberInput,
	Popover,
	Switch,
	TextInput,
	TextInputProps,
} from "@mantine/core";
import { IconBrandYoutube } from "@tabler/icons-react";

// Context & Helpers

// Other libraries or utilities
import {
	Link,
	RichTextEditor,
	useRichTextEditorContext,
} from "@mantine/tiptap";
import { useEditor } from "@tiptap/react";

// Types
import { sanitiseHtml } from "@okedia/shared/helpers/string/sanitise/client";
import { UseFormReturn } from "react-hook-form";
import { FormValues } from "../../types/formTypes";
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
interface RichTextEditorProps extends Omit<TextInputProps, "dbqueryparams"> {
	value: string;
	onChange: ChangeEventHandler<HTMLInputElement>;
	onBlur: (event: React.FocusEvent) => void;
	validators?: { maxLength?: number; required?: boolean };
	error?: string;
	label?: string;
	description?: string;
	width?: string;
	dbqueryparams: {
		dbQueryParams: UseFormReturn<FormValues>;
		formInstance: any;
		sectionProperties: any;
		fieldName: string;
		denormalize: boolean;
	};
}
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
export default function TextEditor(props: RichTextEditorProps) {
	const {
		value,
		onChange,
		onBlur,
		validators,
		label,
		error,
		description,
		width,
	} = props;
	const [loading, setLoading] = useState(true);

	const ExtendedYoutube = Youtube.extend({
		addOptions() {
			return {
				...this.parent?.(),
				draggable: false,
			};
		},
		addAttributes() {
			return {
				...this.parent?.(),
				draggable: {
					default: false,
					renderHTML: () => ({ draggable: "false" }),
				},
				width: {
					renderHTML: (attributes) => ({
						width: attributes.width || this.options.width,
					}),
				},

				height: {
					renderHTML: (attributes) => ({
						height: attributes.height || this.options.height,
					}),
				},

				loop: {
					parseHTML: (element) =>
						element.getAttribute("loop") || this.options.loop, // adds to attributes (makes available for url)
					renderHTML: (attributes) => ({
						// adds to iframe code
						loop: attributes.loop,
					}),
				},

				allowFullscreen: {
					parseHTML: (element) =>
						element.hasAttribute("allowfullscreen") ||
						this.options.allowFullscreen,
				},

				autoplay: {
					parseHTML: (element) =>
						element.getAttribute("autoplay") === "1" || this.options.autoplay,
				},

				controls: {
					parseHTML: (element) =>
						element.getAttribute("controls") !== "0" || this.options.controls,
				},

				disableKbControls: {
					parseHTML: (element) =>
						element.getAttribute("disablekb") === "1" ||
						this.options.disableKBcontrols,
				},

				modestBranding: {
					parseHTML: (element) =>
						element.getAttribute("modestbranding") === "1" ||
						this.options.modestBranding,
				},

				rel: {
					parseHTML: (element) =>
						element.getAttribute("rel") || this.options.rel,
				},

				nocookie: {
					parseHTML: (element) =>
						element.getAttribute("nocookie") === "true" ||
						this.options.nocookie,
				},

				start: {
					parseHTML: (element) =>
						parseInt(element.getAttribute("start") ?? "0"),
				},

				end: {
					parseHTML: (element) => parseInt(element.getAttribute("end") ?? "0"),
				},
				src: {
					parseHTML: (element) => element.getAttribute("src"),
					renderHTML: (attributes) => {
						if (!attributes.src) return {};

						let url = new URL(attributes.src);
						let params = url.searchParams;

						let videoId = null;

						// Try to extract video ID safely
						const match = attributes.src.match(
							/(?:youtube\.com\/(?:[^/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/ ]{11})/
						);

						if (match && match[1]) {
							videoId = match[1];
							url = new URL(
								`https://${
									attributes.nocookie
										? "www.youtube-nocookie.com"
										: "www.youtube.com"
								}/embed/${videoId}`
							);
						} else if (url.pathname.startsWith("/embed/")) {
							// Already in embed format – try to extract ID
							videoId = url.pathname.split("/embed/")[1]?.split("/")[0] ?? null;
						}

						// Always safe to continue now, even without a valid video ID
						if (attributes.start)
							params.set("start", attributes.start.toString());
						if (attributes.end) params.set("end", attributes.end.toString());
						if (attributes.autoplay) params.set("autoplay", "1");
						if (!attributes.controls) params.set("controls", "0");
						if (attributes.disableKbControls) params.set("disablekb", "1");
						if (attributes.modestBranding) params.set("modestbranding", "1");
						if (!attributes.allowFullscreen) params.set("fs", "0");
						if (attributes.listType)
							params.set("listType", attributes.listType);
						if (attributes.list) params.set("list", attributes.list);
						if (attributes.loop) params.set("loop", "1");

						// Ensure playlist param if looping but no explicit playlist
						if (attributes.loop && !attributes.playlist && videoId) {
							params.set("playlist", videoId);
						} else if (attributes.playlist) {
							params.set("playlist", attributes.playlist);
						}

						if (attributes.rel != null) {
							params.set("rel", attributes.rel.toString());
						}

						url.search = params.toString();

						return { src: url.toString() };
					},
				},
			};
		},
	});

	const editor = useEditor({
		shouldRerenderOnTransaction: false,
		immediatelyRender: false,
		extensions: [
			StarterKit.configure({
				codeBlock: false, // Disable code blocks
			}),
			Underline,
			Link,
			TextAlign.configure({ types: ["heading", "paragraph"] }),
			Placeholder.configure({
				placeholder: props?.placeholder ?? "Write something …",
			}),
			ExtendedYoutube.configure({
				controls: false,
				addPasteHandler: true,
				allowFullscreen: true,
				disableKBcontrols: false,
				enableIFrameApi: false,
				ivLoadPolicy: 0, // Disable annotations
				modestBranding: true, // Youtube decipricated
				nocookie: true,
				rel: 0, // Youtube decipricated but this will ensure only current publishers' videos are shown at
			}),
			CharacterCount.configure({ limit: validators?.maxLength ?? Infinity }),
			OfficePaste,
		],
		content: sanitiseHtml(value),
		onUpdate: ({ editor }) => {
			const event = {
				target: { value: editor.getHTML() },
			} as any;
			return onChange(event);
		},
		onBlur: ({ editor, event }) => {
			if (editor.isEmpty) {
				return props.dbqueryparams.formInstance.control.setError?.(
					props.dbqueryparams.fieldName,
					{
						type: "required",
						message: "Please complete this information; it is required.",
					}
				);
			}

			onBlur(event as unknown as React.FocusEvent);
		},
		onCreate: ({ editor }) => {
			setLoading(false);
		},
	});

	function YoutubeVideoControl() {
		const { editor } = useRichTextEditorContext();
		const [opened, setOpened] = useState(false);

		// Single state object for all options
		const [videoOptions, setVideoOptions] = useState({
			src: "",
			width: 640,
			height: 480,
			allowFullscreen: false,
			autoplay: false,
			controls: true,
			disableKBcontrols: false,
			loop: false,
			modestBranding: true,
			rel: 0,
			nocookie: true,
			start: 0,
			end: 0,
		});

		// Generic handler for input changes
		const handleChange = (key: string, value: any) => {
			setVideoOptions((prev) => ({ ...prev, [key]: value }));
		};

		const handleInsertVideo = () => {
			if (!videoOptions.src) return;

			console.log("Editor commands:", editor?.commands); // Log available commands

			// Ensure the setYoutubeVideo command is available
			const res = editor?.chain().focus().setYoutubeVideo(videoOptions).run();
			console.log(res);

			// Log the editor's content after insert
			console.log("Editor content after insert:", editor?.getHTML());

			setOpened(false);
		};

		return (
			<Popover
				opened={opened}
				onChange={setOpened}
				position="bottom"
				withArrow
				width={500}
			>
				<Popover.Target>
					<RichTextEditor.Control
						onClick={() => setOpened((o) => !o)}
						aria-label="Insert/Edit Youtube Video"
						title="Insert/Edit Youtube Video"
					>
						<IconBrandYoutube
							stroke={1.5}
							size={16}
						/>
					</RichTextEditor.Control>
				</Popover.Target>
				<Popover.Dropdown>
					<Flex
						wrap="wrap"
						gap="md"
					>
						<TextInput
							label="YouTube URL"
							placeholder="https://www.youtube.com/watch?v=..."
							value={videoOptions.src}
							onChange={(event) =>
								handleChange("src", event.currentTarget.value)
							}
							flex="1 1 calc(100% - 1rem)"
						/>
						<NumberInput
							label="Width"
							value={videoOptions.width}
							onChange={(value) => handleChange("width", value)}
							flex="1 1 calc(50% - 1rem)"
						/>
						<NumberInput
							label="Height"
							value={videoOptions.height}
							onChange={(value) => handleChange("height", value || 480)}
							flex="1 1 calc(50% - 1rem)"
						/>
						<NumberInput
							label="Start Time (s)"
							value={videoOptions.start}
							onChange={(value) => handleChange("start", value || 0)}
							flex="1 1 calc(50% - 1rem)"
						/>
						<NumberInput
							label="End Time (s)"
							value={videoOptions.end}
							onChange={(value) => handleChange("end", value || 0)}
							flex="1 1 calc(50% - 1rem)"
						/>
						<Switch
							label="Allow Fullscreen"
							checked={videoOptions.allowFullscreen}
							onChange={(event) =>
								handleChange("allowFullscreen", event.currentTarget.checked)
							}
							flex="1 1 calc(50% - 1rem)"
						/>
						<Switch
							label="Autoplay"
							checked={videoOptions.autoplay}
							onChange={(event) =>
								handleChange("autoplay", event.currentTarget.checked)
							}
							flex="1 1 calc(50% - 1rem)"
						/>
						<Switch
							label="Show Controls"
							checked={videoOptions.controls}
							onChange={(event) =>
								handleChange("controls", event.currentTarget.checked)
							}
							flex="1 1 calc(50% - 1rem)"
						/>

						<Switch
							label="Loop"
							checked={videoOptions.loop}
							onChange={(event) =>
								handleChange("loop", event.currentTarget.checked)
							}
							flex="1 1 calc(50% - 1rem)"
						/>
					</Flex>
					<Button
						fullWidth
						onClick={handleInsertVideo}
						mt="md"
					>
						Insert Video
					</Button>
				</Popover.Dropdown>
			</Popover>
		);
	}
	const renderEditor = React.useCallback(() => {
		return (
			<Input.Wrapper
				label={label}
				error={error}
				description={description}
				required={validators?.required}
				w={width || "100%"}
			>
				<RichTextEditor
					editor={editor}
					variant="subtle"
					w="100%"
					styles={{
						toolbar: { justifyContent: "center" },
						root: {
							...(props.error
								? {
										borderColor: "var(--mantine-color-error)",
										color: "var(--mantine-color-branding-5)",
								  }
								: editor?.isFocused
								? { borderColor: "var(--mantine-color-branding-5)" }
								: {}),
						},
					}}
				>
					<RichTextEditor.Toolbar
						sticky
						stickyOffset={100}
					>
						<RichTextEditor.ControlsGroup>
							<RichTextEditor.H1 />
							<RichTextEditor.H2 />
							<RichTextEditor.H3 />
							<RichTextEditor.H4 />
						</RichTextEditor.ControlsGroup>

						<RichTextEditor.ControlsGroup>
							<RichTextEditor.Bold />
							<RichTextEditor.Italic />
							<RichTextEditor.Underline />
							<RichTextEditor.ClearFormatting />
						</RichTextEditor.ControlsGroup>
						<RichTextEditor.ControlsGroup>
							<RichTextEditor.AlignLeft />
							<RichTextEditor.AlignCenter />
							<RichTextEditor.AlignRight />
							<RichTextEditor.AlignJustify />
						</RichTextEditor.ControlsGroup>
						<RichTextEditor.ControlsGroup>
							<RichTextEditor.Blockquote />
							<RichTextEditor.BulletList />
							<RichTextEditor.OrderedList />
						</RichTextEditor.ControlsGroup>

						<RichTextEditor.ControlsGroup>
							<YoutubeVideoControl />
							<RichTextEditor.Link />
							<RichTextEditor.Unlink />
						</RichTextEditor.ControlsGroup>

						<RichTextEditor.ControlsGroup>
							<RichTextEditor.Undo />
							<RichTextEditor.Redo />
						</RichTextEditor.ControlsGroup>
					</RichTextEditor.Toolbar>{" "}
					<LoadingOverlay visible={loading} />
					<RichTextEditor.Content />
				</RichTextEditor>
			</Input.Wrapper>
		);
	}, [loading, error]);

	return renderEditor();
}
