// React Imports
import React, { useEffect, useState } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { TextInput, TextInputProps } from "@mantine/core";

// Context & Helpers
import { useWatch } from "react-hook-form";

// Other libraries or utilities
import { useDebouncedValue } from "@mantine/hooks";
import { UseFormReturn } from "react-hook-form";
import { getFromObjectByPath } from "../../helpers";
import { convertStringToSlug } from "../../helpers/string";
import { FormValues } from "../../types/formTypes";

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
interface SlugInputProps extends Omit<TextInputProps, "dbqueryparams"> {
	dbqueryparams: {
		dbqueryparams: Record<string, any>;
		formInstance: UseFormReturn<FormValues, any, undefined>;
		sectionProperties: any;
		fieldName: string;
		sectionName: string;
	};
}
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export function Slug(props: SlugInputProps) {
	const fieldName = `${props.dbqueryparams.sectionName}.name`;
	const fieldValue = props.dbqueryparams.formInstance.watch(fieldName);
	const sectionName = `${props.dbqueryparams.sectionProperties.inputGroup}.${props.dbqueryparams.sectionProperties.id}`;

	const { value, onChange } = props;
	const [_value, _setValue] = useState<string | null>();
	const [_debouncedValue] = useDebouncedValue(fieldValue, 500);

	const values = useWatch({
		control: props.dbqueryparams.formInstance.control,
	});

	useEffect(() => {
		if (_debouncedValue) {
			const existingEntries = getFromObjectByPath(values, sectionName);
			const newSlug = convertStringToSlug(_debouncedValue, existingEntries);
			onChange?.(newSlug as any);
		}
	}, [_debouncedValue]);

	return (
		<TextInput
			{...props}
			disabled={true}
			value={value}
			onChange={() => {}}
		/>
	);
}
