// React Imports
import React, { useEffect, useRef, useState } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import {
	Badge,
	Combobox,
	ComboboxOption,
	Flex,
	Loader,
	Pill,
	PillsInput,
	TextInputProps,
	Tooltip,
	useCombobox,
} from "@mantine/core";
import {
	IconFileUnknown,
	IconFingerprint,
	IconInputCheck,
	IconInputSearch,
} from "@tabler/icons-react";

// Context & Helpers
import { getFromObjectByPath } from "../../helpers";
import arrayHelpers from "../../helpers/arrayHelpers";

// Other libraries or utilities
import { useDebouncedValue } from "@mantine/hooks";
import { ObjectId } from "bson";
import { useWatch } from "react-hook-form";
import { useDatabase } from "../../hooks";
import { PaginitedMongoResponse } from "../../types/documentResponses";
import { Profile } from "../../types/profileTypes";

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

function replaceDynamicFilters({
	dbqueryparams,
	formValues,
	sectionProperties,
}: {
	dbqueryparams: Record<string, any>;
	formValues: any;
	sectionProperties: any;
}) {
	if (!dbqueryparams?.filter) return dbqueryparams; // If no filter, return as is
	const updatedQueryParams = { ...dbqueryparams }; // Copy object to avoid mutation
	updatedQueryParams.filter = JSON.parse(
		JSON.stringify(updatedQueryParams.filter)
	); // Deep copy filter

	Object.keys(updatedQueryParams.filter).forEach((key) => {
		const fieldKey = `${sectionProperties?.sectionId}`;
		const value = `${updatedQueryParams.filter[key]}`;

		if (
			typeof value === "string" &&
			value.startsWith("{{") &&
			value.endsWith("}}")
		) {
			const fieldName = value.slice(2, -2); // Extract the referenced field name
			const fullPath = `${fieldKey}.${fieldName}`; // Combine section ID with field name
			const retrievedValue = getFromObjectByPath(formValues, fullPath); // Use your existing function
			updatedQueryParams.filter[key] = retrievedValue || null; // Replace with actual value
		}
	});

	return updatedQueryParams;
}

interface TextSearchProps extends Omit<TextInputProps, "dbqueryparams"> {
	dbqueryparams: {
		dbQueryParams: Record<string, any>;
		formInstance: any;
		sectionProperties: any;
		fieldName: string;
		denormalize: boolean;
	};
}

export function TextSearch(props: TextSearchProps) {
	const db = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);
	const { value, onChange, onBlur } = props;

	const formValues = useWatch({
		control: props.dbqueryparams.formInstance.control,
	});

	const dbqueryparams = replaceDynamicFilters({
		dbqueryparams: props.dbqueryparams.dbQueryParams,
		formValues: formValues,
		sectionProperties: props.dbqueryparams.sectionProperties,
	});

	const isDependantOnOtherFields = Object.values(dbqueryparams.filter).some(
		(filter) =>
			!filter ||
			(typeof filter === "string" || Array.isArray(filter)
				? !filter.length
				: false)
	);

	function getAsyncData(searchQuery: string, signal: AbortSignal) {
		return new Promise((resolve, reject) => {
			signal.addEventListener("abort", () => {
				reject(new Error("Request aborted"));
			});

			const filterObject = [
				{
					...dbqueryparams.filter,
				},
				{ [dbqueryparams.searchField]: searchQuery },
			];
			db.get<PaginitedMongoResponse<Profile<unknown>[]>>(
				`/${dbqueryparams.collection}?filter=${encodeURIComponent(
					JSON.stringify(filterObject)
				)}`,
				{ cache: "no-cache" } // Disable caching for this request
			)
				.then((res) => resolve(res.data))
				.catch((e) => {
					console.error(e);
				});
		});
	}

	const combobox = useCombobox({
		onDropdownClose: () => combobox.resetSelectedOption(),
	});

	const [loading, setLoading] = useState(false);
	const [addingToDb, setAddingToDb] = useState(false);
	const [data, setData] = useState<Record<any, any> | null>(null);
	const [empty, setEmpty] = useState(false);
	const [_value, _setValue] = useState<string | null>();
	const [_debouncedValue] = useDebouncedValue(_value, 500);
	const abortController = useRef<AbortController>(undefined);
	const [searchValueHasMatchingOption, setSearchValueHasMatchingOption] =
		useState(false);

	useEffect(() => {
		if (_debouncedValue) {
			setLoading(true);
			fetchOptions(
				typeof _debouncedValue === "string"
					? _debouncedValue
					: _debouncedValue[0]
			);
		} else {
			setLoading(false);
		}
	}, [_debouncedValue]);

	useEffect(() => {
		const hasMatching = data?.some((item: any) => {
			const fieldValue =
				typeof item === "object" && item[dbqueryparams.searchField]
					? getFromObjectByPath(item, dbqueryparams.searchField)
					: String(item);

			return fieldValue.toLowerCase().includes(_debouncedValue?.toLowerCase());
		});

		if (hasMatching) {
			setSearchValueHasMatchingOption(true);
		} else {
			setSearchValueHasMatchingOption(false);
		}
	}, [data, _debouncedValue]);

	function immutablyAddArrayToData(dataToAdd: string[]) {
		setData((prevData) => {
			const newData = Array.isArray(prevData) ? [...prevData] : [];
			dataToAdd.forEach((item) => {
				if (
					!newData.some((dataItem: any) => dataItem._id === (item as any)._id)
				) {
					newData.push(item);
				}
			});
			return newData;
		});
	}

	const fetchOptions = (query: string) => {
		abortController.current?.abort();
		abortController.current = new AbortController();

		getAsyncData(query, abortController.current.signal)
			.then((result) => {
				if (Array.isArray(result) && result.length > 0) {
					immutablyAddArrayToData(result as string[]);
				}
				setLoading(false);
				setEmpty(Array.isArray(result) && result.length === 0);
				abortController.current = undefined;
			})
			.catch(() => {});
	};

	const options = (data || [])
		.map((item: any) => {
			const isAlreadySelected = Array.isArray(value)
				? value.includes(item._id)
				: value === item._id;

			if (isAlreadySelected) return null;

			const fieldValue =
				typeof item === "object"
					? getFromObjectByPath(item, dbqueryparams.searchField)
					: String(item);

			const isSimilarMatch =
				!_debouncedValue ||
				fieldValue?.toLowerCase().includes(_debouncedValue?.toLowerCase());
			if (!isSimilarMatch) return null;

			return (
				<ComboboxOption
					value={
						dbqueryparams.denormalize
							? item.commonFormDataValues.title
							: item._id
					}
					key={item._id}
				>
					{fieldValue}
					{item.owner && (
						<Badge
							color="blue"
							leftSection={<IconFingerprint size="1.3em" />}
							styles={{ root: { float: "right" } }}
						>
							{item.owner}
						</Badge>
					)}
				</ComboboxOption>
			);
		})
		.filter((option: any) => option !== null);

	const handleValueRemove = (val: string, keepVal = false) => {
		if (value === ".*") {
			onChange?.({
				target: { value: null },
			} as unknown as React.ChangeEvent<HTMLInputElement>);
		}

		if (Array.isArray(value)) {
			const updatedArray = value.filter((v) => v !== val);
			onChange?.({
				target: { value: updatedArray },
			} as unknown as React.ChangeEvent<HTMLInputElement>);
			_setValue(keepVal ? val : "");
		} else {
			onChange?.({
				target: { value: keepVal ? val : "" },
			} as React.ChangeEvent<HTMLInputElement>);
		}
	};

	function Values() {
		function Component({ lookupId }: { lookupId: string }) {
			const thisObject = data?.find((item: any) => item._id === lookupId);

			useEffect(() => {
				if (!thisObject && ObjectId.isValid(lookupId)) {
					db.get(`/${dbqueryparams.collection}/${lookupId}`, {
						cache: "no-cache", // Disable caching for this request
					})
						.then((res) => {
							if (!res) {
								return immutablyAddArrayToData([
									{ _id: lookupId },
								] as unknown as string[]);
							}
							immutablyAddArrayToData([res as string]);
						})
						.catch((e) => {
							console.error(e);
						});
				}
			}, [thisObject, lookupId, dbqueryparams.collection]);

			const label = getFromObjectByPath(thisObject, dbqueryparams.searchField);

			if (!label) {
				return (
					<Pill
						withRemoveButton
						onRemove={() => handleValueRemove(lookupId)}
					>
						<Flex
							gap="xs"
							align="center"
						>
							{!dbqueryparams.denormalize && <IconFileUnknown size="1.5em" />}
							{typeof value === "string" ? value : null}
							{Array.isArray(value) && value[0] ? value[0] : null}
						</Flex>
					</Pill>
				);
			}

			return (
				<Pill
					withRemoveButton
					onRemove={() => handleValueRemove(lookupId)}
					key={`inner_${lookupId}`}
				>
					{label}
				</Pill>
			);
		}

		if (Array.isArray(value)) {
			return value.map((lookupId: string) => {
				return (
					<Component
						key={lookupId}
						lookupId={lookupId}
					/>
				);
			});
		} else if (value) {
			return (
				<Component
					key={
						typeof value === "string" || typeof value === "number"
							? value
							: undefined
					}
					lookupId={typeof value === "string" ? value : ""}
				/>
			);
		}
	}
	return (
		<Combobox
			onClose={() => {
				if (!value) {
					props.dbqueryparams.formInstance.setError(
						props.dbqueryparams.fieldName,
						{
							type: "required",
							message:
								"You must select an option from the dropdown box after typing in the search field.",
						}
					);
				}
			}}
			onOptionSubmit={async (optionValue) => {
				let calculatedValue = optionValue;

				if (dbqueryparams.allowAddToDb) {
					if (optionValue === "$create") {
						let searchField = dbqueryparams.searchField;
						if (Array.isArray(searchField) && searchField.length === 1) {
							searchField = searchField[0];
						}
						const newDocument = arrayHelpers.add.toObjectAtPath(
							{ ...dbqueryparams?.filter },
							searchField,
							_debouncedValue
						);

						setAddingToDb(true);
						await db
							.post(`/${dbqueryparams.collection}`, newDocument)
							.then((res) => {
								immutablyAddArrayToData([res as any]);
								calculatedValue = (res as any)._id;

								_setValue("");
								return res;
							})
							.catch(() => {
								_setValue(_debouncedValue);
							})
							.finally(() => setAddingToDb(false));
					}
				}

				if (typeof value === "string") {
					onChange?.({
						target: {
							value:
								value.length > 0 ? [value, calculatedValue] : [calculatedValue],
						},
					} as unknown as React.ChangeEvent<HTMLInputElement>);
				} else if (Array.isArray(value)) {
					onChange?.({
						target: { value: [...value, calculatedValue] },
					} as unknown as React.ChangeEvent<HTMLInputElement>);
				} else {
					onChange?.({
						target: { value: [calculatedValue] },
					} as unknown as React.ChangeEvent<HTMLInputElement>);
				}

				combobox.closeDropdown();
			}}
			withinPortal={false}
			store={combobox}
		>
			<Combobox.Target>
				<Tooltip
					label={
						isDependantOnOtherFields
							? "Complete prerequisite fields before this one."
							: "Remove the current value to search again"
					}
					disabled={
						isDependantOnOtherFields ||
						(!dbqueryparams.multiple && Array.isArray(value) && value.length)
							? false
							: true
					}
					position="top"
					arrowPosition="center"
					withArrow
					arrowSize={6}
					openDelay={1000}
				>
					<PillsInput
						{...props}
						onChange={(event) => {
							combobox.openDropdown();
							_setValue((event.target as HTMLInputElement).value);
							combobox.resetSelectedOption();
							setLoading(true);
						}}
						onClick={() => {
							if (dbqueryparams.autoPopulate) {
								setLoading(true);
								combobox.openDropdown();
								fetchOptions(".*"); // Wildcard Search
							}
						}}
						disabled={isDependantOnOtherFields}
						pointer={
							!dbqueryparams.multiple && Array.isArray(value) && value.length
								? true
								: false
						}
						onBlur={(e) => {
							combobox.closeDropdown();
							onBlur?.(e as React.FocusEvent<HTMLInputElement>);
						}}
						rightSection={
							loading ? (
								<Loader size={18} />
							) : (!isDependantOnOtherFields &&
									(!Array.isArray(value) || !value.length)) ||
							  dbqueryparams.multiple ? (
								<Tooltip
									label={`Search ${
										dbqueryparams?.allowAddToDb ? "or Add" : ""
									} ${dbqueryparams.multiple ? "Values" : "a Value"}`}
								>
									<IconInputSearch size="1.5em" />
								</Tooltip>
							) : (
								!isDependantOnOtherFields && (
									<Tooltip label="Remove the current value to search again">
										<IconInputCheck size="1.5em" />
									</Tooltip>
								)
							)
						}
						onKeyDown={(event) => {
							if (event.key === "Backspace") {
								if (!_value || _value === "") {
									event.preventDefault();
									handleValueRemove(
										Array.isArray(value) ? value[value.length - 1] : ""
									);
								}
							}
						}}
					>
						<Pill.Group>
							<Values />
							{(dbqueryparams.multiple ||
								!Array.isArray(value) ||
								!value.length) && (
								<PillsInput.Field
									value={_value ?? ""}
									onChange={() => null}
									placeholder={props.placeholder}
								/>
							)}
						</Pill.Group>
					</PillsInput>
				</Tooltip>
			</Combobox.Target>

			<Combobox.Dropdown
				hidden={
					(data === null && !_value) ||
					_value?.toString().trim() === "" ||
					loading
				}
			>
				<Combobox.Options>
					{options}

					{!searchValueHasMatchingOption &&
						dbqueryparams.allowAddToDb &&
						_debouncedValue?.length && (
							<Combobox.Empty>
								<Combobox.Option
									value="$create"
									disabled={addingToDb || loading}
								>
									{addingToDb && <Loader size={18} />}
									{!addingToDb && (
										<span>
											+ Create{" "}
											<span style={{ fontWeight: "bold" }}>
												{_debouncedValue}
											</span>
										</span>
									)}
								</Combobox.Option>
							</Combobox.Empty>
						)}

					{!options.length &&
						!searchValueHasMatchingOption &&
						!dbqueryparams.allowAddToDb && (
							<Combobox.Empty>
								{_value && _value.length < 1
									? "All options selected"
									: empty
									? "No results found"
									: null}
							</Combobox.Empty>
						)}
				</Combobox.Options>
			</Combobox.Dropdown>
		</Combobox>
	);
}
