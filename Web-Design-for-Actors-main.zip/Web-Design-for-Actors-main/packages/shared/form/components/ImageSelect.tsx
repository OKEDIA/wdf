// React Imports;
import React, {
	Fragment,
	ReactNode,
	useEffect,
	useRef,
	useState,
	useTransition,
} from "react";

// Next.js Imports

// Lower Order Components
import "html5-device-mockups/dist/device-mockups.min.css";

// UI Components & Icons
import {
	__InputStylesNames,
	Button,
	Card,
	ColorInput,
	Flex,
	Image,
	InputError,
	InputWrapper,
	LoadingOverlay,
	MantineComponent,
	ScrollArea,
	Select,
	Skeleton,
	Stack,
	TextInputProps,
	Title,
} from "@mantine/core";
import { IconMoodEmpty } from "@tabler/icons-react";

// Context & Helpers

// Other libraries or utilities
import { useElementSize } from "@mantine/hooks";
import { useDatabase } from "@okedia/shared/hooks";
import { Template } from "../../types/formTypes";

// Types
import { FileUpload } from "../../types/profile";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * A component that displays a horizontal scrollable list of image templates with color variations.
 *
 * @component
 * @param {Object} props - The component props
 * @param {TextInputProps} props.props - Mantine text input properties
 * @param {HTMLInputElement} props.ref - Reference to the input element
 * @param {__InputStylesNames} props.stylesNames - Input style names
 * @param {string} [props.brand] - The brand name used in image path
 * @param {string} [props.design] - The design name used in image path
 *
 * @returns {JSX.Element} A scrollable area containing image cards with select buttons
 *
 * @example
 * <ImageSelect
 *   props={textInputProps}
 *   ref={inputRef}
 *   stylesNames={styleNames}
 *   brand="mybrand"
 *   design="mydesign"
 * />
 */
export default function ImageSelect(
	props: MantineComponent<{
		props: TextInputProps;
		ref: HTMLInputElement;
		stylesNames: __InputStylesNames;
		brand?: string;
		design?: string;
	}>
) {
	const db = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);
	const [designs, setDesigns] = useState<Template[] | undefined>(undefined);
	const scrollArea = useElementSize();
	const brand = props.brand;

	useEffect(() => {
		async function fetchTemplates() {
			try {
				const res = await db.get<{ [key: string]: Template }>(
					`/templates/${props.brand}`
				);

				console.log(res);

				const designs: Template[] = Object.keys(res).reduce(
					(acc: Template[], key) => {
						if (Array.isArray(res[key].colors)) {
							acc.push({
								...res[key],
								id: key,
								demo: typeof res.demo === "string" ? res.demo : undefined, // Ensure the demo object is added
							});
						}
						return acc;
					},
					[]
				);

				console.log(designs);

				setDesigns(designs);
			} catch (error) {
				console.error("Error fetching templates", error);
			}
		}

		fetchTemplates();
	}, []);

	function Accordian({ children }: { children: ReactNode }) {
		return (
			<ScrollArea
				scrollbars="x"
				w="100%"
				h={`calc(${scrollArea.height}px + 25px)`}
				styles={{ viewport: { position: "absolute" } }}
				offsetScrollbars
				scrollbarSize={20}
			>
				<Flex
					ref={scrollArea.ref}
					gap="lg"
				>
					{children}
				</Flex>
			</ScrollArea>
		);
	}

	function Loading() {
		function SkeletonCard() {
			return (
				<Flex gap="lg">
					<Skeleton
						visible
						animate
					>
						<Card
							radius="md"
							styles={{ root: { minWidth: "250px", minHeight: "250px" } }}
						/>
					</Skeleton>
				</Flex>
			);
		}

		const skeletonCount = 6;

		return (
			<Accordian>
				{Array.from({ length: skeletonCount }).map((_, index) => (
					<SkeletonCard key={index} />
				))}
			</Accordian>
		);
	}

	if (db.loading) {
		return <Loading />;
	}

	if (!designs) {
		return <NoneAvailable type={props?.brand ?? "this type"} />;
	}

	return (
		<>
			<ScrollArea
				scrollbars="x"
				w="100%"
				h={`calc(${scrollArea.height}px + 25px)`}
				styles={{ viewport: { position: "absolute" } }}
				offsetScrollbars
				scrollbarSize={20}
			>
				<Flex
					ref={scrollArea.ref}
					gap="lg"
				>
					<Templates
						designs={designs}
						props={props}
						brand={brand}
					/>
				</Flex>
				{props.error && <InputError>{props.error}</InputError>}
			</ScrollArea>
		</>
	);
}

function Templates({
	designs,
	props,
	brand,
}: {
	designs: Template[];
	props: any;
	brand: string;
}) {
	const db = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);
	return designs.map((design, index) => {
		const [isPending, startTransition] = useTransition();
		const [imageUrl, setImageUrl] = useState<string | null>(null);
		const isCustom = props.value?.colorScheme === "custom" || false;
		const isCurrentlySelectedDesign = props.value?.design === design.id;
		const imageRef = useRef<HTMLImageElement | null>(null);

		const isValid =
			isCurrentlySelectedDesign &&
			(isCustom ? props.value?.customColor : props.value?.colorScheme);

		const colorToDisplay =
			isValid && props.value?.colorScheme && !isCustom
				? props.value?.colorScheme
				: design.colors[0].id;

		const hasMultiple = designs.length > 1;
		const designHasMultipleColors =
			design.settings?.hasSecondaryColor ||
			design.settings?.hasSecondaryAccent ||
			design.settings?.hasPrimaryColor ||
			design.settings?.hasPrimaryAccent;

		// Fetch the image URL lazily when the image comes into view
		useEffect(() => {
			if (imageRef.current) {
				const observer = new IntersectionObserver(
					(entries) => {
						const entry = entries[0];
						if (entry.isIntersecting) {
							// Load the image when it enters the viewport
							startTransition(() =>
								db
									.get<FileUpload>(
										`/websites/${design.demo}/screenshot/?template=${design.id}&colorScheme=${colorToDisplay}&brand=${brand}`
									)
									.then((res) => {
										setImageUrl(res.downloadUrl);
									})
									.catch((error) => {
										console.error("Error fetching image:", error);
									})
							);

							// Stop observing after the image is loaded
							observer.disconnect();
						}
					},
					{
						rootMargin: "200px", // This can be adjusted to trigger loading before the image is fully in view
					}
				);

				observer.observe(imageRef.current);

				return () => {
					if (imageRef.current) observer.unobserve(imageRef.current);
				};
			}
		}, [colorToDisplay]);

		return (
			<InputWrapper
				key={index}
				w={hasMultiple ? "300px" : "100%"}
			>
				<Card
					shadow="sm"
					radius="md"
					withBorder
					onBlur={props.onBlur}
				>
					<Flex
						gap="md"
						styles={{ root: { flexFlow: "row wrap" } }}
						justify="space-evenly"
					>
						<Flex
							style={{ verticalAlign: "middle" }}
							w={{ sm: hasMultiple ? "100%" : "30%", base: "50%" }}
							onError={(e) => {
								e.currentTarget.style.display = "none";
							}}
							pos="relative"
						>
							<LoadingOverlay visible={isPending} />

							{!isPending && (
								<div className="device-wrapper">
									<div
										className="device"
										data-device="MacbookPro"
										data-orientation="portrait"
										data-color="black"
									>
										<div className="screen">
											<Image
												h="100%"
												w="100%"
												src={imageUrl ?? ""}
												loading="lazy"
												ref={imageRef}
												alt={`Preview of ${props.value}`}
												styles={{
													root: {
														filter:
															isCurrentlySelectedDesign && isCustom
																? "grayscale(1)"
																: undefined,
														width: "100%",
													},
												}}
											/>
										</div>

										<div className="button"></div>
									</div>
								</div>
							)}
						</Flex>
						<Flex w={{ sm: hasMultiple ? "100%" : "40%", base: "60%" }}>
							<Stack
								justify="center"
								align="center"
								gap="xs"
								flex="2 2 auto"
							>
								<Title
									tt="capitalize"
									fw="bold"
									order={5}
								>
									"{design.id}" Design
								</Title>
								<Select
									data={design.colors
										.map((color) => {
											return { value: color.id, label: color.name };
										})
										.concat({ value: "custom", label: "Choose your own" })}
									placeholder="Select a color"
									styles={{ root: { width: "100%" } }}
									onChange={(value, option) =>
										props.onChange({
											...props.value,
											colorScheme: value,
											design: design.id,
										})
									}
									onBlur={props.onBlur}
									value={
										isCurrentlySelectedDesign && props.value?.colorScheme
											? props.value?.colorScheme
											: undefined
									}
								/>
								{isCurrentlySelectedDesign &&
									props.value?.colorScheme === "custom" && (
										<Fragment>
											<ColorInput
												label={
													designHasMultipleColors
														? "Primary Color"
														: "Custom Color"
												}
												styles={{ root: { width: "100%" } }}
												format="hex"
												placeholder={
													designHasMultipleColors
														? "Primary Color"
														: "Custom Color"
												}
												onChangeEnd={(value) => {
													props.onChange({
														...props.value,
														customColor: value,
													});
												}}
												value={props.value?.customColor}
											/>
											{design.settings?.hasSecondaryColor && (
												<ColorInput
													label="Secondary Color"
													styles={{ root: { width: "100%" } }}
													format="hex"
													onChangeEnd={(value) => {
														props.onChange({
															...props.value,
															secondaryColor: value,
														});
													}}
													placeholder="Secondary Color"
													value={props.value?.secondaryColor}
												/>
											)}

											{design.settings?.hasPrimaryAccent && (
												<ColorInput
													label="Primary Accent Color"
													styles={{ root: { width: "100%" } }}
													format="hex"
													placeholder="Primary Accent Color"
													onChangeEnd={(value) => {
														props.onChange({
															...props.value,
															primaryAccent: value,
														});
													}}
													value={props.value?.primaryAccent}
												/>
											)}

											{design.settings?.hasSecondaryAccent && (
												<ColorInput
													label="Secondary Accent Color"
													styles={{ root: { width: "100%" } }}
													format="hex"
													placeholder="Secondary Accent Color"
													onChangeEnd={(value) => {
														props.onChange({
															...props.value,
															secondaryAccent: value,
														});
													}}
													value={props.value?.secondaryAccent}
												/>
											)}
										</Fragment>
									)}
								<Button
									fullWidth
									mt="md"
									radius="md"
									type="button"
									disabled={!isValid || !hasMultiple}
								>
									{isValid
										? "This design is selected"
										: "Pick a colour to use this design."}
								</Button>
							</Stack>{" "}
						</Flex>
					</Flex>
				</Card>
			</InputWrapper>
		);
	});
}

function NoneAvailable({ type }: { type: string }) {
	return (
		<InputWrapper w="100%">
			<Card
				shadow="sm"
				radius="md"
				withBorder
			>
				<Flex
					gap="md"
					styles={{ root: { flexFlow: "row wrap" } }}
					justify="space-evenly"
				>
					<Flex
						style={{ verticalAlign: "middle" }}
						w={{ sm: "100%", base: "50%" }}
						justify="center"
					>
						<IconMoodEmpty size="10em" />
					</Flex>
					<Flex w={{ sm: "100%", base: "60%" }}>
						<Stack
							justify="center"
							align="center"
							gap="xs"
							flex="2 2 auto"
						>
							<Title
								fw="bold"
								order={2}
							>
								Oops! Websites for {type ?? "this type"} are not available yet.
							</Title>
							<Title order={4}>
								We're working hard to bring you more options.
							</Title>

							<Button
								fullWidth
								mt="md"
								radius="md"
								type="button"
								disabled
							>
								Cannot Continue
							</Button>
						</Stack>{" "}
					</Flex>
				</Flex>
			</Card>
		</InputWrapper>
	);
}
