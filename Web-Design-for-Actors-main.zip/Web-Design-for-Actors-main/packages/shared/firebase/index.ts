import { createFirebaseAdminApp } from "./admin";
import { checkUserAuthentication } from "./getUser";
import { authForClientSide, providers, storage } from "./standard";

const firebaseStandard = {
	authForClientSide,
	providers,
	storage,
};

export {
	checkUserAuthentication,
	createFirebaseAdminApp as firebaseAdmin,
	firebaseStandard
};
