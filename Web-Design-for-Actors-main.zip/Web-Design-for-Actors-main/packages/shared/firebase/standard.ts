// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities
import { getApp, getApps, initializeApp } from "firebase/app";
import {
	connectAuthEmulator,
	EmailAuthProvider,
	getAuth,
	GoogleAuthProvider,
	OAuthProvider,
} from "firebase/auth";
import { connectStorageEmulator, getStorage } from "firebase/storage";
import { getOrInitializeAppCheck } from "./appCheck";

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Firebase configuration object containing essential credentials and settings.
 * @property {string} apiKey - The API key for Firebase authentication
 * @property {string} authDomain - The authentication domain for Firebase
 * @property {string} messagingSenderId - The messaging sender ID for Firebase Cloud Messaging
 * @property {string} appId - The unique identifier for the Firebase application
 * @property {string} measurementId - The ID for Firebase Analytics measurement
 * @property {string} projectId - The unique identifier for the Firebase project
 * @property {string} storageBucket - The storage bucket URL for Firebase Storage
 * @property {string} privateKey - The private key for Firebase Admin SDK authentication
 */
const firebaseConfig = {
	apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY as string,
	authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN as string,
	messagingSenderId: process.env
		.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID as string,
	appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID as string,
	measurementId: process.env.NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID as string,
	projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID as string,
	storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET as string,
	privateKey: process.env.FIREBASE_PRIVATE_KEY as string,
};

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

const providers = {
	apple: new OAuthProvider("apple.com"),
	email: new EmailAuthProvider(),
	google: new GoogleAuthProvider(),
};

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export const getFirebaseApp = () => {
	if (getApps().length) {
		return getApp();
	}

	const app = initializeApp(firebaseConfig);

	if (process.env.NEXT_PUBLIC_FIREBASE_APP_CHECK_KEY) {
		getOrInitializeAppCheck(app);
	}

	return app;
};

export function getFirebaseAuth() {
	const auth = getAuth(getFirebaseApp());

	// App relies only on server token. We make sure Firebase does not store credentials in the browser.
	// See: https://github.com/awinogrodzki/next-firebase-auth-edge/issues/143
	// setPersistence(auth, inMemoryPersistence);
	// NB: This seems to completely screw up the firebase client side authentication preventing access to client side apis like firebase storage.

	return auth;
}

const authForClientSide = getFirebaseAuth();
const app = getFirebaseApp();
const storage = getStorage(app);

if (process.env.NEXT_PUBLIC_VERCEL_TARGET_ENV !== "production") {
	if (process.env.NEXT_PUBLIC_FIREBASE_EMULATOR_HOST) {
		connectAuthEmulator(authForClientSide, "http://localhost:9099");
	}
	connectStorageEmulator(storage, "127.0.0.1", 9199);
} else {
	console.log(
		`Not running firebase emulator as environment mode is ${process.env.NEXT_PUBLIC_VERCEL_TARGET_ENV}`
	);
}

export { authForClientSide, providers, storage };
