import "server-only";

import admin from "firebase-admin";

interface FirebaseAdminAppParams {
	projectId: string;
	clientEmail: string;
	storageBucket: string;
	privateKey: string;
}

function formatPrivateKey(key: string) {
	return key.replace(/\\n/g, "\n");
}

/**
 * Creates and initializes a Firebase Admin app instance if one doesn't already exist.
 *
 * @param params - Configuration parameters for the Firebase Admin app
 * @param params.privateKey - Private key for Firebase service account
 * @param params.projectId - Firebase project ID
 * @param params.clientEmail - Firebase client email
 * @param params.storageBucket - Firebase storage bucket URL
 *
 * @returns An initialized Firebase Admin app instance
 *
 * @remarks
 * If an app is already initialized, returns the existing instance.
 * The private key is formatted before being used in the credential certificate.
 */
export function createFirebaseAdminApp(params: FirebaseAdminAppParams) {
	const privateKey = formatPrivateKey(params.privateKey);

	if (admin.apps.length > 0) {
		return admin.app();
	}

	const cert = admin.credential.cert({
		projectId: params.projectId,
		clientEmail: params.clientEmail,
		privateKey,
	});

	return admin.initializeApp({
		credential: cert,
		projectId: params.projectId,
		storageBucket: params.storageBucket,
	});
}

export async function firebaseAdmin() {
	const params = {
		projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID as string,
		clientEmail: process.env.NEXT_PUBLIC_FIREBASE_CLIENT_EMAIL as string,
		storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET as string,
		privateKey: process.env.FIREBASE_PRIVATE_KEY as string,
	};

	return createFirebaseAdminApp(params);
}
