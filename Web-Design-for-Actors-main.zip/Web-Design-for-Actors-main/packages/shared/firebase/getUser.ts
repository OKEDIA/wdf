// React Imports

// Next.js Imports
import { cookies } from "next/headers";

// Firebase Imports

// Helpers

// Other libraries or utilities
import { getTokens } from "next-firebase-auth-edge";
import { formatPrivateKey } from "@okedia/shared/helpers/string";

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Checks the user's authentication status by verifying their tokens.
 *
 * @returns {Promise<{ isAuthenticated: boolean; isAdmin: boolean; tokens: any }>}
 * An object containing the authentication status, admin status, and tokens.
 *
 * @throws Will throw an error if token retrieval fails.
 */
export async function checkUserAuthentication() {
	const tokens = await getTokens(await cookies(), {
		apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY as string,
		cookieName: process.env.NEXT_PUBLIC_FIREBASE_COOKIE_NAME as string,
		cookieSignatureKeys: [
			process.env.NEXT_PUBLIC_FIREBASE_COOKIE_KEY_1 as string,
			process.env.NEXT_PUBLIC_FIREBASE_COOKIE_KEY_2 as string,
		],
		serviceAccount: {
			projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID as string,
			clientEmail: process.env.NEXT_PUBLIC_FIREBASE_CLIENT_EMAIL as string,
			privateKey: formatPrivateKey(process.env.FIREBASE_PRIVATE_KEY),
		},
	});

	const isAuthenticated = tokens ? true : false;
	const isAdmin = tokens?.decodedToken.isAdmin === true ? true : false;

	return { isAuthenticated, isAdmin, tokens };
}
