import "server-only";

// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import Stripe from "stripe";

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export const stripeAdmin = new Stripe(process.env.STRIPE_API_KEY as string);

export interface StripeResponse<T> {
	object: string;
	url: string;
	has_more: boolean;
	data: T[]; // Array of T
	next_page?: string; // Optional for pagination
	total_count?: number;
}

export type Coupon = Stripe.Coupon;
export type CustomerCreateParams = Stripe.CustomerCreateParams;
export type Customer = Stripe.Customer;
export type PaymentMethodParams = Stripe.CustomerListPaymentMethodsParams;
export type PaymentMethod = Stripe.PaymentMethod;
export type SubscriptionMethodParams = Stripe.SubscriptionListParams;
export interface Subscription extends Stripe.Subscription {
	[x: string]: any; // Allow "Extend"
	plan: Stripe.Plan;
	latest_invoice: Stripe.Invoice;
}

export interface CustomerWithSession extends Stripe.Customer {
	[x: string]: any; // Allow "Extend"
}

export type SubscriptionCreateParams = Stripe.SubscriptionCreateParams;
export type PriceListParams = Stripe.PriceListParams;
export type Price = Stripe.Price;
export type Product = Stripe.Product;
export type Invoice = Stripe.Invoice;
export type PromotionCode = Stripe.PromotionCode;
export type PaymentIntent = Stripe.PaymentIntent;
