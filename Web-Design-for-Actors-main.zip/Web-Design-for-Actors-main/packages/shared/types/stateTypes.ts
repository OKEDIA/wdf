import { Dispatch, SetStateAction } from "react";

/**
 * A type definition for a state setter function that is used to update state in React.
 * @template T - The type of the state value
 */
export type StateSetter<T> = Dispatch<SetStateAction<T>>;
