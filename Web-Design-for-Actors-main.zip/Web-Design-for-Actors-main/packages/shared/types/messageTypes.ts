// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import { ObjectId } from "bson";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export interface Message {
	content?: any;
	subject?: any;
	sender?: string;
	profile: ObjectId;
}
