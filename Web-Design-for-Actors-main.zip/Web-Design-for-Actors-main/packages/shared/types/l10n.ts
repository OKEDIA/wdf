import { MantineThemeOverride } from "@mantine/core";
import { StaticImageData } from "next/image";

export interface l10nType {
	id: string;
	isBrand: boolean;
	public_name_ends: string;

	theme: MantineThemeOverride;
}

export interface Localisation {
	l10n: {
		websiteBuilder: {
			intro: {
				title: string;
				subtitle: string;
				secondaryCta: string;
				primaryCta: string;
				smallprint: string;
				smallprintUrl: string;
				secondaryCtaUrl: string;
			};
		};
	};
	logoURL: StaticImageData;
	article: "an" | "a";
	singular: string;
}
