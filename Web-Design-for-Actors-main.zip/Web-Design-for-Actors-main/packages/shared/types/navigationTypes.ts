// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import {
	IconExternalLink,
	IconHeartbeat,
	IconHome,
	IconList,
	IconTopologyStar3,
	IconUsersGroup,
} from "@tabler/icons-react";
import { CommonFormDataProps } from "./formTypes";

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export const icons = {
	IconHome: IconHome,
	IconHeartbeat: IconHeartbeat,
	IconExternalLink: IconExternalLink,
	IconUsersGroup: IconUsersGroup,
	IconTopologyStar3: IconTopologyStar3,
	IconList: IconList,
};

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export type IconType = keyof typeof icons;

export interface Steps {
	stepTitle: string;
	stepDescription: string;
	shortTitle: string;
	stepFields: {
		[key: string]: string[];
	};
	id: number;
}

export interface LinkProps {
	steps?: Steps[];
	label: string | CommonFormDataProps;
	to: string;
	icon?: IconType;
}

interface ConfigProps {
	label: string;
	displayLabel: boolean;
}

interface NavigationGroup {
	config: ConfigProps;
	links: LinkProps[];
}

export type NavigationConfig = NavigationGroup[];

export interface NavComponentProps {
	navConfig: NavigationConfig;
}
