const fileTypes = {
	pdf: "application/pdf",
	images:
		"image/png,image/jpeg,image/gif,image/webp,image/bmp,image/tiff,image/svg+xml",
	videos: "video/mp4,video/webm,video/ogg",
	audio: "audio/mpeg,audio/wav,audio/ogg",
	documents:
		"application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation,text/plain",
};

export const fileTypeMap = {
	pdf: fileTypes.pdf,
	image: fileTypes.images,
	video: fileTypes.videos,
	audio: fileTypes.audio,
	media: `${fileTypes.images},${fileTypes.videos},${fileTypes.audio}`,
	document: fileTypes.documents,
};

export interface ScreenshotResponse {
	screenshot_url: string;
	input_data: {
		url: string;
		wait: number;
		full_page: boolean;
		browser_size: string;
		execute_js: string;
		screenshot_element: string;
		screenshot_crop_box: string;
		return_as_file: string;
	};
}
