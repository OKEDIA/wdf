// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import {
	NumberInput,
	PasswordInput,
	PinInput,
	Rating,
	Select,
	Space,
	Switch,
	TextInput,
} from "@mantine/core";
import { DateInput } from "@mantine/dates";
import ImageSelect from "@okedia/shared/form/components/ImageSelect";
import { Font } from "../form/components/Font";

// Context & Helpers

// Other libraries or utilities

// Types
import { UseFormReturn } from "react-hook-form";
import FileUpload from "../form/components/FileUpload";
import TextEditor from "../form/components/RichTextEditor";
import { Slug } from "../form/components/Slug";
import { TextSearch } from "../form/components/TextSearch";
import { FormPropsOptions } from "../form/Form";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export const components = {
	text: TextInput,
	password: PasswordInput,
	number: NumberInput,
	rating: Rating,
	textArea: TextEditor,
	select: Select,
	upload: FileUpload,
	pincode: PinInput,
	switch: Switch,
	spacer: Space,
	date: DateInput,
	imageSelect: ImageSelect,
	textSearch: TextSearch,
	slug: Slug,
	font: Font,
};

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// ROOT FORM TYPES

export type FormConfig = {
	formFields: Input[];
	formSteps?: Step[];
	commonFormDataMap?: CommonFormDataProps;
};

export type Step = {
	id: number;
	stepTitle: string;
	shortTitle: string;
	stepDescription: string;
	stepFields?: Record<string, string[]>;
};

// Define the possible components in a union type
type ComponentType =
	| "text"
	| "password"
	| "number"
	| "rating"
	| "textArea"
	| "select"
	| "upload"
	| "pincode"
	| "spacer"
	| "switch"
	| "group"
	| "imageSelect";

export type FieldComponent<T extends ComponentType = ComponentType> = {
	component: T;
	validators?: Validators;
	attributes?: any;
	inputWeight?: number;
	id: string;
	append?: string;
	dbQueryParams?: {
		collection: string;
		filter: Record<string, any>[] | Record<string, any>;
		searchField: string;
		multiple?: boolean;
		allowAddToDb?: boolean;
	};
	source?: string;
	fieldComponents?: FieldComponent[];
};

// Type for validation rules

export const errorTextMap = {
	required: "Please complete this information; it is required.",
	min: "The value is too low.",
	max: "The value is too high.",
	minLength: "The length of this information is too short.",
	maxLength: "The length of this information is too long.",
	pattern: "The input does not match the required pattern.",
	validate: "Custom validation failed.",
};

export const patternMap: Record<
	string,
	{ regex: RegExp; defaultMessage: string }
> = {
	// Regex Library: https://uibakery.io/regex-library
	name: {
		regex: /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/,
		defaultMessage: "We do not currently accept this format of name.",
	},
	email: {
		regex:
			/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/,
		defaultMessage: "Please enter a valid email address.",
	},
	url: {
		regex:
			/^https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&\/=]*)$/,
		defaultMessage: "Please enter a valid URL. It must start with https://.",
	},
	tel: {
		regex:
			/^\+?\d{1,4}?[-.\s]?\(?\d{1,3}?\)?[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,9}$/,
		defaultMessage: "Please enter a valid phone number.",
	},
	date: {
		// ISO 8601 Date Time e.g. new Date() or e.g. 2021-11-04T22:32:47.142354-10:00
		regex:
			/^(?:\d{4})-(?:\d{2})-(?:\d{2})T(?:\d{2}):(?:\d{2}):(?:\d{2}(?:\.\d*)?)(?:(?:-(?:\d{2}):(?:\d{2})|Z)?)$/,
		defaultMessage: "Please enter a valid date.",
	},
};

const fileTypes = {
	pdf: "application/pdf",
	images:
		"image/png,image/jpeg,image/gif,image/webp,image/bmp,image/tiff,image/svg+xml",
	videos: "video/mp4,video/webm,video/ogg",
	audio: "audio/mpeg,audio/wav,audio/ogg",
	documents:
		"application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation,text/plain",
};

export const fileTypeMap = {
	pdf: fileTypes.pdf,
	image: fileTypes.images,
	video: fileTypes.videos,
	audio: fileTypes.audio,
	media: `${fileTypes.images},${fileTypes.videos},${fileTypes.audio}`,
	document: fileTypes.documents,
};
interface Validators {
	required?: boolean;
	min?: number;
	max?: number;
	minLength?: number;
	maxLength?: number;
	pattern?: keyof typeof patternMap;
	accept?: keyof typeof fileTypeMap;
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// FIELD ATTRIBUTE TYPES

// Type for a text input object
export type Input = {
	id: string;
	label: string;
	helpText: string;
	inputGroup: string;
	fieldComponents: FieldComponent[];
	dynamicFieldCount?: number;
	optionalDynamicField?: boolean;
	provideDate?: boolean;
	isBoxed?: boolean;
};

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// COLOR SCHEME TYPES

// Type for the root object that includes "default"
export type TemplatesList = {
	[templateName: string]: Template;
}[];
export interface Template {
	id: string;
	colors: ColorScheme[];
	settings?: {
		hasPrimaryColor?: boolean;
		hasSecondaryColor?: boolean;
		hasPrimaryAccent?: boolean;
		hasSecondaryAccent?: boolean;
	};
	demo?: string;
}

// Type for a color scheme object
type ColorScheme = {
	id: string;
	name: string;
};

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// FORM RETURNS

export interface FormValues {
	[key: string]: any;
}
export type FormProps = {
	formFields: Input[];
	formInstance: UseFormReturn<FormValues, any, unknown>;
	commonFormDataMap?: CommonFormDataProps;
	stepConfig?: Step;
	options?: FormPropsOptions;
};

export interface CommonFormDataProps {
	image: string; // Profile Image/Logo URL
	title: string; // Name of Actor, Producer etc
	tags: string[]; // Identifying tags such as Location, Age, Social Media Profiles etc
}
