interface FirebaseIncident {
	id: string;
	created: string;
	end: string | null;
	external_desc: string;
	status_impact: string;
	severity: string;
	service_name: "Authentication" | "Firestore" | "Storage";
}

interface FirebaseServiceStatus {
	id: string;
	created: string;
	end: string | null;
	desc: string;
	impact: string;
	severity: string;
	service: string;
}

interface FirebaseStatus {
	Authentication?: FirebaseServiceStatus;
	Firestore?: FirebaseServiceStatus;
	Storage?: FirebaseServiceStatus;
}

interface StripeStatus {
	status?: string;
	id: string;
	impact: string;
	desc: string;
}

interface CrispStatusResponse {
	id: string;
	impact: string;
	desc: string;
}

export interface ServiceStatus {
	status: "up";
}

export type FirebaseResult = ServiceStatus | FirebaseStatus;
export type StripeResult = ServiceStatus | StripeStatus;
export type CrispResult = ServiceStatus | CrispStatusResponse;

export interface ServiceStatusResult {
	service: "firebase" | "stripe" | "crisp";
	description: string;
	friendly_name: string;
	result: FirebaseResult | StripeResult | CrispResult;
}
