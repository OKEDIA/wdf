import { FullMetadata } from "@firebase/storage-types";
import { MongoDocumentResponse } from "../mongoTypes";
import { Profile } from "../profileTypes";
import { socialNetworks } from "../socialNetworks";
import { Website } from "../websiteTypes";

type FileUpload = FullMetadata & { downloadUrl: string };

interface Rating {
	title: string;
	value: number;
}

interface SocialMediaValue {
	network: keyof typeof socialNetworks;
	username?: any;
}

interface Review {
	content: any;
	reviewer?: any;
	company: any;
	rating?: any;
	logo?: FileUpload;
}

interface Address {
	street1?: any;
	street2?: any;
	town?: any;
	city?: any;
	postcode?: any;
}

interface Agency extends Address {
	name?: any;
	representing?: any;
	tel?: any;
	url?: any;
	email?: any;
	spacer?: "";
}

interface Post {
	name?: any;
	date?: string;
	content?: any;
	cover?: FileUpload;
	slug: string;
}

interface Section {
	type: string;
	title?: any;
	image?: FileUpload;
	content: any;
}

interface GalleryFile {
	name: any;
	category: any;
	upload: FileUpload;
}

type StandardValue = { value: string }[];

interface ActorProfile extends Profile<ActorProfile> {
	training?: { training: Rating[] };
	skills?: { skills: Rating[] };
	socials?: { socialMedia: SocialMediaValue[] };
	intro: {
		stageName?: StandardValue;
		biog?: StandardValue;
		role?: StandardValue;
		file?: {
			cv?: FileUpload;
			headshot?: FileUpload;
		}[];
		location?: {
			city: any;
			country: any;
		}[];
		playingAge?: {
			min?: any;
			max?: any;
		}[];
		availability?: StandardValue;
	};
	testimonials?: {
		testimonials?: Review[];
	};
	gallery?: {
		file?: GalleryFile[];
	};
	contacts?: {
		agentDetails?: Agency[];
	};
	blog?: {
		post?: Post[];
	};
}

interface CarouselImages {
	backgroundImage?: FileUpload;
	altText?: any;
	isFeatured: any;
}

interface ProducerProfile extends Profile<ProducerProfile> {
	brand?: {
		name?: {
			tradingName?: any;
			brandName?: any;
		}[];
		tagline?: StandardValue;
		graphics?: {
			logo?: FileUpload;
			icon?: FileUpload;
		}[];
	};
	sections?: {
		section?: Section[];
	};
	featuredImages?: {
		carousel?: CarouselImages[];
	};
	contact?: {
		address?: Address &
			{
				tel?: any;
				url?: any;
				spacer?: "";
			}[];
		socialMedia?: SocialMediaValue[];
	};
	productions?: {
		production?: {
			producer?: MongoDocumentResponse<ProducerProfile>[];
			production?: MongoDocumentResponse<ProductionProfile>[];
		}[];
	};
}

interface Award {
	organisation?: any;
	awardName?: any;
	isAwarded?: any;
	image?: FileUpload;
	year?: any;
}

interface Venue {
	ticketUrl?: any;
	venue?: {
		venue?: any;
		space?: any;
	}[];
	ticketAvailability?: any;
}

interface EventDates {
	starts?: any;
	ends?: any;
}

interface BasePerson extends Partial<MongoDocumentResponse<any>> {
	role?: any;
	department?: any;
	image?: FileUpload;
}

type Person<K extends string | number | symbol> = {
	[key in K]?: any;
} & BasePerson;

interface VenueAndDates extends Venue, EventDates {}
interface ProductionProfile extends Profile<ProducerProfile> {
	intro?: {
		name?: StandardValue;
		graphics?: {
			logo?: FileUpload;
			icon?: FileUpload;
		}[];
		teaser?: {
			text?: any;
			url?: any;
		}[];
		awards?: Award[];
	};
	faq?: {
		faq?: {
			type: any;
			question?: any;
			answer?: any;
		}[];
	};
	people?: {
		producers?: StandardValue;
		creatives?: Person<"creative">[];
		crew?: Person<"crew">[];
		cast?: Person<"performer">[];
	};
	sections?: { section: Section[] };
	calendar?: {
		datesandvenue?: VenueAndDates[];
	};
	featuredImages?: {
		carousel?: CarouselImages[];
	};
	attributes?: {
		attributes?: {
			triggerWarnings?: any;
			tickettcs?: any;
			type?: any;
			genre?: any;
			age?: any;
		}[];
	};
	contact?: {
		socialMedia?: SocialMediaValue[];
	};
	testimonials?: {
		testimonials?: Review[];
	};
}

export type {
	ActorProfile,
	Agency,
	Award,
	CarouselImages,
	FileUpload,
	GalleryFile,
	Person,
	Post,
	ProducerProfile,
	ProductionProfile,
	Profile,
	Rating,
	Review,
	Section,
	VenueAndDates,
	Website,
};
