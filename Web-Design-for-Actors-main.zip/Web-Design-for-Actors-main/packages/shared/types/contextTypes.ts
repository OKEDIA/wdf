// React Imports
import { ReactNode } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types
import { Auth } from "firebase/auth";
import { Tokens } from "next-firebase-auth-edge";
import { CustomerWithSession } from "@okedia/shared/stripe";
import { MongoDocumentResponse } from "./mongoTypes";
import { Profile } from "./profileTypes";
import { StateSetter } from "./stateTypes";
import { Website, WebsiteFormConfiguration } from "./websiteTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// USER CONTEXT
export interface ContextProps {
	children: ReactNode;
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// AUTH CONTEXT
export interface AuthContextValues {
	setters: AuthSettersType;
	states: AuthStatesType;
	authForClientSide: Auth;
	signOut: () => Promise<void>;
}

interface AuthSettersType {
	setAuthLoading: StateSetter<boolean>;
	setUserAuthData: StateSetter<Tokens | null>;
	setIsFormValidating: StateSetter<boolean>;
}

interface AuthStatesType {
	authLoading: boolean;
	userAuthData: Tokens | null;
	billingUserData: CustomerWithSession | undefined;
	isFormValidating: boolean;
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// WEBSITE CONTEXT
export interface WebsiteContextValues {
	setters: WebsiteSettersType;
	states: WebsiteStatesType;
	create: (values: Partial<Profile<unknown>>) => Promise<Profile<unknown>>;
	createWebsite: (
		values: Partial<Website<unknown>>,
		profileId: string
	) => Promise<Website<unknown>>;
	update: Function;
	updateProfile: Function;
	deleter: Function;
	getTypeData: Function;
}

interface WebsiteSettersType {
	setWebsites: StateSetter<any[]>;
	setProfiles: StateSetter<any[]>;
	setIsLoading: StateSetter<boolean>;
}

interface WebsiteStatesType {
	websites: MongoDocumentResponse<Website<any[]>>[];
	profiles: MongoDocumentResponse<Profile<any[]>>[];
	isLoading: boolean;
	typeData?: WebsiteFormConfiguration;
}
