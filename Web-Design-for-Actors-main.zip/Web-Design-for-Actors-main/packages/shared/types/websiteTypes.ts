// React Imports

import { CommonFormDataProps, FormValues, Input, Step } from "./formTypes";
import { FileUpload } from "./profile";

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export interface Website<T> extends FormValues {
	package: string;
	addons: {
		[key: string]: boolean;
	};
	type: string;
	status: string;
	domain: string;
	development?: boolean;
	cvViews: number;
	websiteViews: number;
	productId: Readonly<string>;
	subscriptionId: Readonly<string>;
	template: FormValues;
	searchEngine: FormValues;
	meta: FormValues;
	analytics: FormValues;
	profile: T;
	graphics?: {
		logo?: { icon?: FileUpload }[];
	};
}

export interface FormConfiguration {
	editorSteps: Step[];
	builderSteps: Step[];
	inputs: Input[];
	commonFormDataMap: CommonFormDataProps;
}

export interface WebsiteFormConfiguration extends FormConfiguration {
	data: { productId: string; tld: "wdfa.site" };
}

export interface ProfileFormConfiguration extends FormConfiguration {}

export interface FontsResponse {
	kind: "webfonts#webfontList";
	items?: {
		family: string;
		variants: string[];
		subsets: string[];
		version: string;
		lastModified: string;
		files: { [key: string]: string };
		category: string;
		kind: string;
		menu: string;
	}[];
}
