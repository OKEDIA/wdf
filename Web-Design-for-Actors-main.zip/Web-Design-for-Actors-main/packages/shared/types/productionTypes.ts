// React Imports

import { ObjectId } from "bson";

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export interface Production {
	id: string;
	websites: ObjectId[];
	owner: ObjectId;
	type: string;
	development: boolean;
}
