import { ObjectId } from "mongodb";
import { useRouter } from "next/navigation";
import { TransitionStartFunction } from "react";
import { AuthContextValues } from "./contextTypes";
import { MongoDocumentResponse } from "./mongoTypes";
import { Production } from "./productionTypes";
import { Profile } from "./profileTypes";
import { StateSetter } from "./stateTypes";
import { Website } from "./websiteTypes";

export interface AuthenticationState {
	setByEmail: StateSetter<boolean>;
	byEmail: boolean;
	router: ReturnType<typeof useRouter>;
	signInWithProvider: (provider: any) => Promise<void>;
	isPending: boolean;
	startTransition: TransitionStartFunction;
	params?: {
		[key: string]: string;
	};
}

export interface AuthenticationComponent {
	state: AuthenticationState;
	userContext: AuthContextValues;
}

export interface LocalUser {
	firebaseUID: string;
	websites?: ObjectId[] | MongoDocumentResponse<Website<unknown>[]>;
	profiles?: ObjectId[] | MongoDocumentResponse<Profile<unknown>[]>;
	productions?: ObjectId[] | Production[];
}

export interface CookieAcceptance {}
