// React Imports

import { ObjectId } from "mongodb";
import { CommonFormDataProps } from "./formTypes";

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export interface Profile<T> {
	websites?: T | ObjectId[];
	messages?: ObjectId[];
	type: string;
	development: boolean;
	commonFormDataValues: CommonFormDataProps;
}

export interface Actor {}
export interface Producer {}
export interface Theatre {}
export interface Production {}

export interface MongoUser {
	firebaseUID: string;
	websites?: ObjectId[];
	profiles?: ObjectId[];
}
