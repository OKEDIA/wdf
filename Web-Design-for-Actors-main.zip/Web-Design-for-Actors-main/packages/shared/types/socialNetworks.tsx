import backstage from "@okedia/shared/images/socialNetworks/backstage.png";
import castingNetworks from "@okedia/shared/images/socialNetworks/castingnetworks.png";
import fb from "@okedia/shared/images/socialNetworks/facebook.png";
import iActor from "@okedia/shared/images/socialNetworks/iactor.png";
import imdbpro from "@okedia/shared/images/socialNetworks/imdb.png";
import instagram from "@okedia/shared/images/socialNetworks/instagram.png";
import mandy from "@okedia/shared/images/socialNetworks/mandy.png";
import spotlight from "@okedia/shared/images/socialNetworks/spotlight.png";
import starnow from "@okedia/shared/images/socialNetworks/starnow.png";
import tiktok from "@okedia/shared/images/socialNetworks/tiktok.png";
import x from "@okedia/shared/images/socialNetworks/x.png";
import youtube from "@okedia/shared/images/socialNetworks/youtube.png";

export const socialNetworks = {
	facebook: {
		base_uri: "https://www.facebook.com/",
		short: "FB",
		full: "Facebook",
		icon: fb,
		color: "#316FF6",
	},
	mandy: {
		base_uri: "https://mandy.com/",
		short: "M",
		full: "Mandy",
		icon: mandy,
		color: "#48c8af",
	},
	spotlight: {
		base_uri: "https://spotlight.com/",
		short: "S",
		full: "Spotlight",
		icon: spotlight,
		color: "#fff",
	},
	starnow: {
		base_uri: "https://starnow.com/",
		short: "Sn",
		full: "Starnow",
		icon: starnow,
		color: "#6aae14",
	},
	castingNetworks: {
		base_uri: "https://www.castingnetworks.com/",
		short: "cN",
		full: "Casting Networks",
		color: "#89AAB1",
		icon: castingNetworks,
	},
	backstage: {
		base_uri: "https://www.backstage.com/",
		short: "B",
		full: "Backstage",
		color: "#000",
		icon: backstage,
	},
	iActor: {
		base_uri: "https://www.iactor.com/",
		short: "iA",
		full: "iActor",
		color: "#fed100",
		icon: iActor,
	},
	imdbpro: {
		base_uri: "https://pro.imdb.com/",
		short: "iMP",
		full: "iMDBPRO",
		color: "#03abd2",
		icon: imdbpro,
	},
	x: {
		base_uri: "https://x.com/",
		short: "X",
		full: "X",
		icon: x,
		color: "#0f1419",
	},
	instagram: {
		base_uri: "https://instagram.com/",
		short: "IG",
		full: "Instagram",
		icon: instagram,
		color: "#d300c5",
	},
	youtube: {
		base_uri: "https://youtube.com/",
		short: "Yt",
		full: "Youtube",
		icon: youtube,
		color: "#FF0033",
	},
	tiktok: {
		base_uri: "https://tiktok.com/@",
		short: "TT",
		full: "TikTok",
		color: "#69C9D0",
		icon: tiktok,
	},
};
