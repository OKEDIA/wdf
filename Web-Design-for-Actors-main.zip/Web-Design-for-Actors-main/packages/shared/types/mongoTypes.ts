import { ObjectId, OptionalId } from "mongodb";

export interface MongoDocumentProps<T> {
	collectionName: string;
	documentName?: string;
	body?: OptionalId<T>;
}

export type MongoDocumentResponse<T> = T & {
	id: ObjectId | string;
	_id: Readonly<ObjectId>;
	created: Readonly<Date>;
	updated?: Date;
	permissions?: MongoDocumentPermissions;
};

export type MongoDocumentPermissions = {
	creator: ObjectId | string;
	owners: ObjectId[] | string[];
	editors: ObjectId[] | string[];
	claimed: {
		date: Date;
	};
};

export type PipelineStage =
	| { $match?: Record<string, any> }
	| {
			$lookup?: LookupProps;
	  }
	| {
			$unwind?: string | { path: string; preserveNullAndEmptyArrays?: boolean };
	  }
	| { $sort?: Record<string, 1 | -1> }
	| { $limit?: number }
	| { $skip?: number };

export interface LookupProps {
	from: string;
	localField: string;
	foreignField: string;
	as: string;
	pipeline?: PipelineStage[];
}
