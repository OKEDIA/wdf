// React Imports

// Next.js Imports

// Firebase Imports

// Helpers
import { format } from "date-fns";
import { isProductionEnvironment } from "@okedia/shared/helpers";

// Other libraries or utilities

import pino, { Logger } from "pino";
import pretty from "pino-pretty";
import { generateApiResponse } from "../helpers";

// Types
import { Tokens } from "next-firebase-auth-edge";
import type { NextRequest, NextResponse } from "next/server";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export interface ErrorProps {
	user?: Partial<Tokens> | null;
	error?: Partial<Error>;
	response?: {
		body?: any;
		status?: number;
		instance: typeof NextResponse;
		message?: string;
	};
	request?: NextRequest;
}
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
const COLOR = {
	RESET: "\x1b[0m",
	BLACK: "\x1b[30m",
	RED: "\x1b[31m",
	GREEN: "\x1b[32m",
	YELLOW: "\x1b[33m",
	BLUE: "\x1b[34m",
	MAGENTA: "\x1b[35m",
	CYAN: "\x1b[36m",
	WHITE: "\x1b[37m",
};

function getLevelColor(level: string): string {
	switch (level) {
		case "ERROR":
			return COLOR.RED;
		case "WARN":
			return COLOR.YELLOW;
		case "INFO":
			return COLOR.GREEN;
		case "DEBUG":
			return COLOR.BLUE;
		default:
			return COLOR.WHITE;
	}
}

const stream =
	process.env.NEXT_RUNTIME === "nodejs"
		? pretty({
				colorize: true,
				messageFormat: `[{group}] {msg}`,
				hideObject: false, // Ensure objects are not hidden
				ignore: `pid,hostname`,
		  })
		: undefined;

const defaultConfig = {
	browser: {
		write: (logObj: unknown) => {
			const { level, msg, group, time, icon, ...context } = logObj as Record<
				string,
				string
			>;
			const levelUppercased = level.toUpperCase();
			const timeFormatted = format(new Date(time), `HH:mm:ss.sss`);
			const levelColor = getLevelColor(levelUppercased);

			!isProductionEnvironment &&
				console.log(
					"[DEV NOTICE]: Logging next item from Edge Runtime / Browser Config"
				);
			console.log(
				`[${timeFormatted}] ${levelColor}${levelUppercased} ${COLOR.CYAN}[${icon} ${group}] ${msg} ${COLOR.WHITE}`
			);
		},
		formatters: {
			level: (label: string) => ({ level: label }),
		},
		level: isProductionEnvironment ? "info" : "debug",
	},
	level: isProductionEnvironment ? "info" : "debug",
};

export const logger: Logger = pino(
	{
		...(process.env.NEXT_RUNTIME === "nodejs" ? defaultConfig : defaultConfig),
	},
	stream
);

function getLoggingInstance(status = 520) {
	if (status >= 200 && status < 300) {
		// Success range
		return { toConsole: console.log, toPino: logger.info.bind(logger) };
	} else if (status >= 400 && status < 500) {
		// Client error range
		return {
			toConsole: console.warn,
			toPino: logger.warn.bind(logger),
		};
	} else if (status >= 500 && status < 600) {
		// Server error range
		return {
			toConsole: console.error,
			toPino: logger.error.bind(logger),
		};
	} else {
		// Unexpected error
		return {
			toConsole: console.error,
			toPino: logger.fatal.bind(logger),
		};
	}
}

export async function handleError({
	error,
	response,
	request,
	user,
}: ErrorProps) {
	// Handle API Errors
	if (response?.instance) {
		const responseToSend = generateApiResponse(
			response?.instance,
			response?.status ?? 520,
			response?.message
		);
		const loggerMessage = `Error: ${responseToSend.status} - ${
			responseToSend.statusText
		}: ${response.message || error?.message}`;
		const logger = getLoggingInstance(responseToSend.status);
		logger.toPino(
			{
				request: {
					requestUrl: request?.nextUrl.href,
					requestMethod: request?.method,
					requestHeaders: request?.headers,
					requestBody: request?.body,
				},
				response: {
					responseBody: responseToSend.body,
					responseStatus: responseToSend.status,
					responseHeaders: responseToSend.headers,
					responseStatusText: responseToSend.statusText,
				},
				user: {
					localUID: user?.decodedToken?.localUID,
					isAdmin: user?.decodedToken?.isAdmin,
					isDeveloper: user?.decodedToken?.isDeveloper,
					email: user?.decodedToken?.email,
					uid: user?.decodedToken?.uid,
				},
				error: {
					message: error?.message,
					stack: error?.stack,
					name: error?.name,
				},
			},
			loggerMessage
		);

		return responseToSend;
	} else {
		const loggerMessage = `Error: ${error?.message}`;
		const logger = getLoggingInstance(200);

		logger.toPino(
			{
				request: {
					requestUrl: request?.nextUrl.href,
					requestMethod: request?.method,
					requestHeaders: request?.headers,
					requestBody: request?.body,
				},
				user: {
					localUID: user?.decodedToken?.localUID,
					isAdmin: user?.decodedToken?.isAdmin,
					isDeveloper: user?.decodedToken?.isDeveloper,
					email: user?.decodedToken?.email,
					uid: user?.decodedToken?.uid,
				},
				error: {
					message: error?.message,
					stack: error?.stack,
					name: error?.name,
				},
			},
			loggerMessage
		);
	}
}
