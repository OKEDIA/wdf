// React Imports

import { Tokens } from "next-firebase-auth-edge";
import { NextRequest } from "next/server";
import { ErrorProps, handleError, logger } from "../logger";

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// Must not be added to a barrel file as it will cause tree shaking issues due to checkUserAuthentication
export async function apiLogging(request: NextRequest, user?: Tokens | null) {
	const thisUser = user;

	logger.info(
		`[${request.method}] ${request.nextUrl.pathname} from ${
			user?.decodedToken.email ?? "Unknown User"
		}`
	);

	return {
		error: ({
			user,
			error,
			response,
		}: Pick<ErrorProps, "error" | "user" | "response">) =>
			handleError({ request, response, user: user || thisUser, error }),

		custom: logger,
	};
}
