import "server-only";

// React Imports

// Next.js Imports

// Firebase Imports

// Helpers
import { SES } from "aws-sdk";
import { existsSync, readdirSync, readFileSync } from "fs";
import Handlebars from "handlebars";
import { htmlToText } from "html-to-text";
import { logger } from "@okedia/shared/logging";
import path from "path";
// Other libraries or utilities

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export const ses = new SES({
	region: "eu-west-2",
	credentials: {
		accessKeyId: process.env.AWS_ACCESS_KEY_ID as string,
		secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY as string,
	},
});

export async function sendEmail({
	to,
	from,
	subject,
	message,
}: {
	to: string;
	from: string;
	subject: string;
	message: { html?: string; text?: string };
}) {
	logger.debug("Sending an email!");

	if (!message.text && !message.html) {
		return logger.error(
			{ to, from, subject, message },
			"No message content provided"
		);
	}

	const params = {
		Source: from,
		Destination: { ToAddresses: [to] },
		Message: {
			Subject: { Data: subject },
			Body: {
				...(message.text ? { Text: { Data: message.text } } : ""),
				...(message.html ? { Html: { Data: message.html } } : ""),
			},
		},
	};

	try {
		const result = ses.sendEmail(params);
		logger.debug(result, "Email sent successfully");

		return result.promise();
	} catch (error) {
		logger.error(error, "Error sending an email via AWS SES");
		throw error;
	}
}

export const loadEmailTemplate = (filename: string): string => {
	// Adjust the path to match where you've stored the HTML templates inside your Next.js directory
	const filePath = path.join(
		process.cwd(),
		"src/emails/authentication/passwordresetlink.mjml"
	);
	console.warn("Current working directory:", process.cwd());

	const entries = readdirSync(process.cwd(), { withFileTypes: true });

	console.warn("Contents of process.cwd():");
	entries.forEach((entry) => {
		const type = entry.isDirectory() ? "📁" : "📄";
		console.warn(`${type} ${entry.name}`);
	});

	console.warn("Reading from:", filePath);
	console.warn("Exists?", existsSync(filePath));
	logger.warn(`READING FILE: ${filePath}`);
	const file = readFileSync(filePath, { encoding: "utf8" });
	logger.warn(file);

	return file;
};

export async function generateEmailTemplate({
	templateFile,
	dynamicData,
}: {
	templateFile: string;
	dynamicData?: object;
}) {
	try {
		// Step 1: Load the Email Template
		logger.debug({ templateFile, dynamicData }, "Loading email template");

		// Step 2: Compile the MJML template with Handlebars
		logger.debug({ templateFile }, "Compiling email template");
		const template = Handlebars.compile(templateFile);

		// Step 3: Render the template with dynamic data
		logger.debug(
			{ dynamicData },
			"Rendering email template with dynamic data, if any"
		);
		const renderedTemplate = template(dynamicData || {});

		// Step 5: Return the HTML and Text Versions
		const textVersion = htmlToText(renderedTemplate, {
			wordwrap: 130,
		});

		logger.debug(
			{ renderedTemplate, textVersion },
			"Done Generating email template"
		);

		return {
			html: renderedTemplate,
			text: textVersion,
		};
	} catch (error) {
		logger.error(error, "Error generating email template:");
		throw error;
	}
}
