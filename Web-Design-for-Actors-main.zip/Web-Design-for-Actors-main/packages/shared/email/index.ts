export { generateEmailTemplate, sendEmail, ses } from "./admin";
