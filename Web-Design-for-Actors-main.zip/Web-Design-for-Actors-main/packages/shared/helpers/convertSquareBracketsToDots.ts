export function convertSquareBracketsToDots(field: string): string {
	// Replace occurrences of [0] with .0
	// Example use is to convert "field[0].name" to "field.0.name" for mongoDB-friendly queries

	return field.replace(/\[(\d+)]/g, ".$1");
}
