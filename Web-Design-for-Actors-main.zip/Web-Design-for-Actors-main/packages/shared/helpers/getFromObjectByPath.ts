/**
 * Retrieves a value from an object using a dot notation string path.
 *
 * @param o - The object to retrieve the value from.
 * @param s - The dot notation string path to the desired value.
 * @returns The value at the specified path, or `undefined` if the path does not exist.
 */

export function getFromObjectByPath(o: object, s: string | string[]): any {
	if (Array.isArray(s)) {
		// If `s` is an array, recursively get values for each path
		return s.map((path) => getFromObjectByPath(o, path));
	}

	if (typeof s !== "string") return undefined; // Guard against invalid input

	// Convert array-style notation like "stageName[0]" -> "stageName.0"
	s = s.replace(/\[(\d+)\]/g, ".$1").replace(/^\./, "");
	const a = s.split(".");

	for (let i = 0, n = a.length; i < n; ++i) {
		const k = a[i];
		if (isObject(o) && k in o) {
			o = (o as any)[k];
		} else if (Array.isArray(o) && !isNaN(Number(k))) {
			o = o[Number(k)];
		} else {
			return undefined;
		}
	}
	return o;
}

function isObject(obj: any): boolean {
	return obj !== null && typeof obj === "object" && !Array.isArray(obj);
}
