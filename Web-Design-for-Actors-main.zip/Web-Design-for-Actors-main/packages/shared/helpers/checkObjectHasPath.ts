export function checkObjectHasPath(o: object, s: string): boolean {
	s = s.replace(/\[(\d+)\]/g, ".$1");
	s = s.replace(/^\./, "");
	const a = s.split(".");
	for (let i = 0, n = a.length; i < n; ++i) {
		const k = a[i];
		if (isObject(o) && k in o) {
			o = (o as any)[k];
		} else if (Array.isArray(o) && !isNaN(Number(k))) {
			o = o[Number(k)];
		} else {
			return false;
		}
	}
	return true;
}

function isObject(obj: any): boolean {
	return obj !== null && typeof obj === "object" && !Array.isArray(obj);
}
