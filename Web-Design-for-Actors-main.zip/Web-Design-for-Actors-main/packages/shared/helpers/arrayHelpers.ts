// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Removes an item from the specified index in an array.
 *
 * @template T - The type of elements in the array.
 * @param {T[]} array - The array from which to remove the item.
 * @param {number} index - The index of the item to remove.
 * @returns {T[]} A new array with the item removed.
 * @throws {Error} If the index is out of bounds.
 */
function removeItemAtIndex<T>(array: T[], index: number): T[] {
	// Remove an Item at an Index
	if (index < 0 || index >= array.length) {
		throw new Error("Index out of bounds");
	}
	return [...array.slice(0, index), ...array.slice(index + 1)];
}

/**
 * Finds the index of the first object in an array that contains a specified key-value pair.
 *
 * @template T - The type of objects in the array. Each object must have string keys and any type of values.
 * @param {T[]} array - The array of objects to search through.
 * @param {string} key - The key to look for in each object.
 * @param {any} value - The value to match against the specified key.
 * @returns {number} - The index of the first object that matches the key-value pair, or -1 if no match is found.
 */
function findIndexByKeyValue<T extends { [key: string]: any }>(
	array: T[],
	key: string,
	value: any
) {
	// Find the index of the object with the specified key:value pair
	return array.findIndex((item) => item[key] === value);
}

function addToObjectAtPath(obj: Record<any, any>, path: string, value: any) {
	const pathArray = path.split(/[\.\[\]]/).filter(Boolean); // Split the path into an array, handling brackets

	// Traverse and create necessary objects along the path
	let current = obj;
	for (let i = 0; i < pathArray.length; i++) {
		const key = pathArray[i];

		// If we are at the last part of the path, set the value
		if (i === pathArray.length - 1) {
			// If the key doesn't exist, initialize it as an array or object depending on value
			if (Array.isArray(current[key])) {
				current[key].push(value);
			} else if (typeof current[key] === "object" && current[key] !== null) {
				current[key] = value;
			} else {
				current[key] = value;
			}
		} else {
			// Create an empty object or array if not already existing
			if (!current[key]) {
				current[key] = isNaN(Number(pathArray[i + 1])) ? {} : [];
			}
		}
		current = current[key];
	}
	return obj;
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

const arrayHelpers = {
	remove: {
		atIndex: removeItemAtIndex,
	},
	find: {
		index: findIndexByKeyValue,
	},
	add: {
		toObjectAtPath: addToObjectAtPath,
	},
};

export default arrayHelpers;
