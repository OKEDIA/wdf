// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Extracts and returns a human-readable error message from an unknown error object.
 *
 * @param error - The error object from which to extract the message. This can be of any type.
 * @returns A string representing the error message. If the error object is an instance of `Error`,
 *          the message property is returned. If the error object has a `message` property, that
 *          property is returned as a string. If the error is a string, it is returned directly.
 *          Otherwise, a default message "Unknown Error. Unable to find Error Message." is returned.
 */
export default function getErrorMessage(error: unknown): string {
	let message: string;

	if (error instanceof Error) {
		message = error.message;
	} else if (error && typeof error === "object" && "message" in error) {
		message = String(error.message);
	} else if (typeof error === "string") {
		message = error;
	} else {
		message = "Unknwon Error. Unable to find Error Message.";
	}

	return message;
}
