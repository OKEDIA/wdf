/**
 * A boolean flag indicating whether the current environment is a production environment.
 *
 * This flag is determined based on the value of the `NODE_ENV` environment variable.
 * If `NODE_ENV` is not set to "development", this flag will be `true`, indicating a production environment.
 * Otherwise, it will be `false`, indicating a development environment.
 */
export const isProductionEnvironment: boolean =
	process.env.NEXT_PUBLIC_VERCEL_TARGET_ENV !== "development";
