interface RemoveAllAfterCharacterProps {
	str: string;
	charToSplit: string;
}

/**
 * Removes all characters in the given string after the specified character.
 *
 * @param {Object} props - The properties object.
 * @param {string} props.str - The string to process.
 * @param {string} props.charToSplit - The character after which all characters will be removed.
 * @returns {string} - The resulting string with all characters after the specified character removed.
 */
export function removeAllAfterCharacter({
	str,
	charToSplit,
}: RemoveAllAfterCharacterProps): string {
	return str.split(charToSplit)[0];
}
