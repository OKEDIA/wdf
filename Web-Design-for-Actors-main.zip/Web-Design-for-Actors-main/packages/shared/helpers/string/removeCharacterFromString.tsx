interface RemoveCharacterFromStringProps {
	str: string;
	charToRemove: string;
}

/**
 * Removes all occurrences of a specified character from a given string.
 *
 * @param {Object} props - The properties object.
 * @param {string} props.str - The string from which the character will be removed.
 * @param {string} props.charToRemove - The character to remove from the string.
 * @returns {string} - The resulting string with the specified character removed.
 */
export function removeCharacterFromString({
	str,
	charToRemove,
}: RemoveCharacterFromStringProps): string {
	return str.split(charToRemove).join("");
}
