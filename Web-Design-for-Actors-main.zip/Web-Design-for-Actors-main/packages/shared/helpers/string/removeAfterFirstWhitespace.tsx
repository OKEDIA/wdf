/**
 * Removes the substring after the first whitespace character in the given string.
 *
 * @param str - The input string from which to remove the substring after the first whitespace. Defaults to an empty string.
 * @returns The substring before the first whitespace character, or the entire string if no whitespace is found.
 */
export function removeAfterFirstWhitespace(str: string = ""): string {
	const index = str.indexOf(" ");
	return index === -1 ? str : str.substring(0, index);
}
