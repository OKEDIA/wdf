import createDOMPurify from "dompurify";
import { deepHtmlStrip, deepSanitize } from "../sanitiseUtils";

export function sanitiseHtml(html: any) {
	if (typeof window !== "undefined") {
		// Client-side: Use DOMPurify directly
		const DOMPurify = createDOMPurify(window);

		// Hook to allow only safe YouTube iframes
		DOMPurify.addHook("uponSanitizeElement", (node, data) => {
			if (data.tagName === "iframe") {
				const src = (node as HTMLElement).getAttribute("src") || "";

				if (
					src.startsWith("https://www.youtube.com/embed/") ||
					src.startsWith("https://www.youtube-nocookie.com/embed/")
				) {
					(node as HTMLElement).setAttribute("allowfullscreen", "true");
				} else {
					node.parentNode?.removeChild(node); // Remove unsafe iframes
				}
			}
		});

		return DOMPurify.sanitize(html, {
			USE_PROFILES: { html: true },
			ADD_TAGS: ["iframe"],
			ADD_ATTR: [
				"width",
				"height",
				"allowfullscreen",
				"src",
				"frameborder",
				"autoplay",
				"controls",
				"loop",
				"modestbranding",
				"rel",
				"start",
				"end",
			],
		});
	}

	// Server-side: Dynamically import `jsdom` (avoids bundling issues)
	const { JSDOM } = require("jsdom");
	const DOMPurify = createDOMPurify(new JSDOM("").window);

	// Apply the same iframe allowance on the server
	DOMPurify.addHook("uponSanitizeElement", (node, data) => {
		if (data.tagName === "iframe") {
			const src = (node as HTMLElement).getAttribute("src") || "";

			if (
				src.startsWith("https://www.youtube.com/embed/") ||
				src.startsWith("https://www.youtube-nocookie.com/embed/")
			) {
				(node as HTMLElement).setAttribute("allowfullscreen", "true");
			} else {
				node.parentNode?.removeChild(node);
			}
		}
	});

	return deepSanitize(html, DOMPurify);
}

export function stripHTML(html: any) {
	return sanitiseHtml(deepHtmlStrip(html)); // Removes all HTML tags
}
