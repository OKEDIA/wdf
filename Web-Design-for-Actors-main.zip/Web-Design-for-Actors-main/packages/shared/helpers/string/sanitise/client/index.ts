"use client";
// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities
import DOMPurify from "isomorphic-dompurify";
import { deepHtmlStrip, deepSanitize } from "../sanitiseUtils";

// Types

export function sanitiseHtml(html: any) {
	// Hook to allow only safe YouTube iframes
	DOMPurify.addHook("uponSanitizeElement", (node, data) => {
		if (data.tagName === "iframe") {
			const src = (node as HTMLElement).getAttribute("src") || "";

			if (
				src.startsWith("https://www.youtube.com/embed/") ||
				src.startsWith("https://www.youtube-nocookie.com/embed/")
			) {
				(node as HTMLElement).setAttribute("allowfullscreen", "true");
			} else {
				node.parentNode?.removeChild(node); // Remove unsafe iframes
			}
		}
	});

	return deepSanitize(html, DOMPurify);
}

export function stripHTML(html: any) {
	return sanitiseHtml(deepHtmlStrip(html)); // Removes all HTML tags
}
