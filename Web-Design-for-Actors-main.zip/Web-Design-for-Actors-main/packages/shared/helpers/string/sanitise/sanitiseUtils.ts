import { DOMPurify } from "dompurify";

export function deepSanitize(item: any, DOMPurify: DOMPurify): any {
	if (typeof item === "string") {
		// Hook to allow only safe YouTube iframes
		DOMPurify.addHook("uponSanitizeElement", (node, data) => {
			if (data.tagName === "iframe") {
				const src = (node as HTMLElement).getAttribute("src") || "";

				if (
					src.startsWith("https://www.youtube.com/embed/") ||
					src.startsWith("https://www.youtube-nocookie.com/embed/")
				) {
					(node as HTMLElement).setAttribute("allowfullscreen", "true");
				} else {
					node.parentNode?.removeChild(node); // Remove unsafe iframes
				}
			}
		});

		return DOMPurify.sanitize(item, {
			USE_PROFILES: { html: true },
			ADD_TAGS: ["iframe"],
			ADD_ATTR: [
				"width",
				"height",
				"allowfullscreen",
				"src",
				"frameborder",
				"autoplay",
				"controls",
				"loop",
				"modestbranding",
				"rel",
				"start",
				"end",
			],
		});
	}

	if (Array.isArray(item)) {
		return item.map((entry) => deepSanitize(entry, DOMPurify));
	}

	if (item && typeof item === "object") {
		const sanitizedObj: Record<string, any> = {};
		for (const key in item) {
			if (Object.prototype.hasOwnProperty.call(item, key)) {
				sanitizedObj[key] = deepSanitize(item[key], DOMPurify);
			}
		}
		return sanitizedObj;
	}

	return item;
}

export function deepHtmlStrip(item: any): any {
	const regex = /<[^>]+>/g; // Matches any HTML tags
	if (typeof item === "string") {
		return item?.replace(regex, "");
	}

	if (Array.isArray(item)) {
		return item.map((entry) => deepHtmlStrip(entry));
	}

	if (item && typeof item === "object") {
		const sanitizedObj: Record<string, any> = {};
		for (const key in item) {
			if (Object.prototype.hasOwnProperty.call(item, key)) {
				sanitizedObj[key] = deepHtmlStrip(item[key]);
			}
		}
		return sanitizedObj;
	}

	return item;
}
