/**
 * Formats a private key by replacing escaped newline characters with actual newline characters.
 *
 * @param {string} [key=""] - The private key string to format. Defaults to an empty string.
 * @returns {string} - The formatted private key with actual newline characters.
 */
export function formatPrivateKey(key: string = ""): string {
	return key.replace(/\\n/g, "\n");
}
