/**
 * Converts a given string into a URL-friendly slug and ensures uniqueness
 * by appending a numeric suffix if duplicates exist in the provided entries.
 *
 * @param input - The input string to be converted into a slug.
 * @param existingEntries - An array of existing entries to check for duplicate slugs.
 * Each entry is expected to have a `name` property used for comparison.
 *
 * @returns A unique slug string derived from the input.
 *
 * @example
 * const entries = [{ name: "Example Entry" }, { name: "Example Entry" }];
 * const slug = convertStringToSlug("Example Entry", entries);
 * console.log(slug); // Outputs: "example-entry-2"
 */
export function convertStringToSlug(
	input: string,
	existingEntries: any[]
): string {
	const slug = input
		.toLowerCase()
		.replace(/[^a-z0-9]+/g, "-")
		.replace(/^-+|-+$/g, "");

	const duplicateCount = existingEntries.filter((entry: any) => {
		const entrySlug = entry.name
			.toLowerCase()
			.replace(/[^a-z0-9]+/g, "-")
			.replace(/^-+|-+$/g, "");
		return entrySlug === slug || entrySlug.startsWith(`${slug}-`);
	}).length;

	return duplicateCount > 1 ? `${slug}-${duplicateCount}` : slug;
}
