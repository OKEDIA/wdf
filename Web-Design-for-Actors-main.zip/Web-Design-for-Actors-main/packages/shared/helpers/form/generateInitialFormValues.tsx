// Types
import {
	FieldComponent,
	FormValues,
	Input,
} from "@okedia/shared/types/formTypes";

interface GenerateInitialFormValuesProps {
	formFields: Input[];
	websiteData?: FormValues;
	testValues?: boolean;
	generateEmpty?: boolean;
}

export default function generateInitialFormValues({
	formFields,
	websiteData,
	testValues,
	generateEmpty,
}: GenerateInitialFormValuesProps) {
	const initialValues = {} as FormValues;

	if (testValues) {
		return {
			template: { colorScheme: [{ value: undefined }] },
			intro: {
				stageName: [{ value: undefined }],
				biog: [{ value: undefined }],
				file: [{ cv: undefined, headshot: undefined }],
				location: [{ city: undefined, country: undefined }],
				role: [{ value: undefined }],
				playingAge: [{ min: undefined, max: undefined }],
				availability: [{ value: undefined }],
			},
			socials: {
				facebook: [{ value: undefined }],
				twitter: [{ value: undefined }],
				instagram: [{ value: undefined }],
			},
			skills: { skills: [{ title: undefined, value: undefined }] },
			training: { training: [{ title: undefined, value: undefined }] },
			gallery: {
				file: [{ name: undefined, category: undefined, upload: undefined }],
			},
			productions: {
				productions: [
					{
						productionName: undefined,
						slug: undefined,
						thumbnail: undefined,
						coverImg: undefined,
						cast: [{ name: undefined, role: null }],
						venue: [{ venueName: null, space: null }],
					},
				],
			},
			contact: { contactText: [{ value: undefined }] },
		} as FormValues;
	} else {
		if (!formFields) {
			console.error("No Form Configuration Provided to useForm");
			return;
		}

		const processFieldComponents = (
			fieldComponents: FieldComponent[],
			fieldValuesArray: any[] = []
		) => {
			const sortedFields = fieldComponents.sort((a, b) => {
				const aWeight = a.inputWeight ?? 999;
				const bWeight = b.inputWeight ?? 999;
				return aWeight - bWeight;
			});

			return fieldValuesArray.map((fieldValues) => {
				const newFieldValues = {} as any;

				sortedFields.forEach((fieldConfig) => {
					const key = fieldConfig.id ?? "value";
					let value = fieldValues[key] ?? null; // Default value if missing

					// Handle nested components properly
					if (fieldConfig.fieldComponents) {
						const nestedValues = Array.isArray(value) ? value : [{}];
						value = processFieldComponents(
							fieldConfig.fieldComponents,
							nestedValues
						);
					}

					newFieldValues[key] = value;
				});

				return newFieldValues;
			});
		};

		formFields.forEach((field) => {
			const group: string = field.inputGroup;
			const id: string = field.id;

			if (!initialValues[group]) {
				initialValues[group] = {};
			}

			initialValues[group][id] = [];

			if (
				websiteData &&
				websiteData[group] &&
				websiteData[group][id] &&
				generateEmpty !== true
			) {
				const fieldValuesArray = websiteData[group][id];
				initialValues[group][id] = processFieldComponents(
					field.fieldComponents,
					fieldValuesArray
				);
			} else {
				const keyValuesObject = {} as any;
				field.fieldComponents.forEach((fieldComponent: FieldComponent) => {
					const key = fieldComponent.id ?? "value";
					keyValuesObject[key] = "";

					if (fieldComponent.fieldComponents) {
						keyValuesObject[key] = processFieldComponents(
							fieldComponent.fieldComponents,
							[{}]
						);
					}
				});
				initialValues[group][id].push(keyValuesObject);
			}
		});
		return initialValues;
	}
}
