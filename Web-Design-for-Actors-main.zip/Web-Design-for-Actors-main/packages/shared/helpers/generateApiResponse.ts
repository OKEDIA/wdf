// React Imports

import { NextResponse } from "next/server";

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities

// Types

interface HttpStatus {
	status: number;
	statusText: string;
	description?: string;
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

const statusCodeMap: Record<number, HttpStatus> = {
	"100": {
		status: 100,
		statusText: "Continue",
		description:
			"The server has received the request headers, and the client should proceed to send the request body.",
	},
	"200": {
		status: 200,
		statusText: "OK",
		description:
			"The request is OK (this is the standard response for successful HTTP requests).",
	},
	"201": {
		status: 201,
		statusText: "Created",
		description:
			"The request has been fulfilled, and a new resource is created.",
	},
	"204": {
		status: 204,
		statusText: "No Content",
		description:
			"The request has been successfully processed, but is not returning any content.",
	},
	"301": {
		status: 301,
		statusText: "Moved Permanently",
		description: "The requested page has moved to a new URL.",
	},
	"302": {
		status: 302,
		statusText: "Found",
		description: "The requested page has moved temporarily to a new URL.",
	},
	"400": {
		status: 400,
		statusText: "Bad Request",
		description: "The request cannot be fulfilled due to bad syntax.",
	},
	"401": {
		status: 401,
		statusText: "Unauthorized",
		description:
			"The request was a legal request, but the server is refusing to respond to it. For use when authentication is possible but has failed or not yet been provided.",
	},
	"403": {
		status: 403,
		statusText: "Forbidden",
		description:
			"The request was a legal request, but the server is refusing to respond to it.",
	},
	"404": {
		status: 404,
		statusText: "Not Found",
		description:
			"The requested page could not be found but may be available again in the future.",
	},
	"405": {
		status: 405,
		statusText: "Method Not Allowed",
		description:
			"A request was made of a page using a request method not supported by that page.",
	},
	"429": {
		status: 429,
		statusText: "Too Many Requests",
		description:
			"The user has sent too many requests in a given amount of time. Intended for use with rate limiting schemes.",
	},
	"500": {
		status: 500,
		statusText: "Internal Server Error",
		description:
			"An error has occurred in a server side script, a no more specific message is suitable.",
	},
	"501": {
		status: 501,
		statusText: "Not Implemented",
		description:
			"The server either does not recognize the request method, or it lacks the ability to fulfill the request.",
	},
	"502": {
		status: 502,
		statusText: "Bad Gateway",
		description:
			"The server was acting as a gateway or proxy and received an invalid response from the upstream server.",
	},
	"503": {
		status: 503,
		statusText: "Service Unavailable",
		description: "The server is currently unavailable (overloaded or down).",
	},
	"520": {
		status: 520,
		statusText: "Unknown Error",
		description:
			'The 520 error is used as a "catch-all response for when the origin server returns something unexpected", listing connection resets, large headers, and empty or invalid responses as common triggers.',
	},
	// Full list available at https://status.js.org/codes.json
};

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Generates a JSON response based on the provided status code and data.
 *
 * @param res - The response object to send the JSON response.
 * @param statusCode - The HTTP status code to determine the response structure.
 * @param data - Optional data to include in the response.
 *
 * @returns The JSON response with the appropriate structure based on the status code.
 *
 * The function handles different ranges of status codes:
 * - 2xx: Success responses with the provided data.
 * - 4xx: Client error responses with an optional message.
 * - 5xx: Server error responses with an optional message.
 *
 * If the status code is not recognized, it returns a default error response.
 */
export function generateApiResponse(
	res: typeof NextResponse,
	statusCode: number,
	data?: any
) {
	const result = statusCodeMap[statusCode];

	if (!result) {
		return res.json(
			{
				success: false,
				message: "The error code provided was not an expected option.",
			},
			{
				status: statusCode,
				statusText: data,
			}
		);
	}

	if (result.status >= 200 && result.status < 300) {
		return res.json(
			{
				success: true,
				response: data?.response ? data.response : data ?? undefined,
			},
			{ ...result }
		);
	}

	if (result.status >= 400 && result.status < 500) {
		return res.json(
			{ success: false, message: data ?? result.statusText },
			{ ...result }
		);
	}

	if (result.status >= 500) {
		return res.json(
			{ success: false, message: data ?? result.statusText },
			{ ...result }
		);
	}

	return res.json(
		{
			success: false,
			message: "Could not generate a http response, or use the default.",
		},
		{
			status: 500,
			statusText: "Unexpected error",
		}
	);
}
