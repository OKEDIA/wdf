// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Checks if a value is considered empty.
 *
 * This function recursively checks if a given value is empty. It handles strings, arrays,
 * objects, and array-like objects. For arrays, it checks if all items are empty. For objects,
 * it checks if all values are empty. A value is considered empty if it is null, undefined,
 * or an empty string.
 *
 * @param values - The value to check for emptiness. It can be a string, an array, an object,
 *               an array-like object, null, or undefined.
 * @returns `true` if the value is considered empty, `false` otherwise.
 */
export function checkIsEmpty(
	values:
		| string
		| any[]
		| { [s: string]: unknown }
		| ArrayLike<unknown>
		| null
		| undefined
): boolean {
	if (Array.isArray(values)) {
		return values.every((item) => {
			if (typeof item === "object" && item !== null) {
				return Object.values(item).every(
					(value) => value === "" || value === null || value === undefined
				);
			}
			return item === null || item === undefined || item === "";
		});
	} else if (typeof values === "object" && values !== null) {
		return Object.values(values).every((value) =>
			checkIsEmpty(
				value as
					| string
					| any[]
					| { [s: string]: unknown }
					| ArrayLike<unknown>
					| null
					| undefined
			)
		);
	} else {
		return values === null || values === undefined || values === "";
	}
}
