/**
 * Converts string keys of an object or array of objects into nested objects.
 *
 * This function takes an object or an array of objects and converts any string keys
 * that contain dot notation or array notation into nested objects or arrays.
 *
 * @param obj - The object or array of objects to be converted.
 * @returns A new object or array of objects with nested structures based on the string keys.
 *
 * @example
 * ```typescript
 * const input = {
 *   "a.b.c": 1,
 *   "d[0].e": 2
 * };
 * const output = convertStringKeys(input);
 * // output will be:
 * // {
 * //   a: {
 * //     b: {
 * //       c: 1
 * //     }
 * //   },
 * //   d: [
 * //     {
 * //       e: 2
 * //     }
 * //   ]
 * // }
 * ```
 */
export function convertStringKeys(
	obj: Record<string, any> | any[]
): Record<string, any> | any[] {
	if (Array.isArray(obj)) {
		return obj.map((item) => convertStringKeys(item));
	} else if (typeof obj === "object" && obj !== null) {
		let newObj: Record<string, any> = {};
		for (let key in obj) {
			const keys = key.split(".");
			let tempObj: Record<string, any> = newObj;
			const k = key.replace(/\[(\d+)\]/g, ".$1").split(".");
			k.forEach((subKey, index) => {
				if (!tempObj[subKey]) {
					if (index === k.length - 1) {
						tempObj[subKey] = obj[key];
					} else {
						tempObj[subKey] = isNaN(Number(k[index + 1])) ? {} : [];
					}
				}
				if (index === k.length - 1) {
					tempObj[subKey] = obj[key];
				} else {
					tempObj = tempObj[subKey];
				}
			});
		}
		return newObj;
	} else {
		return obj;
	}
}
