/**
 * Recursively returns a new object with the same structure as the input object, but with all values set to an empty string.
 * If a key is specified in `omitKey`, it will be omitted from the new object.
 *
 * @param obj - The input object whose structure will be used in the new object.
 * @param omitKey - The key that should be omitted from the new object.
 * @returns A new object with the same structure as the input object, but with all values set to an empty string,
 *          except for the omitted key.
 */
export function returnObjectWithEmptyValues<T extends Record<string, any>>({
	obj,
	omitKey,
}: {
	obj: T;
	omitKey?: string;
}): T {
	const updated: {
		[K in keyof T]?:
			| string
			| Record<string, any>
			| (string | Record<string, any>)[];
	} = {};

	for (const key in obj) {
		if (key === omitKey) {
			continue;
		}

		const value = obj[key];

		if (Array.isArray(value)) {
			updated[key] = value.map((item: unknown) => {
				if (
					typeof item === "object" &&
					item !== null &&
					!(item instanceof Date)
				) {
					return returnObjectWithEmptyValues({
						obj: item as Record<string, any>,
					});
				}
				return "";
			});
			if (JSON.stringify(updated[key]) === JSON.stringify([""])) {
				updated[key] = "";
			}
		} else if (
			typeof value === "object" &&
			value !== null &&
			!Object.getOwnPropertyNames(value).some(
				(prop) => typeof (value as Record<string, any>)[prop] === "function"
			)
		) {
			updated[key] = "";
		} else if (typeof value === "object" && value !== null) {
			updated[key] = value;
		} else {
			updated[key] = "";
		}
	}
	return updated as T;
}
