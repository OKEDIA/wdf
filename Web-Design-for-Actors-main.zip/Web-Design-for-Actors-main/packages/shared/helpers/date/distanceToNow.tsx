// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities
import { formatDistanceToNow } from "date-fns";

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
/**
 * Formats a date string to a human-readable relative time string.
 *
 * @param {string} value - The date string to format.
 * @returns {string} - A formatted string representing the relative time from now.
 *                      Returns "Never" if the input is invalid or empty.
 */
export default function distanceToNow(value: string): string {
	if (!value || value === "Invalid Date") {
		return "Never";
	}

	return formatDistanceToNow(new Date(value), { addSuffix: true });
}
