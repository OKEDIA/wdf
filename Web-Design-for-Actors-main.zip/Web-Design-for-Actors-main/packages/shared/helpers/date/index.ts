import distanceToNow from "./distanceToNow";

export { distanceToNow };
