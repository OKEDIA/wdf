import { SDK } from "./managers/Main.js";

/**
 * The global SDK instance, or `null` if not initialized.
 *
 * @remarks
 * This variable holds the current instance of the SDK. It should be set during initialization
 * and can be used throughout the application to access SDK functionality.
 *
 * @public
 */
export let sdk: SDK | null = null;

/**
 * Initializes and returns a singleton instance of the SDK.
 * If the SDK has already been initialized, returns the existing instance.
 *
 * @param args - Arguments to be passed to `SDK.create`.
 * @returns A promise that resolves to the initialized SDK instance.
 *
 * @example
 * ```typescript
 * import {initSDK, sdk} from "@okedia/sdk-js"
 *
 * // Define the arguments for SDK initialization
 * const args = {apiKey: "your-api-key"};
 *
 * // Initialize the SDK with an API key
 * await initSDK(args);
 *
 * // OPTION 1: Use the global SDK instance:
 * sdk?.someMethod();
 *
 * // OPTION 2: Use the SDK instance directly:
 * await initSDK(args).someMethod();
 * ```
 */
export async function initSDK(...args: Parameters<typeof SDK.create>) {
	if (sdk) return sdk;

	sdk = await SDK.create(...args);
	return sdk;
}
