"use client";

// React Imports
import React from "react";
import { initSDK } from "../index.js";
import { SDK } from "../managers/Main.js";

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

const SDKContext = React.createContext<SDK | undefined>(undefined);

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Provides the SDK context to its child components.
 *
 * This component initializes the SDK instance using the provided `apiKey` and optionally logs in a user with `userId`.
 * Once the SDK is initialized and authenticated, it is made available to all descendant components via React context.
 *
 * @param children - The React node(s) that will have access to the SDK context.
 * @param apiKey - The API key used to initialize the SDK instance.
 * @param userId - (Optional) The user ID to authenticate with the SDK.
 *
 * @returns The SDK context provider wrapping the children, or `null` while the SDK is initializing.
 */
export default function SDKProvider({
	children,
	apiKey,
	userId,
}: {
	children: React.ReactNode;
	apiKey: string;
	userId?: string;
}) {
	const [sdk, setSDK] = React.useState<SDK | null>(null);

	React.useEffect(() => {
		async function setup() {
			const instance = await initSDK({ apiKey });
			await instance.auth.login(userId);
			setSDK(instance);
		}
		setup();
	}, [userId]);

	if (!sdk) return null;

	return <SDKContext.Provider value={sdk}>{children}</SDKContext.Provider>;
}

/**
 * Custom React hook to access the SDK context.
 *
 * @returns {SDKContextType} The SDK class.
 * @throws {Error} If used outside of an `SDKProvider`.
 *
 * @example
 * const sdk = useSDK();
 */
export const useSDK = () => {
	const context = React.useContext(SDKContext);
	if (context === undefined) {
		throw new Error("useSDK must be used within a SDKProvider");
	}
	return context;
};
