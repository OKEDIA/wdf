"use client";

import { Base, BaseRepository } from "@okedia/core/domain";
import { produce } from "immer";
import { createStore } from "zustand/vanilla";
import type { DatabaseClient } from "../common/DatabaseClient.js";
import { EndpointProperties } from "../managers/CollectionManager.js";
export interface BaseStore<T> extends BaseRepository<T> {
	items?: T[];
	endpoint: EndpointProperties;
}

/**
 * Creates a collection store for managing a set of items of type `T` with CRUD operations.
 *
 * @template T - The type of items in the collection, extending `Base`.
 * @param client - The database client used to perform HTTP requests.
 * @param endpoint - The endpoint properties, including URI and optional filters.
 * @returns A store object implementing `BaseStore<T>`, providing methods to find, create, update, and delete items.
 *
 * @remarks
 * - The store synchronizes its state with the backend using the provided `client`.
 * - The `find` method merges provided filters with endpoint filters and updates the store's items.
 * - The `create` method adds a new item to the store upon successful creation.
 * - The `update` method updates an existing item in the store upon successful update.
 * - The `delete` method removes an item from the store upon successful deletion.
 * - Throws an error if any CRUD operation fails.
 */
export function createCollectionStore<T extends Base>(
	client: DatabaseClient,
	endpoint: EndpointProperties
) {
	return createStore<BaseStore<T>>((set, get) => ({
		items: [],
		endpoint: endpoint,
		find: async <PopulatePaths = {}>(
			args: Parameters<BaseRepository<T>["find"]>[0]
		) => {
			const filter = args && args.filter ? args.filter : [];
			filter.push(endpoint?.filters);
			const res = await client.get<T[]>({
				...args,
				url: endpoint.uri,
				responseSettings: { ...args },
			});
			console.log("Response from find:", res);
			if (res.success) {
				set((state) => ({
					items: res.response,
				}));
				return res.response as any as (Omit<T, keyof PopulatePaths> &
					PopulatePaths)[];
			}
			throw new Error("Find failed");
		},
		create: async (...args: Parameters<BaseRepository<T>["create"]>) => {
			const [item] = args;
			const res = await client.post<T>({ url: endpoint.uri, body: item });
			if (res.success) {
				set((state) => ({
					items: produce(state.items, (draft) => {
						draft.push(res.response as import("immer").Draft<T>);
					}),
				}));
				return res.response as Awaited<ReturnType<BaseRepository<T>["create"]>>;
			}
			throw new Error("Create failed");
		},
		update: async (...args: Parameters<BaseRepository<T>["update"]>) => {
			const [id, updates, responseSettings] = args;
			const res = await client.patch<T>({
				url: `${endpoint.uri}/${id}`,
				body: updates,
				responseSettings: responseSettings,
			});
			if (res.success) {
				set((state) => ({
					items: produce(state.items, (draft) => {
						const index = draft.findIndex((i) => i.id === id);
						if (index !== -1)
							draft[index] = res.response as import("immer").Draft<T>;
					}),
				}));
				return res.response as Awaited<ReturnType<BaseRepository<T>["update"]>>;
			}
			throw new Error("Update failed");
		},
		delete: async (...args: Parameters<BaseRepository<T>["delete"]>) => {
			const [id] = args;
			const res = await client.delete<T>({ url: `${endpoint.uri}/${id}` });
			if (res.success) {
				set((state) => ({
					items: produce(state.items, (draft) =>
						draft.filter((i) => i.id !== id)
					),
				}));
			}
		},
	}));
}
