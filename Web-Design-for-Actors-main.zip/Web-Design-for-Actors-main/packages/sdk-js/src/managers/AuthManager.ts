import { Tenant } from "@okedia/core/domain/apiKey";
import {
	AuthApiResponses,
	ResolvedAuthToken,
	UserRecord,
} from "@okedia/core/domain/authentication";
import { verifyJwt } from "@okedia/core/utils";
import { DatabaseClient } from "../common/DatabaseClient.js";
import { BASE_URL, JWT_PUBLIC_KEY } from "../config.js";

export class AuthManager {
	public user: UserRecord | null = null;
	private authToken: string | null = null;
	private auth: ResolvedAuthToken | null = null;
	public permissions: Tenant["permissions"] | null = null;

	constructor(
		private apiKey: string,
		private client: DatabaseClient
	) {
		this.client = client || new DatabaseClient(BASE_URL as string);
	}

	async initialize(): Promise<boolean> {
		const result = await this.client.get<AuthApiResponses["get"]["auth/init"]>({
			url: `/auth/init`,
			options: {
				headers: {
					"x-api-key": this.apiKey,
				},
			},
		});

		if (!result.success)
			throw new Error((result as any).message || "Unknown error");

		this.auth = await verifyJwt<ResolvedAuthToken>(
			result.response,
			JWT_PUBLIC_KEY
		);

		this.permissions = this.auth.permissions;

		return true;
	}

	async login(userId: string): Promise<UserRecord | null> {
		const result = await this.client.get<AuthApiResponses["get"]["auth/login"]>(
			{
				url: `/auth/login`,
				responseSettings: { params: { userId } },
				options: {
					headers: {
						"x-api-key": this.apiKey,
					},
				},
			}
		);

		if (!result.success || !result.response)
			throw new Error((result as any).message || "Unknown error");

		this.auth = await verifyJwt<ResolvedAuthToken>(
			result.response,
			JWT_PUBLIC_KEY
		);
		this.authToken = result.response;
		this.client.setAuthToken(result.response);
		return this.user;
	}

	/**
	 * Retrieves the current authentication token.
	 *
	 * @returns The auth token as a string or undefined if not set.
	 */
	getToken() {
		return this.authToken;
	}
}
