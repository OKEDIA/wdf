import { EpmBasic } from "@okedia/core/domain/epm";
import {
	ActorBasic,
	ProductionBasic,
	ProfileBasic,
} from "@okedia/core/domain/profiles";
import { createActorsStore } from "../common/Actors.js";
import { DatabaseClient } from "../common/DatabaseClient.js";
import { createEpmStore } from "../common/Epm.js";
import { createProductionsStore } from "../common/Productions.js";
import { BASE_URL } from "../config.js";
import { AuthManager } from "./AuthManager.js";
import { CollectionManager } from "./CollectionManager.js";

/**
 * The main entry point for interacting with the SDK.
 *
 * Use the static {@link SDK.create} method to asynchronously instantiate an SDK instance.
 *
 * @remarks
 * - Handles authentication and provides access to actor collections.
 * - Use {@link SDK.create} to obtain a new instance.
 *
 * @example
 * ```typescript
 * const sdk = await SDK.create({ apiKey: 'your-api-key' });
 * ```
 */
export class SDK {
	public auth: AuthManager;
	public actors!: CollectionManager<ProfileBasic<ActorBasic>>;
	public productions!: CollectionManager<ProfileBasic<ProductionBasic>>;
	public epm!: CollectionManager<EpmBasic>;

	private client: DatabaseClient;

	private constructor(apiKey: string) {
		this.client = new DatabaseClient(BASE_URL as string);
		this.auth = new AuthManager(apiKey, this.client);
	}

	// Static async initializer — only way to get an SDK instance
	static async create({ apiKey }: { apiKey: string }): Promise<SDK> {
		const sdk = new SDK(apiKey);

		await sdk.#initialize(); // # makes it a private class field (truly private)
		return sdk;
	}

	/**
	 * Initializes the authentication and sets up the relevant states based on the user's permissions.
	 *
	 * @private
	 * @async
	 * @returns {Promise<void>} Resolves when initialization is complete.
	 *
	 * @remarks
	 * - Calls the `initialize` method on the `auth` object.
	 * - Logs authentication and permissions information to the console.
	 * - Conditionally creates state stores if the user has the corresponding permissions; otherwise, sets them to `null`.
	 * - - Note: Nulling the stores is intentional to avoid unnecessary state management when permissions are not granted.
	 *     This is for the convenience of the client-side code and should not be relied upon for security checks.
	       Therefore, we should always ensure that the user has the relevant permissions in the server-side code.
	 */
	async #initialize() {
		await this.auth.initialize();

		this.actors = this.auth.permissions?.["/profiles"]?.["actors"]
			? createActorsStore(this.client, this.auth.permissions)
			: null;

		this.productions = this.auth.permissions?.["/profiles"]?.["productions"]
			? createProductionsStore(this.client, this.auth.permissions)
			: null;

		this.epm = this.auth.permissions?.["/epm"]?.["*"]
			? createEpmStore(this.client, this.auth.permissions)
			: null;
	}
}
