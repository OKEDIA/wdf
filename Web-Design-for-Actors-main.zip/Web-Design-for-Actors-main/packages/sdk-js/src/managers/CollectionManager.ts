import { BaseRepository } from "@okedia/core/domain";
import { ResolvedAuthToken } from "@okedia/core/domain/authentication";
import { hasPermission } from "@okedia/core/utils";
import { StoreApi } from "zustand/vanilla";
import { DatabaseClient } from "../common/DatabaseClient.js";
import {
	BaseStore,
	createCollectionStore,
} from "../utils/createCollectionStore.js";

export interface EndpointProperties {
	uri: `/${string}`;
	filters?: Record<string, any>;
}

/**
 * Manages a collection of items of type `T` with CRUD operations and permission checks.
 *
 * @template T The type of items managed by the collection.
 * @implements {BaseRepository<T>}
 *
 * @remarks
 * This class wraps a store and exposes methods to interact with a collection,
 * enforcing permission checks for each operation based on the provided tenant rights.
 *
 * @param client The database client used for store operations.
 * @param rights The permissions object for the current tenant.
 * @param endpoint The endpoint properties for the collection.
 *
 * @property items The current items in the collection.
 *
 * @method update Updates items in the collection if the user has "update" permission.
 * @method delete Deletes items from the collection if the user has "delete" permission.
 * @method find Finds items in the collection if the user has "read" permission.
 * @method create Creates new items in the collection if the user has "write" permission.
 * @method subscribe Subscribes to changes in the collection if the user has "read" permission.
 */
export class CollectionManager<T> implements BaseRepository<T> {
	private store: StoreApi<BaseStore<T>>;
	private rights: ResolvedAuthToken["permissions"];
	private endpoint: EndpointProperties;
	private client: DatabaseClient;

	constructor(
		client: DatabaseClient,
		rights: ResolvedAuthToken["permissions"],
		endpoint: EndpointProperties
	) {
		this.store = createCollectionStore<T>(client, endpoint);
		this.rights = rights;
		this.endpoint = endpoint;
		this.client = client;
		this.store.getInitialState();

		// Bind public methods as own properties
		this.find = this.find.bind(this);
		this.update = this.update.bind(this);
		this.create = this.create.bind(this);
		this.delete = this.delete.bind(this);
		this.subscribe = this.subscribe.bind(this);
	}

	get items() {
		return this.store.getState().items;
	}

	get state() {
		return this.store.getState();
	}

	get type(): string | undefined {
		return this.endpoint.filters?.type;
	}

	async update(...args: Parameters<BaseRepository<T>["update"]>) {
		return hasPermission(this.rights, {
			namespace: this.rights[this.endpoint.uri],
			resource: this.type,
			action: "update",
		})
			? this.state.update(...args)
			: null;
	}

	async delete(...args: Parameters<BaseRepository<T>["delete"]>) {
		return hasPermission(this.rights, {
			namespace: this.rights[this.endpoint.uri],
			resource: this.type,
			action: "delete",
		})
			? this.state.delete(...args)
			: null;
	}

	async find<PopulatePaths = {}>(
		...args: Parameters<BaseRepository<T>["find"]>
	) {
		return hasPermission(this.rights, {
			namespace: this.endpoint.uri,
			resource: this.type,
			action: "read",
		})
			? (this.state.find(...args) as Promise<
					(Omit<T, keyof PopulatePaths> & PopulatePaths)[]
				>)
			: null;
	}

	async create(...args: Parameters<BaseRepository<T>["create"]>) {
		return hasPermission(this.rights, {
			namespace: this.rights[this.endpoint.uri],
			resource: this.type,
			action: "write",
		})
			? this.state.create(...args)
			: null;
	}

	async subscribe(fn: (items: T[]) => void) {
		return hasPermission(this.rights, {
			namespace: this.rights[this.endpoint.uri],
			resource: this.type,
			action: "read",
		})
			? this.store.subscribe(() => fn(this.items))
			: null;
	}
}
