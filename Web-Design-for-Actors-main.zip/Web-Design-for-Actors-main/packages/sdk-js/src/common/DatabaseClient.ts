import { ApiResponse, RequestMethod } from "@okedia/core/domain/api";
import { convertResponseSettingsToUrl } from "@okedia/core/utils";
/**
 * A generic HTTP client for interacting with RESTful APIs, providing convenient methods for GET, POST, PATCH, and DELETE requests.
 *
 * This client is designed for use in TypeScript projects and can be easily integrated with data-fetching libraries such as [TanStack Query](https://tanstack.com/query/latest).
 *
 * @example
 * ```typescript
 * import { useQuery } from '@tanstack/react-query';
 * import { DatabaseClient } from './DatabaseClient';
 *
 * const dbClient = new DatabaseClient('https://api.example.com');
 *
 * function useUsers() {
 *   return useQuery({
 *     queryKey: ['users'],
 *     queryFn: async () => {
 *       const result = await dbClient.get<{ users: User[] }>({ url: '/users' });
 *       if (!result.success) throw new Error(result.message);
 *       return result.response.users;
 *     }
 *   });
 * }
 * ```
 *
 * @remarks
 * - All requests are sent with `Content-Type: application/json` by default.
 * - The client exposes a `loading` property to indicate the request state, but when using TanStack Query, prefer its built-in loading state.
 * - Error handling is performed internally, and unsuccessful responses return a descriptive message.
 *
 * @see [TanStack Query Documentation](https://tanstack.com/query/latest)
 */
export class DatabaseClient {
	public baseUrl: string;
	public responseType: string;
	public loading: boolean;
	private authToken: string | null = null;

	constructor(
		baseUrl: RequestMethod["url"],
		responseType: string = "application/json"
	) {
		this.baseUrl = baseUrl;
		this.responseType = responseType;
		this.loading = false;
	}

	private async request<T>({
		url,
		method,
		body,
		options = {},
		responseSettings,
	}: RequestMethod): Promise<ApiResponse<T>> {
		this.loading = true;
		const urlWithParams = convertResponseSettingsToUrl(responseSettings, url);

		console.log(`Making ${method} request to: ${this.baseUrl}${url}`);
		console.log("Auth token:", this.authToken);

		const requestInit: RequestInit = {
			method,
			headers: {
				"Content-Type": "application/json",
				...(options.headers || {}),
				...(this.authToken && { Authorization: `Bearer ${this.authToken}` }),
			},
			...options,
		};

		if (body) {
			requestInit.body = JSON.stringify(body);
		}

		try {
			const response = await fetch(this.baseUrl + urlWithParams, requestInit);
			const contentType = response.headers.get("content-type") || "";

			if (!response.ok) {
				return {
					success: false,
					message: `HTTP ${response.status}: ${response.statusText}`,
				};
			}

			if (!contentType.startsWith(this.responseType)) {
				return {
					success: false,
					message: `Unexpected response type: ${contentType}`,
				};
			}

			const isJson = contentType.includes("application/json");
			const result = isJson ? await response.json() : await response.text();

			return {
				success: true,
				response: result as T,
			};
		} catch (e: any) {
			console.error(e);
			return {
				success: false,
				message: e?.message ?? "Unknown error",
			};
		} finally {
			this.loading = false;
		}
	}

	/**
	 * Sets the authentication token to be used for subsequent requests.
	 *
	 * @param token - The authentication token string.
	 */
	public setAuthToken(token: string) {
		console.log("Setting auth token:", token);
		this.authToken = token;
	}

	/**
	 * Sends a GET request to the API using the provided request properties.
	 *
	 * @typeParam T - The expected type of the response data.
	 * @param props - The request properties, excluding the HTTP method and body.
	 * @returns A promise that resolves to an `ApiResponse<T>` containing the response data.
	 */
	public get<T>(
		props: Omit<RequestMethod, "method" | "body">
	): Promise<ApiResponse<T>> {
		return this.request<T>({ method: "GET", ...props });
	}

	/**
	 * Sends a POST request using the provided request properties and returns a promise with the API response.
	 *
	 * @typeParam T - The expected type of the response data.
	 * @param props - The request properties, excluding the HTTP method (which is set to "POST" internally).
	 * @returns A promise that resolves to an `ApiResponse<T>` containing the response data.
	 */
	public post<T>(
		props: Omit<RequestMethod, "method">
	): Promise<ApiResponse<T>> {
		return this.request<T>({ method: "POST", ...props });
	}

	/**
	 * Sends a PATCH request to the API with the specified properties.
	 *
	 * @typeParam T - The expected response data type.
	 * @param props - The request properties, excluding the HTTP method.
	 * @returns A promise that resolves to an `ApiResponse<T>`.
	 */
	public patch<T>(
		props: Omit<RequestMethod, "method">
	): Promise<ApiResponse<T>> {
		return this.request<T>({ method: "PATCH", ...props });
	}

	/**
	 * Sends a DELETE request to the specified endpoint.
	 *
	 * @typeParam T - The expected response data type.
	 * @param props - The request configuration, excluding the `body` and `method` properties.
	 * @returns A promise that resolves to an `ApiResponse<T>` containing the response data.
	 */
	public delete<T>(
		props: Omit<RequestMethod, "body" | "method">
	): Promise<ApiResponse<T>> {
		return this.request<T>({ method: "DELETE", ...props });
	}
}
