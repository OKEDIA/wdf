import { ResolvedAuthToken } from "@okedia/core/domain/authentication";
import { EpmBasic } from "@okedia/core/domain/epm";
import { CollectionManager } from "../managers/CollectionManager.js";
import { DatabaseClient } from "./DatabaseClient.js";

export function createEpmStore(
	client: DatabaseClient,
	rights: ResolvedAuthToken["permissions"]
) {
	return new CollectionManager<EpmBasic>(client, rights, {
		uri: "/epm",
	});
}
