import { ResolvedAuthToken } from "@okedia/core/domain/authentication";
import { ActorBasic, ProfileBasic } from "@okedia/core/domain/profiles";
import { CollectionManager } from "../managers/CollectionManager.js";
import { DatabaseClient } from "./DatabaseClient.js";

export function createActorsStore(
	client: DatabaseClient,
	rights: ResolvedAuthToken["permissions"]
) {
	return new CollectionManager<ProfileBasic<ActorBasic>>(client, rights, {
		uri: "/profiles",
		filters: { type: "actors" },
	});
}
