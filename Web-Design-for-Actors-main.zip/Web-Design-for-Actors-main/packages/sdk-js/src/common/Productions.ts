import { ResolvedAuthToken } from "@okedia/core/domain/authentication";
import { ProductionBasic, ProfileBasic } from "@okedia/core/domain/profiles";
import { CollectionManager } from "../managers/CollectionManager.js";
import { DatabaseClient } from "./DatabaseClient.js";

export function createProductionsStore(
	client: DatabaseClient,
	rights: ResolvedAuthToken["permissions"]
) {
	return new CollectionManager<ProfileBasic<ProductionBasic>>(client, rights, {
		uri: "/profiles",
		filters: { type: "productions" },
	});
}
