import type { HydratedDocument } from "mongoose";
import mongoose from "mongoose";
import { ProfileService } from "../../../domain/profiles/services/document.services.js";
import { BaseSchema } from "../common/base.schema.js";
const { Schema, Types } = mongoose;
/**
 * Mongoose schema for the Profile collection.
 *
 * @remarks
 * DOCUMENT LEVEL FUNCTIONS FOR THE PROFILES COLLECTION.
 * We extend the Profiles schema to tell mongoose what the data inside these documents look like.
 * We also add some document-level functions to the schema to handle common operations.
 * Adding the functions at this level compared to the Adapter level allows us to perform operations on THIS document
 * without having to pass the document ID around.
 *
 * @example
 * const profileSchema = new ProfileSchema();
 * const ProfileModel = mongoose.model("Profile", profileSchema);
 */

export const ProfileSchema = new Schema(
	{
		...BaseSchema.obj,
		type: {
			type: String,
			required: true,
			enum: ["actors", "productions", "producers"],
		},
		websites: [Schema.Types.ObjectId],
	},
	{
		discriminatorKey: "type",
		methods: {
			addPermission: async function (
				this: HydratedDocument<any>,
				userId: string,
				type: keyof any["permissions"]
			) {
				try {
					console.log("Calling the Profile Service to add permission...");
					const updatedProfile = await new ProfileService(
						this.toObject()
					).addPermission(userId, type); // Call the static claimProfile function from the service layer
					console.log("Updated Profile: ", updatedProfile.permissions);
					Object.assign(this, updatedProfile); // Merge the updated profile back into the document
					return await this.save(); // Save the updated document
				} catch (error) {
					// Handle the error
					throw new Error(`Error adding permission: ${error.message}`);
				}
			},
			removePermission: async function (
				this: HydratedDocument<any>,
				userId: string,
				type: keyof any["permissions"]
			) {
				try {
					const updatedProfile = await new ProfileService(
						this.toJSON()
					).removePermission(userId, type); // Call the removePermission function from the service layer

					Object.assign(this, updatedProfile); // Merge the updated profile back into the document
					return await this.save();
				} catch (error) {
					// Handle the error
					throw new Error(`Error removing permission: ${error.message}`);
				}
			},
			claim: async function (this: HydratedDocument<any>, userId: string) {
				try {
					const updatedProfile = await new ProfileService(
						this.toObject()
					).claim(userId); // Call the static claimProfile function from the service layer
					Object.assign(this, updatedProfile); // Merge the updated profile back into the document
					return await this.save(); // Save the updated document
				} catch (error) {
					// Handle the error
					throw new Error(`Error claiming profile: ${error.message}`);
				}
			},
		},
	}
);

// Apply schema-level options
ProfileSchema.set("timestamps", { createdAt: "created", updatedAt: "updated" });

ProfileSchema.on("init", async function () {
	const { ActorSchema } = await import("./actor.schema.js");
	const { ProductionSchema } = await import("./production.schema.js");

	const discriminatorMap = {
		actors: ActorSchema,
		// producers: ProducerSchema,
		productions: ProductionSchema,
	} as const;

	for (const [key, schema] of Object.entries(discriminatorMap)) {
		ProfileSchema.discriminator(key, schema);
	}
});
