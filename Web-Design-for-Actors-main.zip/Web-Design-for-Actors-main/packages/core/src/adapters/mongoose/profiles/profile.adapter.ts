import type { Model } from "mongoose";
import mongoose from "mongoose";
import {
	BaseMongooseAdapter,
	ProfileBasic,
	ProfileMongoose,
} from "../../../domain/index.js";
import { ProfileRepository } from "../../../domain/profiles/ports/collection.ports.js";
import { ProfileSchema } from "./profile.schema.js";
const { model, models } = mongoose;
export const ProfileModel: Model<ProfileBasic<any>> =
	models.Profile ||
	model<ProfileBasic<any>>("Profile", ProfileSchema, "profiles");

const fakeValidator = (data: ProfileBasic<any>) => data;

/**
 * A Mongoose adapter for managing profile documents.
 *
 * @class ProfileManager
 *
 * @extends BaseMongooseAdapter<ProfileBasic, ProfileMongoose>
 * @implements BaseRepository<ProfileBasic, ProfileMongoose>
 *
 * @remarks
 * This class serves as a bridge between the Mongoose model (ProfileModel) and the domain logic
 * for profile management. It uses the BaseMongooseAdapter to provide core database operations
 * while ensuring that the data conforms to the MongooseProfile interface.
 *
 * Important:
 * - Do not add new functions here. New functionality should be implemented in
 *   the domain/profile/services/collection.services.ts file to allow for re-use across the application.
 *
 * @example
 * const profileManager = new ProfileManager();
 * Use profileManager to interact with profile data in MongoDB
 */
export class ProfileManager
	extends BaseMongooseAdapter<ProfileBasic<any>, ProfileMongoose<any>>
	implements ProfileRepository
{
	// * Note:
	//   Don't define new functions here. Instead functions should be imported from domain/profile/services/collection.services.ts file for re-use everywhere.
	// *

	constructor() {
		super(ProfileModel, (data) => fakeValidator(data));
	}
}
