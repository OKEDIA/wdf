import mongoose from "mongoose";
import { agentDetailsSchema } from "../schema/agent.js";
import { fileSchema } from "../schema/file.js";
import { gallerySchema } from "../schema/gallery.js";
import { locationSchema } from "../schema/location.js";
import { blogPostSchema } from "../schema/post.js";
import { ratingSchema } from "../schema/rating.js";
import { testimonialSchema } from "../schema/review.js";
import { socialMediaSchema } from "../schema/socialMedia.js";
import { ProfileSchema } from "./profile.schema.js";
const { Schema } = mongoose;

export const ActorSchema = new Schema({
	...ProfileSchema.obj,
	type: { type: String, required: true, enum: ["actors"] },
	intro: {
		stageName: [{ value: { type: String, required: true } }],
		biog: [{ value: { type: String, required: true } }],
		file: [
			{
				cv: { type: fileSchema, required: true },
				headshot: { type: fileSchema, required: true },
			},
		],
		location: [locationSchema],
		role: [{ value: { type: String, required: true } }],
		playingAge: [
			{
				min: { type: Number, required: true },
				max: { type: Number, required: true },
			},
		],
		availability: [{ value: { type: String, required: true } }],
	},
	socials: {
		socialMedia: [socialMediaSchema],
	},
	skills: {
		skill: [ratingSchema],
	},
	training: {
		training: [ratingSchema],
	},
	contacts: {
		agentDetails: [agentDetailsSchema],
	},
	gallery: {
		file: [gallerySchema],
	},
	blog: {
		post: [blogPostSchema],
	},
	testimonials: {
		testimonials: [testimonialSchema],
	},
});
