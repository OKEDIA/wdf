import mongoose from "mongoose";
const { Schema } = mongoose;
import { ProfileSchema } from "./profile.schema.js";

export const ProductionSchema = new Schema({
	type: { type: String, required: true, enum: ["productions"] },
	...ProfileSchema.obj,
});
