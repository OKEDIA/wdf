import type { Model } from "mongoose";
import mongoose from "mongoose";
import { BaseMongooseAdapter } from "../../../domain/index.js";
import { UserRepository } from "../../../domain/users/ports/collection.ports.js";
import { UserBasic, UserMongoose } from "../../../domain/users/types.js";
import { UsersSchema } from "./users.schema.js";
const { model, models } = mongoose;
export const UsersModel: Model<UserBasic> =
	models.User || model<UserBasic>("User", UsersSchema, "users");

const fakeValidator = (data: UserMongoose) => data;

/**
 * A Mongoose adapter for managing user documents.
 *
 * @class ApiKeyManager
 *
 * @extends BaseMongooseAdapter<UserBasic, UserMongoose>
 * @implements UserRepository
 *
 * @remarks
 * This class serves as a bridge between the Mongoose model (UserModel) and the domain logic
 * for user management. It uses the BaseMongooseAdapter to provide core database operations
 * while ensuring that the data conforms to the User interface.
 *
 * Important:
 * - Do not add new functions here. New functionality should be implemented in
 *   the domain/users/services/collection.services.ts file to allow for re-use across the application.
 *
 * @example
 * const usersManager = new UsersManager();
 * Use usersManager to interact with user data in MongoDB
 */
export class UsersManager
	extends BaseMongooseAdapter<UserBasic, UserMongoose>
	implements UserRepository
{
	// * Note:
	//   Don't define new functions here. Instead functions should be imported from domain/users/services/collection.services.ts file for re-use everywhere.
	// *

	constructor() {
		super(UsersModel, (data) => fakeValidator(data));
	}
}
