import mongoose from "mongoose";
const { Schema } = mongoose;

export const UserTenantSchema = new Schema(
	{
		tenant_id: { type: String, required: true },
		external_user_id: { type: String, required: true, unique: true },
	},
	{ _id: false }
);

/**
 * Mongoose schema for the users collection.
 *
 * @remarks
 * DOCUMENT LEVEL FUNCTIONS FOR THE USERS COLLECTION.
 *
 * @example
 * const usersSchema = new UsersSchema();
 * const UsesrModel = mongoose.model("Users", usersSchema);
 */

export const UsersSchema = new Schema({
	firebaseUID: { type: String, required: true, unique: true },
	tenants: {
		type: [UserTenantSchema],
		_id: false,
	},
});

// Apply schema-level options
UsersSchema.set("timestamps", { createdAt: "created", updatedAt: "updated" });
