import mongoose from "mongoose";
const { Schema } = mongoose;
import { fileSchema } from "./file.js";

export const gallerySchema = new Schema({
	slug: { type: String, required: true },
	category: { type: String, required: true },
	upload: { type: fileSchema, required: true },
});
