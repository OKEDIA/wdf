import mongoose from "mongoose";
const { Schema } = mongoose;

export const fileSchema = new Schema({
	type: { type: String, required: true },
	bucket: { type: String, required: true },
	generation: { type: String, required: true },
	metageneration: { type: String, required: true },
	fullPath: { type: String, required: true },
	name: { type: String, required: true },
	size: { type: Number, required: true },
	timeCreated: { type: Date, required: true },
	updated: { type: Date, required: true },
	md5Hash: { type: String, required: true },
	contentDisposition: { type: String, required: true },
	contentEncoding: { type: String, required: true },
	contentType: { type: String, required: true },
	downloadUrl: { type: String, required: true },
});
