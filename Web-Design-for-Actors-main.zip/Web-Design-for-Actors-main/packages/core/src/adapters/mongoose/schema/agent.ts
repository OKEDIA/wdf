import mongoose from "mongoose";
const { Schema } = mongoose;

export const agentDetailsSchema = new Schema({
	name: { type: String, required: true },
	representing: { type: String, required: true },
	tel: { type: String, required: true },
	url: { type: String, required: true },
	email: { type: String, required: true },
	spacer: { type: String },
	street1: { type: String },
	street2: { type: String },
	town: { type: String },
	city: { type: String },
	postcode: { type: String },
});
