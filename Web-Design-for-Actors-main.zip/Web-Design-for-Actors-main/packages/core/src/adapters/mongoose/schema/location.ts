import mongoose from "mongoose";
const { Schema } = mongoose;

export const locationSchema = new Schema({
	city: { type: String, required: true },
	country: { type: String, required: true },
});
