import mongoose from "mongoose";
const { Schema } = mongoose;

export const testimonialSchema = new Schema({
	content: { type: String, required: true },
	reviewer: { type: String, required: true },
	company: { type: String, required: true },
});
