import mongoose from "mongoose";
const { Schema } = mongoose;
export const socialMediaSchema = new Schema({
	network: { type: String, required: true },
	username: { type: String, required: true },
});
