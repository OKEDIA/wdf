import mongoose from "mongoose";
const { Schema } = mongoose;

export const ratingSchema = new Schema({
	title: { type: String, required: true },
	value: { type: Number, required: true },
});
