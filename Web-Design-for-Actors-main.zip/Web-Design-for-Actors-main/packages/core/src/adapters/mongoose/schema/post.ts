import mongoose from "mongoose";
const { Schema } = mongoose;
import { fileSchema } from "./file.js";

export const blogPostSchema = new Schema({
	name: { type: String, required: true },
	slug: { type: String, required: true },
	date: { type: String },
	content: { type: String, required: true },
	cover: { type: fileSchema, required: true },
});
