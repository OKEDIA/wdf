import type { Schema } from "mongoose";

/**
 * Adds `id` virtual and `createdAt`/`updatedAt` fields + hooks to any schema.
 */
export function applyBaseSchema(schema: Schema) {
	// 2) Add timestamp fields
	schema.add({
		created: { type: String, required: true },
		updated: { type: String, required: true },
	});

	// 3) Pre-save hook to auto-set timestamps
	schema.pre("save", function (next) {
		const now = new Date().toISOString();
		this.set("updated", now);
		if (!this.get("created")) {
			this.set("created", now);
		}
		next();
	});
}
