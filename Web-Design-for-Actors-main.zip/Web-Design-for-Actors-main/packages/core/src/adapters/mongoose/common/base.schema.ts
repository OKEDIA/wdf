import mongoose from "mongoose";
import { applyBaseSchema } from "./base.plugin.js";
const { Schema, Types } = mongoose;

export const BaseSchema = new Schema({
	id: { type: String, required: true },
	commonFormDataValues: {
		title: { type: String, required: false, default: undefined },
		tags: [{ type: String, required: false, default: undefined }],
		image: { type: String, required: false, default: undefined },
	},
	permissions: {
		creator: { type: Types.ObjectId, required: true },
		owners: [{ type: Types.ObjectId, required: false, default: undefined }],
		editors: [{ type: Types.ObjectId, required: false, default: undefined }],
	},
	development: { type: Boolean, required: false, default: false },
	created: { type: Date, required: true },
	updated: { type: Date, required: true },
});

applyBaseSchema(BaseSchema);
