import mongoose from "mongoose";
const { Schema } = mongoose;

export const PermissionKeys = ["read", "write", "update", "delete"] as const;

/**
 * Mongoose schema for storing permissions.
 *
 * The schema defines a `permissions` field, which is a Map where:
 * - The key is a namespace such as "profiles" or "websites".
 * - The value is another Map, where:
 *   - The key is a resource such as "actors" or "producers".
 *   - The value is an array of actions such as "read" or "write".
 *
 * The array of strings is validated against the `PermissionKeys` enum and is required.
 * The schema does not include an `_id` field.
 *
 * @example
 * {
 *   permissions: {
 *     "namespace": {
 *       "resource": [actions],
 *       "resource": [actions]
 *     },
 *     "profiles": {
 *       "actors": ["READ"]
 *     }
 *   }
 * }
 */
export const PermissionsSchema = new Schema(
	{
		permissions: {
			type: Map,
			of: {
				type: Map,
				of: {
					type: [String],
					enum: [...PermissionKeys],
					required: true,
				},
			},
			default: {},
		},
	},
	{ _id: false }
);

/**
 * The base schema for the organization.
 *
 * @remarks
 * This schema defines the structure of organization data in the database.
 * It includes fields for the display name, client ID, issuer, client secret,
 * provider ID, enabled status, and authorized domains.
 *
 * @implements {import("firebase-admin/auth").OIDCAuthProviderConfig}
 */
export const OrgSchema = new Schema({
	/**
	 * The user-friendly display name to the current configuration. This name is
	 * also used as the provider label in the Cloud Console.
	 */
	displayName: { type: String, required: true },
	/**
	 * This is the required client ID used to confirm the audience of an OIDC
	 * provider's
	 * [ID token](https://openid.net/specs/openid-connect-core-1_0-final.html#IDToken).
	 */
	clientId: { type: String, required: true },
	/**
	 * This is the required provider issuer used to match the provider issuer of
	 * the ID token and to determine the corresponding OIDC discovery document, eg.
	 * [`/.well-known/openid-configuration`](https://openid.net/specs/openid-connect-discovery-1_0.html#ProviderConfig).
	 * This is needed for the following:
	 * <ul>
	 * <li>To verify the provided issuer.</li>
	 * <li>Determine the authentication/authorization endpoint during the OAuth
	 *     `id_token` authentication flow.</li>
	 * <li>To retrieve the public signing keys via `jwks_uri` to verify the OIDC
	 *     provider's ID token's signature.</li>
	 * <li>To determine the claims_supported to construct the user attributes to be
	 *     returned in the additional user info response.</li>
	 * </ul>
	 * ID token validation will be performed as defined in the
	 * [spec](https://openid.net/specs/openid-connect-core-1_0.html#IDTokenValidation).
	 */
	issuer: {
		type: String,
		required: true,
		enum: ["https://auth.wdf.me"],
		default: "https://auth.wdf.me",
	},
	/**
	 * The OIDC provider's client secret to enable OIDC code flow.
	 */
	clientSecret: { type: String, required: false, default: undefined },
	/**
	 * The provider ID defined by the developer.
	 * For a SAML provider, this is always prefixed by `saml.`.
	 * For an OIDC provider, this is always prefixed by `oidc.`.
	 */
	providerId: {
		type: String,
		required: true,
		enum: ["oidc.wdf.me"],
		default: "oidc.wdf.me",
	},

	/**
	 * Whether the provider configuration is enabled or disabled. A user
	 * cannot sign in using a disabled provider.
	 */
	enabled: { type: Boolean, required: true, default: true },

	/**
	 * The list of authorized domains for the provider. This is used to
	 * restrict the domains that can use this provider for authentication.
	 */
	authorized_domains: { type: [String], required: true },
});
