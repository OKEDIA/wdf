import type { Model } from "mongoose";
import { BaseRepository } from "../../../domain/_base/ports.js";
import { ResponseSettings } from "../../../domain/api/types.js";
import {
	createMongooseProjection,
	NestedProjection,
} from "../../../utils/projection.js";

/**
 * Abstract base adapter class for Mongoose models, providing common CRUD operations.
 *
 * @template BaseType - The base type representing the bare document type without any mongoose-specific properties.
 * @template ReturnType - The return type for repository methods, so we can return hydrated mongoose documents from backend libraries. 
   Defaults to BaseType for use in frontend libraries.
 *
 * @implements {BaseRepository<BaseType, ReturnType>}
 *
 * @remarks
 * This class is intended to be extended by specific adapters for different collections.
 * It provides generic implementations for `find`, `create`, `update`, and `delete` methods,
 * and supports projection, population, and pagination for queries.
 *
 * @example
 * class UserAdapter extends BaseMongooseAdapter<UserBasic, UserMongoose> { ... }
 */
export abstract class BaseMongooseAdapter<BaseType, ReturnType = BaseType>
	implements BaseRepository<BaseType, ReturnType>
{
	/**
	 * Creates an instance of the adapter.
	 *
	 * @param model - A Mongoose model instance used to interact with the database.
	 * @param validator - A function that validates and converts raw data into type T.
	 */

	constructor(
		protected model: Model<BaseType>,
		protected validator: (data: any) => BaseType
	) {}

	async find<PopulatePaths = {}>(
		args: ResponseSettings
	): Promise<
		(Omit<ReturnType, keyof PopulatePaths> & PopulatePaths)[] | undefined
	> {
		const { filter, projection, populate, pagination, sort, groupBy } = args;

		// 1) build the base query
		let processedFilter = filter;

		// Replace any { key: '*' } with { key: { $exists: true } }
		if (Array.isArray(filter)) {
			processedFilter = filter.map((f) => {
				const newObj: Record<string, any> = {};
				for (const key in f) {
					if (f[key] === "*") {
						newObj[key] = { $exists: true };
					} else {
						newObj[key] = f[key];
					}
				}
				return newObj;
			});
		} else if (typeof filter === "object") {
			const newObj: Record<string, any> = {};
			if (filter && typeof filter === "object") {
				for (const key in filter as Record<string, any>) {
					if ((filter as Record<string, any>)[key] === "*") {
						newObj[key] = { $exists: true };
					} else {
						newObj[key] = (filter as Record<string, any>)[key];
					}
				}
			}
			processedFilter = [newObj];
		}

		let baseQuery = this.model.find(
			!processedFilter
				? {}
				: Array.isArray(processedFilter)
					? { $and: processedFilter }
					: processedFilter
		);

		// 2) apply projection
		if (projection) {
			baseQuery = baseQuery.select(createMongooseProjection(projection));
		}

		// 3) apply sorting
		if (sort) {
			baseQuery = baseQuery.sort(sort);
		}

		// 4) apply pagination
		if (pagination) {
			const { page = 1, limit = 20 } = pagination;
			const skip = (page - 1) * limit;
			baseQuery = baseQuery.skip(skip).limit(limit);
		}

		// 5) apply groupBy (via aggregation + lookup, if you need real grouping)
		//    If groupBy is a simple field-based grouping, you might instead do:
		//    baseQuery = baseQuery.sort({ [groupBy]: 1 });
		//    Or, if you require true $group, you'll need an aggregation pipeline:
		//    const pipeline = [
		//      { $match: filter },
		//      { $group: { _id: `$${groupBy}`, items: { $push: '$$ROOT' } } },
		//      // and then optionally $skip/$limit/$sort
		//    ];
		//    const docs = await this.model.aggregate(pipeline).exec();
		//    return docs as any; // aggregated shape
		//
		//    Here, I'll demonstrate a simple sort-as-group:
		if (groupBy) {
			baseQuery = baseQuery.sort({ [groupBy]: 1 });
		}

		// 6) handle populate
		if (populate) {
			const populateArray = Array.isArray(populate) ? populate : [populate];
			const populateOptions = populateArray.map((pop) => {
				const { field, populatePage = 1, populateLimit = 20, ...rest } = pop;
				const skip = (populatePage - 1) * populateLimit;
				return {
					path: field,
					options: { skip, limit: populateLimit },
					...rest,
				};
			});

			const populatedQuery = baseQuery.populate<PopulatePaths>(populateOptions);
			const docs = await populatedQuery.exec();
			return docs as (Omit<ReturnType, keyof PopulatePaths> & PopulatePaths)[];
		}

		// 7) no populate: execute baseQuery
		const docs = await baseQuery.exec();
		return docs as (Omit<ReturnType, keyof PopulatePaths> & PopulatePaths)[];
	}
	/**
	 * Creates a new document in the database.
	 *
	 * Automatically sets the createdAt and updatedAt fields to the current timestamp.
	 *
	 * @param input - An object containing the partial data for type T.
	 * @returns A promise that resolves to the created object of type T.
	 */

	async create(input: Partial<BaseType>): Promise<ReturnType> {
		const now = new Date().toISOString();
		const full = { ...input, createdAt: now, updatedAt: now };
		const created = await new this.model(full).save();
		return created as ReturnType;
	}

	/**
	 * Updates an existing document by its identifier.
	 *
	 * Automatically updates the updatedAt field to the current timestamp.
	 *
	 * @param id - The identifier of the document to update.
	 * @param updates - An object containing the fields of type T to update.
	 * @returns A promise that resolves to the updated object of type T if the document exists, or null otherwise.
	 */
	async update(
		id: string,
		updates: Partial<BaseType>,
		projection: NestedProjection = {}
	): Promise<ReturnType | undefined> {
		const updatedAt = new Date().toISOString();
		const doc = await this.model
			.findByIdAndUpdate(id, { ...updates, updatedAt }, { new: true })
			.select(createMongooseProjection(projection));

		return doc as ReturnType;
	}

	/**
	 * Deletes a document by its identifier.
	 *
	 * @param id - The identifier of the document to delete.
	 * @returns A promise that resolves when the deletion is complete.
	 */
	async delete(id: string): Promise<void> {
		await this.model.findByIdAndDelete(id);
	}
}
