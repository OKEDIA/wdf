export { BaseMongooseAdapter } from "./base.adapter.js";
