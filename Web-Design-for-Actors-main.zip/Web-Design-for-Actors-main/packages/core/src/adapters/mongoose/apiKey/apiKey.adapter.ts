import { ObjectId } from "bson";
import type { Model } from "mongoose";
import mongoose from "mongoose";
import { ApiKeyRepository } from "../../../domain/apiKey/ports/collection.ports.js";
import { ApiKeyService } from "../../../domain/apiKey/services/collection.services.js";
import { ApiKeyBasic, ApiKeyMongoose } from "../../../domain/apiKey/types.js";
import { BaseMongooseAdapter } from "../common/base.adapter.js";
import { ApiKeySchema } from "./apiKey.schema.js";
const { model, models } = mongoose;
export const ApiKey: Model<ApiKeyBasic> =
	models.ApiKey || model<ApiKeyBasic>("ApiKey", ApiKeySchema, "apikeys");

const fakeValidator = (data: ApiKeyMongoose) => data;

/**
 * A Mongoose adapter for managing profile documents.
 *
 * @class ApiKeyManager
 *
 * @extends {BaseMongooseAdapter<ApiKeyBasic>}
 * @implements ApiKeyRepository
 *
 * @remarks
 * This class serves as a bridge between the Mongoose model (ApiKeyModel) and the domain logic
 * for apikey management. It uses the BaseMongooseAdapter to provide core database operations
 * while ensuring that the data conforms to the ApiKey interface.
 *
 * Important:
 * - Do not add new functions here. New functionality should be implemented in
 *   the domain/apiKey/services/collection.services.ts file to allow for re-use across the application.
 *
 * @example
 * const apiKeyManager = new ApiKeyManager();
 * Use apiKeyManager to interact with apikey data in MongoDB
 */
export class ApiKeyManager
	extends BaseMongooseAdapter<ApiKeyBasic, ApiKeyMongoose>
	implements ApiKeyRepository
{
	// * Note:
	//   Don't define new functions here. Instead functions should be imported from domain/profile/services/collection.services.ts file for re-use everywhere.
	// *
	private keyService = new ApiKeyService();

	constructor() {
		super(ApiKey, (data) => fakeValidator(data));
	}

	/**
	 * Creates a new API key document in the database.
	 *
	 * @param data - Partial data for the API key to be created.
	 * @returns A promise that resolves to the created API key document with a salted (encrypted) ID.
	 */
	async create(data: ApiKeyBasic): Promise<ApiKeyMongoose> {
		const id = new ObjectId();
		const saltedId = this.keyService.encrypt(id);

		const doc = await this.model.create({ ...data, _id: id });
		doc._id = saltedId;

		return doc;
	}

	/**
	 * Retrieves an API key document by its encrypted ID.
	 *
	 * @param id - The encrypted API key identifier.
	 * @returns A promise that resolves to the API key document with the original encrypted ID,
	 *          or `null` if no document is found.
	 */
	async get(id: string): Promise<ApiKeyBasic | undefined> {
		const _decryptedId = this.keyService.decrypt(id);

		if (!_decryptedId) {
			return undefined;
		}

		const doc = await this.model.findById(_decryptedId).lean().exec();

		if (!doc) {
			return undefined;
		}

		doc.id = id;
		return doc;
	}

	async find(): Promise<never> {
		throw new Error("The find method is disabled for ApiKeyManager.");
	}
}
