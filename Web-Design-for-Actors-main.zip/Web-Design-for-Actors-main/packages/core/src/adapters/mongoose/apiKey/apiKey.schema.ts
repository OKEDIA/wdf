import mongoose from "mongoose";
import { OrgSchema, PermissionsSchema } from "../common/permissions.schema.js";
const { Schema } = mongoose;

/**
 * Mongoose schema for the apikey collection.
 *
 * @remarks
 * DOCUMENT LEVEL FUNCTIONS FOR THE APIKEY COLLECTION.
 *
 * @example
 * const apiKeySchema = new ApiKeySchema();
 * const ApiKeyModel = mongoose.model("ApiKey", apiKeySchema);
 */

export const ApiKeySchema = new Schema({
	...OrgSchema.obj,
	...PermissionsSchema.obj,
});

// Apply schema-level options
ApiKeySchema.set("timestamps", { createdAt: "created", updatedAt: "updated" });
