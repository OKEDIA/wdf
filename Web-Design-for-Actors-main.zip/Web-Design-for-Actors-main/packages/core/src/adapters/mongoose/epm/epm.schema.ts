import mongoose from "mongoose";
const { Schema } = mongoose;
import { BaseSchema } from "../common/base.schema.js";

/**
 * Mongoose schema for the epm collection.
 *
 * @remarks
 * DOCUMENT LEVEL FUNCTIONS FOR THE EPM COLLECTION.
 *
 * @example
 * const epmSchema = new EpmSchema();
 * const EpmModel = mongoose.model("Epm", epmSchema);
 */
export const EpmSchema = new Schema({
	...BaseSchema.obj,
	type: {
		type: String,
		required: true,
		enum: [
			"crew",
			"creatives",
			"producers",
			"cast",
			"productions",
			"suppliers",
			"venues",
			"cards",
		],
	},
	profile: { type: Schema.Types.ObjectId, ref: "Profile", required: true },
	notes: { type: String, required: false, default: undefined },
	status: {
		type: Number,
		required: true,
		default: 0,
		enum: [0, 1, 2, 3, 4, 5],
	},
});

// Apply schema-level options
EpmSchema.set("timestamps", { createdAt: "created", updatedAt: "updated" });
