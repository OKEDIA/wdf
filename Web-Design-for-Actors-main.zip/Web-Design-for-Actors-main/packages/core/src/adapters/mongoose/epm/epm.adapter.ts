import type { Model } from "mongoose";
import mongoose from "mongoose";
import { EpmRepository } from "../../../domain/epm/ports/collection.ports.js";
import { EpmBasic, EpmMongoose } from "../../../domain/epm/types.js";
import { BaseMongooseAdapter } from "../../../domain/index.js";
import { EpmSchema } from "./epm.schema.js";
const { model, models } = mongoose;

export const EpmModel: Model<EpmBasic> =
	models.Epm || model<EpmBasic>("Epm", EpmSchema, "epm");

const fakeValidator = (data: EpmMongoose) => data;

/**
 * A Mongoose adapter for managing profile documents.
 *
 * @class ProfileManager
 *
 * @extends {BaseMongooseAdapter<EpmBasic, EpmMongoose>}
 * @implements BaseRepository<EpmBasic, EpmMongoose>
 *
 * @remarks
 * This class serves as a bridge between the Mongoose model (EpmModel) and the domain logic
 * for epm management. It uses the BaseMongooseAdapter to provide core database operations
 * while ensuring that the data conforms to the Epm interface.
 *
 * Important:
 * - Do not add new functions here. New functionality should be implemented in
 *   the domain/epm/services/collection.services.ts file to allow for re-use across the application.
 *
 * @example
 * const epmManager = new EpmManager();
 * Use epmManager to interact with epm data in MongoDB
 */
export class EpmManager
	extends BaseMongooseAdapter<EpmBasic, EpmMongoose>
	implements EpmRepository
{
	// * Note:
	//   Don't define new functions here. Instead functions should be imported from domain/profile/services/collection.services.ts file for re-use everywhere.
	// *

	constructor() {
		super(EpmModel, (data) => fakeValidator(data));
	}
}
