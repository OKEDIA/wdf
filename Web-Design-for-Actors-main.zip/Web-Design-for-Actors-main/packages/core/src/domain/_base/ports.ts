import { ResponseSettings } from "../api/types.js";

/**
 * Defines the contract for a generic repository that provides basic CRUD operations
 * for managing documents in a data store.
 *
 * @typeParam InitialDoc - The return type for repository methods, so we can return hydrated mongoose documents (methods/objects/statics/virtuals etc) in backend libraries. 
   Defaults to BaseType for use in frontend libraries where changes to the document don't return additional methods/objects/statics/virtuals/etc.
 * @typeParam ReturnedDoc - The shape of the document returned by repository methods. Defaults to `InitialDoc`.
 *
 * @remarks
 * This interface abstracts the data access layer, allowing for flexible implementations
 * across different storage mechanisms (e.g., databases, APIs).
 *
 * @example
 * ```typescript
 * class UserRepository implements BaseRepository<UserBasic, UserMongoose> { ... }
 * ```
 */
/**
 * Retrieves documents from the repository based on the provided response settings.
 *
 * @param responseSettings - An object specifying how the response should be formatted or filtered.
 * @returns A promise that resolves to an array of returned documents, or undefined if no documents are found.
 */
export interface BaseRepository<InitialDoc, ReturnedDoc = InitialDoc> {
	find<PopulatePaths = {}>(
		settings: ResponseSettings
	): Promise<
		(Omit<ReturnedDoc, keyof PopulatePaths> & PopulatePaths)[] | undefined
	>;

	/**
	 * Creates a new document with the given partial document data.
	 *
	 * @param document - An object containing the properties for the new document.
	 * @returns A promise that resolves to the newly created document.
	 */
	create(document: Partial<InitialDoc>): Promise<ReturnedDoc>;

	/**
	 * Updates an existing document identified by the given id with new values.
	 *
	 * @param id - The unique identifier of the document to update.
	 * @param updates - An object containing the document properties to update.
	 * @param responseSettings - An object specifying how the response should be formatted or filtered.
	 * @returns A promise that resolves to the updated document.
	 */
	update(
		id: string,
		updates: Partial<InitialDoc>,
		responseSettings?: ResponseSettings
	): Promise<ReturnedDoc>;

	/**
	 * Deletes a document with the specified unique identifier.
	 *
	 * @param id - The unique identifier of the document to delete.
	 * @returns A promise that resolves when the operation is complete.
	 */
	delete(id: string): Promise<void>;
}
