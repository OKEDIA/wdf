import { NestedProjection } from "../../utils/projection.js";

export interface RequestMethod {
	/**
	 * The HTTP method to use for the request.
	 * @example "GET"
	 */
	method: "GET" | "POST" | "PATCH" | "DELETE";
	/**
	 * The full URL to send the request to.
	 * @example "https://api.example.com/resource"
	 */
	url: string;
	/**
	 * The request body, if applicable.
	 * @example { "key": "value" }
	 * @remarks This is typically used in POST and PATCH requests.
	 */
	body?: unknown;
	/**
	 * The request headers.
	 * @example { "Content-Type": "application/json" }
	 */
	options?: RequestInit;
	/**
	 * The response settings for the request.
	 * @example { filter: { key: "value" }, pagination: { page: 1, limit: 10 } }
	 */
	responseSettings?: ResponseSettings;
}

interface PopulationSettings {
	/**
	 * The field to populate.
	 * @example "author"
	 */
	field: string;
	/**
	 * The page number for pagination of the populated data.
	 * @example 1
	 */
	populatePage?: number;
	/**
	 * The limit for pagination of the populated data.
	 * @example 10
	 */
	populateLimit?: number;
}

export interface ResponseSettings {
	/**
	 * The filter to apply to the request.
	 * @example [{ "status": "active" }]
	 */
	filter?: Record<string, any>[] | undefined;
	/**
	 * The projection to apply to the request.
	 * @defaultValue Always includes: ["created", "updated", "permissions", "type", "id", "development"]
	 * @example { "intro": true, "socials.socialMedia.network": true }
	 */
	projection?: NestedProjection;
	/**
	 * The population settings for the request.
	 * @example [{ field: "author", populatePage: 1, populateLimit: 10 }]
	 * @remarks This is used to specify which fields to populate and their pagination settings.
	 * @see [Mongoose Population Documentation](https://mongoosejs.com/docs/populate.html)
	 */
	populate?: PopulationSettings[];
	/**
	 * The pagination settings for the request.
	 * @example { page: 1, limit: 10, count: "total", afterId: "12345" }
	 */
	pagination?: {
		/**
		 * The page number for pagination.
		 * @example 1
		 */
		page?: number;
		/**
		 * The limit for pagination.
		 * @example 10
		 */
		limit?: number;
		/**
		 * The total count of items.
		 * @example "total"
		 */
		count?: string;
		/**
		 * The ID to start pagination after.
		 * @example "12345"
		 */
		afterId?: string;
	};
	/**
	 * The sorting settings for the request.
	 * @example { "createdAt": -1 }
	 */
	sort?: string;
	/**
	 * The field to group the results by.
	 * @example "category"
	 */
	groupBy?: string;
	/**
	 * Additional query parameters usually added by a request URL such as ?userId=123
	 * @remarks This is used for any additional parameters that don't fit into the other categories.
	 * @example { "userId": "123" }
	 */
	params?: Record<string, string>;
}

export interface ApiSuccess<T> {
	success: true;
	response: T;
}

export interface ApiError {
	success: false;
	message: string;
}

export type ApiResponse<T> = ApiSuccess<T> | ApiError;
