// Firebase Admin Auth
import type { UserRecord } from "firebase-admin/auth";
import { verifyJwt } from "../../utils/jwt.js";
import type { PermissionOrg, Tenant } from "../apiKey/types.js";
import type { ProfileBasic } from "../profiles/index.js";
export { UserRecord };

// Internal Auth
export type Token = string;

// API Responses

export type ResolvedAuthToken = Awaited<
	ReturnType<typeof verifyJwt<PermissionOrg & Tenant & { user?: UserRecord }>>
>;

export type AuthApiResponses = {
	get: {
		"auth/init": Token;
		"auth/login": Token;
	};
};

export type ProfileApiResponses<T> = {
	get: {
		"profiles/*": ProfileBasic<T>[];
	};
};
