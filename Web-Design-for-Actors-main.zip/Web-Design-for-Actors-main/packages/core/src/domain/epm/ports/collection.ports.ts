import { BaseRepository } from "../../_base/ports.js";
import { EpmBasic } from "../index.js";

/**
 * Provides an abstraction for performing CRUD operations on Epm entities.
 *
 * This is the Ports layer (Interfaces/Contracts) of the hexagonal architecture for "Epm".
 * The EpmRepository interface defines the contracts (ports) through which the core
 * business logic interacts with external systems (adapters).
 *
 * @remarks
 * This interface includes COLLECTION LEVEL functions for the Epm collection.
 * We can add methods here to handle any future specific epm-related tasks and they should then be defined in the adapter.
 */

export interface EpmRepository extends BaseRepository<EpmBasic> {}
