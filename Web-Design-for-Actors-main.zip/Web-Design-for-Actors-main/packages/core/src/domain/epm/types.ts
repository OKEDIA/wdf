import type { HydratedDocument, InferSchemaType } from "mongoose";
import { EpmSchema } from "../../adapters/mongoose/epm/epm.schema.js";
import { Base } from "../profiles/types.js";

export type EpmBasic = InferSchemaType<typeof EpmSchema> & Base;
export type EpmMongoose = HydratedDocument<EpmBasic>;

export type EpmApiResponses<T> = {
	get: {
		"epm/*": EpmBasic[];
	};
};
