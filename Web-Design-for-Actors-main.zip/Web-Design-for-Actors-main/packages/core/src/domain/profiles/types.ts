import type { HydratedDocument, InferSchemaType } from "mongoose";
import { BaseSchema } from "../../adapters/mongoose/common/base.schema.js";
import { ActorSchema } from "../../adapters/mongoose/profiles/actor.schema.js";
import { ProductionSchema } from "../../adapters/mongoose/profiles/production.schema.js";
import { ProfileSchema } from "../../adapters/mongoose/profiles/profile.schema.js";
import { MongooseProfile } from "./ports/document.ports.js";

/** @deprecated Use ActorBasic or ActorMongoose instead */
export type Actor = ActorMongoose;

/** @deprecated Use ProductionBasic or ProductionMongoose instead */
export type Production = ProductionMongoose;

// Base Types
export type Base = InferSchemaType<typeof BaseSchema>;
export type ProfileBasic<T> = T & InferSchemaType<typeof ProfileSchema> & Base;
export { MongooseProfile as ProfileMongoose };

// Actor Profiles
export type ActorBasic = ProfileBasic<InferSchemaType<typeof ActorSchema>>;
export type ActorMongoose = HydratedDocument<MongooseProfile<ActorBasic>>;

// Production Profiles
export type ProductionBasic = ProfileBasic<
	InferSchemaType<typeof ProductionSchema>
>;
export type ProductionMongoose = HydratedDocument<
	MongooseProfile<ProductionBasic>
>;

// Unknown Profile Type
export type AnyProfileBasic = ActorBasic | ProductionBasic;
export type AnyProfileMongoose = HydratedDocument<AnyProfileBasic>;
