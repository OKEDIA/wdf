// import { Profile } from "../../index.js";

import { ProfileBasic, ProfileMongoose } from "../types.js";
/**
 * Provides an abstraction for performing document-level operations on Profile entities.
 *
 * This is the Ports layer (Interfaces/Contracts) of the hexagonal architecture for all mongoose functions.
 * The BaseRepository interface defines the contracts (ports) through which the core
 * business logic interacts with external systems (adapters).
 *
 * @remarks
 * DOCUMENT LEVEL FUNCTIONS FOR THE PROFILE DOCUMENTS.
 * This interface defines methods for creating, retrieving, updating, and deleting mongodb documents.
 */

export type MongooseProfile<T> = ProfileBasic<T> & {
	/**
	 * Claim the profile for a user.
	 *
	 * @param userId - The user ID of the person claiming the profile.
	 * @returns An updated profile object.
	 * @throws Error if the user is already an owner.
	 * @throws Error if the user is not the creator of the profile.
	 */
	claim(userId: string): Promise<ProfileBasic<T>>;
	/**
	 * Add a permission to the profile.
	 *
	 * @param userId - The user ID of the person to add.
	 * @param type - The type of permission to add (owner or editor).
	 * @returns An updated profile object.
	 */
	addPermission(
		userId: string,
		type: keyof NonNullable<ProfileBasic<T>["permissions"]>
	): Promise<ProfileBasic<T>>;
	/**
	 * Remove a permission from the profile.
	 *
	 * @param userId - The user ID of the person to remove.
	 * @param type - The type of permission to remove (owner or editor).
	 * @returns An updated profile object.
	 */
	removePermission(
		userId: string,
		type: keyof NonNullable<ProfileBasic<T>["permissions"]>
	): Promise<ProfileMongoose<T>>;
};
