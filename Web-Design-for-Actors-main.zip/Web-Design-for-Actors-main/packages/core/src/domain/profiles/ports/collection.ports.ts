import { BaseRepository } from "../../_base/ports.js";
import { ActorBasic, ProductionBasic, ProfileBasic } from "../types.js";

/**
 * Provides an abstraction for performing CRUD operations on Profile entities.
 *
 * This is the Ports layer (Interfaces/Contracts) of the hexagonal architecture for "Profiles".
 * The ProfileRepository interface defines the contracts (ports) through which the core
 * business logic interacts with external systems (adapters).
 *
 * @remarks
 * This interface includes COLLECTION LEVEL functions for the Profiles collection.
 * We can add methods here to handle any future specific profile-related tasks and they should then be defined in the adapter.
 */

export interface ProfileRepository
	extends BaseRepository<
		| ProfileBasic<ActorBasic>
		| ProfileBasic<ProductionBasic>
		| ProfileBasic<unknown>
	> {}
