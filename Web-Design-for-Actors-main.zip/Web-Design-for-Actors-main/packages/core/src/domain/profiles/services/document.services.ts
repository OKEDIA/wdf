import { ObjectId } from "bson";
import { produce } from "immer";
import { ProfileBasic } from "../index.js";

export class ProfileService {
	constructor(private profile: ProfileBasic<unknown>) {}

	/**
	 * Claims a profile for a given user immutably.
	 *
	 * @param userId - The identifier of the user claiming the profile.
	 * @returns The updated profile with the userId added as an owner.
	 * @throws {Error} When the profile is already claimed by another user or the userId is invalid.
	 */
	async claim(userId: string): Promise<any> {
		// Verify that the userId is a valid ObjectId.
		if (!ObjectId.isValid(userId)) {
			throw new Error("Invalid user ID");
		}

		// If the profile is claimed by someone else, throw an error.
		if (
			this.profile.permissions?.owners?.length &&
			!this.profile.permissions.owners.some((owner) =>
				(owner as unknown as ObjectId).equals(new ObjectId(userId))
			)
		) {
			throw new Error("Profile already claimed by another user");
		}

		//
		if (
			this.profile.permissions?.owners?.some((owner) =>
				(owner as unknown as ObjectId).equals(new ObjectId(userId))
			)
		) {
			return this.profile;
		}

		// Use immer to update the profile immutably and update the instance.
		return produce(this.profile, (draft) => {
			if (!draft.permissions) {
				// Initialize permissions if it doesn't exist.
				draft.permissions = {} as typeof draft.permissions;
			}
			if (!draft.permissions.owners) {
				// Initialize owners array if it doesn't exist.
				draft.permissions.owners = [] as typeof draft.permissions.owners;
			}

			// Add the userId to the owners array.
			draft.permissions.owners.push(new ObjectId(userId));
		});
	}

	/**
	 * Adds a permission for the given user to the specified permission type immutably.
	 *
	 * @param type - The key of the permissions object where the userId is to be added.
	 * @param userId - The identifier of the user to add.
	 * @returns The updated profile with the new permission.
	 * @throws Error if the profile has not been claimed, the permission type is invalid,
	 * attempting to set the creator permission manually, or the userId is invalid.
	 */
	async addPermission(
		userId: string,
		type: keyof NonNullable<ProfileBasic<any>["permissions"]>
	) {
		console.log("Adding permission to profile...");
		const { profile } = this;

		if (!profile.permissions?.owners?.length) {
			throw new Error(
				"Profile has not yet been claimed. Claim the profile first before adding permissions for other users."
			);
		}

		if (!(profile.permissions && type in profile.permissions)) {
			throw new Error("Invalid permission type");
		}

		if (type === "creator") {
			throw new Error(
				"Unable to add the permission. Creator key cannot be set manually."
			);
		}

		if (!ObjectId.isValid(userId)) {
			throw new Error("Invalid user ID");
		}

		// Use immer to update the profile immutably.
		const updatedProfile = produce(profile, (draft) => {
			if (!draft.permissions) {
				console.log("Permissions not found, initializing...");
				// Initialize permissions if it doesn't exist.
				draft.permissions = {} as typeof draft.permissions;
			}
			// Initialize permission array if it doesn't exist.
			draft.permissions[type] = draft.permissions[type] || [];
			draft.permissions[type].push(new ObjectId(userId));
		});
		this.profile = updatedProfile;
		return this.profile;
	}

	/**
	 * Removes a permission for the given user from the specified permission type immutably.
	 *
	 * @param type - The key of the permissions object from which the userId is to be removed.
	 * @param userId - The identifier of the user to remove.
	 * @returns The updated profile with the permission removed.
	 * @throws Error if the profile has not been claimed, the permission type is invalid,
	 * attempting to remove the creator permission, the userId is invalid, or the user does not have this permission.
	 */
	async removePermission(
		userId: string,
		type: keyof NonNullable<ProfileBasic<any>["permissions"]>
	): Promise<any> {
		const { profile, ...rest } = this;

		if (!profile.permissions?.owners?.length) {
			throw new Error(
				"Profile has not yet been claimed. Claim the profile first before removing permissions for users."
			);
		}

		if (type === "creator") {
			throw new Error(
				"Unable to remove the permission. Creator cannot be removed."
			);
		}

		if (!(profile.permissions && type in profile.permissions)) {
			throw new Error("Invalid permission type");
		}

		if (!ObjectId.isValid(userId)) {
			throw new Error("Invalid user ID");
		}

		// Check if the user has the permission to remove.
		const currentPermission = profile.permissions[
			type
		] as unknown as ObjectId[];

		if (
			!currentPermission.find((permission) =>
				permission.equals(new ObjectId(userId))
			)
		) {
			throw new Error(
				"Unable to remove the permission. User does not currently have this permission."
			);
		}

		// Use immer to update the profile immutably.
		return produce(profile, (draft) => {
			if (!draft.permissions) {
				// Initialize permissions if it doesn't exist.
				draft.permissions = {} as typeof draft.permissions;
			}

			draft.permissions[type] = (draft.permissions[type] as ObjectId[]).filter(
				(permittedUser: ObjectId) => !permittedUser.equals(new ObjectId(userId))
			);
		});
	}
}
