import { BaseRepository } from "../../_base/ports.js";
import { ApiKeyBasic } from "../types.js";

/**
 * Provides an abstraction for performing CRUD operations on ApiKey entities.
 *
 * This is the Ports layer (Interfaces/Contracts) of the hexagonal architecture for "ApiKey"s.
 * The ApiKeyRepository interface defines the contracts (ports) through which the core
 * business logic interacts with external systems (adapters).
 *
 * @remarks
 * This interface includes COLLECTION LEVEL functions for the Apikey collection.
 * We can add methods here to handle any future specific apiKey-related tasks and they should then be defined in the adapter.
 */

export interface ApiKeyRepository extends BaseRepository<ApiKeyBasic> {}
