import type { HydratedDocument, InferSchemaType } from "mongoose";
import { ApiKeySchema } from "../../adapters/mongoose/apiKey/apiKey.schema.js";
import {
	PermissionKeys,
	PermissionsSchema,
} from "../../adapters/mongoose/common/permissions.schema.js";

// API Keys
export type ApiKeyBasic = InferSchemaType<typeof ApiKeySchema>;
export type ApiKeyMongoose = HydratedDocument<ApiKeyBasic>;

// Permissions
export type Tenant = InferSchemaType<typeof PermissionsSchema>;
export type PermissionRule = Tenant["permissions"];
export type PermissionOrg = Omit<
	InferSchemaType<typeof ApiKeySchema>,
	"permissions"
>;
export type PermissionKey = (typeof PermissionKeys)[number];
