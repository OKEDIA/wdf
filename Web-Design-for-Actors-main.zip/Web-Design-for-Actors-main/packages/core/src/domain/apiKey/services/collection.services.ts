import { ObjectId } from "bson";
import crypto from "crypto";

export class ApiKeyService {
	constructor() {
		if (!process.env.APIKEY_ENCRYPTION_KEY || !process.env.APIKEY_HMAC_KEY) {
			throw new Error("APIKEY_ENCRYPTION_KEY and APIKEY_HMAC_KEY must be set");
		}
	}

	#ENCRYPTION_KEY = Buffer.from(process.env.APIKEY_ENCRYPTION_KEY!, "base64");
	#HMAC_KEY = process.env.APIKEY_HMAC_KEY;

	/**
	 * Encrypts the provided ObjectId using AES-256-CBC encryption and generates an HMAC for integrity.
	 *
	 * The method performs the following steps:
	 * 1. Generates a random initialization vector (IV).
	 * 2. Encrypts the string representation of the ObjectId using AES-256-CBC with a secret key and IV.
	 * 3. Concatenates the IV and encrypted data, separated by a colon.
	 * 4. Computes an HMAC (SHA-256) of the concatenated data using a secret HMAC key.
	 * 5. Returns the final result as a base64-encoded string containing the IV, encrypted data, and HMAC.
	 *
	 * @param key - The ObjectId to encrypt.
	 * @returns A promise that resolves to a base64-encoded string containing the encrypted ObjectId and its HMAC.
	 */
	encrypt(key: ObjectId): string {
		// Generate a random initialization vector (IV)
		const iv = crypto.randomBytes(16);

		// Create a cipher using the encryption key and IV
		const cipher = crypto.createCipheriv(
			"aes-256-cbc",
			this.#ENCRYPTION_KEY,
			iv
		);

		// Encrypt the stringified ObjectId
		let encrypted = cipher.update(key.toString(), "utf8", "base64");
		encrypted += cipher.final("base64");

		// Concatenate the IV and encrypted data, separated by a colon
		const data = iv.toString("base64") + ":" + encrypted;

		// Compute the HMAC of the concatenated data
		const hmac = crypto
			.createHmac("sha256", this.#HMAC_KEY)
			.update(data)
			.digest("base64");

		// Return the final result as a base64-encoded string
		return Buffer.from(`${data}:${hmac}`).toString("base64");
	}

	decrypt(key: string): string {
		try {
			// Decode the base64-encoded string
			const decoded = Buffer.from(key, "base64").toString("utf8");

			// Split the decoded string into IV, encrypted data, and HMAC
			const [ivB64, encryptedB64, hmac] = decoded.split(":");

			// Check if the HMAC is valid
			const data = `${ivB64}:${encryptedB64}`;
			const expectedHmac = crypto
				.createHmac("sha256", this.#HMAC_KEY)
				.update(data)
				.digest("base64");

			// Compare the expected HMAC with the provided HMAC
			// If they don't match, the data may have been tampered with
			// or the key is invalid
			if (expectedHmac !== hmac) return null; // tampered

			// Decode the IV and encrypted data from base64
			const iv = Buffer.from(ivB64, "base64");

			// Check if the IV is valid
			const encrypted = Buffer.from(encryptedB64, "base64");

			// Create a decipher using the encryption key and IV
			const decipher = crypto.createDecipheriv(
				"aes-256-cbc",
				this.#ENCRYPTION_KEY,
				iv
			);

			// Decrypt the encrypted data
			let decrypted = decipher.update(encrypted, undefined, "utf8");
			decrypted += decipher.final("utf8");

			return decrypted;
		} catch {
			return null;
		}
	}
}
