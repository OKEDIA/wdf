import type { HydratedDocument, InferSchemaType } from "mongoose";
import {
	UsersSchema,
	UserTenantSchema,
} from "../../adapters/mongoose/users/users.schema.js";
import { Base } from "../profiles/types.js";

export type UserBasic = InferSchemaType<typeof UsersSchema> & Base;
export type UserMongoose = HydratedDocument<UserBasic>;

export type UserTenant = InferSchemaType<typeof UserTenantSchema>;
