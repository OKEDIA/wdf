// import { Profile, ProfileManager } from "../domain/index.js";
// import { ProfileRepository } from "../domain/profile/ports/collection.ports.js";

// export const makeProfileAPI = (repo: ProfileRepository<Profile>) => {
// 	const service = new ProfileManager();

// 	return {
// 		get: (id: string) => service.findById(id),
// 		listByType: (type: string) => service.findByType(type as any),
// 		create: (profile: any) => service.create(profile),
// 		update: (id: string, updates: any) => service.update(id, updates),
// 		delete: (id: string) => service.delete(id),
// 	};
// };
