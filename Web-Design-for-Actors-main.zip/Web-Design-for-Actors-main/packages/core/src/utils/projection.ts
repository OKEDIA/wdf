export type NestedProjection = {
	[key: string]: true | NestedProjection;
};

const GLOBAL_DEFAULTS = [
	"created",
	"updated",
	"permissions",
	"type",
	"id",
	"development",
];

/**
 * Flattens a nested projection object into dot-notation for Mongoose `.select()`.
 *
 * @param userProjection - Nested object like { permissions: { owners: true } }
 * @returns Flat projection object like { "permissions.owners": true }
 */
export function createMongooseProjection(
	userProjection: NestedProjection
): Record<string, true> {
	const result: Record<string, true> = {};

	function flatten(obj: NestedProjection, parentPath = "") {
		for (const key in obj) {
			const value = obj[key];
			const fullPath = parentPath ? `${parentPath}.${key}` : key;

			if (value === true) {
				result[fullPath] = true;
			} else if (typeof value === "object") {
				flatten(value, fullPath);
			}
		}
	}

	flatten(userProjection);

	// Always include items from GLOBAL_DEFAULTS
	for (const field of GLOBAL_DEFAULTS) {
		result[field] = true;
	}

	return result;
}
