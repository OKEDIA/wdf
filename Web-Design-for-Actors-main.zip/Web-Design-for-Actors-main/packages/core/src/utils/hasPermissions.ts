import { PermissionKey, Tenant } from "@okedia/core/domain/apiKey";

/**
 * Checks if a given action is permitted on a resource within a namespace.
 *
 * @param namespace - An object mapping resource names to arrays of allowed actions.
 * @param resource - The name of the resource to check permissions for. Defaults to `"*"`, which represents a wildcard resource.
 * @param action - The action to check permission for.
 * @returns `true` if the action is permitted on the resource or via a wildcard, otherwise `false`.
 */
export function hasPermission(
	rights: Tenant["permissions"],
	{
		namespace,
		resource = "*",
		action,
	}: {
		namespace: `/${string}`;
		resource: string;
		action: PermissionKey;
	}
): boolean {
	if (!namespace || !resource)
		throw new Error(
			"Unable to check permissions: namespace or resource is missing"
		);

	function handleTrue() {
		console.log(
			`Permission granted for action "${action}" on resource "${resource}" in namespace "${namespace}".`
		);
		return true;
	}

	try {
		if (rights?.[namespace]?.[resource]?.includes(action)) {
			return handleTrue();
		}

		if (rights?.[namespace]?.["*"]?.[action]) {
			return handleTrue();
		}

		console.log(
			`Permission denied for action "${action}" on resource "${resource}" in namespace "${namespace}".`
		);
		return false;
	} catch (error) {
		console.error(
			`Error checking permissions for action "${action}" on resource "${resource}" in namespace "${namespace}":`,
			error
		);
		return false;
	}
}
