import type { Secret } from "jsonwebtoken";

export function formatPrivateKey(key: Secret) {
	const keyStr = typeof key === "string" ? key : key.toString();
	return keyStr.replace(/\\n/g, "\n");
}
