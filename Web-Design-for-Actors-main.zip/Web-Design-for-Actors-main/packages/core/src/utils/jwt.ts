import { JWTPayload, SignJWT, jwtVerify } from "jose";

/**
 * Asynchronously signs a JWT (JSON Web Token) using the RS256 algorithm and a provided private key.
 *
 * @param payload - The payload object to include in the JWT.
 * @param privateKey - The PEM-encoded private key as a string, used for signing the JWT.
 * @returns A promise that resolves to the signed JWT as a string.
 *
 * @throws Will throw an error if the private key is invalid or if signing fails.
 *
 * @example
 * ```typescript
 * const token = await signJwt({ userId: 123 }, PRIVATE_KEY);
 * ```
 */
export async function signJwt(
	payload: object,
	privateKey: string
): Promise<string> {
	const cryptoKey = await crypto.subtle.importKey(
		"pkcs8",
		str2ab(privateKey),
		{
			name: "RSASSA-PKCS1-v1_5",
			hash: "SHA-256",
		},
		false,
		["sign"]
	);

	return await new SignJWT(payload as JWTPayload)
		.setProtectedHeader({ alg: "RS256" })
		.setExpirationTime("1h")
		.sign(cryptoKey);
}

/**
 * Verifies a JWT (JSON Web Token) using the provided RS256 public key.
 *
 * @template T - The expected shape of the JWT payload.
 * @param token - The JWT string to verify.
 * @param publicKey - The PEM-encoded RSA public key used for verification.
 * @returns A promise that resolves to the decoded JWT payload (merged with `JWTPayload`) if verification succeeds, or `null` if the token is invalid.
 *
 * @throws Will throw if the public key import or token verification fails.
 */
export async function verifyJwt<T>(
	token: string,
	publicKey: string
): Promise<T & JWTPayload> {
	// Import the public key as a CryptoKey for RS256
	const cryptoKey = await crypto.subtle.importKey(
		"spki",
		str2abPublic(publicKey),
		{
			name: "RSASSA-PKCS1-v1_5",
			hash: "SHA-256",
		},
		false,
		["verify"]
	);

	if (
		typeof token !== "string" ||
		!token.trim() ||
		token.split(".").length !== 3
	) {
		return null;
	}

	const { payload } = await jwtVerify(token, cryptoKey, {
		algorithms: ["RS256"],
	});

	return payload as T & JWTPayload;
}

/**
 * Converts a PEM-formatted public key string to an ArrayBuffer.
 *
 * This function removes the PEM header and footer, decodes the base64 content,
 * and returns the resulting binary data as an ArrayBuffer.
 *
 * @param pem - The PEM-formatted public key string.
 * @returns The decoded public key as an ArrayBuffer.
 */
function str2abPublic(pem: string): ArrayBuffer {
	const b64 = pem
		.replace(/-----BEGIN PUBLIC KEY-----/, "")
		.replace(/-----END PUBLIC KEY-----/, "")
		.replace(/\s+/g, "");
	const binary = atob(b64);
	const len = binary.length;
	const buffer = new ArrayBuffer(len);
	const view = new Uint8Array(buffer);
	for (let i = 0; i < len; i++) {
		view[i] = binary.charCodeAt(i);
	}
	return buffer;
}

/**
 * Converts a PEM-formatted private key string to an ArrayBuffer.
 *
 * This function removes the PEM header and footer, strips whitespace,
 * decodes the base64 content, and returns the resulting binary data
 * as an ArrayBuffer.
 *
 * @param pem - The PEM-formatted private key string.
 * @returns An ArrayBuffer containing the decoded binary data.
 */
function str2ab(pem: string): ArrayBuffer {
	const b64 = pem
		.replace(/-----BEGIN PRIVATE KEY-----/, "")
		.replace(/-----END PRIVATE KEY-----/, "")
		.replace(/\s+/g, "");
	const binary = atob(b64);
	const len = binary.length;
	const buffer = new ArrayBuffer(len);
	const view = new Uint8Array(buffer);
	for (let i = 0; i < len; i++) {
		view[i] = binary.charCodeAt(i);
	}
	return buffer;
}
