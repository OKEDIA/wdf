import { ResponseSettings } from "@okedia/core/domain/api";

/**
 * Converts a `ResponseSettings` object into a URL with query parameters.
 *
 * @param responseSettings - The settings object containing filters, projections, population, pagination, sorting, and grouping options.
 * @param url - The base URL to which the query parameters will be appended.
 * @returns The URL with the appropriate query string based on the provided response settings.
 *
 * @remarks
 * - If `responseSettings` is not provided, the original URL is returned.
 * - Handles nested parameters for filtering, population, and pagination.
 * - Automatically determines whether to use `?` or `&` when appending query parameters.
 *
 * @example
 * ```typescript
 * const settings = {
 *   filter: { status: 'active' },
 *   pagination: { page: 2, limit: 10 }
 * };
 * const url = responseSettingsToUrl(settings, 'https://api.example.com/items');
 * // Result: 'https://api.example.com/items?filter[status]="active"&pagination[page]=2&pagination[limit]=10'
 * ```
 */
export function convertResponseSettingsToUrl(
	responseSettings: ResponseSettings,
	url: string
) {
	let queryString = "";
	if (responseSettings) {
		const params = new URLSearchParams();

		if (responseSettings.filter) {
			for (const [key, value] of Object.entries(responseSettings.filter)) {
				params.append(`filter[${key}]`, JSON.stringify(value));
			}
		}

		if (responseSettings.projection) {
			params.append("projection", JSON.stringify(responseSettings.projection));
		}

		if (responseSettings.populate) {
			responseSettings.populate.forEach((pop, idx) => {
				params.append(`populate[${idx}][field]`, pop.field);
				if (pop.populatePage !== undefined)
					params.append(
						`populate[${idx}][populatePage]`,
						String(pop.populatePage)
					);
				if (pop.populateLimit !== undefined)
					params.append(
						`populate[${idx}][populateLimit]`,
						String(pop.populateLimit)
					);
			});
		}

		if (responseSettings.pagination) {
			const { page, limit, count, afterId } = responseSettings.pagination;
			if (page !== undefined) params.append("pagination[page]", String(page));
			if (limit !== undefined)
				params.append("pagination[limit]", String(limit));
			if (count !== undefined) params.append("pagination[count]", count);
			if (afterId !== undefined) params.append("pagination[afterId]", afterId);
		}

		if (responseSettings.sort) {
			params.append("sort", responseSettings.sort);
		}

		if (responseSettings.groupBy) {
			params.append("groupBy", responseSettings.groupBy);
		}

		if (responseSettings.params) {
			for (const [key, value] of Object.entries(responseSettings.params)) {
				params.append(`params[${key}]`, JSON.stringify(value));
			}
		}

		const qs = params.toString();
		if (qs) {
			// Add ? or & depending on whether url already has query params
			queryString = (url.includes("?") ? "&" : "?") + qs;
		}
	}

	url += queryString;
	return url;
}

/**
 * Converts a URL with query parameters into a `ResponseSettings` object.
 *
 * @param url - The URL containing query parameters to be converted.
 * @returns A `ResponseSettings` object based on the provided URL.
 *
 * @remarks
 * - If no query parameters are found, an empty `ResponseSettings` object is returned.
 * - Handles nested parameters for filtering, population, and pagination.
 *
 * @example
 * ```typescript
 * const url = 'https://api.example.com/items?filter[status]="active"&pagination[page]=2&pagination[limit]=10';
 * const settings = convertUrlToResponseSettingsObject(url);
 * // Result: { filter: { status: 'active' }, pagination: { page: 2, limit: 10 } }
 * ```
 */
export function convertUrlToResponseSettingsObject(
	url: string
): ResponseSettings {
	const responseSettings: ResponseSettings = {};
	const paramsObj: Record<string, string> = {};
	responseSettings.filter = []; // Ensure filter is initialized as an array

	const queryString = url.split("?")[1];
	if (!queryString) return responseSettings;

	const params = new URLSearchParams(queryString);

	for (const [key, value] of params.entries()) {
		if (key.startsWith("filter[")) {
			const filterKey = key.match(/^filter\[(.+)\]$/)?.[1];
			if (filterKey) {
				try {
					responseSettings.filter[filterKey] = JSON.parse(value);
				} catch {
					responseSettings.filter[filterKey] = value;
				}
			}
		} else if (key === "filter") {
			// Handle ?filter=[{"type":"productions"}]
			try {
				responseSettings.filter = JSON.parse(value);
			} catch {
				responseSettings.filter = [];
			}
		} else if (key === "projection") {
			try {
				responseSettings.projection = JSON.parse(value);
			} catch {
				responseSettings.projection = {};
			}
		} else if (key.startsWith("populate[")) {
			const match = key.match(/^populate\[(\d+)\]\[(.+)\]$/);
			if (match) {
				const idx = Number(match[1]);
				const field = match[2];
				responseSettings.populate ??= [];
				if (!responseSettings.populate[idx])
					responseSettings.populate[idx] = { field: "" };
				if (field === "field") {
					responseSettings.populate[idx].field = value;
				} else if (field === "populatePage") {
					responseSettings.populate[idx].populatePage = Number(value);
				} else if (field === "populateLimit") {
					responseSettings.populate[idx].populateLimit = Number(value);
				}
			}
		} else if (key.startsWith("pagination[")) {
			const paginationKey = key.match(/^pagination\[(.+)\]$/)?.[1];
			if (paginationKey) {
				responseSettings.pagination ??= {};
				if (paginationKey === "page" || paginationKey === "limit") {
					responseSettings.pagination[paginationKey] = Number(value);
				} else {
					responseSettings.pagination[paginationKey] = value;
				}
			}
		} else if (key === "sort") {
			responseSettings.sort = value;
		} else if (key === "groupBy") {
			responseSettings.groupBy = value;
		} else if (key.startsWith("params[")) {
			const paramsKey = key.match(/^params\[(.+)\]$/)?.[1];
			if (paramsKey) {
				responseSettings.params ??= {};
				try {
					responseSettings.params[paramsKey] = JSON.parse(value);
				} catch {
					responseSettings.params[paramsKey] = value;
				}
			}
		} else {
			paramsObj[key] = value;
		}
	}

	// Clean up populate array
	if (responseSettings.populate) {
		responseSettings.populate = responseSettings.populate.filter(Boolean);
	}

	if (Object.keys(paramsObj).length > 0) {
		responseSettings.params = paramsObj;
	}

	return responseSettings;
}
