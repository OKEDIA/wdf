import mongoosedb from "mongoose";

declare global {
	var mongoose: {
		conn: typeof mongoosedb | null;
		promise: Promise<typeof mongoosedb> | null;
	}; // This must be a `var` and not a `let / const`
}

let cached = global.mongoose;

if (!cached) {
	cached = global.mongoose = { conn: null, promise: null };
}

if (!mongoosedb.connection.listeners("connected").length) {
	mongoosedb.connection.on("connected", async () => {
		console.log("✅ Mongoose connected to", mongoosedb.connection.name);
	});
	mongoosedb.connection.on("error", (err) => {
		console.error("❌ Mongoose connection error:", err);
	});
	mongoosedb.connection.on("disconnected", () => {
		console.warn("⚠️ Mongoose disconnected");
	});
}

/**
 * Initializes a connection to MongoDB using Mongoose.
 *
 * Checks for an existing Mongoose connection in the global cache and returns it if available.
 * If no connection exists, it attempts to establish a new connection using the MONGODB_URI
 * environment variable. The connection is cached to prevent multiple simultaneous connections.
 *
 * @remarks
 * This function is designed to prevent multiple connections to the database in a serverless environment,
 * where multiple instances of the application may be running concurrently. By caching the connection,
 * it ensures that only one connection is established and reused across different invocations.
 * For more details, please refer to the original implementation at:
 * {@link https://github.com/vercel/next.js/blob/canary/examples/with-mongodb-mongoose/lib/dbConnect.ts}
 *
 * @throws {Error} If the MONGODB_URI environment variable is not defined.
 *
 * @returns A promise that resolves to an active Mongoose connection.
 */
export async function initMongoose() {
	const MONGODB_URI = process.env.MONGODB_URI!;

	if (!MONGODB_URI || !process.env.DB_NAME) {
		throw new Error(
			"Please define the MONGODB_URI and DB_NAME environment variable inside .env"
		);
	}

	if (cached.conn) {
		console.log("Using cached Mongoose connection");
		return cached.conn;
	}
	if (!cached.promise) {
		console.log("Creating new Mongoose connection");
		const opts: Partial<mongoosedb.ConnectOptions> = {
			bufferCommands: true,
			autoIndex: false, // Don't build indexes by default
			dbName: process.env.DB_NAME,
			maxPoolSize: 10,
			minPoolSize: 1,
			maxIdleTimeMS: 10000,
			serverSelectionTimeoutMS: 10000,
			socketTimeoutMS: 2000,
		};

		cached.promise = mongoosedb.connect(MONGODB_URI, opts).then((mongoose) => {
			return mongoose;
		});
	}
	try {
		cached.conn = await cached.promise;
	} catch (e) {
		cached.promise = null;
		throw e;
	}

	return cached.conn;
}
