"use client";

import { system } from "@/app/theme";
import { ChakraProvider, SystemContext, defaultSystem } from "@chakra-ui/react";
import { ColorModeProvider, type ColorModeProviderProps } from "./color-mode";

export function Provider(
	props: ColorModeProviderProps & { theme?: SystemContext }
) {
	const { theme, ...rest } = props;

	return (
		<ChakraProvider value={system || defaultSystem}>
			<ColorModeProvider {...rest} />
		</ChakraProvider>
	);
}
