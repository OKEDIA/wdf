"use server";

// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { Provider } from "@/components/ui/provider";
import { initMongoose } from "@okedia/core/utils/initMongoose";
import { Poppins } from "next/font/google";
import { AppProvider } from "./_context/App";
import { SessionProvider } from "./_context/Session";

// Context & Helpers
import SDKProvider from "@okedia/sdk-js/context";

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
const poppins = Poppins({
	weight: ["100", "200", "300", "400", "500", "600", "700", "800", "900"],
	subsets: ["latin"],
});

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default async function GlobalContainer({
	children,
}: Readonly<{
	children: React.ReactNode;
}>) {
	const apiKey = process.env.OKEDIA_API_KEY as string;
	const userId = process.env.OKEDIA_USER_ID;

	await initMongoose();

	// const sdk = await initSDK({
	// 	apiKey,
	// });

	// await sdk.auth.login(userId).then((res) => {
	// 	console.log("Logged In");
	// });

	return (
		<body className={poppins.className}>
			<Provider>
				<AppProvider>
					<SDKProvider
						apiKey={apiKey}
						userId={userId}
					>
						<SessionProvider>{children}</SessionProvider>
					</SDKProvider>
				</AppProvider>
			</Provider>
		</body>
	);
}
