"use client";

// React Imports
import {
	createContext,
	ReactNode,
	TransitionStartFunction,
	useContext,
	useTransition,
} from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

type Profile = {
	id: string;
	name: string;
};

interface AppStates {
	isBigRouteChange: boolean;
}

interface AppSetters {
	startRouteChange: TransitionStartFunction;
}

type AppContextType = {
	states: AppStates;
	setters: AppSetters;
};

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

const AppContext = createContext<AppContextType | undefined>(undefined);

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export const AppProvider = ({ children }: { children: ReactNode }) => {
	const [isBigRouteChange, startRouteChange] = useTransition();

	return (
		<AppContext.Provider
			value={{
				states: { isBigRouteChange },
				setters: {
					startRouteChange,
				},
			}}
		>
			{children}
		</AppContext.Provider>
	);
};

export const useApp = () => {
	const context = useContext(AppContext);
	if (context === undefined) {
		throw new Error("useSession must be used within a SessionProvider");
	}
	return context;
};
