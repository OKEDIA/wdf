"use client";

import { useTabs, UseTabsReturn } from "@chakra-ui/react";
// React Imports
import { EpmBasic } from "@okedia/core/domain/epm";
import { StateSetter } from "@okedia/shared/types/stateTypes";
import { useParams, useRouter } from "next/navigation";
import {
	createContext,
	ReactNode,
	TransitionStartFunction,
	useContext,
	useEffect,
	useState,
	useTransition,
} from "react";
// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

type Profile = Pick<EpmBasic, "id" | "type"> & { name?: string };

interface SessionStates {
	profiles: EpmBasic[];
	openProductions: Profile[];
	productionsPending: boolean;
	rowStructure: "grid" | "list" | null;
}

interface SessionSetters {
	setProfiles: StateSetter<EpmBasic[]>;
	setOpenProductions: StateSetter<Profile[]>;
	setRowStructure: StateSetter<"grid" | "list" | null>;
	startProductionsPending: TransitionStartFunction;
}

type SessionContextType = {
	states: SessionStates;
	setters: SessionSetters;
	tabs: { productions: UseTabsReturn };
};

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

const SessionContext = createContext<SessionContextType | undefined>(undefined);

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export const SessionProvider = ({ children }: { children: ReactNode }) => {
	const router = useRouter();
	const { type } = useParams();

	const [rowStructure, setRowStructure] = useState<"grid" | "list" | null>(
		"grid"
	);
	const [profiles, setProfiles] = useState<EpmBasic[]>([]);
	const [productionsPending, startProductionsPending] = useTransition();
	const [openProductions, setOpenProductions] = useState<Profile[]>([]);

	useEffect(() => {
		const stored = localStorage?.getItem("rowStructure");
		const initial = stored === "grid" || stored === "list" ? stored : "grid";
		setRowStructure(initial);
	}, []);

	useEffect(() => {
		if (
			rowStructure &&
			rowStructure !== window?.localStorage?.getItem("rowStructure")
		) {
			window?.localStorage?.setItem("rowStructure", rowStructure);
		}
	}, [rowStructure]);

	const productionsTabs = useTabs({
		onValueChange: ({ value }) => {
			if (!value || value.endsWith("/search")) {
				return startProductionsPending(() => router.push(`/dashboard/${type}`));
			}
			startProductionsPending(() => router.push(`/dashboard/${value}`));
		},
	});

	return (
		<SessionContext.Provider
			value={{
				states: { profiles, openProductions, productionsPending, rowStructure },
				setters: {
					setProfiles,
					setOpenProductions,
					startProductionsPending,
					setRowStructure,
				},
				tabs: { productions: productionsTabs },
			}}
		>
			{children}
		</SessionContext.Provider>
	);
};

export const useSession = () => {
	const context = useContext(SessionContext);
	if (context === undefined) {
		throw new Error("useSession must be used within a SessionProvider");
	}
	return context;
};
