import GlobalContainer from "./GlobalContainer";

/**
 * RootLayout component that wraps the entire application.
 *
 * @param {Object} props - The properties object.
 * @param {React.ReactNode} props.children - The child components to be rendered within the layout.
 *
 * @returns {JSX.Element} The root layout component.
 */
export default async function RootLayout({
	children,
}: Readonly<{
	children: React.ReactNode;
}>) {
	return (
		<html lang="en">
			<GlobalContainer>{children}</GlobalContainer>
		</html>
	);
}
