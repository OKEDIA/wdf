import {
	IconBuildingCircus,
	IconCreditCard,
	IconCrown,
	IconCubeSend,
	IconMasksTheater,
	IconMoodSmileBeam,
} from "@tabler/icons-react";

export interface Category {
	label: string;
	article: string;
	singular: string;
	value: string;
	Icon: JSX.Element;
}

export const epmCategories: Category[] = [
	{
		label: "Production Companies",
		singular: "Production Company",
		article: "a",
		value: "producers",
		Icon: <IconCrown />,
	},
	{
		label: "Productions",
		singular: "Production",
		article: "a",
		value: "productions",
		Icon: <IconMasksTheater />,
	},
	{
		label: "People",
		singular: "Person",
		article: "a",
		value: "people",
		Icon: <IconMoodSmileBeam />,
	},
	{
		label: "Suppliers",
		singular: "Supplier",
		article: "a",
		value: "suppliers",
		Icon: <IconCubeSend />,
	},
	{
		label: "Venues",
		singular: "venue",
		article: "a",
		value: "venues",
		Icon: <IconBuildingCircus />,
	},
	{
		label: "Virtual Cards",
		singular: "Virtual Card",
		article: "a",
		value: "cards",
		Icon: <IconCreditCard />,
	},
];
