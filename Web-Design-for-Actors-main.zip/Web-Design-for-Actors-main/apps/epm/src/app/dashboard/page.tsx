// React Imports

import { GridItem } from "@chakra-ui/react";

import { Fragment } from "react";
import CategoryCard from "./_components/CategoryCard";
import Search from "./_components/Search";
import { epmCategories } from "./categories";

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Page() {
	return (
		<Fragment>
			<GridItem
				colSpan={12}
				my={10}
			>
				<Search categories={epmCategories} />
			</GridItem>
			{epmCategories
				.sort((a, b) => a.label.localeCompare(b.label))
				.map((category) => {
					return (
						<GridItem
							colSpan={{ base: 12, md: 6, lg: 4 }}
							key={category.value}
						>
							<CategoryCard {...category} />
						</GridItem>
					);
				})}
		</Fragment>
	);
}
