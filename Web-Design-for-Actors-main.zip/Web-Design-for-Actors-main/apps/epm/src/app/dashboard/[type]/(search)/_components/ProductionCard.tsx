"use client";

// React Imports

// Next.js Imports
import NextLink from "next/link";

// Lower Order Components

// UI Components & Icons
import { useSession } from "@/app/_context/Session";
import LoadingOverlay from "@/app/dashboard/_components/LoadingOverlay";
import {
	Box,
	Flex,
	GridItem,
	Heading,
	Image,
	Link,
	LinkBox,
	LinkOverlay,
	Stack,
	Text,
} from "@chakra-ui/react";
import { IconChevronRight } from "@tabler/icons-react";
import { useTransition } from "react";
import { CalculatedProfile } from "../page";

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function ProductionCard({
	profile,
}: {
	profile: CalculatedProfile;
}) {
	const session = useSession();
	const [isPending, startTransition] = useTransition();
	const colSpan =
		session.states.rowStructure === "grid" ? { base: 12, lg: 6, xl: 4 } : 12;
	return (
		<GridItem colSpan={colSpan}>
			<Box mx="5">
				<LinkBox
					p="5"
					borderWidth="1px"
					rounded="md"
					bgImage={
						"url('https://firebasestorage.googleapis.com/v0/b/web-design-for-actors.appspot.com/o/4N93AE8qvyLX8V6k8dRrRsyEzBj2%2FThe%20Forsyte%20Saga%20Header%20Template.jpeg?alt=media&token=9d0781b0-f14a-4ec4-b07a-9a26011da86d')"
					}
					bgPos="left center"
					bgSize="cover"
					bgColor="bg.emphasized"
					bgBlendMode="screen"
					h="100%"
				>
					<LoadingOverlay visible={isPending} />
					<Flex
						w="100%"
						h="100%"
						justify="space-between"
						align="center"
					>
						<Stack
							direction="column"
							gap={0}
						>
							<Heading
								size="lg"
								my="2"
							>
								<LinkOverlay
									asChild
									onClick={(e) => {
										e.preventDefault();
										session?.setters.setOpenProductions((prev) => {
											if (prev.some((p) => p.id === profile.id)) return prev;
											return [
												...prev,
												{
													id: profile.id,
													name: profile.profile?.commonFormDataValues?.title,
													type: profile.type,
												},
											];
										});

										startTransition(() => {
											session.tabs.productions.setValue(
												`${profile.type}/${profile.id}`
											);
										});
									}}
								>
									<Link asChild>
										<NextLink href={`/dashboard/${profile.type}/${profile.id}`}>
											{profile.profile?.commonFormDataValues?.title !== ""
												? profile.profile?.commonFormDataValues?.title
												: (profile.profile.id ?? "Unknown name")}
										</NextLink>
									</Link>
								</LinkOverlay>
							</Heading>
							<Text color="fg.muted">
								{profile.profile?.commonFormDataValues?.tags[0] &&
									new Date(
										profile.profile?.commonFormDataValues?.tags[0] ?? ""
									).getFullYear()}
							</Text>
						</Stack>
						<Stack
							direction="row"
							alignItems="center"
						>
							<Image
								src={profile.profile?.commonFormDataValues?.image}
								h="50px"
							/>
							<IconChevronRight />
						</Stack>
					</Flex>
				</LinkBox>
			</Box>
		</GridItem>
	);
}
