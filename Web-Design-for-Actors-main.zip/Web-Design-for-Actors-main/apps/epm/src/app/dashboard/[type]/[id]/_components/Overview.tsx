"use client";

// React Imports

import { useSession } from "@/app/_context/Session";
import {
	Editable,
	Field,
	Fieldset,
	GridItem,
	IconButton,
	Stack,
} from "@chakra-ui/react";
import { LuCheck, LuPencilLine, LuX } from "react-icons/lu";

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

function CustomField({ name, value }: { name: string; value: any }) {
	return (
		<Field.Root orientation="horizontal">
			<Field.Label>{name}</Field.Label>
			<Editable.Root
				defaultValue="Click to edit"
				value={value}
			>
				<Editable.Preview />
				<Editable.Input />
				<Editable.Control>
					<Editable.EditTrigger asChild>
						<IconButton
							variant="ghost"
							size="xs"
						>
							<LuPencilLine />
						</IconButton>
					</Editable.EditTrigger>
					<Editable.CancelTrigger asChild>
						<IconButton
							variant="outline"
							size="xs"
						>
							<LuX />
						</IconButton>
					</Editable.CancelTrigger>
					<Editable.SubmitTrigger asChild>
						<IconButton
							variant="outline"
							size="xs"
						>
							<LuCheck />
						</IconButton>
					</Editable.SubmitTrigger>
				</Editable.Control>
			</Editable.Root>
		</Field.Root>
	);
}

export default function Overview() {
	const session = useSession();
	const colSpan = {
		base: 12,
		lg: session.states.rowStructure === "grid" ? 6 : 12,
	};

	const dates = [
		{
			name: "Rehearsals",
			value: "05/05/2025",
		},
		{
			name: "Performances",
			value: "29/05/2025",
		},
		{
			name: "Get Out",
			value: "28/06/2025",
		},
	];

	const production = [
		{
			name: "Name",
			value: "The Reckoning",
		},
		{
			name: "Status",
			value: "Initial Contact",
		},
		{
			name: "Notes",
			value:
				"lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec a diam lectus. Sed sit amet ipsum mauris.",
		},
	];

	return (
		<>
			<GridItem colSpan={colSpan}>
				<Fieldset.Root size="lg">
					<Stack>
						<Fieldset.Legend>Production</Fieldset.Legend>
					</Stack>

					<Fieldset.Content>
						{production.map((item, index) => (
							<CustomField
								key={index}
								{...item}
							/>
						))}
					</Fieldset.Content>
				</Fieldset.Root>
			</GridItem>
			<GridItem colSpan={colSpan}>
				<Fieldset.Root size="lg">
					<Stack>
						<Fieldset.Legend>Key Dates</Fieldset.Legend>
					</Stack>

					<Fieldset.Content>
						{dates.map((item, index) => (
							<CustomField
								key={index}
								{...item}
							/>
						))}
					</Fieldset.Content>
				</Fieldset.Root>
			</GridItem>
		</>
	);
}
