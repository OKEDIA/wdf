"use client";

// React Imports

import { useSession } from "@/app/_context/Session";
import {
	Button,
	CloseButton,
	Flex,
	GridItem,
	Heading,
	SegmentGroup,
	Stack,
	Tabs,
} from "@chakra-ui/react";
import {
	IconLayoutGrid,
	IconLayoutList,
	IconList,
	IconPlus,
} from "@tabler/icons-react";
import { useParams } from "next/navigation";
import { useEffect } from "react";
import LoadingOverlay from "../_components/LoadingOverlay";
import { epmCategories } from "../categories";

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function ProductionsTemplate({
	children,
}: {
	children: React.ReactNode;
}) {
	const { type, id } = useParams();

	const session = useSession();
	const category = epmCategories.find((cat) => cat.value === type);

	useEffect(() => {
		if (!id || id === "search") {
			session.tabs.productions.setValue(`${type}/search`);
		}
	}, []);

	if (!category) {
		throw new Error(`Category ${type} not found in template
	`);
	}

	return (
		<GridItem colSpan={12}>
			<LoadingOverlay
				visible={session.states.productionsPending}
				withText
				minH="80dvh"
			/>

			<Tabs.RootProvider
				lazyMount={true}
				value={session.tabs.productions}
				w="100%"
				colorPalette="yellow"
				mt="5"
			>
				<Tabs.List
					justifyContent={{ base: "center", lg: "space-between" }}
					hideBelow="md"
				>
					<Flex>
						<Tabs.Trigger value={`${category.value}/search`}>
							<IconList size="1.3rem" />
							<Heading size="md">{category?.singular} Search</Heading>
						</Tabs.Trigger>
						{session?.states.openProductions.map((production, index) => {
							const thisCategory = epmCategories.find(
								(cat) => cat.value === production.type
							);
							return (
								<Tabs.Trigger
									value={`${production.type}/${production.id}`}
									key={`${production.id}[${index}]`}
								>
									{thisCategory?.Icon}

									<Heading size="md">{production.name}</Heading>
									<CloseButton
										as="span"
										role="button"
										size="2xs"
										me="-2"
										onClick={(e) => {
											e.preventDefault();

											session.setters.setOpenProductions((prev) =>
												prev.filter((item) => item.id !== production.id)
											);

											return session.tabs.productions.setValue(
												`${category?.value}`
											);
										}}
									/>
								</Tabs.Trigger>
							);
						})}
					</Flex>
					<Stack
						direction="row"
						position="relative"
						gap={4}
						alignItems="center"
						bottom={2}
						hideBelow="lg"
					>
						<Button
							size="xs"
							colorPalette="yellow"
						>
							{" "}
							<IconPlus /> Add Production
						</Button>
						<SegmentGroup.Root
							defaultValue={session.states.rowStructure}
							onValueChange={({ value }) => {
								if (value !== "grid" && value !== "list") return;
								session.setters.setRowStructure(value);
							}}
							size="sm"
						>
							<SegmentGroup.Indicator />
							<SegmentGroup.Items
								items={[
									{
										value: "grid",
										label: <IconLayoutGrid size="1.3rem" />,
									},
									{
										value: "list",
										label: <IconLayoutList size="1.3rem" />,
									},
								]}
							/>
						</SegmentGroup.Root>
					</Stack>
				</Tabs.List>

				{children}
			</Tabs.RootProvider>
		</GridItem>
	);
}
