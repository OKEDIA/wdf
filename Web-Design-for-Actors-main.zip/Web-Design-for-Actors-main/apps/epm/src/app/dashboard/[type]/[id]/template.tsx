"use client";

// React Imports

import {
	Box,
	Grid,
	GridItem,
	Heading,
	Stack,
	Tabs,
	useBreakpointValue,
	useTabs,
} from "@chakra-ui/react";
import {
	IconCreditCard,
	IconExternalLink,
	IconPresentation,
	IconShieldHeart,
} from "@tabler/icons-react";
import { useParams } from "next/navigation";

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
export default function ProductionTemplate({
	children,
}: {
	children: React.ReactNode;
}) {
	const { type, id } = useParams();

	const tabs = useTabs({
		defaultValue: "overview",
		orientation: useBreakpointValue({ base: "horizontal", lg: "vertical" }),
	});

	return (
		<Tabs.Content value={`${type}/${id}`}>
			<Tabs.RootProvider
				value={tabs}
				variant={{ lgDown: "enclosed", lg: "line" }}
				height="100%"
				colorPalette="yellow"
				mt="0"
				size="lg"
			>
				<Grid
					templateColumns="repeat(12, 1fr)"
					gap={4}
					width="100%"
				>
					<GridItem
						h="100%"
						colSpan={{ base: 12, md: 12, lg: 3, xl: 2 }}
					>
						<Tabs.List
							w="100%"
							h="100%"
							flexWrap="wrap"
							justifyContent={{ base: "center", lg: "flex-start" }}
						>
							<Tabs.Trigger value="overview">
								<Stack
									direction="row"
									align="center"
								>
									<IconPresentation size="1.1rem" />
									<Heading size="md">Overview</Heading>
								</Stack>
							</Tabs.Trigger>
							<Tabs.Trigger value="members">
								<Stack
									direction="row"
									align="center"
								>
									<IconCreditCard size="1.1rem" />
									<Heading size="md">Virtual Cards</Heading>
								</Stack>
							</Tabs.Trigger>
							<Tabs.Trigger value="members">
								<Stack
									direction="row"
									align="center"
								>
									<IconShieldHeart size="1.1rem" />
									<Heading size="md">Health & Safety</Heading>
								</Stack>
							</Tabs.Trigger>
							<Tabs.Trigger
								value="2"
								mt={{ base: "0", lg: "40" }}
							>
								<Stack
									direction="row"
									align="center"
								>
									<IconExternalLink size="1.1rem" />
									<Heading size="md">Xero</Heading>
								</Stack>
							</Tabs.Trigger>
							<Tabs.Trigger value="3">
								<Stack
									direction="row"
									align="center"
								>
									<IconExternalLink size="1.1rem" />
									<Heading size="md">Google Drive</Heading>
								</Stack>
							</Tabs.Trigger>
							<Tabs.Trigger value="3">
								<Stack
									direction="row"
									align="center"
								>
									<IconExternalLink size="1.1rem" />
									<Heading size="md">PM Agreement</Heading>
								</Stack>
							</Tabs.Trigger>
						</Tabs.List>
					</GridItem>
					<GridItem colSpan={{ base: 12, md: 12, lg: 9, xl: 10 }}>
						<Box p="2">
							<Grid
								templateColumns="repeat(12, 1fr)"
								gap={4}
								width="100%"
							>
								{children}
							</Grid>
						</Box>
					</GridItem>
				</Grid>
			</Tabs.RootProvider>
		</Tabs.Content>
	);
}
