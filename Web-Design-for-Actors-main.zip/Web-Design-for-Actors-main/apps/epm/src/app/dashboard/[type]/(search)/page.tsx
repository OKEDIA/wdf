"use server";

// React Imports
import { Fragment } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { Grid, GridItem, Heading } from "@chakra-ui/react";
import { TabsContent } from "@chakra-ui/react/tabs";
import { EpmManager } from "@okedia/core/adapters/mongoose/epm";
import { EpmMongoose } from "@okedia/core/domain/epm";
import { AnyProfileBasic, Production } from "@okedia/core/domain/profiles";
import Search from "../../_components/Search";
import { epmCategories } from "../../categories";
import ProductionCard from "./_components/ProductionCard";

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

const statusMap: Record<string, string> = {
	0: "Initial Contact",
	1: "Planning",
	2: "Rehearsals",
	3: "Performances",
	4: "Completed",
	5: "Cancelled",
};

type PopulatedFields = {
	profile: Production;
};

export type CalculatedProfile = EpmMongoose & { profile?: Production };
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default async function Page({
	params,
}: {
	params: Promise<{ type: string }>;
}) {
	const { type } = await params;
	const category = epmCategories.find((cat) => cat.value === type);

	if (!category) {
		throw new Error(`Category ${type} not found`);
	}

	const profileManager = new EpmManager();
	const profiles = await profileManager.find<{
		profile: AnyProfileBasic;
	}>({
		filter: [{ type }],
		projection: { profile: true, status: true },
		populate: [
			{
				field: "profile",
				populatePage: 1,
				populateLimit: 5,
			},
		],
	});

	const groupedProfiles = profiles?.reduce<Record<string, CalculatedProfile[]>>(
		(acc, profile) => {
			const plainProfile = JSON.parse(
				JSON.stringify(profile)
			) as CalculatedProfile;
			const status = String(plainProfile.status ?? 0);
			if (!acc[status]) {
				acc[status] = [];
			}
			acc[status].push(plainProfile);
			return acc;
		},
		{}
	);

	return (
		<TabsContent value={`${category.value}/search`}>
			<Grid
				className="rootGrid"
				minW="100%"
				gap={4}
				templateColumns="repeat(12, 1fr)"
				width="100%"
				alignItems="stretch"
			>
				<GridItem colSpan={12}>
					<Search categories={[category]} />
				</GridItem>
				{Object.entries(groupedProfiles ?? {}).map(
					(
						[statusKey, profiles]: [string, CalculatedProfile[]],
						index: number
					) => (
						<Fragment key={statusKey}>
							<GridItem
								colSpan={12}
								mt="10"
							>
								<Heading>{statusMap[statusKey]}</Heading>
							</GridItem>
							{profiles.map((profile) => (
								<ProductionCard
									key={profile.id}
									profile={profile}
								/>
							))}
						</Fragment>
					)
				)}
			</Grid>
		</TabsContent>
	);
}
