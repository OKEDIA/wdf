"use client";

// React Imports

import { Box, Container, Grid, Stack } from "@chakra-ui/react";
import { useApp } from "../_context/App";
import LoadingOverlay from "./_components/LoadingOverlay";
import Header from "./_template/Header";

// Next.js Imports
// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function DashboardLayout({
	children,
}: Readonly<{
	children: React.ReactNode;
}>) {
	const app = useApp();
	return (
		<Box
			maxH="100dvh"
			maxW="100dvw"
			minH="100dvh"
			minW="100dvw"
			overflowY="scroll"
			overflowX="hidden"
		>
			<Header />
			<Container h="100%">
				<Stack
					pt="5"
					h="100%"
					direction="row"
					justify="space-between"
					alignItems="center"
				>
					<Container
						h="100%"
						display="flex"
						alignItems="center"
					>
						<Grid
							className="rootGrid"
							minW="100%"
							gap={4}
							templateColumns="repeat(12, 1fr)"
							width="100%"
							alignItems="stretch"
						>
							<LoadingOverlay
								visible={app.states.isBigRouteChange}
								withText
								minH="80dvh"
							/>
							{children}
						</Grid>
					</Container>
				</Stack>
			</Container>{" "}
		</Box>
	);
}
