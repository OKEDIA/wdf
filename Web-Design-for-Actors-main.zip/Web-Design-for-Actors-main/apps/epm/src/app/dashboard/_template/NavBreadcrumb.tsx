"use client";

import { useApp } from "@/app/_context/App";
import {
	Breadcrumb,
	Link as ChakraLink,
	Menu,
	Portal,
	useBreakpointValue,
} from "@chakra-ui/react";
import { IconChevronDown, IconSlash } from "@tabler/icons-react";
import NextLink from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Fragment, ReactNode } from "react";
// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
interface BreadcrumbMenuItemProps {
	children: ReactNode;
	items: Array<{ label: string; value: string }>;
}
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

function BreadcrumbMenuItem(props: BreadcrumbMenuItemProps) {
	const { children, items } = props;

	return (
		<Breadcrumb.Item>
			<Menu.Root>
				<Menu.Trigger asChild>{children}</Menu.Trigger>
				<Portal>
					<Menu.Positioner zIndex="popover!important">
						<Menu.Content>
							{items.map((item) => (
								<Menu.Item
									key={item.value}
									value={item.value}
								>
									{item.label}
								</Menu.Item>
							))}
						</Menu.Content>
					</Menu.Positioner>
				</Portal>
			</Menu.Root>
		</Breadcrumb.Item>
	);
}

export default function NavBreadcrumb() {
	const app = useApp();
	const router = useRouter();
	const pathname = usePathname();
	const onlyOneLevel = useBreakpointValue({ base: true, md: false });

	const pathSegments = pathname
		.split("/")
		.filter(Boolean)
		.map((segment, idx, arr) => ({
			label: segment.replace(/-/g, " "),
			href: "/" + arr.slice(0, idx + 1).join("/"),
			isLast: idx === arr.length - 1,
		}));

	return (
		<Breadcrumb.Root
			size="lg"
			variant="plain"
		>
			<Breadcrumb.List>
				<Breadcrumb.Separator>
					<IconSlash />
				</Breadcrumb.Separator>
				{pathSegments.map((segment, index) => {
					if (!segment.isLast && !onlyOneLevel) {
						return (
							<Fragment key={`${segment.href}[${index}]`}>
								<Breadcrumb.Item>
									<ChakraLink
										asChild
										onClick={(e) => {
											e.preventDefault();

											app.setters.startRouteChange(() =>
												router.push(segment.href)
											);
										}}
									>
										<NextLink href={segment.href}>{segment.label}</NextLink>
									</ChakraLink>
								</Breadcrumb.Item>
								<Breadcrumb.Separator>
									<IconSlash />
								</Breadcrumb.Separator>
							</Fragment>
						);
					}

					if (segment.isLast) {
						return (
							<BreadcrumbMenuItem
								key={`${segment.href}[${index}]`}
								items={[
									...(onlyOneLevel
										? pathSegments
												.slice(0, -1) // filter out the last item
												.map(({ label, href }) => ({
													label: label.charAt(0).toUpperCase() + label.slice(1),
													value: href,
												}))
										: []),
									{ label: "Share Link", value: "components" },
									{ label: "Export to PDF", value: "props" },
									{ label: "Report a Problem", value: "customization" },
								]}
							>
								<Breadcrumb.Link as="button">
									{segment.label}
									<IconChevronDown size="1rem" />
								</Breadcrumb.Link>
							</BreadcrumbMenuItem>
						);
					}
				})}
			</Breadcrumb.List>
		</Breadcrumb.Root>
	);
}
