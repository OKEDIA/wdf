// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { Box, Container, Flex, Heading, Stack } from "@chakra-ui/react";
import NavBreadcrumb from "./NavBreadcrumb";

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Header() {
	return (
		<Box
			maxW="100dvw"
			bg="white"
			borderBottom="1px solid"
			borderColor="border"
			position="sticky"
			top="0"
			zIndex="sticky"
		>
			<Container
				h="80px"
				className="nav"
			>
				{/* All Devices; Phones / Tablets / Laptops */}
				<Stack
					direction="row"
					h="100%"
					justify="space-between"
					alignItems="center"
					className="navContainer"
				>
					<Container
						h="100%"
						display="flex"
						justifyContent={{ base: "center", lg: "flex-start" }}
						alignItems="center"
						className="navItem"
						flexGrow={2}
						flexBasis={2}
					>
						<Flex
							justify="flex-start"
							alignItems="baseline"
							direction="row"
							gap={3}
							className="logo"
						>
							<Heading
								size="4xl"
								color="yellow.fg"
								normal
							>
								epm
							</Heading>
							<Stack justifyContent="center">
								<NavBreadcrumb />
							</Stack>
						</Flex>
					</Container>

					<Container
						hideBelow="lg"
						display="flex"
						flexGrow={1}
						flexBasis={1}
					>
						{/* Tablets / Medium & Large Devices Only */}
						<Flex
							justifyContent="flex-end"
							alignContent="center"
						></Flex>
					</Container>
				</Stack>
			</Container>
		</Box>
	);
}
