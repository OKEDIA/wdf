"use client";

// React Imports

import {
	Flex,
	Heading,
	Link,
	LinkBox,
	LinkOverlay,
	Span,
	Stack,
} from "@chakra-ui/react";
import { IconChevronRight } from "@tabler/icons-react";
import NextLink from "next/link";
import { useRouter } from "next/navigation";
import { useTransition } from "react";
import { Category } from "../categories";
import LoadingOverlay from "./LoadingOverlay";

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function CategoryCard(props: Category) {
	const router = useRouter();
	const [isPending, startTransition] = useTransition();
	const { value, label, Icon } = props;

	return (
		<LinkBox
			p="5"
			borderWidth="1px"
			rounded="md"
			bg="bg"
			h="100%"
		>
			<LoadingOverlay visible={isPending} />
			<Flex
				w="100%"
				h="100%"
				justify="space-between"
				align="center"
			>
				<Stack
					direction="column"
					gap={0}
				>
					<Span
						asChild
						textStyle="sm"
					>
						{Icon}
					</Span>
					<Heading
						size="lg"
						my="2"
					>
						<LinkOverlay
							asChild
							onClick={(e) => {
								e.preventDefault();
								startTransition(() => {
									router.push(`/dashboard/${value}`);
								});
							}}
						>
							<Link asChild>
								<NextLink href={`/dashboard/${value}`}>{label}</NextLink>
							</Link>
						</LinkOverlay>
					</Heading>
				</Stack>
				<IconChevronRight />
			</Flex>
		</LinkBox>
	);
}
