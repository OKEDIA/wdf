// React Imports

import { Box, Center, Heading, Spinner, VStack } from "@chakra-ui/react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function LoadingOverlay({
	visible,
	withText = false,
	minH,
}: {
	visible: boolean;
	withText?: boolean;
	minH?: string | number;
}) {
	return (
		<>
			{visible && (
				<Box
					pos="absolute"
					inset="0"
					zIndex="max"
					backdropFilter="blur(2px)"
					minH={minH}
				>
					<Center h="full">
						<VStack>
							<Spinner
								color="yellow.fg"
								borderWidth="4px"
								size="xl"
							/>
							{withText && <Heading size="lg">Please Wait</Heading>}
						</VStack>
					</Center>
				</Box>
			)}
		</>
	);
}
