// React Imports

import { Field, Input, InputGroup } from "@chakra-ui/react";
import { IconSearch } from "@tabler/icons-react";
import { Category } from "../categories";
import DomainSelect from "./SearchCategories";

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Search({ categories }: { categories: Category[] }) {
	return (
		<Field.Root>
			<InputGroup
				startElement={<IconSearch />}
				endElement={
					categories.length > 1 && <DomainSelect categories={categories} />
				}
			>
				<Input
					placeholder={
						categories.length > 1
							? "Search for something"
							: `Find ${categories[0].article} ${categories[0].singular}`
					}
					size="2xl"
				/>
			</InputGroup>
			<Field.HelperText />
			<Field.ErrorText />
		</Field.Root>
	);
}
