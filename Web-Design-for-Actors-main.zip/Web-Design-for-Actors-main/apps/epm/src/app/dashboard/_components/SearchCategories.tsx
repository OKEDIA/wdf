"use client";

// React Imports
import { useState } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { createListCollection, Portal, Select } from "@chakra-ui/react";

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function DomainSelect({
	categories,
}: {
	categories: { label: string; value: string }[];
}) {
	const list = createListCollection({ items: categories });
	const [value, setValue] = useState<string[]>([]);

	return (
		<Select.Root
			collection={list}
			size="sm"
			width={{ base: "35vw", md: "30vw" }}
			variant="subtle"
			value={value}
			onValueChange={(e) => setValue(e.value)}
		>
			<Select.HiddenSelect />
			<Select.Control>
				<Select.Trigger
					w="100%"
					justifyContent="space-around"
				>
					<Select.ValueText
						w="100%"
						placeholder="No Filters Applied"
						textAlign="right"
					/>
				</Select.Trigger>
				<Select.IndicatorGroup>
					<Select.ClearTrigger />
					{!value?.[0]?.length && <Select.Indicator />}
				</Select.IndicatorGroup>
			</Select.Control>
			<Portal>
				<Select.Positioner>
					<Select.Content>
						{list.items.map((category) => (
							<Select.Item
								item={category}
								key={category.value}
							>
								{category.label}
								<Select.ItemIndicator />
							</Select.Item>
						))}
					</Select.Content>
				</Select.Positioner>
			</Portal>
		</Select.Root>
	);
}
