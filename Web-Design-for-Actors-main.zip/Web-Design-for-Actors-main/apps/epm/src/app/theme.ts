import { createSystem, defaultConfig, defineRecipe } from "@chakra-ui/react";
import { generateColorsMap } from "@okedia/shared/helpers/colors";

function colors(color: string) {
	return generateColorsMap(color).colors.reduce(
		(acc: Record<string, { value: string }>, c, index) => {
			acc[`${(index + 1) * 100}`] = { value: c.hex() };
			return acc;
		},
		{} as Record<string, { value: string }>
	);
}

const headingRecipe = defineRecipe({
	base: {
		textTransform: "lowercase",
		_after: {
			color: "fg",
			content: '"."',
		},
	},

	variants: {
		noDot: {
			true: {
				_after: {
					content: "unset",
				},
			},
		},
		normal: {
			true: {
				textTransform: "unset",
				_after: {
					content: "unset",
					display: "none",
				},
			},
		},
		size: {
			sm: {
				fontWeight: "lighter",
			},
			md: {
				fontWeight: "light",
			},
			lg: {
				fontWeight: "light",
			},
		},
	},
});

const textRecipe = defineRecipe({
	base: {
		textTransform: "lowercase",
	},

	variants: {
		normal: {
			true: {
				textTransform: "unset",
			},
		},
	},
});

const linkRecipe = defineRecipe({
	base: {
		textDecoration: "underline",
		textDecorationColor: "yellow.muted",
		textDecorationThickness: "3px",
		textUnderlineOffset: "0.05lh",
		textDecorationSkipInk: "none",
		textUnderlinePosition: "auto",
		transition:
			"color 0.1s ease-in-out, text-underline-offset 0.1s ease-in-out, text-decoration-color 0.1s ease-in-out",
		textTransform: "lowercase",
		color: "fg",
		"&:hover": {
			textDecoration: "underline!important",
			textDecorationColor: "yellow.fg!important",
			textDecorationThickness: "3px!important",
			textUnderlineOffset: "6px!important",
			textDecorationSkipInk: "none!important",
			textUnderlinePosition: "auto!important",
			color: "yellow.fg!important",
		},
	},
	variants: {
		normal: {
			true: {
				textTransform: "none!important",
				textDecoration: "none!important",
				_hover: {
					textDecoration: "inherit!important",
					color: "inherit!important",
				},
			},
		},

		noUnderline: {
			true: {
				textDecoration: "none",
				_hover: {
					textDecoration: "inherit!important",
					color: "yellow.solid!important",
				},
			},
		},
	},
});

export const system = createSystem(defaultConfig, {
	// strictTokens: true,

	globalCss: {
		body: {
			backgroundColor: "gray.subtle",
		},

		"fieldset:not(.normal)": {
			border: "1px solid var(--chakra-colors-border)",
			borderRadius: 3,
			padding: 5,
		},
	},
	theme: {
		recipes: {
			heading: headingRecipe,
			text: textRecipe,
			link: linkRecipe,
		},

		tokens: {
			fonts: {
				heading: { value: "Poppins, Poppins Fallback, sans-serif" },
				body: { value: "Poppins, Poppins Fallback, sans-serif" },
			},
			colors: {
				yellow: {
					...colors("#f4af09"),
				},
				gray: {
					...colors("#404042"),
				},
			},
		},
		semanticTokens: {
			colors: {
				fg: {
					DEFAULT: {
						value: "{colors.gray.600}",
					},
					contrast: { value: "colors.gray.100" },
					fg: { value: "{colors.gray.100}" },
					muted: { value: "{colors.gray.400}" },
					subtle: { value: "{colors.gray.200}" },
					emphasized: { value: "{colors.gray.300}" },
					focusRing: { value: "{colors.gray.500}" },
				},
				yellow: {
					contrast: { value: "{colors.white}" },
					fg: { value: "{colors.yellow.600}" },
					muted: { value: "{colors.yellow.400}" },
					subtle: { value: "{colors.yellow.50/60}" },
					emphasized: { value: "{colors.yellow.300}" },
					focusRing: { value: "{colors.yellow.400}" },
					solid: { value: "{colors.yellow.800}" },
				},
			},
		},
	},
});
