"use client";

// React Imports
import { useEffect, useState } from "react";

// Next.js Imports
import { useRouter } from "next/navigation";

// Lower Order Components
import {
	Box,
	Center,
	Field,
	Fieldset,
	Input,
	InputGroup,
	PinInput,
	Spinner,
	Text,
} from "@chakra-ui/react";

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities
import { useForm, useWatch } from "react-hook-form";

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
interface FormValues {
	email: string;
	pin: string;
}
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function LoginForm() {
	const form = useForm<FormValues>({
		mode: "onChange",
		reValidateMode: "onChange",
	});

	const { isValid, errors } = form.formState;
	const { handleSubmit, control, register } = form;
	const router = useRouter();

	const onSubmit = handleSubmit(async (data) => {
		// TODO: Handle Login Submission
		console.warn("Login Functionality not implemented yet", data);
		router.push("/dashboard");
	});
	const [step, setStep] = useState(0);
	const [isPending, setIsPending] = useState(false);
	const [userBack, setUserBack] = useState(false);
	const email = useWatch({ control, name: "email", defaultValue: "" });
	const pin = useWatch({ control, name: "pin", defaultValue: "" });

	useEffect(() => {
		if (!email || userBack) return;

		setIsPending(true);

		const handler = setTimeout(() => {
			if (isValid && step === 0) {
				setStep(1);
			}
			setIsPending(false);
		}, 1000); // 1000ms debounce

		return () => {
			clearTimeout(handler); // Cleanup the timeout
		};
	}, [email, isValid, step]);

	useEffect(() => {
		if (step === 1 && errors.email?.message) {
			setIsPending(false);
			setStep(0);
		} else if (step === 1 && pin?.length === 9 && isValid) {
			setStep(2);
			onSubmit();
		}
	}, [step, isPending]);

	return (
		<form
			onSubmit={onSubmit}
			style={{ width: "100%" }}
		>
			<Fieldset.Root
				pos="relative"
				className="normal"
			>
				<Fieldset.Content>
					{step === 0 && (
						<Field.Root
							required
							alignItems={{ base: "center", md: "flex-start" }}
						>
							<Field.Label>
								Company Email Address
								<Field.RequiredIndicator />
							</Field.Label>
							<InputGroup endElement={isPending && <Spinner marginRight="1" />}>
								<Input
									{...register("email", {
										required: true,
										pattern:
											/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/,
									})}
									onFocus={() => {
										setUserBack(false);
									}}
									size={{ base: "xl", md: "2xl" }}
									placeholder="Enter your email"
								/>
							</InputGroup>{" "}
							<Field.ErrorText>{errors.email?.message}</Field.ErrorText>
						</Field.Root>
					)}
					{step === 1 && (
						<Field.Root
							required
							alignItems={{ base: "center", md: "flex-start" }}
						>
							<Field.Label>
								One Time Passcode <Text color="red.fg">*</Text>
							</Field.Label>
							<PinInput.Root
								otp
								type="alphanumeric"
								size={{ base: "xl", md: "2xl" }}
								required
								attached
								{...register("pin", {
									required: true,
									minLength: 9,
								})}
							>
								<PinInput.HiddenInput />
								<PinInput.Control>
									<PinInput.Input
										index={0}
										onKeyDownCapture={(e) => {
											if (e.key === "Backspace") {
												if (pin.length === 0) {
													setUserBack(true);
													setIsPending(false);
													setStep(0);
												}
											}
										}}
									/>
									<PinInput.Input index={1} />
									<PinInput.Input index={2} />
									<PinInput.Input index={3} />
									<PinInput.Input index={4} />
									<PinInput.Input index={5} />
									<PinInput.Input index={6} />
									<PinInput.Input index={7} />
									<PinInput.Input index={8} />
								</PinInput.Control>
								<Field.ErrorText>{errors.pin?.message}</Field.ErrorText>
							</PinInput.Root>
						</Field.Root>
					)}

					{step === 2 && (
						<Box
							pos="absolute"
							inset="0"
							bg="bg/80"
						>
							<Center h="full">
								<Spinner />
							</Center>
						</Box>
					)}
				</Fieldset.Content>
			</Fieldset.Root>
		</form>
	);
}
