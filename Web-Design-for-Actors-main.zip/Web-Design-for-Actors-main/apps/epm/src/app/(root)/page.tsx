// React Imports

// Next.js Imports
import NextImage from "next/image";
import NextLink from "next/link";

// Lower Order Components

// UI Components & Icons
import {
	Center,
	Link as ChakraLink,
	Container,
	Heading,
	Image,
	Stack,
	Text,
} from "@chakra-ui/react";
// Context & Helpers

// Other libraries or utilities
import LoginForm from "./LoginForm";

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Home() {
	return (
		<Container
			fluid
			bg="{colors.gray.subtle}"
			h="100dvh"
			w="100dvw"
			overflowX="hidden"
			overflowY="scroll"
		>
			<Center h="100dvh">
				<Stack
					w="fit-content"
					align="center"
					gap="10"
				>
					<Stack
						align="center"
						gap={0}
						maxW="90dvw"
					>
						<Image
							asChild
							mb="5"
							opacity={{ base: "0.8", md: "0.5" }}
							position={{ base: "relative", md: "absolute" }}
							top={{ base: "unset", md: 30 }}
							right={{ base: "unset", md: 30 }}
						>
							<NextImage
								src="/dark_logo.png"
								alt="eStage Logo"
								width={100}
								height={30}
							/>
						</Image>
						<Heading
							size="5xl"
							textAlign="center"
						>
							Continue with{" "}
							<Text
								as="span"
								color="yellow.600"
							>
								ePM
							</Text>
						</Heading>
						<Heading
							size="md"
							color="fg.muted"
							textAlign="center"
						>
							Generate a code in{" "}
							<ChakraLink asChild>
								<NextLink href="/about">Google Workspace</NextLink>
							</ChakraLink>{" "}
							to continue.
						</Heading>
					</Stack>
					<LoginForm />
				</Stack>
			</Center>
		</Container>
	);
}
