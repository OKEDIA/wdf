import express from "express";

export const errorHandler = (
	req: express.Request,
	res: express.Response,
	next: express.NextFunction,
	err: any
) => {
	console.error(err);
	res.status(err.status || 500).json({
		error: err.message || "Something went wrong",
	});
};
