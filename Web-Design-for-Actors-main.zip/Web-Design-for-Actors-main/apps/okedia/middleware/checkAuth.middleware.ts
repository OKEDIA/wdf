import type { PermissionKey } from "@okedia/core/domain/apiKey";
import { hasPermission } from "@okedia/core/utils";
import express from "express";

/**
 * Middleware to ensure that the current tenant has the required permissions
 * to access a specific resource in a given namespace. The `hasPermission` method is also called
 * in the SDK level but we all it again here at the server level to ensure that the client-side SDK code
 * has not been tampered with and that the application has the required permissions.
 *
 * A future improvement could be that if the tenanted application has not got the required permissions and,
 * if the request came via the SDK, we can assume that the client-side code has been tampered with and
 * we can ban the API key for that application.
 *
 * @param namespace - The namespace in which the resource resides (e.g., `/profiles`).
 * @param getResource - A function that extracts can extract data from the request. This allows for dynamic resource identification based on the request context.
 * @param action - The permission key representing the action to be performed. e.g., `read`, `write`, `update`, `delete`.
 * @returns An Express middleware function that checks authentication and authorization.
 *
 * @remarks
 * - Responds with 401 if the user is not authenticated.
 * - Responds with 403 if the tenant lacks the required permission.
 * - Calls `next()` if the user and tenant are authorized.
 */
export function ensureAuthenticated(
	namespace: `/${string}`,
	getResource: (req: express.Request) => string,
	action: PermissionKey
) {
	return (
		req: express.Request,
		res: express.Response,
		next: express.NextFunction
	) => {
		const user = req.authentication?.user;

		if (!user) {
			res.status(401).json({ message: "Unauthorized" });
			return;
		}

		const resource = getResource(req);
		const allowed = hasPermission(req.authentication.permissions, {
			namespace,
			resource: resource || "*", // Use "*" if no specific resource is provided,
			action,
		});

		if (!allowed) {
			res.status(403).json({
				message: `${req.authentication.displayName || "This application"} does not have permission to perform "${action}" on resource "${resource}" in namespace "${namespace}".`,
			});
			return;
		}

		next();
	};
}
