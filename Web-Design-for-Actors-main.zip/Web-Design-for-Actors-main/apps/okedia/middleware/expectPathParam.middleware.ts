import type { NextFunction, Request, Response } from "express";

/**
 * Middleware to ensure a specific path parameter is present in the request.
 *
 * If the specified `paramName` is not found in `req.params`, this middleware attempts
 * to extract it from the `filters` property within `req.responseSettings.params` (expected to be a JSON string).
 * If found in the filters array, it assigns the value to `req.params[paramName]`.
 *
 * If the parameter is missing and cannot be extracted, responds with a 400 status and an error message.
 *
 * @param paramName - The name of the path parameter to expect and extract if missing.
 * @returns An Express middleware function.
 */
export function expectPathParam(paramName: string) {
	return (req: Request, res: Response, next: NextFunction) => {
		try {
			const filter = req.responseSettings?.filter;

			if (!req.params[paramName]) {
				let value;
				if (Array.isArray(filter)) {
					const found = filter.find((f: Record<string, any>) => f?.[paramName]);
					value = found ? found[paramName] : undefined;
				} else if (filter && typeof filter === "object") {
					value = filter[paramName];
				}

				if (value === undefined) {
					req.params[paramName] = "*";
				} else {
					req.params[paramName] = value;
				}
			}

			next();
		} catch (err) {
			res.status(400).json({
				message: `Expecting ${paramName} to be set in filters or as a path parameter.`,
			});
			return;
		}
	};
}
