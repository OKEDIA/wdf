import { ApiKeyManager } from "@okedia/core/adapters/mongoose/apiKey";
import express from "express";

/**
 * Middleware to validate the presence and validity of an API key in the request.
 *
 * Checks for an API key in the `x-api-key` header or `apiKey` query parameter.
 * If a valid API key is found, attaches the provider data to the request object as `providerData`
 * and calls the next middleware. Otherwise, responds with a 403 status and an error message.
 *
 * @param req - Express request object, extended to include `providerData` if the API key is valid.
 * @param res - Express response object.
 * @param next - Express next function to pass control to the next middleware.
 *
 * @returns Responds with 403 and an error message if the API key is missing or invalid; otherwise, calls `next()`.
 */

export async function checkApiKey(
	req: express.Request,
	res: express.Response,
	next: express.NextFunction
) {
	const apiKeys = new ApiKeyManager();
	const apiKey = req.headers["x-api-key"] || req.query.apiKey;

	if (!apiKey) {
		res.status(403).json({ error: "Invalid API key" });
		return;
	}

	const result = await apiKeys.get(apiKey as string);

	if (!result) {
		res.status(403).json({ error: "Invalid API key" });
		return;
	}

	// Adds the provider data to the request object for use in the next function
	req.authentication = result || undefined;

	// Continue to the next function
	return next();
}
