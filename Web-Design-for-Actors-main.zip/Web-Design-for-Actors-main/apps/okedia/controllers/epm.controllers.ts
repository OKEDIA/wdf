import { EpmManager } from "@okedia/core/domain";
import type { EpmApiResponses, EpmBasic } from "@okedia/core/domain/epm";
import express from "express";

export async function getEpmProfile(
	req: express.Request,
	res: express.Response<EpmApiResponses<unknown>["get"]["epm/*"]>,
	next: express.NextFunction
) {
	const epmManager = new EpmManager();
	req.responseSettings.filter.push({ type: req.params.type });

	const found = await epmManager.find<EpmBasic>({
		...req.responseSettings,
		filter: req.responseSettings.filter,
	});

	res.json(found);
	next();
}
