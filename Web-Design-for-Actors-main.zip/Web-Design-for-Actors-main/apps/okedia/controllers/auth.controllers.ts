import { UsersManager } from "@okedia/core/adapters/mongoose/users";
import type { AuthApiResponses } from "@okedia/core/domain/authentication";
import { formatPrivateKey, signJwt } from "@okedia/core/utils";
import express from "express";
import { UserRecord } from "firebase-admin/auth";
import type { Secret } from "jsonwebtoken";
import { firebaseAdmin } from "../services/firebase.service.ts";

const JWT_SECRET: Secret = process.env.SIGNING_PRIVATE_KEY!;

/**
 * Exchanges a third-party application's API key and user identifier for JWT tokens.
 *
 * This endpoint is intended for use by third-party applications that have already been authenticated
 * via an API key middleware. It generates a JWT token for the tenant (third-party app) and, if a valid
 * external user ID is provided and mapped, also generates a JWT token for the user.
 *
 * The function supports future multi-tenancy and custom authentication providers via Firebase Identity Platform.
 *
 * @param req - Express request object, expected to have `providerData` (OIDC provider info) and `responseSettings.filter.userId` set by middleware.
 * @param res - Express response object, returns an object containing the user JWT and tenant JWT.
 * @param next - Express next function for error handling.
 *
 * @remarks
 * - If no external user ID is provided, returns a tenant token and `user: null`.
 * - If the user mapping is not found, responds with status 400.
 * - If the user is not found in Firebase, responds with status 404.
 * - On success, responds with both user and tenant JWT tokens.
 *
 * @throws Passes any errors to the next middleware.
 */
export const exchangeToken = async (
	req: express.Request,
	res: express.Response<AuthApiResponses["get"]["auth/login"]>,
	next: express.NextFunction
) => {
	try {
		// NB: Future Implementation:
		// Requires Firebase SPARK Plan and Upgrade to Google Identity Platform
		// https://console.firebase.google.com/u/0/project/web-design-for-actors/authentication/providers
		// This would allow us to create a custom tenant (and maybe auth provider) for the 3rd party application
		// We would then store a reference to the tenant ID in the API Key Storage and use it to get the user data
		// and auth methods with the context of the tenanted 3rd party application so that it is more secure
		// Then rather than getting the user via getUser, we would get it via the tenant or custom provider ID
		// So that the third party app can only access the users that are linked to them.
		// More Info: https://cloud.google.com/identity-platform/docs/managing-providers-programmatically#creating_an_oidc_provider_configuration
		// The OIDC Provider info is provided in req?.providerData as it has already been verified by the middleware ./middleware/apiKey.middleware.ts
		////

		let unsignedToken = { ...req?.authentication };

		const externalUserId: string | undefined =
			req.responseSettings?.params?.userId;

		if (!externalUserId) {
			throw new Error("External user ID is required to exchange token.");
		}

		const usersManager = new UsersManager();
		const mapping = await usersManager
			.find({
				filter: [
					{
						"tenants.tenant_id": req?.authentication?._id.toString(),
						"tenants.external_user_id": externalUserId,
					},
				],
				projection: {
					firebaseUID: true,
				},
				pagination: {
					limit: 1,
				},
			})
			.then((users) => users?.[0]?.toObject());

		if (!mapping) {
			res.status(400);
			return;
		}

		const auth = firebaseAdmin().auth();
		const user: UserRecord = await auth.getUser(mapping.firebaseUID);

		// Intentionally set the possibly null user directly after retrieving (before a return) incase req.authentication had a stale user
		req.authentication = { ...req.authentication, user }; // Add the user to the request object for the rest of this request

		if (!user) {
			res.status(404);
			return;
		}

		unsignedToken = { ...unsignedToken, user: user.toJSON() as UserRecord };

		const signedToken = await signJwt(
			unsignedToken,
			formatPrivateKey(JWT_SECRET)
		);

		res.json(signedToken);
	} catch (err) {
		next(err);
	}
};

/**
 * Initializes the authentication process for a user.
 *
 * This function generates a JWT token for the current provider data and returns it
 * in the response as the `tennant` property. If an error occurs during the process,
 * it passes the error to the next middleware.
 *
 * @param req - Express request object, expected to contain `providerData`.
 * @param res - Express response object, returns a JSON object with the generated `tennant` JWT.
 * @param next - Express next function for error handling.
 *
 * @returns A JSON response containing the generated JWT token as `tennant`.
 *
 * @throws Passes any errors to the next middleware.
 */
export async function init(
	req: express.Request,
	res: express.Response<AuthApiResponses["get"]["auth/init"]>,
	next: express.NextFunction
) {
	try {
		const tennant = await signJwt(
			req?.authentication,
			formatPrivateKey(JWT_SECRET)
		);

		res.json(tennant);
	} catch (err) {
		next(err);
	}
}
