import { ProfileManager } from "@okedia/core/domain";
import type { ProfileApiResponses } from "@okedia/core/domain/authentication";
import type { ProfileMongoose } from "@okedia/core/domain/profiles";
import express from "express";

export async function getProfile(
	req: express.Request,
	res: express.Response<
		ProfileApiResponses<ProfileMongoose<unknown>>["get"]["profiles/*"]
	>,
	next: express.NextFunction
) {
	const profileManager = new ProfileManager();
	req.responseSettings.filter.push({ type: req.params.type });

	const found = await profileManager.find<ProfileMongoose<unknown>>({
		...req.responseSettings,
		filter: req.responseSettings.filter,
	});

	res.json(found);
	next();
}
