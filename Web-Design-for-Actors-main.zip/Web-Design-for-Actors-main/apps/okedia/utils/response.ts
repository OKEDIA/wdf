import type { Response } from "express";
import { STATUS_CODES } from "http";

type ExpressError = Error & { status?: number };
type ErrorInput = ExpressError | number | { code: number; message?: string };

/**
 * Handles HTTP responses by sending a JSON response based on the provided input.
 *
 * If a data payload is provided, the response is immediately sent with a status of 200
 * and the corresponding data. If no data is provided, the function determines the appropriate
 * error status and message from the error input and sends an error response.
 *
 * @template T - The type of the optional data payload.
 * @param {Object} params - The parameters for generating the response.
 * @param {Response} params.res - The HTTP response object used to send the JSON response.
 * @param {number | { code: number; message?: string } | { status?: number; message?: string }} params.input -
 *   The error input which may be:
 *   - A number representing an HTTP status code.
 *   - An object with a "code" property (and optionally a "message").
 *   - An object with a "status" property (and optionally a "message").
 * @param {T} [params.data] - An optional data payload. If provided, a successful response is sent.
 */

export function response<T>({
	res,
	error,
	data,
}: {
	res: Response;
	error: ErrorInput;
	data?: T;
}) {
	// If data is provided, return a successful response and continue.
	if (data !== undefined) {
		res.status(200).json({ success: true, data });
	}

	let status: number;
	let errorMessage: string;

	if (typeof error === "number") {
		status = error;
		errorMessage = STATUS_CODES[status] || `Error with status code ${status}`;
	} else if ("code" in error) {
		status = error.code;
		errorMessage =
			error.message ||
			STATUS_CODES[status] ||
			`Error with status code ${status}`;
	} else {
		status = error.status ?? 500;
		errorMessage =
			error.message ||
			STATUS_CODES[status] ||
			`Error with status code ${status}`;
	}

	res.status(status).json({ success: false, message: errorMessage });
}
