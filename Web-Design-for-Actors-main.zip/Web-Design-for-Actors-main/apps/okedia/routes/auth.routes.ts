import { Router } from "express";
import { exchangeToken, init } from "../controllers/auth.controllers.ts";
import { checkApiKey } from "../middleware/apiKey.middleware.ts";

const router = Router();

router.get("/login", checkApiKey, exchangeToken);
router.get("/init", checkApiKey, init);

export default router;
