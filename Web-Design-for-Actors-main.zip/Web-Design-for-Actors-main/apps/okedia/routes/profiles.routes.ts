import { Router } from "express";
import { getProfile } from "../controllers/profiles.controller.ts";
import { ensureAuthenticated } from "../middleware/checkAuth.middleware.ts";
import { expectPathParam } from "../middleware/expectPathParam.middleware.ts";

const router = Router();

// Profile routes should be accessed via /profiles/:type
router.get(
	"/:type",
	ensureAuthenticated("/profiles", (req) => req.params.type, "read"), // Ensure the user and tenant are correctly authed
	getProfile
);

// There are edge cases where the `type` param may not be present in the URL (and it might not be possilbe to do so)
// This route will handle those cases by using the `filter[type]` query parameter
router.get(
	"/",
	expectPathParam("type"), // Pull `filter[type]` into `req.params.type` if it is not already present
	ensureAuthenticated("/profiles", (req) => req.params.type, "read"), // Ensure the user and tenant are correctly authed
	getProfile
);

export default router;
