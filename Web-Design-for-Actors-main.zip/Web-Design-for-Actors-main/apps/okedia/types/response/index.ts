export type ApiBaseResponse<T> =
	| {
			success: true;
			response: T;
	  }
	| {
			success: false;
			message: string;
	  };

export interface WhoisResponse {
	available?: boolean;
}

interface PleskErrorResponse {
	code: number;
	stderr: string;
}

interface PleskSuccessResponse {
	[key: string]: any; // or a more specific type if you have a rough idea of the structure
}

export type PleskResponse = PleskErrorResponse | PleskSuccessResponse;

// export interface PaginitedMongoResponse<T> {
// 	data: MongoDocumentResponse<T>[];
// 	paginition: PaginitionDocumentResult;
// }

// export type UnpaginitedMongoResponse<T> = MongoDocumentResponse<T>;

export interface PaginitionQuery {
	body: any;
	idSelector: string;
	count: number;
}

export interface PaginitionDocumentResult {
	lastId: string;
	limit: number;
	count: number;
}
