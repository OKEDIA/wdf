import type { OIDCAuthProviderConfig } from "firebase-admin/auth";

export interface ProviderData extends OIDCAuthProviderConfig {
	scopes: string[];
}
