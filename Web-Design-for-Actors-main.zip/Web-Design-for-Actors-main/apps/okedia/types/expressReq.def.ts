import { ApiKeyManager } from "@okedia/core/domain";
import { ResponseSettings } from "@okedia/core/domain/api";

/**
 * Extends the Express Request interface to include an optional providerData and responseSettings property.
 * This is useful for storing additional data related to a provider that is requesting the API.
 *
 * See more in the ./controllers/auth.controller.ts file.
 *
 * @property providerData - added upon validating the API Key and will then be used for functions like getting user data based
 * of the connected provider.
 * @property responseSettings - An optional value of type ResponseSettings, used to hold settings for API responses including filters and response projection
 *
 */
declare global {
	namespace Express {
		interface Request {
			authentication?: Awaited<ReturnType<ApiKeyManager["get"]>>;
			responseSettings?: ResponseSettings;
		}
	}
}
