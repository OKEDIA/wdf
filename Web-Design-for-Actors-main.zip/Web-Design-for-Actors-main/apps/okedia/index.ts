/**
 * Entry point for the Okedia API server.
 *
 * - Loads environment variables.
 * - Initializes Express application and sets up middleware.
 * - Provides basic status and root endpoints.
 * - Logs incoming requests with timestamp, method, URL, and IP.
 * - Converts request URLs to response settings objects for downstream use.
 * - Verifies JWT tokens from the Authorization header and attaches user data to the request.
 * - Mounts authentication routes under `/auth`.
 * - Initializes Mongoose connection on server start.
 *
 * @module OkediaAPI
 */
import "../okedia/utils/env.ts";

import type { ResolvedAuthToken } from "@okedia/core/domain/authentication";
import {
	convertUrlToResponseSettingsObject,
	verifyJwt,
} from "@okedia/core/utils";
import { initMongoose } from "@okedia/core/utils/initMongoose";
import cors from "cors";
import express from "express";
import authRoutes from "./routes/auth.routes.ts";
import epmRoutes from "./routes/epm.routes.ts";
import profileRoutes from "./routes/profiles.routes.ts";

const app = express();
const port = 5002;

const corsOptions = {
	origin: "*",
};

app.get("/", (_req, res) => {
	res.send("OKEDIA API");
});

app.get("/status", (_req, res) => {
	const status = {
		Status: "Running",
	};

	res.send(status);
});

app.use(cors(corsOptions));

// Middleware to console.log incoming requests
app.use((req, _res, next) => {
	console.log(
		`[${new Date().toISOString()}] ${req.method} ${req.originalUrl} from ${req.ip}`
	);
	next();
});

// Middleware to convert URL to ResponseSettings object
app.use((req, _res, next) => {
	req.responseSettings = convertUrlToResponseSettingsObject(req.originalUrl);
	next();
});

// Middleware to verify JWT and attach verified user data to request
// TODO: If the sesssion is expired, we should...
app.use(async (req, _res, next) => {
	const authHeader = req.headers.authorization;
	if (authHeader && authHeader.startsWith("Bearer ")) {
		const token = authHeader.split(" ")[1];
		try {
			console.log("User is authenticated.");
			const decoded = await verifyJwt<ResolvedAuthToken>(
				token,
				process.env.JWT_PUBLIC
			);
			if (decoded) {
				req.authentication = decoded;
			}
		} catch (err) {
			console.error("JWT verification failed:", err);
		}
	}
	next();
});

app.use("/auth", authRoutes);
app.use("/profiles", profileRoutes);
app.use("/epm", epmRoutes);

app.listen(port, "0.0.0.0", () => {
	initMongoose();
	console.log(`Example app listening on port ${port}`);
});
