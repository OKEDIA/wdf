import { formatPrivateKey } from "@okedia/core/utils";
import admin from "firebase-admin";

/**
 * Creates and initializes a Firebase Admin application instance.
 *
 * This function formats the provided private key and uses the Firebase Admin SDK to
 * initialize a new app instance if one does not already exist. If an instance is already
 * initialized, it returns the existing instance.
 *
 * @param params - An object containing the necessary parameters to configure the Firebase Admin app.
 *   @property {string} projectId - The Firebase project ID.
 *   @property {string} clientEmail - The service account client email.
 *   @property {string} privateKey - The private key for the service account; it will be formatted.
 *   @property {string} [storageBucket] - The storage bucket associated with the Firebase project.
 *
 * @returns The initialized Firebase Admin app instance.
 */
function createFirebaseAdminApp(params: FirebaseAdminAppParams) {
	const privateKey = formatPrivateKey(params.privateKey);

	if (admin.apps.length > 0) {
		return admin.app();
	}

	const cert = admin.credential.cert({
		projectId: params.projectId,
		clientEmail: params.clientEmail,
		privateKey,
	});

	return admin.initializeApp({
		credential: cert,
		projectId: params.projectId,
		storageBucket: params.storageBucket,
	});
}

/**
 * Initializes the Firebase Admin application using environment-provided configuration.
 *
 * This function reads necessary environment variables to build the configuration required
 * for initializing the Firebase Admin SDK. It sets up the authentication and storage services,
 * and also provides a method to properly shutdown the admin app.
 *
 * @remarks
 * Make sure the following environment variables are correctly set:
 * - NEXT_PUBLIC_FIREBASE_PROJECT_ID: The Firebase project identifier.
 * - NEXT_PUBLIC_FIREBASE_CLIENT_EMAIL: The service account email.
 * - NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET: The storage bucket name.
 * - FIREBASE_PRIVATE_KEY: The private key for the service account.
 *
 * @returns An object containing the Firebase Admin services:
 * - `auth`: The Firebase Admin authentication service.
 * - `storage`: The Firebase Admin storage service.
 * - `close`: A function to shut down the Firebase Admin application.
 */
export function firebaseAdmin() {
	const params = {
		projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID as string,
		clientEmail: process.env.NEXT_PUBLIC_FIREBASE_CLIENT_EMAIL as string,
		storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET as string,
		privateKey: process.env.FIREBASE_PRIVATE_KEY as string,
	};

	const firebaseAdmin = createFirebaseAdminApp(params);

	return {
		auth: firebaseAdmin.auth,
		storage: firebaseAdmin.storage,
		close: firebaseAdmin.delete,
	};
}

interface FirebaseAdminAppParams {
	projectId: string;
	clientEmail: string;
	storageBucket: string;
	privateKey: string;
}
