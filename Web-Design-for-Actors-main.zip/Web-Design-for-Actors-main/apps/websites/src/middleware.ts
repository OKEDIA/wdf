import { NextRequest, NextResponse } from "next/server";

/**
 * Middleware function that processes incoming requests and manages domain-related operations.
 *
 * @param request - The incoming Next.js request object
 * @returns A Next.js response object with domain information set in cookies
 *
 * @remarks
 * This middleware performs the following operations:
 * - Extracts the host from request headers
 * - Handles optional domain override from URL parameters
 * - Sets the current domain in cookies
 *
 * @throws Returns a 400 status response if no host is found in request headers
 */

export async function middleware(request: NextRequest) {
	const response = NextResponse.next();

	const currentHost = request.headers.get("host"); // e.g. "localhost:3001"
	const domainOverride = request.nextUrl.searchParams.get("domain");
	const noCache = !!request.nextUrl.searchParams.get("noCache");
	const overrideColorScheme = request.nextUrl.searchParams.get("colorScheme");
	const overrideTemplate = request.nextUrl.searchParams.get("template");
	const portlessHost = domainOverride || currentHost?.split(":")[0]; // e.g. "localhost"

	console.warn(
		"[websites] Middleware Dealing with params:",
		currentHost,
		domainOverride,
		portlessHost,
		noCache
	);

	if (!portlessHost) {
		console.error("No host found in request headers");
		return NextResponse.json({ status: 400 });
	}

	response.cookies.set("currentDomain", portlessHost);

	if (noCache) {
		response.cookies.set("noCache", "true", { maxAge: 3600 }); // Set for 1 hour
	}

	if (overrideColorScheme) {
		response.cookies.set("colorScheme", overrideColorScheme, { maxAge: 3600 }); // Set for 1 hour
	}

	if (overrideTemplate) {
		response.cookies.set("template", overrideTemplate, { maxAge: 3600 }); // Set for 1 hour
	}

	return response;
}
export const config = {
	matcher: ["/", "/((?!_next|favicon.ico|api|.*\\.).*)"],
};
