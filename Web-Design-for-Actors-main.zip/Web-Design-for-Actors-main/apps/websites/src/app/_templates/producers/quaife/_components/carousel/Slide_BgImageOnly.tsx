// React Imports

import { CarouselSlide } from "@mantine/carousel";
import { Image } from "@mantine/core";
// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
export default function Slide_BgImageOnly({
	backgroundImageUrl,
	altText,
}: {
	backgroundImageUrl?: string;
	altText?: string;
}) {
	return (
		<CarouselSlide>
			<Image
				src={backgroundImageUrl}
				alt={altText}
				h="100dvh"
				fit="cover"
			/>
		</CarouselSlide>
	);
}
