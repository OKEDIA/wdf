// React Imports
import { useContext, useRef } from "react";

// Next.js Imports

// Lower Order Components
import Slide_BgImageOnly from "./Slide_BgImageOnly";
import Slide_WithLogo from "./Slide_WithLogo";

// UI Components & Icons
import { Carousel } from "@mantine/carousel";
import {
	AppShellSection,
	Grid,
	GridCol,
	Stack,
	Text,
	useMantineTheme,
} from "@mantine/core";
// Context & Helpers
import { DataContext, DataContextValues } from "@/app/_context/Data";

// Other libraries or utilities
import Autoplay from "embla-carousel-autoplay";

// Types
import {
	CarouselImages,
	ProducerProfile,
	Website,
} from "@okedia/shared/types/profile";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function CarouselSection({
	scrollButton: { onClick, text, Icon },
	carouselData,
}: {
	scrollButton: {
		onClick: () => void;
		text: string;
		Icon: React.FC<{
			height: string;
			width: string;
			color: string;
			style: React.CSSProperties;
		}>;
	};
	carouselData?: CarouselImages[];
}) {
	const autoplay = useRef(Autoplay({ delay: 10000 }));
	const theme = useMantineTheme();
	const data = useContext(DataContext) as DataContextValues<
		Website<ProducerProfile>
	>;
	const website = data.states.websiteData.profile[0] as ProducerProfile;
	const carouselSlides = () => {
		return carouselData?.map((slide, index) => {
			if (index === 0) {
				return (
					<Slide_WithLogo
						key={index}
						backgroundImageUrl={slide?.backgroundImage?.downloadUrl}
						logoImage={website.brand?.graphics?.[0]?.logo?.downloadUrl || ""}
					/>
				);
			} else {
				return (
					<Slide_BgImageOnly
						key={index}
						backgroundImageUrl={slide?.backgroundImage?.downloadUrl}
						altText={slide.altText}
					/>
				);
			}
		});
	};

	function ScrollButton() {
		return (
			<>
				<Stack
					gap={0}
					align="center"
					justify="center"
					onClick={() => onClick()}
					style={{
						transition: "transform 0.3s ease",
						animation: "bounce 1s ease-in-out 8s 13",
					}}
					onMouseEnter={(e) => {
						e.currentTarget.style.transform = "scale(1.1)";
					}}
					onMouseLeave={(e) => {
						e.currentTarget.style.transform = "scale(1)";
					}}
					mt="-100px"
				>
					<Text
						c="gray.3"
						p={0}
						m={0}
						size="sm"
						fw="bold"
						tt="uppercase"
					>
						{text}
					</Text>
					<Icon
						height={"5vh"}
						width={"5vh"}
						color={theme.colors.gray[3]}
						style={{ marginTop: "-15px" }}
					/>
				</Stack>
				<style jsx>{`
					@keyframes bounce {
						0%,
						100% {
							transform: translateY(0);
						}
						50% {
							transform: translateY(-10px);
						}
					}
				`}</style>
			</>
		);
	}

	return (
		<AppShellSection>
			<Grid
				columns={24}
				justify="cente r"
				align="center"
			>
				<GridCol
					span={24}
					h="100dvh"
				>
					<Carousel plugins={[autoplay.current]}>{carouselSlides()}</Carousel>
					<ScrollButton />
				</GridCol>
			</Grid>
		</AppShellSection>
	);
}
