// React Imports

import { CarouselSlide } from "@mantine/carousel";
import { Flex, Image, Overlay, Stack } from "@mantine/core";

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Slide_WithLogo({
	backgroundImageUrl,
	logoImage,
}: {
	backgroundImageUrl?: string;
	logoImage: string;
}) {
	return (
		<CarouselSlide
			style={{
				backgroundSize: "cover",
				backgroundPosition: "center",
				backgroundImage: `url('${backgroundImageUrl}')`,
			}}
		>
			<Overlay
				backgroundOpacity={0.2}
				blur="4"
				p="lg"
				component={Flex}
				style={{ display: "flex", justifyContent: "center" }}
			>
				<Stack
					align="center"
					justify="center"
				>
					<Image
						height="1000px"
						w="1000px"
						src={logoImage}
						alt="Cover Image"
					/>
				</Stack>
			</Overlay>
		</CarouselSlide>
	);
}
