// React Imports

import { BaseSyntheticEvent, useState } from "react";

// Next.js Imports

// Lower Order Components
import { Alert, Button, Input, InputWrapper, Textarea } from "@mantine/core";

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities
import { useDatabase } from "@okedia/shared/hooks";

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
export default function ContactForm({ profileId }: { profileId: string }) {
	const [formValues, setFormValues] = useState({
		name: "",
		email: "",
		message: "",
	});
	const [isLoading, setIsLoading] = useState<boolean>(false);
	const [error, setError] = useState<string | null>(null);
	const [success, setSuccess] = useState<boolean>(false);
	const db = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);

	async function handleFormSubmit(
		event: BaseSyntheticEvent,
		content: {
			content: any;
			subject: any;
			sender: any;
			profileId: any;
		}
	) {
		event.preventDefault();

		if (
			!content.content ||
			!content.subject ||
			!content.sender ||
			!content.profileId
		) {
			throw new Error("Please fill in all fields.");
		}

		return await db.post(`/messages/${content.profileId}`, {
			content: content.content,
			subject: content.subject,
			sender: content.sender,
		});
	}

	return (
		<form
			onSubmit={(event) =>
				handleFormSubmit(event, {
					content: formValues.message,
					subject: formValues.email,
					sender: formValues.name,
					profileId,
				})
			}
		>
			<InputWrapper
				size="xl"
				label="Your Name"
				mb="lg"
				variant="filled"
			>
				<Input
					variant="filled"
					placeholder="Mike Doe"
					onChange={(e) =>
						setFormValues({ ...formValues, name: e.currentTarget?.value })
					}
					value={formValues.name}
				/>
			</InputWrapper>
			<InputWrapper
				size="xl"
				label="Your Email"
				mb="lg"
				variant="filled"
			>
				<Input
					variant="filled"
					placeholder="my@email.com"
					onChange={(e) =>
						setFormValues({ ...formValues, email: e.currentTarget?.value })
					}
					value={formValues.email}
				/>
			</InputWrapper>
			<InputWrapper
				size="xl"
				label="Message"
				mb="lg"
				variant="filled"
			>
				<Textarea
					variant="filled"
					placeholder="Hello!"
					onChange={(e) =>
						setFormValues({ ...formValues, message: e.currentTarget?.value })
					}
					value={formValues.message}
				/>
			</InputWrapper>
			{!success && !error && (
				<Button
					fullWidth
					variant="outline"
					color="primaryAccent"
					disabled={isLoading || Boolean(error?.length && error.length > 0)}
					loading={isLoading}
					onClick={async (event) => {
						event.preventDefault();

						setIsLoading(true);
						await handleFormSubmit(event, {
							content: formValues.message,
							subject: `Message from ${formValues.name}`,
							sender: formValues.email,
							profileId: profileId,
						})
							.then(() => {
								setSuccess(true);
							})
							.catch((e) => {
								setError(e.message);
							})
							.finally(() => {
								setIsLoading(false);
							});
					}}
				>
					Send
				</Button>
			)}

			{success && <Alert>Thanks, your message was sent successfully.</Alert>}

			{error && (
				<Alert
					withCloseButton
					color="yellow.5"
					onClose={() => setError(null)}
				>
					{error ? error : "An error occurred, please try again."}
				</Alert>
			)}
		</form>
	);
}
