"use client";

// React Imports
import { ReactNode, useContext } from "react";

// Next.js Imports

// Lower Order Components
import FooterText from "@/app/_shared/components/FooterText";

// UI Components & Icons
import {
	AppShell,
	AppShellHeader,
	AppShellMain,
	Button,
	Grid,
	Group,
	Image,
	useMantineTheme,
} from "@mantine/core";

// Context & Helpers
import { DataContext, DataContextValues } from "@/app/_context/Data";

// Other libraries or utilities
import { useNavClick } from "@/app/_shared/utilities/useNavClick";

// Types
import { ProducerProfile } from "@okedia/shared/types/profile";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Template({
	children,
	withHeader,
}: {
	children: ReactNode;
	withHeader?: boolean;
}) {
	const theme = useMantineTheme();
	const data = useContext(DataContext) as DataContextValues<ProducerProfile[]>;
	const profile = data.states.websiteData.profile[0];
	const navigation = useNavClick();

	return (
		<AppShell header={{ collapsed: !withHeader, height: 120 }}>
			<AppShellHeader>
				<Grid
					columns={12}
					h="100%"
					styles={{
						inner: { height: "100%", margin: 0 },
						col: {
							display: "flex",
							alignItems: "center",
							justifyContent: "center",
						},
						root: {
							borderBottom: "2px solid var(--mantine-color-primary-5)",
						},
					}}
					grow
					overflow="hidden"
					align="center"
					justify="space-evenly"
				>
					<Grid.Col span={3}>
						<Image
							src={profile?.brand?.graphics?.[0].logo?.downloadUrl}
							alt={`${profile?.brand?.name?.[0]?.brandName} Logo`}
							height={80}
						/>
					</Grid.Col>
					<Grid.Col
						span={6}
						visibleFrom="md"
					></Grid.Col>
					<Grid.Col
						span={3}
						visibleFrom="md"
					>
						<Group>
							<Button
								color="primaryAccent"
								size="md"
								autoContrast
								onClick={() => navigation.push("/")}
								tt="uppercase"
							>
								Home
							</Button>
						</Group>
					</Grid.Col>
				</Grid>
			</AppShellHeader>
			<AppShellMain>
				{children}
				<Grid
					columns={12}
					h="100%"
					styles={{
						inner: { height: "100%", margin: 0 },
						col: {
							display: "flex",
							alignItems: "center",
							justifyContent: "center",
						},
					}}
					grow
					overflow="hidden"
					align="center"
					justify="space-between"
					p="100px"
					bg="secondary"
					ff="Raleway"
				>
					<FooterText brandName={profile.brand?.name?.[0].tradingName} />
				</Grid>
			</AppShellMain>
		</AppShell>
	);
}
