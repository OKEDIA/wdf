"use client";

// React Imports
import { CSSProperties, useCallback, useContext, useState } from "react";

// Next.js Imports
import Link from "next/link";

// Lower Order Components
import CarouselSection from "../_components/carousel/CarouselSection";

// UI Components & Icons
import {
	AppShellSection,
	Box,
	Container,
	Flex,
	Grid,
	GridCol,
	Image,
	Overlay,
	Stack,
	Title,
	Transition,
	useMantineTheme,
} from "@mantine/core";
import { IconCaretDownFilled, IconCaretRightFilled } from "@tabler/icons-react";
import Template from "./Template";

// Context & Helpers

// Other libraries or utilities
import { DataContext, DataContextValues } from "@/app/_context/Data";
import Slant from "@/app/_shared/components/slant/Slant";
import { useScrollIntoView } from "@mantine/hooks";
import { convertStringToSlug } from "@okedia/shared/helpers/string";
import { usePaginition } from "@okedia/shared/hooks/database";
import { MongoDocumentResponse } from "@okedia/shared/types/mongoTypes";
import {
	CarouselImages,
	ProducerProfile,
	ProductionProfile,
} from "@okedia/shared/types/profile";
import Sections, {
	SectionWrapperProps,
} from "../../../../_shared/components/sections/Sections";
import ContactForm from "../_components/forms/Contact";
import { PageProps } from "../page";

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
export default function Homepage({ data, slug }: PageProps) {
	const theme = useMantineTheme();
	const context = useContext(DataContext) as DataContextValues<
		ProducerProfile[]
	>;
	const productions =
		context.states.websiteData.profile[0].productions?.production;

	const additionalSections = [
		{
			id: "productions",
			title: "Productions",
			index: 2,
			children: (
				<Grid
					grow
					columns={24}
				>
					<ProductionsRows />
				</Grid>
			),
		},
	];

	const paginition = usePaginition<any>({
		initialCount: 6,
		initialData: productions,
		pageLimit: 6,
		onDataChange: useCallback(
			(
				data: {
					producer?: MongoDocumentResponse<ProducerProfile>[];
					production?: MongoDocumentResponse<ProductionProfile>[];
				}[]
			) =>
				context.setters.setWebsiteData((draft) => {
					if (draft.profile[0]?.productions) {
						draft.profile[0].productions.production = data;
					}
				}),
			[context.setters]
		),
		endpointUrl: { producer: "/profiles/", production: "/profiles/" },
	});

	const { scrollIntoView, targetRef } = useScrollIntoView<HTMLDivElement>({
		offset: 60,
	});

	function ProductionsRows() {
		const [visibleIndex, setVisibleIndex] = useState<number | null>(null);
		return context.states.websiteData.profile[0].productions?.production?.map(
			(
				production: {
					producer?: ProducerProfile[];
					production?: ProductionProfile[];
				},
				index: number
			) => {
				const thisProduction = production.production?.[0];
				const productionName = thisProduction?.intro?.name?.[0]?.value;
				if (!productionName) return;
				const slug = convertStringToSlug(productionName, []);

				return (
					<GridCol
						span={4}
						key={index}
						pos="relative"
						onMouseEnter={() => setVisibleIndex(index)}
						onMouseLeave={() => setVisibleIndex(null)}
					>
						<Link href={`/productions/${slug}`}>
							<Box pos="relative">
								<Transition
									mounted={visibleIndex === index}
									transition="fade"
									duration={200}
									timingFunction="ease"
									keepMounted
								>
									{(transitionStyles) => (
										<Overlay
											color={theme.colors.primary[9]}
											backgroundOpacity={0.6}
											blur="5"
											p="lg"
											component={Flex}
											styles={{
												root: {
													...transitionStyles,
													alignItems: "center",
													justifyContent: "center",
												},
											}}
										>
											<Stack
												justify="center"
												align="center"
											>
												<Title
													order={2}
													ta="center"
													c="gray.1"
												>
													{productionName}
												</Title>
												<IconCaretRightFilled
													color={theme.colors.gray[1]}
													height={"5vh"}
													width={"5vh"}
												/>
											</Stack>
										</Overlay>
									)}
								</Transition>

								<Image
									src={
										thisProduction.featuredImages?.carousel?.[0].backgroundImage
											?.downloadUrl
									}
									alt="Production Image"
								/>
							</Box>
						</Link>
					</GridCol>
				);
			}
		);
	}

	function SectionWrapper({
		colors,
		index,
		children,
	}: Pick<SectionWrapperProps, "colors" | "index"> & {
		children: React.ReactNode;
	}) {
		return (
			<AppShellSection bg={colors.mainColor}>
				<Slant options={{ reverse: index % 2 === 0, withPadding: true }}>
					<Container
						styles={{
							root: {
								display: "flex",
								justifyContent: "center",
								flexDirection: "column",
								alignItems: "center",
							},
						}}
						c={colors.accentColor}
					>
						{children}
					</Container>
				</Slant>
			</AppShellSection>
		);
	}

	return (
		<Template>
			<CarouselSection
				scrollButton={{
					onClick: scrollIntoView,
					text: "Continue to website",
					Icon: ({
						height,
						color,
						style,
					}: {
						height: string;
						color: string;
						style: CSSProperties;
					}) => (
						<IconCaretDownFilled
							style={style}
							size={height}
							color={color}
						/>
					),
				}}
				carouselData={
					data?.[0]?.featuredImages?.carousel as CarouselImages[] | undefined
				}
			/>
			<Sections
				data={data?.[0].sections?.section}
				additionalSections={additionalSections}
				options={{ offsetLastColor: true }}
				Wrapper={({ section, index, colors, children }) => {
					if (section.type === "contact") {
						return (
							<SectionWrapper
								colors={colors}
								index={index}
							>
								<Box
									mb="xl"
									ta="center"
								>
									{children}
								</Box>
								<Box w="100%">
									<ContactForm profileId={data?.[0]?.id as string} />
								</Box>
							</SectionWrapper>
						);
					}
					return (
						<SectionWrapper
							colors={colors}
							index={index}
						>
							{children}
						</SectionWrapper>
					);
				}}
			/>
		</Template>
	);
}
