"use client";

// React Imports
import { useContext } from "react";

// Next.js Imports
import { useParams } from "next/navigation";

// Lower Order Components
import Homepage from "./_pages/Homepage";

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types
import { DataContext, DataContextValues } from "@/app/_context/Data";
import { Profiles } from "@okedia/shared/types";
import { MongoDocumentResponse } from "@okedia/shared/types/mongoTypes";
import Productions from "./_pages/Productions";
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
export interface PageProps {
	data: MongoDocumentResponse<Profiles.ProducerProfile>[];
	slug: string | string[];
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function QuaifeTemplate() {
	const params = useParams();
	const slug = params.slug ? params.slug : [""]; // Handle dynamic slug
	const routeKey = !slug.length || slug[0] === "" ? "home" : slug[0];
	const RouteComponent = routes[routeKey as keyof typeof routes];
	const context = useContext(DataContext) as DataContextValues<
		MongoDocumentResponse<Profiles.ProducerProfile>[]
	>;

	const data = context.states.websiteData.profile;

	if (RouteComponent) {
		return (
			<RouteComponent
				data={data}
				slug={slug}
			/>
		);
	}

	return <div>Page not found for Quaife Template</div>;
}

const routes = {
	home: ({ data, slug }: PageProps) => (
		<Homepage
			data={data}
			slug={slug}
		/>
	),

	productions: ({ data, slug }: PageProps) => (
		<Productions
			data={data}
			slug={slug}
		/>
	),
};
