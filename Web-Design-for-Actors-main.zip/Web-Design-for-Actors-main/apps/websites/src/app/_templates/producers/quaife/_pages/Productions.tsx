"use client";

// React Imports
import { useContext, useEffect, useState } from "react";

// Next.js Imports

// Lower Order Components
import Testimonials from "@/app/_shared/components/testimonials/Testimonials";
import Sections, {
	AdditionalSection,
} from "../../../../_shared/components/sections/Sections";

// UI Components & Icons
import {
	Center,
	Container,
	Grid,
	Image,
	LoadingOverlay,
	Title,
} from "@mantine/core";
import Template from "./Template";

// Context & Helpers
import { DataContext, DataContextValues } from "@/app/_context/Data";
import { convertStringToSlug } from "@okedia/shared/helpers/string";

// Other libraries or utilities
import { useDatabase } from "@okedia/shared/hooks";

// Types
import { PaginitedMongoResponse } from "@okedia/shared/types/documentResponses";
import { MongoDocumentResponse } from "@okedia/shared/types/mongoTypes";
import {
	ProducerProfile,
	ProductionProfile,
} from "@okedia/shared/types/profile";
import { PageProps } from "../page";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
export default function Productions({ data, slug }: PageProps) {
	const db = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);
	const context = useContext(DataContext) as DataContextValues<
		MongoDocumentResponse<ProducerProfile>[]
	>;
	const [found, setFound] = useState<ProductionProfile | undefined>(undefined);

	useEffect(() => {
		if (found) return;

		getProfile().then((newProductions) => {
			const production = newProductions?.[0];
			if (!production?.id) return;

			let matchedProduction: ProductionProfile | undefined;

			context.setters.setWebsiteData((draft) => {
				const productions = draft.profile?.[0]?.productions?.production;
				if (!productions) return;

				const index = productions.findIndex((item) => {
					const currentId =
						typeof item.production?.[0] === "string"
							? item.production[0]
							: item.production?.[0]?.id;
					return currentId === production.id;
				});

				if (index !== -1) {
					productions[index].production = newProductions;

					// Derive the match from the updated draft
					const prodData = Array.isArray(newProductions)
						? newProductions.find((p) => {
								return (
									convertStringToSlug(p.intro?.name?.[0]?.value || "", []) ===
									slug[1]
								);
						  })
						: undefined;

					matchedProduction = prodData;
				}
			});

			// Set it from the match found inside the state update
			if (matchedProduction) {
				setFound(matchedProduction);
			}
		});
	}, [context.states.websiteData]);

	const additionalSections: AdditionalSection[] = [];

	async function getProfile() {
		const filter = JSON.stringify([
			{ type: "productions" },
			{ "people.producers[0].value": data[0].id },
		]);

		return await db
			.get<PaginitedMongoResponse<ProductionProfile>>(
				`/profiles?filter=${filter}`
			)
			.then((res) => {
				if (res) {
					return res.data;
				}

				throw new Error("Production not found");
			});
	}

	////
	// HERO IMAGE
	////
	additionalSections.push({
		index: 0,
		options: {
			withTitle: false,
		},
		children: (
			<Grid.Col
				mih="75dvh"
				styles={{
					col: {
						backgroundImage: `url(${found?.featuredImages?.carousel?.[0]?.backgroundImage?.downloadUrl})`,
						backgroundSize: "cover",
						backgroundPosition: "center",
						backgroundRepeat: "no-repeat",
						justifyContent: "center",
						alignItems: "center",
						display: "flex",
					},
				}}
			>
				<Center h="100%">
					<Title c="primaryAccent">{found?.intro?.name?.[0].value}</Title>
				</Center>
			</Grid.Col>
		),
	});

	////
	// TESTIMONIALS
	////
	additionalSections.push({
		index: 1,
		options: {
			withTitle: false,
		},
		children: (
			<Grid.Col
				c="primary"
				ta="center"
			>
				<Testimonials
					testimonials={found?.testimonials?.testimonials}
					carouselProps={{
						slideSize: "100%",
						slidesToScroll: 1,
						withIndicators: true,
						withControls: false,
					}}
					contentProps={{
						styles: {
							root: {
								maxWidth: "600px",
							},
						},
					}}
				/>
			</Grid.Col>
		),
	});

	////
	// PRODUCTION IMAGES
	////
	additionalSections.push({
		index: 3,
		options: {
			withTitle: false,
		},
		children: (
			<Grid.Col p={0}>
				<Grid grow>
					{found?.featuredImages?.carousel?.map((image, index) => {
						return (
							<Grid.Col
								key={`image_${index}`}
								span={{ base: 12, md: 4 }}
							>
								<Image
									src={image.backgroundImage?.downloadUrl}
									alt={image.altText}
								/>
							</Grid.Col>
						);
					})}
				</Grid>
			</Grid.Col>
		),
	});

	return (
		<Template withHeader>
			<LoadingOverlay visible={!found} />
			<Grid columns={12}>
				<Sections
					data={found?.sections?.section}
					additionalSections={additionalSections}
					Wrapper={({ section, children, colors, index }) => {
						if (index === 0) {
							// Do not wrap the first (hero image) section
							return <>{children}</>;
						}

						return (
							<Grid.Col my="xl">
								<Container size="xl">{children}</Container>
							</Grid.Col>
						);
					}}
				/>
			</Grid>
		</Template>
	);
}
