// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { AppShellSection } from "@mantine/core";
import { Alex_Brush } from "next/font/google";
import Gallery from "../_components/gallery/Gallery";
import Testimonials from "../_components/testimonials/Testimonials";

// Context & Helpers

// Other libraries or utilities

// Types
import { checkIsEmpty } from "@okedia/shared/helpers";
import { PageProps } from "../page";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
const alexBrush = Alex_Brush({
	weight: ["400"],
	subsets: ["latin"],
});
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
export default function Homepage({ data, slug }: PageProps) {
	return (
		<AppShellSection>
			{/* Card - About */}

			{/* About */}
			<div className="content about">
				{/* <!-- title --> */}
				<div className="title">Welcome</div>
				{/* <!-- content --> */}
				<div className="row">
					<div className="col col-d-12 col-t-12 col-m-12 border-line-v">
						<div className="text-box">
							<div
								dangerouslySetInnerHTML={{
									__html: data.intro?.biog?.[0]?.value as string,
								}}
							/>
							<p
								style={{
									fontFamily: "Alex Brush",
									fontWeight: 500,
									fontSize: "2em",
									marginTop: "10px",
									fontKerning: "auto",
									textAlign: "left",
								}}
								className={alexBrush.className}
							>
								{data.intro?.stageName?.[0]?.value}
							</p>
						</div>
					</div>
				</div>
				{!checkIsEmpty(data.gallery?.file) && (
					<Gallery images={data.gallery?.file} />
				)}
				{!checkIsEmpty(data.testimonials?.testimonials) &&
					data.testimonials?.testimonials?.length && (
						<Testimonials testimonials={data.testimonials?.testimonials} />
					)}
			</div>
		</AppShellSection>
	);
}
