"use client";

// React Imports
import { useContext } from "react";
// Next.js Imports
import { useParams } from "next/navigation";

// Lower Order Components

import BlogPage from "./_pages/Blog";
import Contact from "./_pages/Contact";
import Gallery from "./_pages/Gallery";
import Homepage from "./_pages/Homepage";
import Profile from "./_pages/Profile";
import Template from "./_pages/Template";

// UI Components & Icons

// Context & Helpers
import { DataContext, DataContextValues } from "@/app/_context/Data";

// Other libraries or utilities

// Types
import { Profiles } from "@okedia/shared/types";
import { MongoDocumentResponse } from "@okedia/shared/types/mongoTypes";
import { ActorProfile } from "@okedia/shared/types/profile";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
export interface PageProps {
	data: MongoDocumentResponse<ActorProfile>;
	slug: string | string[];
}

export default function Page() {
	const params = useParams();
	const slug = params.slug ? params.slug : [""]; // Handle dynamic slug
	const routeKey = !slug.length || slug[0] === "" ? "home" : slug[0];
	const RouteComponent = routes[routeKey as keyof typeof routes];
	const context = useContext(DataContext) as DataContextValues<
		Profiles.ActorProfile[]
	>;
	const data = context.states.websiteData
		.profile[0] as MongoDocumentResponse<ActorProfile>;

	if (RouteComponent) {
		return (
			<Template>
				<RouteComponent
					data={data}
					slug={slug}
				/>
			</Template>
		);
	}

	return <div>Page not found for Ryan Template</div>;
}

const routes = {
	home: ({ data, slug }: PageProps) => (
		<Homepage
			data={data}
			slug={slug}
		/>
	),
	profile: ({ data, slug }: PageProps) => (
		<Profile
			data={data}
			slug={slug}
		/>
	),
	blog: ({ data, slug }: PageProps) => (
		<BlogPage
			data={data}
			slug={slug}
		/>
	),

	gallery: ({ data, slug }: PageProps) => (
		<Gallery
			data={data}
			slug={slug}
		/>
	),

	contact: ({ data, slug }: PageProps) => (
		<Contact
			data={data}
			slug={slug}
		/>
	),
};
