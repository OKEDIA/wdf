// React Imports

// Next.js Imports

// Lower Order Components
import BlogPost from "../_components/blog/BlogPost";
import BlogPosts from "../_components/blog/BlogPosts";

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types
import { PageProps } from "../page";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
export default function BlogPage({ data, slug }: PageProps) {
	const matchingPost = data.blog?.post?.find((post) => post.slug === slug[1]);

	if (!slug[1]) {
		return (
			<BlogPosts
				data={data}
				slug={slug}
			/>
		);
	}

	if (slug[1] && !matchingPost) {
		return <p>Post not found.</p>;
	}

	return (
		<BlogPost
			data={data}
			slug={slug}
		/>
	);
}
