// React Imports
import { Fragment, useState } from "react";

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import FooterText from "@/app/_shared/components/FooterText";
import { Alert, Button, Grid } from "@mantine/core";
import { useDatabase } from "@okedia/shared/hooks";

// Types
import { Agency } from "@okedia/shared/types/profile";
import { PageProps } from "../page";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

const formatAgencyDetails = (
	street1: string,
	street2: string,
	town: string,
	city: string
) => {
	const details = [];

	if (street1) {
		details.push(street1);
	}
	if (street2) {
		details.push(street2);
	}
	if (town) {
		details.push(town);
	}
	if (city) {
		details.push(city);
	}

	return details.join(", ");
};

function AgentDetail({ agencies }: { agencies?: Agency[] }) {
	return agencies?.map((agency, index) => {
		const agencyAddress = formatAgencyDetails(
			agency.street1,
			agency.street2,
			agency.town,
			agency.city
		);

		return (
			<Fragment key={index}>
				<div className="title">Get in Touch - {agency.representing}</div>
				<div className="row">
					<div className="col col-d-12 col-t-12 col-m-12 border-line-v">
						<div className="info-list">
							<ul>
								<li>
									<strong>Contact Name</strong>
									{agency.name}
								</li>
								<li>
									<strong>Number</strong>
									{agency.tel}
								</li>
								<li>
									<strong>Email</strong>
									{agency.email}
								</li>
								<li>
									<strong>Website</strong>{" "}
									<a
										href={(agency?.url ?? "") as string}
										target="_blank"
										// alt="Agency Website"
									>
										Click Here
									</a>
								</li>
								<li>
									<strong>Address</strong> {agencyAddress}
								</li>
							</ul>
						</div>
					</div>
					<div className="clear"></div>
				</div>
			</Fragment>
		);
	});
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Contact({ data, slug }: PageProps) {
	const [formValues, setFormValues] = useState({
		name: "",
		email: "",
		message: "",
	});
	const [isLoading, setIsLoading] = useState<boolean>(false);
	const [error, setError] = useState<string | null>(null);
	const [success, setSuccess] = useState<boolean>(false);
	const db = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);

	async function handleFormSubmit(
		event: React.MouseEvent<HTMLButtonElement, MouseEvent>,
		content: {
			content: any;
			subject: any;
			sender: any;
			profileId: any;
		}
	) {
		event.preventDefault();

		if (
			!content.content ||
			!content.subject ||
			!content.sender ||
			!content.profileId
		) {
			throw new Error("Please fill in all fields.");
		}

		return await db.post(`/messages/${content.profileId}`, {
			content: content.content,
			subject: content.subject,
			sender: content.sender,
		});
	}

	return (
		<div className="card-wrap">
			{/* <!-- Conacts Info --> */}
			<div className="content contacts">
				{/* <!-- content --> */}
				<AgentDetail agencies={data?.contacts?.agentDetails} />
			</div>

			{/* <!-- Contact Form --> */}
			<div className="content contacts">
				{/* <!-- title --> */}
				<div className="title">
					Get in Touch - Contact {data?.intro?.stageName?.[0].value}
				</div>

				{/* <!-- content --> */}
				<div className="row">
					<div className="col col-d-12 col-t-12 col-m-12 border-line-v">
						<div className="contact_form">
							<form
								id="cform"
								method="post"
							>
								<div className="row">
									<div className="col col-d-6 col-t-6 col-m-12">
										<div className="group-val">
											<input
												type="text"
												name="name"
												placeholder="Full Name"
												value={formValues.name}
												onChange={(event) => {
													setFormValues({
														...formValues,
														name: event.target.value,
													});
												}}
											/>
										</div>
									</div>
									<div className="col col-d-6 col-t-6 col-m-12">
										<div className="group-val">
											<input
												type="text"
												name="email"
												placeholder="Email Address"
												value={formValues.email}
												onChange={(event) => {
													setFormValues({
														...formValues,
														email: event.target.value,
													});
												}}
											/>
										</div>
									</div>
									<div className="col col-d-12 col-t-12 col-m-12">
										<div className="group-val">
											<textarea
												name="message"
												placeholder="Your Message"
												value={formValues.message}
												onChange={(event) => {
													setFormValues({
														...formValues,
														message: event.target.value,
													});
												}}
											></textarea>
										</div>
									</div>
								</div>
								{!success && !error && (
									<Button
										variant="subtle"
										className="button"
										id="submit-button"
										mb="lg"
										disabled={
											isLoading || Boolean(error?.length && error.length > 0)
										}
										loading={isLoading}
										onClick={async (event) => {
											setIsLoading(true);
											await handleFormSubmit(event, {
												content: formValues.message,
												subject: `Message from ${formValues.name}`,
												sender: formValues.email,
												profileId: data?.id,
											})
												.then(() => {
													setSuccess(true);
												})
												.catch((e) => {
													setError(e.message);
												})
												.finally(() => {
													setIsLoading(false);
												});
										}}
									>
										<div className="align-left">
											<span className="text">Send Message</span>
											<span className="arrow"></span>
										</div>{" "}
									</Button>
								)}
							</form>
							{success && (
								<Alert>Thanks, your message was sent successfully.</Alert>
							)}

							{error && (
								<Alert
									withCloseButton
									color="yellow.5"
									onClose={() => setError(null)}
								>
									{error ? error : "An error occurred, please try again."}
								</Alert>
							)}
						</div>
					</div>
				</div>
			</div>
			<div className="row">
				<div className="col col-d-12 col-t-12 col-m-12 border-line-v">
					<Grid columns={12}>
						<FooterText />
					</Grid>
				</div>
			</div>
		</div>
	);
}
