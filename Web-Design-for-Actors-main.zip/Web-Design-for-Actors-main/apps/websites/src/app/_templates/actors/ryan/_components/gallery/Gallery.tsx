// React Imports
import { GalleryFile } from "@okedia/shared/types/profile";
import { Fragment } from "react";

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Gallery({ images }: { images?: GalleryFile[] }) {
	return (
		<Fragment>
			<div className="clear"></div>

			<div className="content clients">
				<div
					className="row client-items"
					style={{ marginTop: "-0px" }}
				>
					{images?.map((image, index) => {
						return (
							<div
								className="col col-d-3 col-t-3 col-m-6 border-line-v"
								key={index}
							>
								<div className="client-item">
									<div className="image">
										<div
											style={{
												backgroundImage: `url(${image.upload.downloadUrl})`,
												height: "115px",
												backgroundSize: "cover",
												backgroundRepeat: "no-repeat",
												backgroundPosition: "center top",
											}}
										></div>
										<a
											target="_blank"
											href={image?.upload?.downloadUrl ?? ""}
										>
											{/* <!-- <img src="<?php echo $item['upload']['downloadURL']; ?>" alt="<?php echo isset($item['name']) ? $item['name'] : ''; ?>"> --> */}
										</a>
									</div>
								</div>
							</div>
						);
					})}
				</div>
			</div>
		</Fragment>
	);
}
