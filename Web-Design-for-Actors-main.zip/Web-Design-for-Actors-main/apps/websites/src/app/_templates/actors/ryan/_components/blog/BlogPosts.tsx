// React Imports

// Next.js Imports
import Link from "next/link";

// Lower Order Components

// UI Components & Icons
import { AppShellSection, Box, Image } from "@mantine/core";

// Context & Helpers

// Other libraries or utilities

// Types
import { Post } from "@okedia/shared/types/profile";
import { PageProps } from "../../page";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

function BlogPostCards({ posts }: { posts?: Post[] }) {
	return posts?.map((post, index) => {
		return (
			<div
				className="col col-d-6 col-t-6 col-m-12"
				key={index}
			>
				<div className="box-item">
					<div className="image">
						<Link href={`/blog/${post.slug}`}>
							<Image
								src={post?.cover?.downloadUrl}
								alt="By spite about do of allow"
							/>
						</Link>
					</div>
					<div className="desc">
						<Link href={`/blog/${post.slug}`}>
							<span className="date">{post.date}</span>
						</Link>
						<Link
							href={`/blog/${post.slug}`}
							className="name"
						>
							{post.name}
						</Link>
						<Box
							dangerouslySetInnerHTML={{
								__html: post.content,
							}}
						/>
					</div>
				</div>
			</div>
		);
	});
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function BlogPosts({ data, slug }: PageProps) {
	return (
		<AppShellSection>
			{/* Card - Blog */}

			{/* <!-- Blog --> */}
			<div className="content blog">
				{/* <!-- title --> */}
				<div className="title">
					<span>Blog</span>
				</div>

				{/* <!-- content --> */}
				<div className="row border-line-v">
					{/* <!-- blog item --> */}
					<BlogPostCards posts={data?.blog?.post} />

					<div className="clear"></div>
				</div>

				{/* <div className="pager">
					<nav className="navigation pagination">
						<div className="nav-links">
							<span className="page-numbers current">1</span>
							<a
								className="page-numbers"
								href="#"
							>
								2
							</a>
							<a
								className="next page-numbers"
								href="#"
							>
								Next
							</a>
						</div>
					</nav>
				</div> */}
			</div>
		</AppShellSection>
	);
}
