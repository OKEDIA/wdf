// React Imports

// Next.js Imports
import Link from "next/link";

// Lower Order Components

// UI Components & Icons
import { Image } from "@mantine/core";

// Context & Helpers
import { distanceToNow } from "@okedia/shared/helpers/date";

// Other libraries or utilities

// Types
import { Post } from "@okedia/shared/types/profile";
import { PageProps } from "../../page";
import { checkIsEmpty } from "@okedia/shared/helpers";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function BlogPost({ data, slug }: PageProps) {
	const matchingPost = data.blog?.post?.find(
		(post: Post) => post.slug === slug[1]
	);

	console.log(matchingPost);

	return (
		<div className="card-wrap">
			{/* <!--
						Blog Single
					--> */}
			<div className="content blog-single">
				{/* <!-- title --> */}
				<div className="title">Blog Post</div>

				{/* <!-- blog image --> */}
				<div className="blog-image">
					<Image
						src="images/blog/blog1.jpg"
						alt=""
					/>
				</div>

				{/* <!-- content --> */}
				<div className="row border-line-v">
					<div className="col col-m-12 col-t-12 col-d-12">
						<div className="post-box">
							{/* <!-- blog detail --> */}
							<h1 className="h-title">{matchingPost?.name}</h1>
							{!checkIsEmpty(matchingPost?.date) && (
								<div className="blog-detail">
									<span className="date">
										{distanceToNow(matchingPost?.date ?? "")}
									</span>
								</div>
							)}

							{/* <!-- blog image --> */}
							<div className="blog-image">
								<Image
									src={matchingPost?.cover?.downloadUrl}
									alt=""
								/>
							</div>

							{/* <!-- blog content --> */}
							<div className="blog-content">
								<div
									dangerouslySetInnerHTML={{
										__html: matchingPost?.content,
									}}
								/>
							</div>
						</div>
					</div>
				</div>

				<nav className="navigation post-navigation">
					<div className="nav-links">
						<div className="nav-previous">
							<Link href="/blog">
								<span className="post-nav-next post-nav-text">
									Back to Posts
								</span>
							</Link>
						</div>
					</div>
				</nav>
			</div>
		</div>
	);
}
