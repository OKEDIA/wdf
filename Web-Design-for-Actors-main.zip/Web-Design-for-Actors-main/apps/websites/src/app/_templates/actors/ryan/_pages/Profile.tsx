// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import {
	AppShellSection,
	Progress,
	Rating,
	useMantineTheme,
} from "@mantine/core";
import { IconPaint, IconPointFilled, IconSchool } from "@tabler/icons-react";

// Context & Helpers

// Other libraries or utilities

// Types
import { Rating as RatingType } from "@okedia/shared/types/profile";
import { PageProps } from "../page";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

function SkillsMap({ skills }: { skills: RatingType[] }) {
	return skills?.map((skill, index) => {
		return (
			<li key={`skill_${index}`}>
				<div className="name">{skill.title}</div>
				<Progress
					size="lg"
					value={skill.value * 10}
					mb="md"
				/>
			</li>
		);
	});
}

function TrainingMap({ training }: { training: RatingType[] }) {
	const theme = useMantineTheme();
	return training?.map((training, index) => {
		return (
			<li key={`training_${index}`}>
				<div
					className="name"
					style={{ margin: 0 }}
				>
					{training.title}
				</div>
				<Rating
					size="xs"
					color="primary"
					value={training.value}
					count={10}
					readOnly
					fullSymbol={
						<IconPointFilled
							color={theme.colors.primary?.[5]}
							size="1.8em"
						/>
					}
					emptySymbol={
						<IconPointFilled
							color={theme.colors.gray[3]}
							size="1.8em"
						/>
					}
				/>
			</li>
		);
	});
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
export default function Profile({ data, slug }: PageProps) {
	return (
		<AppShellSection>
			{/* <!-- About --> */}
			<div className="content profile">
				{/* <!-- title --> */}
				<div className="title">About {data?.intro?.stageName?.[0].value}</div>

				{/* <!-- content --> */}
				<div className="row">
					<div className="col col-d-12 col-t-12 col-m-12 border-line-v">
						<div className="info-list">
							<ul>
								<li>
									<strong>Playing Age:</strong>
									{data?.intro?.playingAge?.[0].min} -{" "}
									{data?.intro?.playingAge?.[0].max}
								</li>

								{/* {data.intro?.height?.[0]?.value?.length > 0 && (
									<li>
										<strong>Height:</strong>{" "}
										{data.intro.height?.[0]?.value ?? ""}
									</li>
								)} */}

								{data.intro?.availability?.[0]?.value && (
									<li>
										<strong>Availability:</strong>
										{data.intro.availability[0].value === "false"
											? "Not Available"
											: "Available"}
									</li>
								)}

								{data.intro?.location?.[0]?.city &&
									data.intro?.location?.[0]?.country && (
										<li>
											<strong>Current Location:</strong>
											{data.intro?.location?.[0]?.city},{" "}
											{data.intro?.location?.[0]?.country}
										</li>
									)}
							</ul>
						</div>
					</div>
					<div className="clear"></div>
				</div>
			</div>

			{/* <!-- content --> */}
			<div className="row">
				{data.skills?.skills?.length && data.skills.skills.length > 0 && (
					<div className="col col-d-6 col-t-6 col-m-12 border-line-v">
						<div className="skills-list">
							<div className="skill-title border-line-h">
								<div className="icon">
									<IconPaint size="1em" />
								</div>
								<div className="name">Relevant Skills</div>
							</div>

							<ul>
								<SkillsMap skills={data.skills.skills} />
							</ul>
						</div>
					</div>
				)}

				{/* <!-- training items --> */}
				{data.training?.training?.length &&
					data.training.training.length > 0 && (
						<div className="col col-d-6 col-t-6 col-m-12 border-line-v">
							<div className="skills-list dotted">
								<div className="skill-title border-line-h">
									<div className="icon">
										<IconSchool size="1em" />
									</div>
									<div className="name">Relevant Training</div>
								</div>

								<ul>
									<TrainingMap training={data.training.training} />
								</ul>
							</div>
						</div>
					)}

				<div className="clear"></div>
			</div>
		</AppShellSection>
	);
}
