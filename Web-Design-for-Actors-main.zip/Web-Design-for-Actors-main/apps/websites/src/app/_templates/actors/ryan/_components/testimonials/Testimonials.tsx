// React Imports
import { Fragment, useRef } from "react";

// Next.js Imports

// Firebase Imports

// Helpers
import { Carousel } from "@mantine/carousel";
import { Stack, Text, useMantineTheme } from "@mantine/core";
import Autoplay from "embla-carousel-autoplay";

// Other libraries or utilities
import { IconQuoteFilled } from "@tabler/icons-react";
import { Review } from "@okedia/shared/types/profile";
import classes from "./testimonials.module.css";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Testimonials({
	testimonials,
}: {
	testimonials?: Review[];
}) {
	const autoplay = useRef(Autoplay({ delay: 5000 }));
	const theme = useMantineTheme();
	return (
		<Fragment>
			<div
				className="content testimonials"
				style={{ marginTop: "-0px" }}
			>
				{/* <!-- content --> */}
				<div className="row testimonials-items">
					{/* <!-- client item --> */}
					<div className="col col-d-12 col-t-12 col-m-12 border-line-v">
						<Carousel
							withIndicators
							height={200}
							plugins={[autoplay.current]}
							onMouseEnter={autoplay.current.stop}
							onMouseLeave={autoplay.current.reset}
							classNames={classes}
							withControls={false}
						>
							{testimonials?.map((testimonial, index) => {
								return (
									<Carousel.Slide
										styles={{
											slide: {
												position: "relative", // Needed for absolute positioning inside
												display: "flex",
												justifyContent: "center",
												alignItems: "center",
												width: "100%",
												padding: "2rem",
											},
										}}
										key={index}
									>
										{/* Top Left Quote */}
										<IconQuoteFilled
											style={{
												position: "absolute",
												top: 0,
												left: 0,
												transform: "rotate(-180deg)",
												color: theme.colors.gray[2],
											}}
											size="2em"
										/>

										{/* Testimonial Content */}
										<Stack
											gap="0"
											align="center"
										>
											<Text
												fs="italic"
												mb="lg"
												fw="light"
												c="gray.6"
												size="sm"
											>
												{testimonial.content}
											</Text>
											<Text
												fw="bold"
												size="md"
											>
												{testimonial.reviewer}
											</Text>
											<Text
												size="sm"
												c="gray.6"
												mb="xl"
											>
												{testimonial?.company}
											</Text>
										</Stack>

										{/* Bottom Right Quote */}
										<IconQuoteFilled
											style={{
												position: "absolute",
												bottom: 0,
												right: 0,
												color: theme.colors.gray[2],
												// transform: "translate(50%, 50%)",
											}}
											size="2em"
										/>
									</Carousel.Slide>
								);
							})}
						</Carousel>
					</div>
				</div>
			</div>
			<div className="clear"></div>
		</Fragment>
	);
}
