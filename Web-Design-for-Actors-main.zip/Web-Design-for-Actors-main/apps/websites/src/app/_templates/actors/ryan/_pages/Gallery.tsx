// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { Image } from "@mantine/core";

// Context & Helpers

// Other libraries or utilities

// Types
import { GalleryFile } from "@okedia/shared/types/profile";
import { PageProps } from "../page";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

function GalleryItems({ galleryPosts }: { galleryPosts?: GalleryFile[] }) {
	return galleryPosts?.map((post, index) => {
		return (
			<div
				className="col col-d-6 col-t-6 col-m-12 grid-item video border-line-h"
				key={index}
			>
				<div className="box-item">
					<Image
						src={post.upload.downloadUrl}
						alt=""
					/>
				</div>
			</div>
		);
	});
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Gallery({ data, slug }: PageProps) {
	const galleryPosts = data?.gallery?.file;

	const galleryFilters = galleryPosts?.reduce((acc: string[], post) => {
		if (post?.category && !acc.includes(post.category)) {
			acc.push(post.category.charAt(0).toUpperCase() + post.category.slice(1));
		}
		return acc;
	}, [] as string[]);

	return (
		<div className="card-wrap">
			{/* <!--
						Works
					--> */}
			<div className="content works">
				{/* <!-- title --> */}
				<div className="title">Headshots & Reels</div>

				{/* <!-- filters --> */}
				<div className="filter-menu filter-button-group">
					<div className="f_btn active">
						<label>
							<input
								type="radio"
								name="fl_radio"
								value="grid-item"
							/>
							All
						</label>
					</div>
					{galleryFilters?.map((filter, index) => {
						return (
							<div
								className="f_btn"
								key={index}
							>
								<label>
									<input
										type="radio"
										name="fl_radio"
										value={filter?.toLowerCase()}
									/>
									{filter}
								</label>
							</div>
						);
					})}
				</div>

				{/* <!-- content --> */}
				<div className="row grid-items border-line-v">
					<GalleryItems galleryPosts={galleryPosts} />

					<div className="clear"></div>
				</div>
			</div>
		</div>
	);
}
