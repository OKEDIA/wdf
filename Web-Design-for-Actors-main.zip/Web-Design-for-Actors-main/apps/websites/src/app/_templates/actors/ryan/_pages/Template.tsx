"use client";

// React Imports
import { ReactNode, useContext, useEffect, useState } from "react";

// Next.js Imports
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import Script from "next/script";

// Lower Order Components

// UI Components & Icons
import {
	ActionIcon,
	AppShell,
	AppShellMain,
	Flex,
	Image,
	LoadingOverlay,
	Tooltip,
} from "@mantine/core";
import {
	IconAt,
	IconCloudDownload,
	IconEye,
	IconListLetters,
	IconMovie,
	IconNews,
	IconUserCircle,
} from "@tabler/icons-react";
import { Poppins } from "next/font/google";

// Context & Helpers
import { DataContext, DataContextValues } from "@/app/_context/Data";

// Other libraries or utilities
import { useScrollIntoView } from "@mantine/hooks";
import { socialNetworks } from "@okedia/shared/types/socialNetworks";

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

import { checkIsEmpty } from "@okedia/shared/helpers";
import { Profiles } from "@okedia/shared/types";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

const poppins = Poppins({
	weight: ["100", "200", "300", "400", "500", "600", "700", "800", "900"],
	subsets: ["latin"],
});

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// If loading a variable font, you don't need to specify the font weight

export default function Template({ children }: { children: ReactNode }) {
	const [isStylesLoaded, setIsStylesLoaded] = useState(false);

	useEffect(() => {
		// Dynamically import the CSS files
		// Doing it this way will ensure that the CSS is only loaded for this template
		Promise.all([
			import("../css/basic.css"),
			import("../css/blogs.css"),
			import("../css/gradient.css"),
			import("../css/layout.css"),
			import("../css/magnific-popup.css"),
			import("../css/new-skin/new-skin.css"),
			import("../css/owl.carousel.css"),
			import("../css/template-colors/light.css"),
		]).then(() => {
			setIsStylesLoaded(true);
		});
	}, []);

	const data = useContext(DataContext) as DataContextValues<
		Profiles.ActorProfile[]
	>;
	const websiteData = data.states.websiteData.profile[0];
	const [page, setPage] = useState("home");
	const queryParams = useSearchParams().toString();
	const { scrollIntoView, targetRef } = useScrollIntoView<HTMLDivElement>({
		offset: 60,
	});

	// const loadDarkTheme = async () => {
	// 	await import("../css/template-colors/dark.module.css");
	// };

	// useEffect(() => {
	// 	if (
	// 		window.matchMedia &&
	// 		window.matchMedia("(prefers-color-scheme: dark)").matches
	// 	) {
	// 		loadDarkTheme();
	// 	}
	// }, []);

	function Roles() {
		if (
			websiteData?.intro?.role?.length &&
			websiteData.intro.role.length <= 1
		) {
			return (
				<div className="subtitle">{websiteData.intro?.role?.[0]?.value}</div>
			);
		}
		return (
			<div className="subtitle subtitle-typed">
				<div className="typing-title">
					{/* eslint-disable-next-line  @typescript-eslint/no-explicit-any
					 */}
					{websiteData?.intro?.role?.map((role: any, index: number) => {
						return <p key={index}>{role.value}</p>;
					})}
				</div>
			</div>
		);
	}

	function Title() {
		return (
			<div className="title">{websiteData?.intro?.stageName?.[0].value}</div>
		);
	}

	return (
		<>
			<AppShell className={poppins.className}>
				<AppShellMain>
					<LoadingOverlay
						visible={!isStylesLoaded}
						overlayProps={{ opacity: 1, backgroundOpacity: 1 }}
					/>
					<div className="page new-skin">
						{/* <!-- background --> */}
						<div className="background gradient">
							<ul className="bg-bubbles">
								<li></li>
								<li></li>
								<li></li>
								<li></li>
								<li></li>
								<li></li>
								<li></li>
								<li></li>
								<li></li>
								<li></li>
							</ul>
						</div>

						{/* <!-- Container --> */}
						<div
							className="container opened"
							data-animation-in="fadeInLeft"
							data-animation-out="fadeOutLeft"
						>
							{/* <!-- Header --> */}
							<header className="header">
								{/* <!-- header profile --> */}
								<div className="profile">
									<Title />
									<Roles />
								</div>

								{/* <!-- menu --> */}
								<div className="top-menu">
									<ul>
										<li className={page === "home" ? "active" : ""}>
											<Link
												href={`/home?${queryParams}`}
												onClick={() => {
													setPage("home");
													scrollIntoView();
												}}
											>
												<IconUserCircle />

												<span className="link">About</span>
											</Link>
										</li>
										{!checkIsEmpty(websiteData?.gallery?.file) && (
											<li className={page === "reels" ? "active" : ""}>
												<Link
													href={`/gallery?${queryParams}`}
													onClick={() => {
														setPage("reels");
														scrollIntoView();
													}}
												>
													<IconMovie /> <span className="link">Reels</span>
												</Link>
											</li>
										)}
										{!checkIsEmpty(websiteData.blog?.post) && (
											<li className={page === "blog" ? "active" : ""}>
												<Link
													href={`/blog?${queryParams}`}
													onClick={() => {
														setPage("blog");
														scrollIntoView();
													}}
												>
													<IconNews /> <span className="link">Blog</span>
												</Link>
											</li>
										)}
										<li className={page === "profile" ? "active" : ""}>
											<Link
												href={`/profile?${queryParams}`}
												onClick={() => {
													setPage("profile");
													scrollIntoView();
												}}
											>
												<IconEye />

												<span className="link">Profile</span>
											</Link>
										</li>
										{!checkIsEmpty(
											websiteData.intro?.file?.[0].cv?.downloadUrl
										) && (
											<li>
												<Link
													href={
														websiteData.intro?.file?.[0]?.cv
															?.downloadUrl as string
													}
												>
													<IconListLetters />
													<span className="link">Resume</span>
												</Link>
											</li>
										)}
										<li className={page === "contact" ? "active" : ""}>
											<Link
												href={`/contact?${queryParams}`}
												onClick={() => {
													setPage("contact");
													scrollIntoView();
												}}
											>
												<IconAt /> <span className="link">Contact</span>
											</Link>
										</li>
									</ul>
								</div>
							</header>
							<div
								className="card-started"
								id="home-card"
							>
								{/* Profile */}
								<div className="profile no-photo">
									{/* <!-- profile image --> */}
									<div
										className="slide"
										style={{
											backgroundImage: `url(${websiteData?.intro?.file?.[0]?.headshot?.downloadUrl})`,
										}}
									></div>

									{/* <!-- profile titles --> */}
									<Title />
									<Roles />

									{/* <!-- profile socials --> */}
									<Flex
										className="social"
										gap="sm"
										mt="xl"
									>
										{websiteData.socials?.socialMedia?.map((social, index) => {
											const networkData = socialNetworks[social.network];

											if (!social.username || !networkData?.icon) {
												return;
											}

											return (
												<Tooltip
													label={networkData.full}
													key={index}
													color="primary.5"
													styles={{ tooltip: { color: "#fff" } }}
													onClick={() => {
														const url = `${networkData.base_uri}${social.username}`;
														window.open(url, "_blank");
													}}
												>
													<ActionIcon
														color={networkData?.color}
														name={networkData?.short}
														size="sm"
													>
														<Image
															src={networkData.icon.src}
															styles={{
																root: {
																	filter: "invert(100%)",
																},
															}}
															alt={`${networkData.full} Profile Link`}
														/>
													</ActionIcon>
												</Tooltip>
											);
										})}
									</Flex>

									{/* <!-- profile buttons --> */}
									<div className="lnks">
										{!checkIsEmpty(
											websiteData.intro?.file?.[0].cv?.downloadUrl
										) &&
											websiteData.intro?.file?.[0].cv?.downloadUrl && (
												<Link
													href={websiteData.intro.file[0].cv.downloadUrl}
													className="lnk"
													style={{
														display: "flex",
														alignItems: "center",
														justifyContent: "space-evenly",
														columnGap: "7px",
													}}
												>
													{" "}
													<IconCloudDownload size="1.5em" />
													<span className="text">Download CV</span>
												</Link>
											)}
										<Link
											href={`/contact?${queryParams}`}
											onClick={() => setPage("contact")}
											className="lnk"
											style={{
												display: "flex",
												alignItems: "center",
												justifyContent: "space-evenly",
												columnGap: "7px",
											}}
										>
											<span className="text">Contact Me</span>
											<span className="arrow"></span>
										</Link>
									</div>
								</div>
							</div>
							<div
								className="card-inner animated active"
								id={`${page}-card`}
							>
								<div
									className="card-wrap"
									ref={targetRef}
								>
									{children}
								</div>
							</div>
						</div>
					</div>
				</AppShellMain>
			</AppShell>
			{/* jQuery Scripts */}
			<Script src="./templates/actor/ryan/js/jquery.min.js" />
			<Script src="./templates/actor/ryan/js/jquery.validate.js" />
			<Script src="./templates/actor/ryan/js/jquery.magnific-popup.js" />
			<Script src="./templates/actor/ryan/js/imagesloaded.pkgd.js" />
			<Script src="./templates/actor/ryan/js/isotope.pkgd.js" />
			<Script src="./templates/actor/ryan/js/jquery.slimscroll.js" />
			<Script src="./templates/actor/ryan/js/owl.carousel.js" />
			<Script src="./templates/actor/ryan/js/typed.js" />
			<Script src="./templates/actor/ryan/js/scripts.js" />
		</>
	);
}
