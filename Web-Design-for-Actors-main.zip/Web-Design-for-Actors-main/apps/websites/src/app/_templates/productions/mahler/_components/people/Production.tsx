"use client";

// React Imports
import { Fragment, useCallback, useContext, useState } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { Box, Button, Grid, Title } from "@mantine/core";

// Context & Helpers
import { DataContext, DataContextValues } from "@/app/_context/Data";

// Other libraries or utilities
import { usePaginition } from "@okedia/shared/hooks/database";

// Types
import { Person, ProductionProfile } from "@okedia/shared/types/profile";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Production() {
	const context = useContext(DataContext) as DataContextValues<
		ProductionProfile[]
	>;
	const crew = context.states.websiteData.profile[0].people?.crew;
	const [isLoading, setLoading] = useState(true);

	const paginition = usePaginition<Person<"crew">>({
		initialCount: 8,
		initialData: crew,
		pageLimit: 8,
		onReady: useCallback(() => setLoading(false), []),
		onDataChange: useCallback(
			(data) =>
				context.setters.setWebsiteData((draft) => {
					if (
						draft.profile &&
						draft.profile[0] &&
						draft.profile[0].people &&
						draft.profile[0].people.crew !== undefined
					) {
						draft.profile[0].people.crew = data;
					}
				}),
			[context.setters]
		),
		endpointUrl: { crew: "/profiles/", role: "/roles/" },
	});

	const groupedCrew = [...(crew || [])]?.reduce((acc: any, crew: any) => {
		const department = crew.department;
		if (!acc[department]) {
			acc[department] = [];
		}
		acc[department].push(crew);
		return acc;
	}, {});

	return (
		<Grid
			columns={12}
			gutter="xl"
		>
			{Object.entries(groupedCrew || []).map(
				([department, crewList], index) => (
					<Fragment key={`department_${index}`}>
						<Grid.Col span={12} />
						{Array.isArray(crewList) &&
							crewList?.map((crew: any, crewIndex: number) => {
								const castName = crew.crew?.[0]?.intro?.crewName?.[0]?.value;
								if (!castName) return null;

								return (
									<Grid.Col
										span={{ base: 12, sm: 6, lg: 4, xl: 3 }}
										key={`cast_${crewIndex}`}
									>
										<Box
											style={{
												alignContent: "flex-start",
												justifyContent: "space-between",
												textAlign: "start",
												overflow: "clip",
												textWrap: "wrap",
											}}
											h="100%"
											py="xl"
											p="sm"
										>
											<Title
												order={4}
												c="primaryAccent"
												tt="uppercase"
												style={{ opacity: 0.7 }}
											>
												{crew.role?.[0]?.commonFormDataValues?.title}
											</Title>
											<Title
												order={2}
												c="primaryAccent"
												tt="uppercase"
											>
												{castName}
											</Title>
										</Box>
									</Grid.Col>
								);
							})}
					</Fragment>
				)
			)}
			<Grid.Col span={12}>
				{paginition.hasMore && (
					<Button
						fullWidth
						onClick={() => {
							setLoading(true);
							paginition.handlePaginition().finally(() => setLoading(false));
						}}
						variant="outline"
						loading={isLoading}
						size="xl"
						color="primaryAccent"
						tt="uppercase"
					>
						{isLoading ? "Loading Crew" : "See More Crew"}
					</Button>
				)}
			</Grid.Col>
		</Grid>
	);
}
