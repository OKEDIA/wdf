"use client";

// React Imports
import { Carousel, Embla } from "@mantine/carousel";
import { BackgroundImage, Box, useMatches } from "@mantine/core";
import { CarouselImages } from "@okedia/shared/types/profile";
import Autoplay from "embla-carousel-autoplay";
import { useCallback, useEffect, useRef, useState } from "react";
import classes from "./gallery.module.css";
// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Gallery({ images }: { images?: CarouselImages[] }) {
	const autoplay = useRef(Autoplay({ delay: 5000 }));
	const [embla, setEmbla] = useState<Embla | null>(null);

	const imageWidth = useMatches({
		base: "100%",
		sm: "75%",
		xl: "50%",
	});

	const [selectedIndex, setSelectedIndex] = useState(0);
	const onSelect = useCallback(() => {
		if (!embla) return;
		setSelectedIndex(embla.selectedScrollSnap());
	}, [embla]);

	useEffect(() => {
		if (!embla) return;
		embla.on("select", onSelect);
		onSelect(); // Initial call to set the correct active slide
	}, [embla, onSelect]);

	return (
		<Carousel
			mt="xl"
			classNames={classes}
			slideSize={imageWidth}
			height={540}
			slideGap="xl"
			controlsOffset="xl"
			controlSize={40}
			slidesToScroll={1}
			loop
			withIndicators
			plugins={[autoplay.current]}
			onMouseEnter={autoplay.current.stop}
			onMouseLeave={autoplay.current.reset}
			getEmblaApi={setEmbla}
		>
			{images?.map((media, index) => (
				<Carousel.Slide key={`slide-${index}`}>
					<Box
						h="100%"
						w="100%"
						style={{ display: "flex", alignItems: "center" }}
					>
						<BackgroundImage
							src={media.backgroundImage?.downloadUrl as string}
							h={index === selectedIndex ? "100%" : "50%"}
							w="100%"
							bgsz="cover"
							bgp="center center"
							style={{
								transition: "height 0.5s ease-in-out", // Smooth height transition
							}}
						/>
					</Box>
				</Carousel.Slide>
			))}
		</Carousel>
	);
}
