"use client";

// React Imports
import { useContext, useState } from "react";

// Next.js Imports
import { useRouter } from "next/navigation";

// Lower Order Components

// UI Components & Icons
import {
	Box,
	Button,
	Flex,
	Grid,
	Group,
	LoadingOverlay,
	Text,
	Title,
} from "@mantine/core";

// Context & Helpers
import { DataContext, DataContextValues } from "@/app/_context/Data";

// Other libraries or utilities
import { checkIsEmpty } from "@okedia/shared/helpers";
import { usePaginition } from "@okedia/shared/hooks/database";

// Types
import { ProductionProfile, VenueAndDates } from "@okedia/shared/types/profile";
import { StateSetter } from "@okedia/shared/types/stateTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

function FeaturedVenue({
	venue,
}: {
	venue?: VenueAndDates & {
		ticketAvailability?: keyof typeof ticketAvailabilityText;
	};
}) {
	const loading = !venue?.venue?.[0]?.venue?.[0]?.id;
	if (!venue?.venue?.[0]?.venue?.[0]?.id) return;

	const router = useRouter();
	const currentDate = new Date();
	const hasStarted = new Date(venue?.starts) <= currentDate;
	const hasEnded = new Date(venue?.ends) <= currentDate; // Ensure the event has not ended
	const venueName = venue.venue?.[0].venue?.[0].intro?.venueName?.[0].value;

	return (
		<Box
			p="xs"
			mt="xl"
			w="100%"
			pos="relative"
			id="venues"
			style={{
				borderBottom: "1px solid var(--mantine-color-secondaryAccent-3)",
				borderTop: "1px solid var(--mantine-color-secondaryAccent-3)",
			}}
			py="20px"
		>
			<LoadingOverlay visible={loading} />
			<Flex
				direction="column"
				maw="100%"
			>
				{hasStarted && !hasEnded && (
					<Text
						w="max-content"
						maw="100%"
						tt="uppercase"
					>
						Now Playing
					</Text>
				)}
				<Flex
					justify="space-between"
					align="center"
					ta="left"
				>
					{!checkIsEmpty(venueName) && (
						<Title
							w="max-content"
							maw="100%"
							order={2}
							tt="uppercase"
						>
							{venueName}
						</Title>
					)}
					{!hasEnded && !checkIsEmpty(venue.ticketUrl) && (
						<Button
							onClick={() => router.push(venue.ticketUrl)}
							tt="uppercase"
							variant="outline"
						>
							Book Now
						</Button>
					)}
				</Flex>
				<Group justify="space-between">
					{!checkIsEmpty(venue.ends) &&
						new Date(venue.starts) <= currentDate && (
							<Text
								fw="lighter"
								styles={{ root: { width: "fit-content" } }}
							>
								{!hasEnded ? "Until" : "Closed"}{" "}
								{new Date(venue.ends).toLocaleDateString()}
							</Text>
						)}

					{!checkIsEmpty(venue.starts) &&
						new Date(venue.starts) >= currentDate && (
							<Text
								fw="lighter"
								styles={{ root: { width: "fit-content" } }}
							>
								Starting {new Date(venue.starts).toLocaleDateString()} until{" "}
								{new Date(venue.ends).toLocaleDateString()}
							</Text>
						)}
					{!hasEnded && !checkIsEmpty(venue.ticketAvailability) && (
						<Text
							fw="lighter"
							styles={{ root: { width: "fit-content" } }}
						>
							Ticket Availability{" "}
							{
								ticketAvailabilityText[
									venue.ticketAvailability as keyof typeof ticketAvailabilityText
								]
							}
						</Text>
					)}
				</Group>
			</Flex>
		</Box>
	);
}

const ticketAvailabilityText = {
	sold: "Sold Out",
	low: "Low",
	medium: "Medium",
	high: "High",
};

function OtherVenue({ venue }: { venue?: VenueAndDates }) {
	const router = useRouter();
	if (!venue?.venue?.[0]?.venue?.[0]?.id) return;
	const venueName = venue.venue?.[0]?.venue?.[0]?.intro?.venueName?.[0]?.value;

	return (
		<Flex
			p="xs"
			py="20px"
			justify="space-between"
		>
			<Flex
				direction="column"
				w="100%"
			>
				<Flex
					justify="space-between"
					ta="left"
					align="center"
				>
					{!checkIsEmpty(venueName) && (
						<Title
							order={3}
							w="max-content"
							tt="uppercase"
						>
							{venueName}
						</Title>
					)}
					{!checkIsEmpty(venue.ticketUrl) && (
						<Button
							onClick={() => router.push(venue.ticketUrl)}
							tt="uppercase"
							variant="outline"
						>
							Book Now
						</Button>
					)}
				</Flex>
				<Group justify="space-between">
					{!checkIsEmpty(venue.starts) && !checkIsEmpty(venue.ends) && (
						<Text
							fw="lighter"
							styles={{ root: { width: "fit-content" } }}
						>
							{new Date(venue.starts).toLocaleDateString()} -{" "}
							{new Date(venue.ends).toLocaleDateString()}
						</Text>
					)}
					{!checkIsEmpty(venue.ticketAvailability) && (
						<Text
							fw="lighter"
							styles={{ root: { width: "fit-content" } }}
						>
							Ticket Availability{" "}
							{
								ticketAvailabilityText[
									venue.ticketAvailability as keyof typeof ticketAvailabilityText
								]
							}
						</Text>
					)}
				</Group>
			</Flex>
		</Flex>
	);
}
export function Venues({
	paginition,
	state,
}: {
	paginition: ReturnType<typeof usePaginition>;
	state: { isLoading: boolean; setLoading: StateSetter<boolean> };
}) {
	const context = useContext(DataContext) as DataContextValues<
		ProductionProfile[]
	>;
	const [isLoading, setLoading] = useState(true);

	const venues =
		context.states.websiteData.profile?.[0].calendar?.datesandvenue || [];

	const currentDate = new Date();

	const currentlyPlayingAt =
		venues?.filter(
			(venue) =>
				new Date(venue.starts) <= currentDate &&
				new Date(venue.ends) >= currentDate
		) || [];

	if (!currentlyPlayingAt?.length && venues?.length) {
		// Ensure there is always at least one venue
		currentlyPlayingAt.push(venues[0]);
	}

	return (
		<Grid
			columns={12}
			align="center"
			justify="center"
		>
			<Flex
				justify="center"
				direction="column"
				w="fit-content"
				miw="55%"
				p="xl"
			>
				{[...(venues || [])]
					?.sort((venue) => venue.starts)
					?.map((venue, index) => {
						if (venue === currentlyPlayingAt[0]) {
							// Add the first active venue to the featured venue section
							return (
								<FeaturedVenue
									key={index}
									venue={venue}
								/>
							);
						}

						// All other venues
						return (
							<OtherVenue
								key={index}
								venue={venue}
							/>
						);
					})}

				{paginition.hasMore && (
					<Button
						onClick={() => {
							setLoading(true);
							paginition.handlePaginition().finally(() => setLoading(false));
						}}
						variant="outline"
						loading={isLoading}
						mt="xl"
						size="xl"
					>
						{isLoading ? "Loading Venues" : "Load More Venues"}
					</Button>
				)}
			</Flex>
		</Grid>
	);
}
