"use client";

// React Imports
import { ReactNode, useContext } from "react";

// Next.js Imports
import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";

// Lower Order Components

// UI Components & Icons
import FooterText from "@/app/_shared/components/FooterText";
import {
	ActionIcon,
	AppShell,
	AppShellHeader,
	AppShellMain,
	Burger,
	Button,
	Flex,
	Grid,
	Group,
	Image,
	Stack,
	Text,
	useMantineTheme,
} from "@mantine/core";
import { IconCircleChevronRight } from "@tabler/icons-react";

// Context & Helpers
import { DataContext, DataContextValues } from "@/app/_context/Data";
import { useDisclosure } from "@mantine/hooks";
import { checkIsEmpty } from "@okedia/shared/helpers";

// Other libraries or utilities
import { useNavClick } from "@/app/_shared/utilities/useNavClick";

// Types
import { ProductionProfile } from "@okedia/shared/types/profile";
import { socialNetworks } from "@okedia/shared/types/socialNetworks";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Template({ children }: { children: ReactNode }) {
	const theme = useMantineTheme();
	const data = useContext(DataContext) as DataContextValues<
		ProductionProfile[]
	>;
	const profile = data.states.websiteData.profile[0];
	const slug = usePathname();
	const [opened, { toggle }] = useDisclosure();
	const router = useRouter();
	const searchParams = useSearchParams();
	const navigation = useNavClick();

	return (
		<AppShell
			header={{ height: 100 }}
			styles={{
				header: { boxShadow: "0px 1px 8px 0px #0000004f" },
			}}
		>
			<AppShellHeader
				bg="primary.5"
				withBorder={false}
			>
				<Grid
					columns={12}
					h="100%"
					styles={{
						inner: { height: "100%", margin: 0 },
						col: {
							display: "flex",
							alignItems: "center",
							justifyContent: "center",
						},
					}}
					grow
					overflow="hidden"
					align="center"
					justify="space-between"
				>
					<Grid.Col span={3}>
						<Image
							src={profile?.intro?.graphics?.[0].logo?.downloadUrl}
							alt={`${profile.intro?.name?.[0].value} Logo`}
							height={80}
						/>
					</Grid.Col>
					<Grid.Col
						span={6}
						visibleFrom="md"
					>
						<Group>
							<Button
								variant={slug === "/" ? "light" : "subtle"}
								color="primaryAccent"
								size="md"
								autoContrast
								onClick={() => navigation.push("/")}
								tt="uppercase"
							>
								Home
							</Button>
							{!checkIsEmpty(profile.people) && (
								<Button
									variant={slug.includes("/people") ? "light" : "subtle"}
									color="primaryAccent"
									size="md"
									autoContrast
									onClick={() => navigation.push("/people")}
									tt="uppercase"
								>
									Cast & Creative
								</Button>
							)}
							{!checkIsEmpty(profile.faq?.faq) && (
								<Button
									variant={slug.includes("/faqs") ? "light" : "subtle"}
									color="primaryAccent"
									size="md"
									autoContrast
									onClick={() => navigation.push("/faqs")}
									tt="uppercase"
								>
									FAQS
								</Button>
							)}
						</Group>
					</Grid.Col>
					<Grid.Col
						span={3}
						visibleFrom="lg"
					>
						<Flex columnGap="md">
							<Group>
								<Group gap="xs">
									{profile.contact?.socialMedia?.map((social, index) => {
										const networkData = socialNetworks[social.network];

										if (!social.username || !networkData?.icon) {
											return;
										}

										return (
											<ActionIcon
												key={`social-${index}`}
												color="primary"
												variant="filled"
												onClick={() => {
													const url = `${networkData.base_uri}${social.username}`;
													window.open(url, "_blank");
												}}
											>
												<Image
													src={networkData.icon.src}
													styles={{
														root: {
															filter: "invert(100%)",
														},
													}}
													alt={`${networkData.full} Profile Link`}
												/>
											</ActionIcon>
										);
									})}
								</Group>
							</Group>
							{!checkIsEmpty(profile.calendar?.datesandvenue) && (
								<Button
									onClick={() => {
										const element = document.getElementById("venues");
										if (element) {
											element.scrollIntoView({
												behavior: "smooth",
												block: "center",
											});
										}
									}}
									color="primaryAccent"
									variant="outline"
									size="md"
									tt="uppercase"
								>
									Book Now
								</Button>
							)}
						</Flex>
					</Grid.Col>
					<Grid.Col
						hiddenFrom="md"
						span="auto"
					>
						<Burger
							color="primaryAccent"
							opened={opened}
							onClick={toggle}
							aria-label="Toggle navigation"
						/>
					</Grid.Col>
				</Grid>

				{opened && (
					<Flex
						bg="primary"
						px="xl"
						pb="sm"
						direction="column"
						hiddenFrom="md"
					>
						<Stack gap="xs">
							<Button
								color="primaryAccent"
								variant={slug === "/" ? "light" : "outline"}
								onClick={() => navigation.push("/")}
								tt="uppercase"
							>
								Home
							</Button>
							{!checkIsEmpty(profile.people) && (
								<Button
									color="primaryAccent"
									variant={slug.includes("/people") ? "light" : "outline"}
									onClick={() => navigation.push("/people")}
									tt="uppercase"
								>
									Cast & Creative
								</Button>
							)}
							{!checkIsEmpty(profile.faq?.faq) && (
								<Button
									color="primaryAccent"
									variant={slug.includes("/faqs") ? "light" : "outline"}
									onClick={() => navigation.push("/faqs")}
									tt="uppercase"
								>
									FAQS
								</Button>
							)}
						</Stack>
					</Flex>
				)}
				{!checkIsEmpty(profile.intro?.teaser?.[0].text) && (
					<Flex
						bg="secondaryAccent.5"
						px="xl"
						py="sm"
						align="center"
						justify="center"
						styles={{ root: { boxShadow: "0px 1px 8px 0px #0000004f" } }}
						visibleFrom="sm"
					>
						{!checkIsEmpty(profile.intro?.teaser?.[0].url) &&
							!checkIsEmpty(profile.intro?.teaser?.[0].text) && (
								<Link href={profile.intro?.teaser?.[0].url}>
									<Flex align="center">
										<Text
											fw="bold"
											c="secondary"
											tt="uppercase"
										>
											{profile.intro?.teaser?.[0].text}
										</Text>
										<IconCircleChevronRight
											stroke={3}
											color={theme.colors.secondary[5]}
											size="1.3rem"
											width="2rem"
										/>
									</Flex>
								</Link>
							)}
						{checkIsEmpty(profile.intro?.teaser?.[0].url) &&
							!checkIsEmpty(profile.intro?.teaser?.[0].text) && (
								<>
									<Text
										fw="bold"
										c="secondary"
										tt="uppercase"
									>
										{profile.intro?.teaser?.[0].text}
									</Text>
								</>
							)}
					</Flex>
				)}
			</AppShellHeader>
			<AppShellMain>
				<Grid columns={12}>{children}</Grid>
				<Grid
					columns={12}
					h="100%"
					styles={{
						inner: { height: "100%", margin: 0 },
						col: {
							display: "flex",
							alignItems: "center",
							justifyContent: "center",
						},
					}}
					grow
					overflow="hidden"
					align="center"
					justify="space-between"
					p="100px"
					bg="secondary"
					ff="Raleway"
				>
					<FooterText brandName={profile.intro?.name?.[0].value} />
				</Grid>
			</AppShellMain>
		</AppShell>
	);
}
