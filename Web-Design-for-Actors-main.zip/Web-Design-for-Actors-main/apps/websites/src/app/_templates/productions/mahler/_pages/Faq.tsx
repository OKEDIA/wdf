// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { Accordion, Box, Grid, Tabs, Title } from "@mantine/core";
import Template from "./Template";

// Context & Helpers

// Other libraries or utilities

// Types
import { IconCircleArrowDownFilled } from "@tabler/icons-react";
import classes from "../_components/faq/faq.module.css";
import { PageProps } from "../page";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Faq({ data, slug }: PageProps) {
	const questions = data?.faq?.faq;
	const categories = Array.from(
		new Set(questions?.map((question) => question.type))
	);

	return (
		<Template>
			<Grid.Col
				bg="primary"
				p="80px"
				c="primaryAccent"
				pt="xl"
				mih="75dvh"
			>
				<Grid.Col pt="xl">
					<Title
						c="primaryAccent"
						tt="uppercase"
						ta="center"
						pt="xl"
					>
						Frequently Asked Questions
					</Title>
				</Grid.Col>
				<Tabs
					defaultValue={categories[0]}
					component={Grid}
					orientation="vertical"
					classNames={classes}
					styles={{ tab: { borderRight: "8px solid" } }}
					mt="xl"
				>
					<Grid.Col span={{ base: 12, md: 6, lg: 4 }}>
						<Tabs.List>
							{categories.map((type, index) => {
								return (
									<Tabs.Tab
										value={type}
										key={`cat-${index}`}
									>
										{type} Information
									</Tabs.Tab>
								);
							})}
						</Tabs.List>
					</Grid.Col>
					<Grid.Col span={{ base: 12, md: 6, lg: 8 }}>
						{categories.map((type, index) => {
							return (
								<Tabs.Panel
									value={type}
									key={`tab-${index}`}
								>
									<Accordion
										chevron={<IconCircleArrowDownFilled size="2em" />}
										classNames={classes}
									>
										{questions
											?.filter((question) => question.type === type)
											.map((question, index) => {
												return (
													<Accordion.Item
														key={`accordion-${type}-${index}`}
														value={question.question}
													>
														<Accordion.Control p="xl">
															<Title
																order={3}
																c="secondaryAccent"
																tt="uppercase"
															>
																{question.question}
															</Title>
														</Accordion.Control>
														<Accordion.Panel p="xl">
															<Box
																dangerouslySetInnerHTML={{
																	__html: question?.answer,
																}}
															/>
														</Accordion.Panel>
													</Accordion.Item>
												);
											})}
									</Accordion>
								</Tabs.Panel>
							);
						})}
					</Grid.Col>
				</Tabs>
			</Grid.Col>
		</Template>
	);
}
