"use client";

// React Imports
import { useContext, useState } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { Box, Grid, Image, Stack, Text } from "@mantine/core";

// Context & Helpers
import { DataContext } from "@/app/_context/Data";

// Other libraries or utilities

// Types
import { DataContextValues } from "@/app/_context/Data";
import { ProductionProfile } from "@okedia/shared/types/profile";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Nominations() {
	const context = useContext(DataContext) as DataContextValues<
		ProductionProfile[]
	>;
	const awards = context.states.websiteData.profile[0].intro?.awards;
	const [isLoading, setLoading] = useState(true);

	return (
		<Grid
			justify="space-evenly"
			my="100px"
		>
			{awards?.map((awards, index) => {
				if (awards.image?.downloadUrl) {
					return (
						<Grid.Col
							span={{ base: 6, xs: 3 }}
							key={`award-${index}`}
						>
							<Image
								src={awards.image?.downloadUrl}
								alt={`${awards.isAwarded ? "Award for" : "Nomination For"} ${
									awards.awardName
								}`}
								w="100%"
							/>
						</Grid.Col>
					);
				} else {
					const awardName = awards?.awardName?.[0]?.commonFormDataValues?.title;
					const awardOrganisation =
						awards?.organisation?.[0]?.commonFormDataValues?.title;

					if (!awardName && !awardOrganisation) {
						return null;
					}

					return (
						<Grid.Col
							span={{ base: 6, xs: 3 }}
							key={`award-${index}`}
						>
							<Box
								bd="5px solid primary"
								w="100%"
								h="0"
								pt="100%"
								style={{
									borderRadius: "50%",
									position: "relative",
									display: "flex",
									alignItems: "center",
									justifyContent: "center",
									textAlign: "center",
									textWrap: "balance",
									overflow: "hidden",
								}}
							>
								<div
									style={{
										position: "absolute",
										top: 0,
										left: 0,
										width: "100%",
										height: "100%",
										display: "flex",
										flexDirection: "column",
										alignItems: "center",
										justifyContent: "center",
									}}
								>
									<Stack>
										<Stack gap="0">
											<Text
												size="lg"
												tt="uppercase"
												c="secondaryAccent"
												fw="bold"
											>
												{awardOrganisation}{" "}
												<Text
													span
													inherit
													fw="initial"
												>
													{awards?.year}
												</Text>
											</Text>
											<Text
												size="xs"
												tt="uppercase"
												c="secondaryAccent"
												fw="bold"
											>
												{awards.isAwarded ? "Awarded" : "Nominated"} {awardName}
											</Text>
										</Stack>
									</Stack>
								</div>
							</Box>
						</Grid.Col>
					);
				}
			})}
		</Grid>
	);
}
