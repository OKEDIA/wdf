// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { Flex, GridCol, Tabs, Title } from "@mantine/core";
import Template from "./Template";

// Context & Helpers

// Other libraries or utilities

// Types
import { checkIsEmpty } from "@okedia/shared/helpers";
import Cast from "../_components/people/Cast";
import Creative from "../_components/people/Creative";
import Crew from "../_components/people/Production";
import classes from "../_components/tabs/tabs.module.css";
import { PageProps } from "../page";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function CastAndCreatives({ data, slug }: PageProps) {
	const people = data.people;

	return (
		<Template>
			<GridCol>
				<Flex
					mih="30vh"
					bg="primary"
					p="80px"
					justify="center"
					align="center"
					direction="column"
				>
					<Title
						c="primaryAccent"
						tt="uppercase"
					>
						Cast & Creative
					</Title>
					<Tabs
						classNames={classes}
						defaultValue={
							!checkIsEmpty(people?.cast)
								? "cast"
								: !checkIsEmpty(people?.creatives)
								? "creatives"
								: "crew"
						}
						c="primaryAccent"
						w="100%"
						variant="default"
						my="xl"
						mih="50vh"
					>
						<Tabs.List
							grow
							mb="md"
							justify="center"
						>
							{!checkIsEmpty(people?.cast) && (
								<Tabs.Tab value="cast">Cast</Tabs.Tab>
							)}
							{!checkIsEmpty(people?.creatives) && (
								<Tabs.Tab value="creatives">Creatives</Tabs.Tab>
							)}
							{!checkIsEmpty(people?.crew) && (
								<Tabs.Tab value="crew">Production</Tabs.Tab>
							)}
						</Tabs.List>

						{!checkIsEmpty(people?.cast) && (
							<Tabs.Panel
								value="cast"
								mih="100vh"
							>
								<Cast />
							</Tabs.Panel>
						)}

						{!checkIsEmpty(people?.creatives) && (
							<Tabs.Panel value="creatives">
								<Creative />
							</Tabs.Panel>
						)}

						{!checkIsEmpty(people?.crew) && (
							<Tabs.Panel value="crew">
								<Crew />
							</Tabs.Panel>
						)}
					</Tabs>
				</Flex>
			</GridCol>
		</Template>
	);
}
