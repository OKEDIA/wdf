"use client";

// React Imports
import { useCallback, useContext, useState } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { Box, Button, Grid, Title } from "@mantine/core";

// Context & Helpers
import { DataContext, DataContextValues } from "@/app/_context/Data";

// Other libraries or utilities
import { usePaginition } from "@okedia/shared/hooks/database";

// Types
import { Person, ProductionProfile } from "@okedia/shared/types/profile";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Cast() {
	const context = useContext(DataContext) as DataContextValues<
		ProductionProfile[]
	>;
	const cast = context.states.websiteData.profile[0].people?.cast;
	const [isLoading, setLoading] = useState(true);

	const paginition = usePaginition<Person<"performer">>({
		initialCount: 6,
		initialData: cast,
		pageLimit: 6,
		onReady: useCallback(() => setLoading(false), []),
		onDataChange: useCallback(
			(data) =>
				context.setters.setWebsiteData((draft) => {
					if (
						draft.profile &&
						draft.profile[0] &&
						draft.profile[0].people &&
						draft.profile[0].people.cast !== undefined
					) {
						draft.profile[0].people.cast = data;
					}
				}),
			[context.setters]
		),
		endpointUrl: "/profiles/",
	});

	return (
		<Grid
			columns={12}
			gutter="xl"
		>
			{cast?.map((cast, index) => {
				const castName = cast.performer?.[0]?.intro?.stageName?.[0]?.value;
				if (!castName) return;

				return (
					<Grid.Col
						span={{ base: 12, sm: 6, lg: 4 }}
						key={`cast_${index}`}
					>
						<Box
							h="400px"
							bg={
								cast.image?.downloadUrl
									? `url(${cast.image?.downloadUrl})`
									: "secondary"
							}
							bgsz="cover"
							bgp="center top"
							bgr="no-repeat"
							style={{
								alignContent: "end",
								justifyContent: "space-between",
								textAlign: "center",
								overflow: "clip",
								textWrap: "wrap",
								border: "15px solid var(--mantine-color-primaryAccent-5)",
							}}
							py="xl"
						>
							<Title
								order={2}
								c="primaryAccent"
								tt="uppercase"
								styles={{
									root: {
										textShadow: "2px 1px 1px var(--mantine-color-primary-5)",
									},
								}}
							>
								{castName}
							</Title>
							<Title
								order={4}
								c="primaryAccent"
								tt="uppercase"
								styles={{
									root: {
										textShadow: "2px 1px 1px var(--mantine-color-primary-5)",
									},
								}}
							>
								{cast.role}
							</Title>
						</Box>
					</Grid.Col>
				);
			})}
			<Grid.Col span={12}>
				{paginition.hasMore && (
					<Button
						fullWidth
						color="primaryAccent"
						onClick={() => {
							setLoading(true);
							paginition.handlePaginition().finally(() => setLoading(false));
						}}
						variant="outline"
						loading={isLoading}
						size="xl"
						tt="uppercase"
					>
						{isLoading ? "Loading Cast" : "See More Cast"}
					</Button>
				)}
			</Grid.Col>
		</Grid>
	);
}
