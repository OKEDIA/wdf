"use client";

// React Imports
import { useCallback, useContext, useState } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { Box, Button, Grid, Title } from "@mantine/core";

// Context & Helpers
import { DataContext, DataContextValues } from "@/app/_context/Data";

// Other libraries or utilities
import { usePaginition } from "@okedia/shared/hooks/database";

// Types
import { Person, ProductionProfile } from "@okedia/shared/types/profile";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Creative() {
	const context = useContext(DataContext) as DataContextValues<
		ProductionProfile[]
	>;

	const creatives = context.states.websiteData.profile[0].people?.creatives;
	const [isLoading, setLoading] = useState(true);

	const paginition = usePaginition<Person<"creative">>({
		initialCount: 12,
		initialData: creatives,
		pageLimit: 12,
		onFilter: useCallback((data: any) => {
			return data.filter((data: any) => {
				if (!(new Date(data?.ends) < new Date())) {
					return data;
				}
			});
		}, []),
		onReady: useCallback(() => setLoading(false), []),
		onDataChange: useCallback(
			(data) =>
				context.setters.setWebsiteData((draft) => {
					if (
						draft.profile &&
						draft.profile[0] &&
						draft.profile[0].people &&
						draft.profile[0].people.creatives !== undefined
					) {
						draft.profile[0].people.creatives = data;
					}
				}),
			[context.setters]
		),
		endpointUrl: { creative: "/profiles/", role: "/roles/" },
	});

	return (
		<Grid
			columns={12}
			gutter="xl"
		>
			{[...(creatives ?? [])]
				?.sort((creative) => creative.department)
				.map((creative, index) => {
					const creativeName =
						creative.creative?.[0]?.intro?.creativeName?.[0]?.value;
					if (!creativeName) return;

					return (
						<Grid.Col
							span={{ base: 12, sm: 6, lg: 4, xl: 3 }}
							key={`cast_${index}`}
						>
							<Box
								style={{
									alignContent: "flex-start",
									justifyContent: "space-between",
									textAlign: "start",
									overflow: "clip",
									textWrap: "wrap",
								}}
								h="100%"
								py="xl"
								p="sm"
							>
								<Title
									order={4}
									c="primaryAccent"
									tt="uppercase"
									styles={{
										root: {
											textShadow: "2px 1px 1px var(--mantine-color-primary-5)",
											opacity: 0.7,
										},
									}}
								>
									{creative.role?.[0]?.commonFormDataValues?.title}
								</Title>
								<Title
									order={2}
									c="primaryAccent"
									tt="uppercase"
									styles={{
										root: {
											textShadow: "2px 1px 1px var(--mantine-color-primary-5)",
										},
									}}
								>
									{creativeName}
								</Title>
							</Box>
						</Grid.Col>
					);
				})}
			<Grid.Col span={12}>
				{paginition.hasMore && (
					<Button
						fullWidth
						onClick={() => {
							setLoading(true);
							paginition.handlePaginition().finally(() => setLoading(false));
						}}
						variant="outline"
						loading={isLoading}
						size="xl"
						tt="uppercase"
						color="primaryAccent"
					>
						{isLoading ? "Loading Creatives" : "See More Creatives"}
					</Button>
				)}
			</Grid.Col>
		</Grid>
	);
}
