"use client";

// React Imports
import { Fragment, useCallback, useContext, useRef, useState } from "react";

// Next.js Imports

// Lower Order Components
import Sections, {
	AdditionalSection,
	SectionWrapperProps,
} from "../../../../_shared/components/sections/Sections";
import Testimonials from "../../../../_shared/components/testimonials/Testimonials";
import Gallery from "../_components/gallery/Gallery";
import Nominations from "../_components/nominations/Nominations";
import { Venues } from "../_components/venues/Venues";

// UI Components & Icons
import Slant from "@/app/_shared/components/slant/Slant";
import { Carousel } from "@mantine/carousel";
import "@mantine/carousel/styles.css";
import {
	Container,
	GridCol,
	Text,
	Title,
	useMantineTheme,
} from "@mantine/core";
import Template from "./Template";

// Context & Helpers

// Other libraries or utilities
import { checkIsEmpty } from "@okedia/shared/helpers";
import { usePaginition } from "@okedia/shared/hooks/database";
import Autoplay from "embla-carousel-autoplay";

// Types
import { DataContext, DataContextValues } from "@/app/_context/Data";
import {
	Award,
	ProductionProfile,
	VenueAndDates,
} from "@okedia/shared/types/profile";
import { PageProps } from "../page";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
export default function Homepage({ data, slug }: PageProps) {
	const additionalSections: AdditionalSection[] = [];
	const context = useContext(DataContext) as DataContextValues<
		ProductionProfile[]
	>;
	const [isLoading, setLoading] = useState(true);
	const theme = useMantineTheme();
	const venues =
		context.states.websiteData.profile?.[0].calendar?.datesandvenue || [];
	const awards = context.states.websiteData.profile[0].intro?.awards;

	const nominationPaginition = usePaginition<Award>({
		initialCount: 6,
		initialData: awards,
		pageLimit: 6,
		onReady: useCallback(() => setLoading(false), []),
		onDataChange: useCallback(
			(data) =>
				context.setters.setWebsiteData((draft) => {
					if (
						draft.profile &&
						draft.profile[0] &&
						draft.profile[0].intro &&
						draft.profile[0].intro.awards !== undefined
					) {
						draft.profile[0].intro.awards = data;
					}
				}),
			[context.setters]
		),

		endpointUrl: { organisation: "/profiles/", awardName: "/awards/" },
	});

	const venuesPaginition = usePaginition<VenueAndDates>({
		initialCount: 3,
		initialData: venues,
		pageLimit: 3,
		onFilter: useCallback((data: any) => {
			// Remove venues that are not upcoming (ends date is in the past)
			const upcomingVenues = data.filter(
				(data: any) => new Date(data?.ends) >= new Date()
			);

			// If there are no upcoming venues, return them all
			if (upcomingVenues.length > 0) {
				return upcomingVenues;
			}
			return data;
		}, []),
		// onReady: useCallback(() => setLoading(false), []),
		onDataChange: useCallback(
			(data) =>
				context.setters.setWebsiteData((draft) => {
					if (
						draft.profile &&
						draft.profile[0] &&
						draft.profile[0].calendar &&
						draft.profile[0].calendar.datesandvenue !== undefined
					) {
						draft.profile[0].calendar.datesandvenue = data;
					}
				}),
			[context.setters]
		),
		endpointUrl: "/profiles/",
	});

	if (!checkIsEmpty(data.testimonials?.testimonials)) {
		additionalSections.push({
			options: { withTitle: false },
			children: <Testimonials testimonials={data.testimonials?.testimonials} />,
		});
	}

	if (!checkIsEmpty(data.calendar?.datesandvenue)) {
		additionalSections.push({
			title: "Tickets & Pricing",
			children: (
				<Fragment>
					<Venues
						paginition={venuesPaginition}
						state={{ isLoading, setLoading }}
					/>
					<Container mt="100px">
						{!checkIsEmpty(
							data.attributes?.attributes?.[0].triggerWarnings
						) && (
							<>
								<Title
									mt="xl"
									order={3}
									tt="uppercase"
								>
									Health and Safety Warnings
								</Title>
								<Text size="sm">
									{data.attributes?.attributes?.[0].triggerWarnings}
								</Text>
							</>
						)}

						{!checkIsEmpty(data.attributes?.attributes?.[0].tickettcs) && (
							<>
								<Title
									mt="xl"
									order={3}
									tt="uppercase"
								>
									Ticket Information
								</Title>
								<Text size="sm">
									{data.attributes?.attributes?.[0].tickettcs}
								</Text>
							</>
						)}
					</Container>
				</Fragment>
			),
		});
	}

	const notFeaturedImages = data?.featuredImages?.carousel?.filter(
		(media) => media?.isFeatured !== true
	);

	if (
		notFeaturedImages &&
		!checkIsEmpty(notFeaturedImages) &&
		notFeaturedImages?.length >= 3
	) {
		additionalSections.push({
			title: "Production Shots",
			children: (
				<>
					<Gallery images={notFeaturedImages} />
				</>
			),
		});
	}

	const autoplay = useRef(Autoplay({ delay: 5000 }));

	const featuredImages = data?.featuredImages?.carousel?.filter(
		(media) => media.isFeatured
	) || [data.featuredImages?.carousel?.[0]];

	additionalSections.push({
		index: 0,
		options: { withTitle: false },
		children: (
			<Slant
				bgsz="cover"
				bgr="no-repeat"
				bgp="center center"
				align="center"
				mih="95dvh"
				options={{ withPadding: false }}
			>
				<Carousel
					withIndicators={false}
					withControls={false}
					draggable={featuredImages && featuredImages?.length > 1}
					height="95dvh"
					plugins={[autoplay.current]}
					onMouseEnter={autoplay.current.stop}
					onMouseLeave={autoplay.current.reset}
				>
					{featuredImages?.map((media, index) => (
						<Carousel.Slide
							key={`slide-${index}`}
							styles={{
								slide: {
									backgroundImage: `url(${media?.backgroundImage?.downloadUrl})`,
									backgroundSize: "cover",
									backgroundRepeat: "no-repeat",
									backgroundPosition: "center center",
								},
							}}
						/>
					))}
				</Carousel>
			</Slant>
		),
	});

	return (
		<Template>
			<GridCol span={12}>
				<Sections
					data={data.sections?.section}
					additionalSections={additionalSections}
					Wrapper={({
						children,
						colors,
						index,
						section,
					}: SectionWrapperProps) => {
						if (index === 0) {
							return <>{children}</>;
						}

						return (
							<Slant
								bg={
									section?.image?.downloadUrl
										? `url('${section.image.downloadUrl}') rgba(0, 0, 0, 0.5)`
										: colors.mainColor
								}
								bgr="no-repeat"
								bgsz="cover"
								align="center"
								key={`section-${index}`}
								c={colors.accentColor}
								style={{
									fill: theme.colors[colors.accentColor][5],
									backgroundBlendMode: "multiply",
								}}
							>
								{section.type !== "custom" && (
									<Container
										my="xl"
										c={colors.accentColor}
									>
										{children}
									</Container>
								)}

								{section.type === "custom" && children}

								{index === 1 && !checkIsEmpty(data.intro?.awards) && (
									<Container>
										<Nominations />
									</Container>
								)}
							</Slant>
						);
					}}
				/>
			</GridCol>
		</Template>
	);
}
