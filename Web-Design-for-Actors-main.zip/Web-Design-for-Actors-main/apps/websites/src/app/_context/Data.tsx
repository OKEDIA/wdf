"use client";

// React Imports
import { createContext, useEffect } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import * as CookieConsent from "vanilla-cookieconsent";

// Context & Helpers

// Other libraries or utilities
import { Updater, useImmer } from "use-immer";

// Types
import { useDatabase } from "@okedia/shared/hooks";
import { MongoDocumentResponse } from "@okedia/shared/types/mongoTypes";
import { Website } from "@okedia/shared/types/websiteTypes";
import { cookieConfig } from "./cookieConfig";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

const DataContext = createContext({});

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

type DataProviderProps = {
	children: React.ReactNode;
	initialWebsiteData: MongoDocumentResponse<Website<unknown>>;
};

export type DataContextValues<T> = {
	states: { websiteData: MongoDocumentResponse<Website<T>> };
	setters: { setWebsiteData: Updater<MongoDocumentResponse<Website<T>>> };
};

function DataProvider({ children, initialWebsiteData }: DataProviderProps) {
	const [websiteData, setWebsiteData] = useImmer(initialWebsiteData);
	const db = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);

	useEffect(() => {
		// Remove noCache query param from the URL if it exists
		// This is done so the user doesn't share the URL with the noCache param
		// The noCache param will have already been registered and dealt with in middleware
		if (typeof window !== "undefined") {
			const url = new URL(window.location.href);
			if (url.searchParams.has("noCache")) {
				url.searchParams.delete("noCache");
				window.history.replaceState({}, document.title, url.toString());
			}
		}

		// Initialize cookie consent
		CookieConsent.run({
			onFirstConsent: ({ cookie }) => {
				db.post("/cookie-acceptance", cookie);
			},

			onChange: ({ cookie, changedCategories, changedServices }) => {
				db.patch("/cookie-acceptance", {
					...cookie,
					categories: changedCategories,
					services: changedServices,
				});
			},

			...(cookieConfig as CookieConsent.CookieConsentConfig),
		});
	}, []);

	useEffect(() => {
		setWebsiteData(initialWebsiteData);
	}, [initialWebsiteData]);

	const setters = { setWebsiteData };
	const states = { websiteData };

	const contextValues: DataContextValues<unknown> = {
		setters,
		states,
	};

	return (
		<DataContext.Provider value={contextValues}>
			{children}
		</DataContext.Provider>
	);
}

export { DataContext, DataProvider };
