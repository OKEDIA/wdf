export const cookieConfig = {
	// https://cookieconsent.orestbida.com/reference/configuration-reference.html#guioptions
	guiOptions: {
		consentModal: {
			layout: "box",
			position: "bottom left",
			equalWeightButtons: true,
			flipButtons: true,
		},
		preferencesModal: {
			layout: "bar",
			position: "right",
			equalWeightButtons: true,
			flipButtons: true,
		},
	},
	lazyHtmlGeneration: true,
	autoClearCookies: true,
	autoShow: true,
	disablePageInteraction: true,
	hideFromBots: true,
	revision: 0,
	cookie: {
		name: "cookie-consent",
		expiresAfterDays: (acceptType: string) => {
			return acceptType === "all" ? 365.25 : 30;
		},
	},
	categories: {
		necessary: {
			enabled: true, // this category is enabled by default
			readOnly: true, // this category cannot be disabled
		},
		functionality: {
			enabled: true,
			autoClear: {
				cookies: [
					{
						name: /^_ga/, // regex: match all cookies starting with '_ga'
					},
					{
						name: "_gid", // string: exact cookie name
					},
					{
						name: /^YSC/, // regex: match all cookies starting with 'YSC' (YouTube)
					},
					{
						name: "VISITOR_INFO1_LIVE", // YouTube
					},
					{
						name: "PREF", // YouTube
					},
					{
						name: "vuid", // Vimeo
					},
					{
						name: "player", // Vimeo
					},
					{
						name: "NID", // Google Maps
					},
					{
						name: "OGPC", // Google Maps
					},
					{
						name: "1P_JAR", // Google Maps
					},
					{
						name: "CONSENT", // Google Maps
					},
					{
						name: "SSID", // Google Maps
					},
					{
						name: "APISID", // Google Maps
					},
					{
						name: "SAPISID", // Google Maps
					},
					{
						name: "SID", // Google Maps
					},
					{
						name: "HSID", // Google Maps
					},
					{
						name: "SIDCC", // Google Maps
					},
					{
						name: "SEARCH_SAMESITE", // Google Maps
					},
					{
						name: "DV", // Google Maps
					},
				],
			},
		},
		analytics: {
			autoClear: {
				cookies: [
					{
						name: /^_ga/, // regex: match all cookies starting with '_ga'
					},
					{
						name: "_gid", // string: exact cookie name
					},
				],
			},
		},
		marketing: {
			autoClear: {
				cookies: [
					{
						name: "_fbp", // Meta (Facebook)
					},
					{
						name: "fr", // Meta (Facebook)
					},
					{
						name: "datr", // Meta (Facebook)
					},
					{
						name: "sb", // Meta (Facebook)
					},
					{
						name: "locale", // Meta (Facebook)
					},
					{
						name: "xs", // Meta (Facebook)
					},
					{
						name: "c_user", // Meta (Facebook)
					},
					{
						name: "tt_webid", // TikTok
					},
					{
						name: "tt_webid_v2", // TikTok
					},
					{
						name: "csrf_session_id", // TikTok
					},
					{
						name: "s_v_web_id", // TikTok
					},
					{
						name: "twid", // X (Twitter)
					},
					{
						name: "auth_token", // X (Twitter)
					},
					{
						name: "guest_id", // X (Twitter)
					},
					{
						name: "personalization_id", // X (Twitter)
					},
				],
			},
		},
	},

	language: {
		default: "en",
		translations: {
			en: {
				consentModal: {
					title: "Would you like a cookie? 🍪",
					description:
						"Choose which cookies you want to allow. Essential cookies are always enabled as they are necessary for the website to function properly.",
					acceptAllBtn: "Accept all",
					acceptNecessaryBtn: "Reject all",
					showPreferencesBtn: "Manage preferences",
					// footer: `
					//     <a href="/terms" target="_blank">Terms & Conditions</a>
					//     <a href="/privacy" target="_blank">Privacy Policy</a>
					// `,
					revisionMessage:
						"Hi, we've made some changes to our cookie policy since the last time you visited!",
				},
				preferencesModal: {
					title: "Manage cookie preferences",
					acceptAllBtn: "Accept all",
					acceptNecessaryBtn: "Reject all",
					savePreferencesBtn: "Accept current selection",
					closeIconLabel: "Close modal",
					serviceCounterLabel: "Service|Services",
					sections: [
						{
							title: "Your Privacy Choices",
							description: `In this panel you can express some preferences related to the processing of your personal information. You may review and change expressed choices at any time by resurfacing this panel via the provided link. To deny your consent to the specific processing activities described below, switch the toggles to off or use the “Reject all” button and confirm you want to save your choices.`,
						},
						{
							title: "Strictly Necessary",
							description:
								"These cookies are essential for the proper functioning of the website and cannot be disabled.",

							linkedCategory: "necessary",
						},
						{
							title: "Basic Functionality",
							description:
								"Thee cookies enable core functionality with 3rd party services such as Youtube, Google Maps, and other social media platforms.",
							cookieTable: {
								caption: "Cookie table",
								headers: {
									name: "Cookie",
									desc: "Description",
									exp: "Expiry",
								},
								body: [
									{
										name: "YSC",
										desc: "YouTube cookie used to track views of embedded videos.",
										exp: "Session",
									},
									{
										name: "VISITOR_INFO1_LIVE",
										desc: "YouTube cookie used to estimate bandwidth.",
										exp: "6 months",
									},
									{
										name: "PREF",
										desc: "YouTube cookie that stores user preferences.",
										exp: "8 months",
									},
									{
										name: "vuid",
										desc: "Vimeo cookie used to track views of embedded videos.",
										exp: "2 years",
									},
									{
										name: "player",
										desc: "Vimeo cookie that stores user preferences.",
										exp: "1 year",
									},
									{
										name: "NID",
										desc: "Google Maps cookie used to track user preferences.",
										exp: "6 months",
									},
									{
										name: "OGPC",
										desc: "Google Maps cookie used to track user preferences.",
										exp: "6 months",
									},
									{
										name: "1P_JAR",
										desc: "Google Maps cookie used to track user preferences.",
										exp: "1 month",
									},
									{
										name: "CONSENT",
										desc: "Google Maps cookie used to track user preferences.",
										exp: "20 years",
									},
									{
										name: "SSID",
										desc: "Google Maps cookie used to track user preferences.",
										exp: "2 years",
									},
									{
										name: "APISID",
										desc: "Google Maps cookie used to track user preferences.",
										exp: "2 years",
									},
									{
										name: "SAPISID",
										desc: "Google Maps cookie used to track user preferences.",
										exp: "2 years",
									},
									{
										name: "SID",
										desc: "Google Maps cookie used to track user preferences.",
										exp: "2 years",
									},
									{
										name: "HSID",
										desc: "Google Maps cookie used to track user preferences.",
										exp: "2 years",
									},
									{
										name: "SIDCC",
										desc: "Google Maps cookie used to track user preferences.",
										exp: "1 year",
									},
									{
										name: "SEARCH_SAMESITE",
										desc: "Google Maps cookie used to track user preferences.",
										exp: "6 months",
									},
									{
										name: "DV",
										desc: "Google Maps cookie used to track user preferences.",
										exp: "10 minutes",
									},
								],
							},
							linkedCategory: "functionality",
						},
						{
							title: "Performance and Analytics",
							description:
								"These cookies collect information about how you use our website. All of the data is anonymized and cannot be used to identify you.",
							linkedCategory: "analytics",
							cookieTable: {
								caption: "Cookie table",
								headers: {
									name: "Cookie",
									desc: "Description",
									exp: "Expiry",
								},
								body: [
									{
										name: "_ga",
										desc: "Used to distinguish users.",
										exp: "2 years",
									},
									{
										name: "_gid",
										desc: "To store and count pageviews.",
										exp: "24 hours",
									},
									{
										name: "_gtag.js",
										desc: "Used to identify unique users and sessions.",
										exp: "1 minute",
									},
									{
										name: "_analytics.js",
										desc: "Used for tracking user interactions on the website.",
										exp: "2 years",
									},
									{
										name: "_utma",
										desc: "Stores the number of visits made from the users’ device, the time of the first visit, the previous visit, and the current visit.",
										exp: "2 years",
									},
									{
										name: "_utmb",
										desc: "Stores information on how long the user stays on a website which uses Google analytics: when a visit started and when ended. This cookie does not contain any personal information other than the IP address of your device.",
										exp: "30 minutes",
									},
									{
										name: "_gat",
										desc: "Used to limit the number of requests and expires after ten minutes.",
										exp: "1 minute",
									},
									{
										name: "_gcl",
										desc: "Used to store and track conversions.",
										exp: "90 days",
									},
								],
							},
						},
						{
							title: "Targeting and Advertising",
							description:
								"These cookies are used to make advertising messages more relevant to you and your interests. The intention is to display ads that are relevant and engaging for the individual user and thereby more valuable for publishers and third party advertisers.",
							linkedCategory: "marketing",
							cookieTable: {
								caption: "Cookie table",
								headers: {
									name: "Cookie",
									desc: "Description",
									exp: "Expiry",
								},
								body: [
									{
										name: "_fbp",
										desc: "Used by Facebook to deliver a series of advertisement products such as real time bidding from third party advertisers.",
										exp: "3 months",
									},
									{
										name: "fr",
										desc: "Used by Facebook to deliver, measure, and improve the relevancy of ads.",
										exp: "3 months",
									},
									{
										name: "datr",
										desc: "Identifies the web browser being used to connect to Facebook independent of the logged in user.",
										exp: "2 years",
									},
									{
										name: "sb",
										desc: "Used by Facebook to improve friend suggestions.",
										exp: "2 years",
									},
									{
										name: "locale",
										desc: "Contains the display locale of the last logged in user on this browser.",
										exp: "1 week",
									},
									{
										name: "xs",
										desc: "Contains multiple pieces of information, separated by a colon, including the session number and the secret.",
										exp: "1 year",
									},
									{
										name: "c_user",
										desc: "Contains the user ID of the currently logged in user.",
										exp: "1 year",
									},
									{
										name: "tt_webid",
										desc: "Used by TikTok to identify users.",
										exp: "1 year",
									},
									{
										name: "tt_webid_v2",
										desc: "Used by TikTok to identify users.",
										exp: "1 year",
									},
									{
										name: "csrf_session_id",
										desc: "Used by TikTok for CSRF protection.",
										exp: "Session",
									},
									{
										name: "s_v_web_id",
										desc: "Used by TikTok to identify users.",
										exp: "1 year",
									},
									{
										name: "twid",
										desc: "Used by Twitter to identify users.",
										exp: "1 year",
									},
									{
										name: "auth_token",
										desc: "Used by Twitter for authentication.",
										exp: "1 year",
									},
									{
										name: "guest_id",
										desc: "Used by Twitter to identify users.",
										exp: "2 years",
									},
									{
										name: "personalization_id",
										desc: "Used by Twitter to store user preferences.",
										exp: "2 years",
									},
								],
							},
						},
						{
							title: "More information",
							description:
								'For any queries in relation to my policy on cookies and your choices, please <a href="#contact-page">contact us</a>',
						},
					],
				},
			},
		},
	},
};
