"use client";

// React Imports

import { Alert, Button, Flex, Group, Stack, Title } from "@mantine/core";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { ColorSchemeScript, MantineProvider } from "@mantine/core";
import "@mantine/core/styles.css";
import { IconAlertTriangleFilled } from "@tabler/icons-react";

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

function LogoIcon() {
	return (
		<Flex
			align="center"
			justify="center"
			gap={0}
			p="xl"
			bottom="30px"
			left="30px"
			pos="absolute"
			style={{
				scale: "200%",
			}}
			opacity={0.5}
		>
			<Flex>
				<Stack
					gap={0}
					mr="xs"
					h="100%"
					styles={{
						root: {
							paddingRight: "5px",
							borderRight: `4px solid #fff`,
						},
					}}
				>
					<Title
						c="#fff"
						px="0"
						order={6}
						ta="right"
						fw="bold"
						styles={{
							root: {
								lineHeight: "100%",
							},
						}}
					>
						WEB
					</Title>

					<Title
						c="#fff"
						px="0"
						order={6}
						ta="right"
						fw="bold"
						styles={{
							root: {
								lineHeight: "100%",
							},
						}}
					>
						DESIGN
					</Title>

					<Title
						c="#fff"
						px="0"
						order={6}
						ta="right"
						fw="bold"
						styles={{
							root: {
								lineHeight: "100%",
							},
						}}
					>
						FOR
					</Title>
				</Stack>
			</Flex>
		</Flex>
	);
}

export default function GlobalError({
	error,
	reset,
}: {
	error: Error & { digest?: string };
	reset: () => void;
}) {
	return (
		<html lang="en">
			<head>
				<link
					rel="preconnect"
					href="https://fonts.googleapis.com"
				/>
				<link
					rel="preconnect"
					href="https://fonts.gstatic.com"
				/>
				<link
					href="https://fonts.googleapis.com/css2?family=Raleway:wght@100..900&display=swap"
					rel="stylesheet"
				/>
				<ColorSchemeScript />
			</head>
			<body>
				<MantineProvider>
					<Flex
						styles={{
							root: {
								backgroundColor: "#d1aa5f",
							},
						}}
						mih="100vh"
						miw="100vw"
						justify="center"
						direction="column"
					>
						{" "}
						<LogoIcon />
						<Flex
							px="10vw"
							py="10vh"
							direction="column"
							justify="middle"
							align="center"
							gap="lg"
						>
							<IconAlertTriangleFilled
								size="10rem"
								color="black"
							/>
							<Alert
								variant="transparent"
								color="white"
							>
								<Title
									style={{ textAlign: "center" }}
									c="white"
								>
									An unexpected error has occured.
								</Title>
								<Title
									order={4}
									style={{ textAlign: "center" }}
									fw="lighter"
									c="white"
								>
									Please try again later.
								</Title>
							</Alert>

							<Group
								mt="xl"
								style={{ fontWeight: "100" }}
							>
								<Button
									onClick={reset}
									color="dark"
								>
									Retry
								</Button>
							</Group>
						</Flex>
					</Flex>
				</MantineProvider>
			</body>
		</html>
	);
}
