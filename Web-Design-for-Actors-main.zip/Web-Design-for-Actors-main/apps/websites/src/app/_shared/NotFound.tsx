// React Imports

import { Flex, Stack, Title } from "@mantine/core";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { ColorSchemeScript, MantineProvider } from "@mantine/core";
import "@mantine/core/styles.css";

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
function LogoIcon() {
	return (
		<Flex
			align="center"
			justify="center"
			gap={0}
			p="xl"
			bottom="30px"
			left="30px"
			pos="absolute"
			style={{
				scale: "200%",
			}}
			opacity={0.5}
		>
			<Flex>
				<Stack
					gap={0}
					mr="xs"
					h="100%"
					styles={{
						root: {
							paddingRight: "5px",
							borderRight: `4px solid #fff`,
						},
					}}
				>
					<Title
						c="#fff"
						px="0"
						order={6}
						ta="right"
						fw="bold"
						styles={{
							root: {
								lineHeight: "100%",
							},
						}}
					>
						WEB
					</Title>

					<Title
						c="#fff"
						px="0"
						order={6}
						ta="right"
						fw="bold"
						styles={{
							root: {
								lineHeight: "100%",
							},
						}}
					>
						DESIGN
					</Title>

					<Title
						c="#fff"
						px="0"
						order={6}
						ta="right"
						fw="bold"
						styles={{
							root: {
								lineHeight: "100%",
							},
						}}
					>
						FOR
					</Title>
				</Stack>
			</Flex>
		</Flex>
	);
}
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
export default function NotFound({
	currentDomain,
}: {
	currentDomain?: string;
}) {
	return (
		<html lang="en">
			<head>
				<link
					rel="preconnect"
					href="https://fonts.googleapis.com"
				/>
				<link
					rel="preconnect"
					href="https://fonts.gstatic.com"
				/>
				<link
					href="https://fonts.googleapis.com/css2?family=Raleway:wght@100..900&display=swap"
					rel="stylesheet"
				/>
				<ColorSchemeScript />
			</head>
			<body>
				<MantineProvider>
					<Flex
						styles={{
							root: {
								backgroundColor: "#d1aa5f",
							},
						}}
						mih="100vh"
						miw="100vw"
						justify="center"
						direction="column"
					>
						{" "}
						<LogoIcon />
						<Stack
							justify="center"
							align="center"
							gap="0"
							mt="xl"
						>
							<Title c="#fff">Unable to find this website.</Title>
							<Title
								order={3}
								fw="lighter"
								c="#fff"
							>
								This website does not exist.
							</Title>
						</Stack>
					</Flex>
				</MantineProvider>
			</body>
		</html>
	);
}
