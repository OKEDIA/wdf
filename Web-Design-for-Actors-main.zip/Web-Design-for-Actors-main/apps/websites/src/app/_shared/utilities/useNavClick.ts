"use client";

// React Imports

// Next.js Imports
import { useRouter, useSearchParams } from "next/navigation";

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export function useNavClick() {
	const router = useRouter();
	const searchParams = useSearchParams();

	function push(slug: string) {
		const currentSearchParams = searchParams.toString();
		let queryString = "";

		if (currentSearchParams && Object.keys(currentSearchParams).length > 0) {
			queryString = "?" + new URLSearchParams(currentSearchParams).toString();
		}

		return router.push(slug + queryString);
	}

	return { push };
}
