"use client";

// React Imports
import { useRef } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { Carousel, CarouselProps } from "@mantine/carousel";
import {
	Image,
	Rating,
	Stack,
	Text,
	useMantineTheme,
	useMatches,
} from "@mantine/core";
import { IconArrowLeft, IconArrowRight } from "@tabler/icons-react";
import { Review } from "@okedia/shared/types/profile";

// Context & Helpers

// Other libraries or utilities
import Autoplay from "embla-carousel-autoplay";
import { checkIsEmpty } from "@okedia/shared/helpers";
import classes from "./testimonials.module.css";

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
export default function Testimonials({
	testimonials,
	carouselProps,
	slideProps,
	contentProps,
}: {
	testimonials?: Review[];
	carouselProps?: Partial<CarouselProps>;
	slideProps?: Partial<React.ComponentProps<typeof Carousel.Slide>>;
	contentProps?: Partial<React.ComponentProps<typeof Stack>>;
}) {
	const autoplay = useRef(Autoplay({ delay: 5000 }));
	const theme = useMantineTheme();
	const testimonialWidth = useMatches({
		base: "100%",
		sm: (testimonials?.length ?? 0) > 2 ? "50%" : "100%",
		md: testimonials?.length && testimonials.length > 5 ? "20.333%" : "100%",
	});

	function Slide({ review }: { review: Review }) {
		if (checkIsEmpty(review.content)) {
			return;
		}

		return (
			<Carousel.Slide
				styles={{
					slide: {
						position: "relative",
						display: "flex",
						justifyContent: "center",
						alignItems: "center",
						width: "100%",
						padding: "2rem",
					},
				}}
				{...slideProps}
			>
				<Stack
					h="fit-content"
					gap="0"
					align="center"
					{...contentProps}
				>
					{!checkIsEmpty(review?.logo?.downloadUrl) && (
						<Image
							src={review.logo?.downloadUrl}
							alt={`Image for ${review.company} Review`}
						/>
					)}
					{!checkIsEmpty(review.rating) && (
						<Rating
							size="lg"
							value={review.rating}
							readOnly
							mb="md"
						/>
					)}
					{!checkIsEmpty(review.content) && (
						<Text
							fs="italic"
							tt="uppercase"
							mb="lg"
							fw="bold"
							size="md"
							lineClamp={5}
						>
							&quot;{review.content}&quot;
						</Text>
					)}
					<Text size="xs">
						{!checkIsEmpty(review.reviewer) && review.reviewer}{" "}
						{!checkIsEmpty(review.company) && (
							<Text
								span
								fw="bold"
								inherit
							>
								{!checkIsEmpty(review.reviewer) && ", "}
								{review.company}
							</Text>
						)}
					</Text>
				</Stack>
			</Carousel.Slide>
		);
	}

	return (
		<Carousel
			controlsOffset="xl"
			controlSize={40}
			nextControlIcon={<IconArrowRight color={theme.colors.primary[5]} />}
			previousControlIcon={<IconArrowLeft color={theme.colors.primary[5]} />}
			height={200}
			slideSize={testimonialWidth}
			align="center"
			slidesToScroll={3}
			loop
			plugins={[autoplay.current]}
			onMouseEnter={autoplay.current.stop}
			onMouseLeave={autoplay.current.reset}
			classNames={classes}
			withControls={true}
			my="xl"
			containScroll="trimSnaps"
			styles={{
				viewport: { height: "auto" },
				container: { height: "fit-content" },
			}}
			{...carouselProps}
		>
			{testimonials?.map((review, index) => (
				<Slide
					key={index}
					review={review}
				/>
			))}
		</Carousel>
	);
}
