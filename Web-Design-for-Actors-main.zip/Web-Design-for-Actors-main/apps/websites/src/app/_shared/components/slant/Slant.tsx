"use client";

// React Imports

import { ReactNode } from "react";

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
import { Box, StackProps } from "@mantine/core";
import styles from "./slant.module.css";

interface SlantProps extends StackProps {
	children?: ReactNode;
	options?: {
		reverse?: boolean;
		withPadding: boolean;
	};
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
export default function Slant(props: SlantProps) {
	const { children, options, ...rest } = props;
	const withPadding = options?.withPadding === false ? false : true;

	return (
		<Box
			className={`${styles["slant"]} ${
				options?.reverse ? styles["reverse"] : ""
			}`}
			style={{
				backgroundRepeat: "no-repeat",
			}}
			{...rest}
		>
			<Box
				style={
					withPadding ? { padding: "10rem 0", paddingBottom: "15rem" } : {}
				}
				c={styles.c}
			>
				{children}
			</Box>
		</Box>
	);
}
