// React Imports
import { Fragment } from "react";

// Next.js Imports
import Link from "next/link";

// Lower Order Components

// UI Components & Icons
import { Grid, Text } from "@mantine/core";

// Context & Helpers

// Other libraries or utilities
import { showPreferences } from "vanilla-cookieconsent";

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function FooterText({ brandName }: { brandName?: string }) {
	return (
		<Fragment>
			<Grid.Col span={{ base: 12, md: 12, lg: 3 }}>
				<Text
					size="sm"
					c="secondaryAccent"
					ta="center"
				>
					Copyright &copy; {brandName || ""} {new Date().getFullYear()}
				</Text>
			</Grid.Col>
			<Grid.Col
				span={{ base: 12, md: 12, lg: 6 }}
				styles={{ col: { textAlign: "center" } }}
			>
				<Text
					size="sm"
					c="secondaryAccent"
					ta="center"
				>
					<Link
						href=""
						data-cc="show-preferencesModal"
						onClick={() => showPreferences()}
						style={{ color: "var(--mantine-color-secondaryAccent)" }}
					>
						Cookie Policy
					</Link>{" "}
				</Text>
			</Grid.Col>
			<Grid.Col span={{ base: 12, md: 12, lg: 3 }}>
				<Link
					href="https://producers.wdf.me/?ref=productions_website_footer"
					target="_blank"
				>
					<Text
						size="sm"
						c="secondaryAccent"
						ta="center"
					>
						A{" "}
						<span
							style={{
								fontWeight: "bold",
								marginLeft: "5px",
								marginRight: "5px",
							}}
						>
							WDF |
						</span>{" "}
						Website
					</Text>
				</Link>
			</Grid.Col>
		</Fragment>
	);
}
