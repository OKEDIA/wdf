// React Imports
import { ReactNode } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { Box, Title, TitleOrder } from "@mantine/core";

// Context & Helpers
import { checkIsEmpty } from "@okedia/shared/helpers";
import { useCallback, useMemo } from "react";

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

type SectionOptions = {
	withTitle?: boolean;
};

export type Section = {
	type?: string;
	title?: string;
	content?: ReactNode | string;
	image?: { downloadUrl?: string };
	options?: Partial<SectionOptions>;
};

export type AdditionalSection = {
	index?: number;
	children: ReactNode;
	title?: string;
	options?: Partial<SectionOptions>;
};

export type SectionWrapperProps = {
	section: Section;
	index: number;
	colors: { mainColor: string; accentColor: string };
	children: ReactNode;
};

export type SectionWrapper = ({
	section,
	index,
	colors,
	children,
}: SectionWrapperProps) => JSX.Element;

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Sections({
	data,
	additionalSections: additionalSectionsProp,
	Wrapper,
	options,
}: {
	data?: Section[];
	additionalSections?: AdditionalSection[];
	Wrapper: SectionWrapper;
	options?: { offsetLastColor?: boolean };
}) {
	const additionalSections = useMemo(
		() => additionalSectionsProp,
		[additionalSectionsProp]
	);
	// Helper to determine colors - memoized
	const getColors = useCallback((index: number, isLast: boolean) => {
		const mainColor =
			isLast && options?.offsetLastColor === true
				? "primary.3"
				: index % 2 === 0
				? "secondary"
				: "primary";
		const accentColor = index % 2 === 0 ? "secondaryAccent" : "primaryAccent";
		return { mainColor, accentColor };
	}, []);

	// Combine predefined and additional sections - memoized
	const sections = useMemo(() => {
		const combinedSections: Section[] = [];

		data?.forEach((section) => {
			combinedSections.push({
				...section,
			});
		});

		additionalSections?.forEach((additionalSection) => {
			const customSection: Section = {
				type: "custom",
				title: additionalSection.title,
				content: additionalSection.children,
				options: additionalSection.options,
			};

			if (
				additionalSection.index !== undefined &&
				additionalSection.index >= 0
			) {
				combinedSections.splice(additionalSection.index, 0, customSection);
			} else {
				combinedSections.push(customSection);
			}
		});

		return combinedSections;
	}, [data, additionalSections]);

	return (
		<>
			{sections.map((section, index) => {
				const isLast = index === sections.length - 1;
				const { mainColor, accentColor } = getColors(index, isLast);

				return (
					<Wrapper
						key={`section-${index}`}
						section={section}
						index={index}
						colors={{ mainColor, accentColor }}
					>
						{!checkIsEmpty(section?.title) && (
							<Title
								order={2}
								c={accentColor}
								tt="uppercase"
							>
								{section.title}
							</Title>
						)}

						{section.options?.withTitle !== false &&
							checkIsEmpty(section?.title) && (
								<Title
									order={(index + 1) as TitleOrder}
									c={accentColor}
									tt="uppercase"
									mb="lg"
								>
									{section.type}
								</Title>
							)}
						{typeof section.content === "string" ? (
							<Box
								mt="sm"
								dangerouslySetInnerHTML={{ __html: section.content }}
							/>
						) : (
							section.content
						)}
					</Wrapper>
				);
			})}
		</>
	);
}
