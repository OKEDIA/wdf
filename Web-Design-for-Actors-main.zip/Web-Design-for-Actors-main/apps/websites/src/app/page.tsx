import RootPage from "./[...slug]/page";

export default async function Page() {
	return <RootPage />;
}
