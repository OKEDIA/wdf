"use server"; // MUST STAY AS A SERVER COMPONENT

// React Imports
import { lazy } from "react";

// Next.js Imports
import { SpeedInsights } from "@vercel/speed-insights/next";
import { cookies } from "next/headers";

// Lower Order Components
import InvalidDomain from "./_shared/InvalidDomain";
import NotFound from "./_shared/NotFound";
import WebsiteUnavailable from "./_shared/WebsiteUnavailable";

// UI Components & Icons

import "@mantine/carousel/styles.css";
import {
	ColorSchemeScript,
	createTheme,
	MantineColor,
	mantineHtmlProps,
	MantineProvider,
} from "@mantine/core";
import "@mantine/core/styles.css";
import "vanilla-cookieconsent/dist/cookieconsent.css";
import "../app/globals.css";

// Context & Helpers

// Other libraries or utilities
import { ObjectId } from "bson";
import { documentHelpers } from "@okedia/shared/database";
import { checkIsEmpty, generateColors } from "@okedia/shared/helpers";
import { useGlobalQueryParams } from "@okedia/shared/hooks";
import { useServersideDatabase as database } from "@okedia/shared/hooks/database/useServersideDatabase";

// Types
import { InternalApiResponse } from "@okedia/shared/types/documentResponses";
import { FontsResponse, Website } from "@okedia/shared/types/websiteTypes";
import { DataProvider } from "./_context/Data";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
interface InternalColorScheme {
	[key: string]: {
		baseColor: string;
		secondaryColor?: string;
		primaryAccent?: string;
		secondaryAccent?: string;
	};
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// In-memory cache
const cache = new Map();

/**
 * RootLayout component that sets up the layout for the application.
 *
 * @param {Object} props - The properties object.
 * @param {React.ReactNode} props.children - The child components to be rendered within the layout.
 *
 * @returns {JSX.Element} The rendered layout component.
 *
 * @throws {Error} If no domain is found in cookies or if an invalid primary color value is encountered.
 *
 * This component performs the following tasks:
 * - Retrieves the current domain from cookies.
 * - Checks if website data is available in the cache; if not, fetches it from the database.
 * - Sets the primary color for the theme based on the website data.
 * - Creates a theme using the Mantine library.
 * - Dynamically imports the appropriate template component based on the website data.
 * - Renders the layout with the MantineProvider, DataProvider, and the dynamically imported template component.
 *
 * @remark There is an ongoing issue which causes the layout to be re-rendered multiple times on navigation.
 * This is caused by the dynamic routing triggering the layout to re-render. The big problem is that the database
 * is called several times. This has been mitigated by adding the cache.
 */
export default async function RootLayout({
	children,
}: {
	children: React.ReactNode;
}) {
	// Cookies must be called outside of the try/catch block so that NextJS knows to opt out of static rendering
	// https://stackoverflow.com/questions/78010331/dynamic-server-usage-page-couldnt-be-rendered-statically-because-it-used-next/78010468
	const currentCookies = await cookies();

	try {
		console.log("LAYOUT RENDERED");
		const currentDomain = currentCookies.get("currentDomain")?.value;
		const db = database(process.env.NEXT_PUBLIC_API_BASE_URL as string, "");

		// eslint-disable-next-line
		const globalQuery = useGlobalQueryParams(new URLSearchParams());
		const mongoQuery = globalQuery.mongoQuery();

		if (!currentDomain) {
			throw new Error("No domain found in cookies");
		}

		// Check if websiteData is in cache
		let websiteData = cache.get(currentDomain);
		const noCache = !!currentCookies.get("noCache")?.value;

		// Check if the cached data is stale or invalid
		if ((noCache && websiteData) || (websiteData && websiteData?.lastUpdated)) {
			const cacheTTL = 60 * 60 * 1000; // 1 hour in milliseconds
			const isCacheExpired =
				Date.now() - new Date(websiteData?.lastUpdated).getTime() > cacheTTL;

			if (noCache || isCacheExpired) {
				console.log("Invalidating Cache");
				cache.delete(currentDomain); // Invalidate the cache
				websiteData = null; // Force a fresh fetch
			}
		}

		const isValidObjectId = ObjectId.isValid(currentDomain);
		const isValidFQDN = /^(?!:\/\/)([a-zA-Z0-9-_]+\.)+[a-zA-Z]{2,6}$/.test(
			currentDomain
		);

		let lookup = null;
		if (isValidObjectId) {
			lookup = { _id: currentDomain };
		} else if (isValidFQDN) {
			lookup = { domain: currentDomain };
		} else {
			return <InvalidDomain currentDomain={currentDomain} />;
		}

		if (!websiteData) {
			console.log("Fetching website data from database");
			// Fetch website data from the database
			websiteData = await documentHelpers.find<Website<unknown>>({
				...mongoQuery,
				collectionName: "websites",
				filter: { ...mongoQuery.filter, ...lookup },
				paginition: {
					...globalQuery.defaultPaginition(),
					limit: 1,
					startAfter: 0,
					callback: mongoQuery.paginition.callback,
				},
				expand: [
					{
						from: "profiles",
						localField: "profileId",
						foreignField: "_id",
						as: "profile",
					},
				],
			});

			// Store websiteData in cache
			cache.set(currentDomain, websiteData);
		}

		if (!websiteData || Array.isArray(websiteData)) {
			return <NotFound currentDomain={currentDomain} />;
		}

		if (websiteData.status?.toLowerCase() !== "online") {
			return <WebsiteUnavailable currentDomain={currentDomain} />;
		}

		const setPrimaryColor = () => {
			const additionalColorSchmes: InternalColorScheme = {
				blue: {
					baseColor: "rgb(8, 86, 193)", // Balanced Blue
					secondaryColor: "rgb(2, 62, 144)",
					primaryAccent: "rgb(255, 255, 255)",
					secondaryAccent: "rgb(208, 224, 255)",
				},
				green: {
					baseColor: "rgb(62, 131, 62)",
					secondaryColor: "rgb(120, 204, 109)", // Glowing Green
					primaryAccent: "rgb(248, 255, 238)",
					secondaryAccent: "rgb(230, 255, 230)",
				},
				orange: {
					baseColor: "rgb(255, 152, 0)", // Outgoing Orange
					secondaryColor: "rgb(255, 87, 34)",
					primaryAccent: "rgb(255, 222, 212)",
					secondaryAccent: "rgb(255, 245, 224)",
				},
				pink: {
					baseColor: "rgb(255, 125, 168)", // Passionate Pink
					secondaryColor: "rgb(194, 24, 91)",
					primaryAccent: "rgb(255, 255, 255)",
					secondaryAccent: "rgb(255, 224, 237)",
				},
				purple: {
					baseColor: "rgb(196, 70, 218)",
					secondaryColor: "rgb(123, 31, 162)",
					primaryAccent: "rgb(255, 255, 255)",
					secondaryAccent: "rgb(215, 158, 255)",
				},
				red: {
					baseColor: "rgb(232, 103, 107)",
					secondaryColor: "rgb(213, 50, 46)",
					primaryAccent: "rgb(255, 255, 255)",
					secondaryAccent: "rgb(255, 102, 102)",
				},
				mysteryMagenta: {
					baseColor: "rgb(143, 0, 119)",
					secondaryColor: "rgb(88, 24, 69)",
					primaryAccent: "rgb(255, 255, 255)",
					secondaryAccent: "rgb(200, 100, 200)",
				},
				powerPurple: {
					baseColor: "rgb(123, 31, 162)",
					secondaryColor: "rgb(78, 52, 149)",
					primaryAccent: "rgb(255, 255, 255)",
					secondaryAccent: "rgb(191, 148, 255)",
				},
				pastelPink: {
					baseColor: "rgb(233, 30, 99)",
					secondaryColor: "rgb(244, 143, 177)",
					primaryAccent: "rgb(0, 0, 0)",
					secondaryAccent: "rgb(255, 248, 242)",
				},
				radientRed: {
					baseColor: "rgb(244, 67, 54)",
					secondaryColor: "rgb(220, 53, 69)",
					primaryAccent: "rgb(255, 255, 255)",
					secondaryAccent: "rgb(255, 204, 203)",
				},
				sunnyYellow: {
					baseColor: "rgb(255, 235, 59)",
					secondaryColor: "rgb(255, 193, 7)",
					primaryAccent: "rgb(0, 0, 0)",
					secondaryAccent: "rgb(255, 243, 120)",
				},
				oceanicOlive: {
					baseColor: "rgb(107, 142, 35)",
					secondaryColor: "rgb(85, 107, 47)",
					primaryAccent: "rgb(255, 255, 255)",
					secondaryAccent: "rgb(180, 195, 125)",
				},
				blissfulBlue: {
					baseColor: "rgb(3, 169, 244)",
					secondaryColor: "rgb(0, 150, 136)",
					primaryAccent: "rgb(255, 255, 255)",
					secondaryAccent: "rgb(187, 222, 251)",
				},
				lavender: {
					baseColor: "rgb(92, 38, 80)", // Lavender Luminary
					secondaryColor: "rgb(51, 20, 51)",
					primaryAccent: "rgb(255, 255, 255)",
					secondaryAccent: "rgb(224, 200, 228)",
				},
				peach: {
					baseColor: "rgb(240, 150, 144)", // Peachy Prodigy
					secondaryColor: "rgb(220, 100, 100)",
					primaryAccent: "rgb(255, 231, 231)",
					secondaryAccent: "rgb(255, 230, 230)",
				},
				rustic: {
					baseColor: "rgb(163, 133, 105)",
					secondaryColor: "rgb(121, 85, 72)",
					primaryAccent: "rgb(255, 255, 255)",
					secondaryAccent: "rgb(198, 168, 147)",
				},
				aqua: {
					baseColor: "rgb(38, 130, 158)", // Aqua Auteur
					secondaryColor: "rgb(0, 105, 130)",
					primaryAccent: "rgb(255, 255, 255)",
					secondaryAccent: "rgb(202, 236, 252)",
				},
				harvest: {
					baseColor: "rgb(116, 158, 54)", // Harvest Hero
					secondaryColor: "rgb(85, 139, 47)",
					primaryAccent: "rgb(255, 255, 255)",
					secondaryAccent: "rgb(225, 245, 204)",
				},
				berry: {
					baseColor: "rgb(158, 19, 100)", // Berry Bold
					secondaryColor: "rgb(94, 0, 74)",
					primaryAccent: "rgb(255, 255, 255)",
					secondaryAccent: "rgb(255, 212, 236)",
				},
				scarlett: {
					baseColor: "rgb(158, 3, 0)", // Scarlett Showman
					secondaryColor: "rgb(97, 0, 0)",
					primaryAccent: "rgb(255, 255, 255)",
					secondaryAccent: "rgb(255, 218, 218)",
				},
				gold: {
					baseColor: "rgb(163, 156, 56)", // Golden Muse
					secondaryColor: "rgb(130, 119, 23)",
					primaryAccent: "rgb(33, 33, 33)",
					secondaryAccent: "rgb(250, 248, 200)",
				},
				sapphire: {
					baseColor: "rgb(0, 76, 158)", // Sapphire Sentinel
					secondaryColor: "rgb(0, 52, 105)",
					primaryAccent: "rgb(255, 255, 255)",
					secondaryAccent: "rgb(200, 224, 255)",
				},
			};

			const overrideColorScheme =
				currentCookies.get("colorScheme")?.value !== ""
					? currentCookies.get("colorScheme")?.value
					: null;

			const colorScheme =
				overrideColorScheme ??
				websiteData?.template?.colorScheme?.[0]?.colorScheme?.colorScheme;

			const customColor =
				websiteData?.template?.colorScheme?.[0]?.colorScheme?.customColor;
			const secondaryColor =
				websiteData?.template?.colorScheme?.[0]?.colorScheme?.secondaryColor;
			const primaryAccent =
				websiteData?.template?.colorScheme?.[0]?.colorScheme?.primaryAccent;
			const secondaryAccent =
				websiteData?.template?.colorScheme?.[0]?.colorScheme?.secondaryAccent;

			if (colorScheme === "custom") {
				console.log("Custom Color Scheme: ", customColor);
				// Colour Scheme is custom hex color scheme
				return {
					colors: {
						primary: generateColors(customColor),
						...(secondaryColor
							? { secondary: generateColors(secondaryColor) }
							: {}),
						...(primaryAccent
							? { primaryAccent: generateColors(primaryAccent) }
							: {}),
						...(secondaryAccent
							? { secondaryAccent: generateColors(secondaryAccent) }
							: {}),
					},
					primaryColor: "primary",
					white: primaryAccent || "white",
					black: secondaryAccent || "black",
				};
			} else if (
				colorScheme &&
				colorScheme !== "custom" &&
				!!additionalColorSchmes[
					colorScheme as keyof typeof additionalColorSchmes
				]
			) {
				const primaryColor = generateColors(
					additionalColorSchmes[
						colorScheme as keyof typeof additionalColorSchmes
					].baseColor || "#000000"
				);
				const secondaryColor = generateColors(
					additionalColorSchmes[
						colorScheme as keyof typeof additionalColorSchmes
					]?.secondaryColor || "#fffff"
				);
				const primaryAccent = generateColors(
					additionalColorSchmes[
						colorScheme as keyof typeof additionalColorSchmes
					]?.primaryAccent || "#ffffff"
				);

				const secondaryAccent = generateColors(
					additionalColorSchmes[
						colorScheme as keyof typeof additionalColorSchmes
					]?.secondaryAccent || "#000000"
				);
				// Colour scheme matches the additional colour schemes
				return {
					colors: {
						primary: primaryColor,
						...(secondaryColor
							? {
									secondary: secondaryColor,
							  }
							: {}),
						...(primaryAccent
							? {
									primaryAccent,
							  }
							: {}),
						...(secondaryAccent
							? {
									secondaryAccent,
							  }
							: {}),
					},
					primaryColor: "primary",
				};
			} else if (colorScheme as keyof MantineColor) {
				// Colour scheme matches the Mantine Default Color Schemes
				return {
					primaryColor: colorScheme,
				};
			} else {
				// Use the default mantine color scheme as no matching colour scheme was found
				console.warn("Invalid primary color value, defaulting to Blue");
				return;
			}
		};

		const headingFont = await db
			.get<InternalApiResponse<FontsResponse>>({
				url: `/fonts?family=${
					(!checkIsEmpty(websiteData?.template?.font?.[0]?.headings) &&
						websiteData?.template?.font?.[0]?.headings) ||
					"Raleway"
				}`,
			})
			.then((res) => {
				if (res.success) {
					return res.response;
				}
			})
			.then((res) => res?.items?.[0]);

		const bodyFont = await db
			.get<InternalApiResponse<FontsResponse>>({
				url: `/fonts?family=${
					(!checkIsEmpty(websiteData?.template?.font?.[0]?.body) &&
						websiteData?.template?.font?.[0]?.body) ||
					"Raleway"
				}`,
			})
			.then((res) => {
				if (res.success) {
					return res.response;
				}
			})
			.then((res) => res?.items?.[0]);

		const theme = createTheme({
			autoContrast: true,
			luminanceThreshold: 0.5,
			fontFamily: `${bodyFont?.family}, sans-serif`,
			fontSizes: {
				md: "20px",
			},
			...setPrimaryColor(),
			headings: {
				fontFamily: `${headingFont?.family}, sans-serif`,
				fontWeight: "700",
				textWrap: "pretty",
				sizes: {
					h1: { fontSize: "50px" },
					h2: { fontSize: "40px" },
				},
			},
			primaryShade: 5,
		});

		const type = websiteData.type;
		const template = websiteData.template.colorScheme[0].colorScheme.design;

		const TemplateComponent = lazy(() =>
			import(`./_templates/${type}/${template}/page`).catch(() => null)
		);

		if (!TemplateComponent) {
			return <p>Template not found.</p>;
		}

		return (
			<html
				lang="en"
				{...mantineHtmlProps}
			>
				<head>
					<meta charSet="UTF-8" />
					{!checkIsEmpty(websiteData?.meta?.meta?.[0]?.description) && (
						// Website Description
						<meta
							name="description"
							content={websiteData?.meta?.meta?.[0]?.description}
						/>
					)}
					{!checkIsEmpty(websiteData?.meta?.meta?.[0]?.keywords) && (
						// Keyword Tags
						<meta
							name="keywords"
							content={websiteData?.meta?.meta?.[0]?.keywords}
						/>
					)}
					{!checkIsEmpty(
						websiteData?.searchEngine?.searchEngine?.[0]?.google
					) && (
						/* Google Webmasters Validation Meta Tag */
						<meta
							name="google-site-verification"
							content={websiteData?.searchEngine?.searchEngine?.[0]?.google}
						/>
					)}

					{!checkIsEmpty(
						websiteData?.searchEngine?.searchEngine?.[0]?.bing
					) && (
						/* Bing Webmasters Validation Meta Tag */
						<meta
							name="msvalidate.01"
							content={websiteData?.searchEngine?.searchEngine?.[0]?.bing}
						/>
					)}

					{!checkIsEmpty(websiteData?.analytics?.analytics?.[0]?.metaPixel) && (
						/* Meta Pixel Tag */
						<>
							<script>
								{`!function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '${websiteData?.analytics?.analytics?.[0]?.metaPixel}');
  fbq('track', 'PageView');`}
							</script>
							<noscript>
								<img
									height="1"
									width="1"
									style={{ display: "none" }}
									src={`https://www.facebook.com/tr?id=${websiteData?.analytics?.analytics?.[0]?.metaPixel}&ev=PageView&noscript=1`}
								/>
							</noscript>
						</>
					)}

					{!checkIsEmpty(
						websiteData?.analytics?.analytics?.[0]?.googleAnalytics
					) && (
						/* Google Analytics Tag */
						<>
							<script
								async
								src={`https://www.googletagmanager.com/gtag/js?id=${websiteData?.analytics?.analytics?.[0]?.googleAnalytics}`}
							></script>
							<script>
								{`window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', ${websiteData?.analytics?.analytics?.[0]?.googleAnalytics}');`}
							</script>
						</>
					)}

					{!checkIsEmpty(
						websiteData?.graphics?.logo?.[0]?.icon?.downloadUrl
					) && (
						/* Favicon */
						<link
							rel="icon"
							href={websiteData?.graphics?.logo?.[0]?.icon?.downloadUrl}
							type={websiteData?.graphics?.logo?.[0]?.icon?.contentType}
						/>
					)}

					{!checkIsEmpty(
						websiteData?.graphics?.logo?.[0]?.icon?.downloadUrl
					) && (
						/* Apple Icon */
						<link
							rel="apple-touch-icon"
							href={websiteData?.graphics?.logo?.[0]?.icon?.downloadUrl}
							type={websiteData?.graphics?.logo?.[0]?.icon?.contentType}
						/>
					)}

					{!checkIsEmpty(websiteData?.meta?.meta[0]?.title) && (
						/* Website Title */
						<title>{websiteData?.meta.meta[0].title}</title>
					)}

					<style>
						{`
							@font-face {
								font-family: '${headingFont?.family}';
								src: url(${headingFont?.files?.regular});
								font-display: swap;
							}
							@font-face {
								font-family: '${bodyFont?.family}';
								src: url(${bodyFont?.files?.regular});
								font-display: swap;
							}
						`}
					</style>
					<link
						rel="preconnect"
						href="https://fonts.gstatic.com"
					/>
					<link
						href="https://fonts.googleapis.com/css2?family=Raleway:wght@100..900&display=swap"
						rel="stylesheet"
					/>
					<ColorSchemeScript defaultColorScheme="auto" />
					<link
						rel="icon"
						href="/static/images/favicon.ico"
					></link>
				</head>
				<body>
					<MantineProvider theme={theme}>
						<DataProvider initialWebsiteData={websiteData}>
							<TemplateComponent>
								{children}
								{/* Vercel Speed Insights */}
								<SpeedInsights />
							</TemplateComponent>
						</DataProvider>
					</MantineProvider>
				</body>
			</html>
		);
	} catch (error: any) {
		console.error(error);
		throw error;
	}
}
