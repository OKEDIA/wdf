// React Imports

// Next.js Imports

// Lower Order Components
import type { Metadata } from "next";
import GlobalContainer from "./(root)/_components/GlobalContainer";
import { getMetadata } from "./_utilities/getMetadata";

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * RootLayout component that wraps the entire application.
 *
 * @param {Object} props - The properties object.
 * @param {React.ReactNode} props.children - The child components to be rendered within the layout.
 *
 * @returns {JSX.Element} The root layout component.
 */
export default async function RootLayout({
	children,
}: Readonly<{
	children: React.ReactNode;
}>) {
	return (
		<html lang="en">
			<GlobalContainer>{children}</GlobalContainer>
		</html>
	);
}

export async function generateMetadata(): Promise<Metadata> {
	return await getMetadata();
}
