"use client";

// React Imports

// Next.js Imports
import Link from "next/link";
import { redirect } from "next/navigation";

// Lower Order Components
import WdfLogo from "../_components/logos/WdfLogo";

// UI Components & Icons
import {
	Alert,
	Box,
	Button,
	Container,
	Flex,
	Grid,
	GridCol,
	List,
	Paper,
	Stack,
	TableOfContents,
	Text,
	Title,
	TypographyStylesProvider,
} from "@mantine/core";
import { IconArrowLeft } from "@tabler/icons-react";

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
const titleMap = {
	"collect-use-services": "Services and Goods",
	"collect-use-accounts": "Accounts and Guarantees",
	"collect-use-marketing": "Marketing Purposes",
	"collect-use-queries": "Queries, Complaints or Claims",
	"right-of-access": "Right of Access",
	"right-to-rectification": "Right to Rectification",
	"right-to-erasure": "Right to Erasure",
	"right-to-restrict": "Right to Restriction of Processing",
	"right-to-object": "Right to Object to Processing",
	"right-to-portability": "Right to Data Portability",
	"right-to-withdraw": "Right to Withdraw Consent",
};
function getCustomLabel(id: string, value: string) {
	return titleMap[id as keyof typeof titleMap] || value;
}

export default function Page() {
	return (
		<TypographyStylesProvider>
			<Flex
				justify="space-between"
				align="center"
				bg="branding"
				h="100px"
				p="lg"
				w="100dvw"
				pos="sticky"
				top={0}
				styles={{
					root: { boxShadow: "0px 1px 8px 0px #0000004f", zIndex: 100 },
				}}
			>
				<WdfLogo
					style={{ position: "relative" }}
					c="white"
				/>
				<Box>
					<Button
						leftSection={<IconArrowLeft />}
						onClick={() => redirect("/dashboard")}
					>
						Back to Dashboard
					</Button>
				</Box>
			</Flex>
			<Grid
				columns={24}
				align="flex-start"
				p="lg"
			>
				<GridCol
					span={{ base: 24, md: 8, lg: 10 }}
					component={Stack}
				>
					<Container
						style={{
							position: "sticky",
							top: 0,
							maxHeight: "100dvh",
							height: "100dvh",
							overflow: "scroll",
						}}
						component={Paper}
						p="xl"
					>
						<Title>Customer Privacy Notice</Title>
						<Text>
							Registered Name:{" "}
							<Link
								href="https://creativeindustries.group/"
								target="_blank"
								style={{ fontWeight: "bold" }}
							>
								Creative Industries Group Ltd
							</Link>
							.
						</Text>
						<Text>
							This privacy notice tells you what to expect us to do with your
							personal information.
						</Text>
						<Text size="xs">Last Updated: 31/03/2025 </Text>

						<TableOfContents
							variant="filled"
							color="blue"
							size="sm"
							radius="sm"
							getControlProps={({ data, active }) => ({
								onClick: () => data.getNode().scrollIntoView(),
								component: "a",
								href: `#${data.id}`,
								style: {
									fontWeight: active ? "bold" : "inherit",
									color: active ? "white" : "black",
									background: active
										? "var(--mantine-color-branding-filled)"
										: "inherit",
								},
								children: getCustomLabel(data.id, data.value),
							})}
							scrollSpyOptions={{
								selector:
									"#privacy-body h1, #privacy-body h2, #privacy-body h3, #privacy-body h4, #privacy-body h5, #privacy-body h6",
							}}
						/>
					</Container>
				</GridCol>
				<GridCol
					p="xl"
					mah="100dvh"
					span={{ base: 24, md: 16, lg: 14 }}
					id="privacy-body"
				>
					<Stack gap="xl">
						<Container w="100%">
							<Title order={2}>Contact details</Title>
							<Title order={3}>Post</Title>
							<Text>
								Creative Industries Group Ltd, 41 Whitcomb Street, LONDON, WC2H
								7DT, GB
							</Text>
							<Title order={3}>Email</Title>
							<Text>hello@wdf.me</Text>
						</Container>
						<Container>
							<Title order={2}>What information we collect, use, and why</Title>
							<Title
								order={3}
								id="collect-use-services-and-goods"
							>
								We collect or use the following information to provide services
								and goods, including delivery:
							</Title>
							<List>
								<List.Item>Names and contact details</List.Item>
								<List.Item>Addresses</List.Item>
								<List.Item>Purchase or account history</List.Item>
								<List.Item>
									Payment details (including card or bank information for
									transfers and direct debits)
								</List.Item>
								<List.Item>Account information</List.Item>
								<List.Item>
									Website user information (including user journeys and cookie
									tracking)
								</List.Item>
								<List.Item>Photographs or video recordings</List.Item>
								<List.Item>
									Information relating to compliments or complaints
								</List.Item>
							</List>
							<Title
								order={3}
								id="collect-use-accounts"
							>
								We collect or use the following information for the operation of
								customer accounts and guarantees:
							</Title>
							<List>
								<List.Item>Names and contact details</List.Item>
								<List.Item>
									Payment details (including card or bank information for
									transfers and direct debits)
								</List.Item>
								<List.Item>Purchase history</List.Item>
								<List.Item>
									Account information, including registration details
								</List.Item>
								<List.Item>Information used for security purposes</List.Item>
							</List>
							<Title
								order={3}
								id="collect-use-marketing"
							>
								We collect or use the following information for service updates
								or marketing purposes:
							</Title>
							<List>
								<List.Item>Names and contact details</List.Item>
								<List.Item>Addresses</List.Item>
								<List.Item>Marketing preferences</List.Item>
								<List.Item>IP addresses</List.Item>
								<List.Item>Website and app user journey information</List.Item>
								<List.Item>Records of consent, where appropriate</List.Item>
							</List>
							<Title
								order={3}
								id="collect-use-queries"
							>
								We collect or use the following personal information for dealing
								with queries, complaints or claims:
							</Title>
							<List>
								<List.Item>Names and contact details</List.Item>
								<List.Item>Account information</List.Item>
							</List>
						</Container>
						<Container>
							<Title order={2}>Lawful bases and data protection rights</Title>
							<Alert
								color="branding"
								variant="light"
							>
								Under UK data protection law, we must have a “lawful basis” for
								collecting and using your personal information. There is a list
								of possible lawful bases in the UK GDPR. You can find out more
								about lawful bases on the ICO’s website. Which lawful basis we
								rely on may affect your data protection rights which are in
								brief set out below. You can find out more about your data
								protection rights and the exemptions which may apply on the
								ICO’s website:
							</Alert>
							<Title
								order={4}
								id="right-of-access"
							>
								Your Right of Access
							</Title>
							<Text>
								You have the right to ask us for copies of your personal
								information. You can request other information such as details
								about where we get personal information from and who we share
								personal information with. There are some exemptions which means
								you may not receive all the information you ask for. You can{" "}
								<Link
									href="https://ico.org.uk/for-organisations/advice-for-small-organisations/create-your-own-privacy-notice/your-data-protection-rights/#roa"
									target="_blank"
								>
									read more about this right here.
								</Link>
							</Text>
							<Title
								order={4}
								id="right-to-rectification"
							>
								Your Right to Rectification
							</Title>
							<Text>
								You have the right to ask us to correct or delete personal
								information you think is inaccurate or incomplete. You can{" "}
								<Link
									href="https://ico.org.uk/for-organisations/advice-for-small-organisations/create-your-own-privacy-notice/your-data-protection-rights/#rtr"
									target="_blank"
								>
									read more about this right here.
								</Link>
							</Text>
							<Title
								order={4}
								id="right-to-erasure"
							>
								Your Right to Erasure
							</Title>
							<Text>
								You have the right to ask us to delete your personal
								information. You can{" "}
								<Link
									href="https://ico.org.uk/for-organisations/advice-for-small-organisations/create-your-own-privacy-notice/your-data-protection-rights/#rte"
									target="_blank"
								>
									read more about this right here.
								</Link>
							</Text>
							<Title
								order={4}
								id="right-to-restrict"
							>
								Your Right to Restriction of Processing
							</Title>
							<Text>
								You have the right to ask us to limit how we can use your
								personal information. You can{" "}
								<Link
									href="https://ico.org.uk/for-organisations/advice-for-small-organisations/create-your-own-privacy-notice/your-data-protection-rights/#rtrop"
									target="_blank"
								>
									read more about this right here.
								</Link>
							</Text>
							<Title
								order={4}
								id="right-to-object"
							>
								Your Right to Object to Processing
							</Title>
							<Text>
								You have the right to object to the processing of your personal
								data. You can{" "}
								<Link
									href="https://ico.org.uk/for-organisations/advice-for-small-organisations/create-your-own-privacy-notice/your-data-protection-rights/#rto"
									target="_blank"
								>
									read more about this right here.
								</Link>
							</Text>
							<Title
								order={4}
								id="right-to-portiability"
							>
								Your Right to Data Portability
							</Title>
							<Text>
								You have the right to ask that we transfer the personal
								information you gave us to another organisation, or to you.
								<Link
									href="https://ico.org.uk/for-organisations/advice-for-small-organisations/create-your-own-privacy-notice/your-data-protection-rights/#rtdp"
									target="_blank"
								>
									read more about this right here.
								</Link>
							</Text>
							<Title
								order={4}
								id="right-to-withdraw"
							>
								Your Right to Withdraw Consent
							</Title>
							<Text>
								When we use consent as our lawful basis you have the right to
								withdraw your consent at any time.
								<Link
									href="https://ico.org.uk/for-organisations/advice-for-small-organisations/create-your-own-privacy-notice/your-data-protection-rights/#rtwc"
									target="_blank"
								>
									read more about this right here.
								</Link>
							</Text>
							<Alert
								variant="light"
								color="branding"
							>
								If you make a request, we must respond to you without undue
								delay and in any event within one month. To make a data
								protection rights request, please contact us using the contact
								details at the top of this privacy notice.
							</Alert>
						</Container>
						<Container>
							<Title order={3}>
								Our lawful bases for the collection and use of your data
							</Title>
							<Title order={4}>Services & Goods</Title>
							<Text>
								Our lawful bases for collecting or using personal information to
								provide services and goods are:
							</Text>
							<List>
								<List.Item>
									<Title order={5}>Contract</Title>
									<Text>
										We have to collect or use the information so we can enter
										into or carry out a contract with you. All of your data
										protection rights may apply except the right to object.
									</Text>
								</List.Item>{" "}
								<List.Item>
									<Title order={5}>Legitimate Interests</Title>
									<Text>
										We’re collecting or using your information because it
										benefits you, our organisation or someone else, without
										causing an undue risk of harm to anyone. All of your data
										protection rights may apply, except the right to
										portability. Our legitimate interests are:
									</Text>
									<List>
										<List.Item>
											<Text
												span
												inherit
												fw="bold"
											>
												A website builder exists to help users create and
												publish websites.
											</Text>
											To function properly, websites often require essential
											details such as the website owner’s name, business name,
											or other identifying information. Without collecting this
											data, the website builder may be unable to publish the
											site or ensure it is presented correctly.
										</List.Item>
										<List.Item>
											<Text
												span
												inherit
												fw="bold"
											>
												For both legal and practical reasons, website ownership
												must be clear.
											</Text>
											Collecting the user’s data ensures that:
											<List>
												<List.Item>
													The right individual has control over the website.
												</List.Item>
												<List.Item>
													The correct person can receive support, account
													recovery assistance, or dispute resolution services.
												</List.Item>
												<List.Item>
													Compliance with domain registration requirements is
													met, where applicable.
												</List.Item>
											</List>
										</List.Item>
									</List>
								</List.Item>
							</List>
							<Title order={4}>
								Operation of Customer Accounts and Guarantees
							</Title>
							<Text>
								Our lawful bases for collecting or using personal information
								for the operation of customer accounts and guarantees are:
							</Text>
							<List>
								<List.Item>
									<Title order={5}>Contract</Title>
									<Text>
										We have to collect or use the information so we can enter
										into or carry out a contract with you. All of your data
										protection rights may apply except the right to object.
									</Text>
								</List.Item>
								<List.Item>
									<Title order={5}>Legal Obligation</Title>
									<Text>
										We have to collect or use your information so we can comply
										with the law. All of your data protection rights may apply,
										except the right to erasure, the right to object and the
										right to data portability.
									</Text>
								</List.Item>
							</List>

							<Title order={4}>Service Updates or Marketing Purposes</Title>
							<Text>
								Our lawful bases for collecting or using personal information
								for service updates or marketing purposes are:
							</Text>
							<List>
								<List.Item>
									<Title order={5}>Consent</Title>
									<Text>
										We have permission from you after we gave you all the
										relevant information. All of your data protection rights may
										apply, except the right to object. To be clear, you do have
										the right to withdraw your consent at any time.
									</Text>
								</List.Item>
								<List.Item>
									<Title order={5}>Legitimate Interests</Title>
									<Text>
										We’re collecting or using your information because it
										benefits you, our organisation or someone else, without
										causing an undue risk of harm to anyone. All of your data
										protection rights may apply, except the right to
										portability. Our legitimate interests are:
									</Text>
									<List>
										<List.Item>
											<Text
												span
												inherit
												fw="bold"
											>
												To send service updates{" "}
											</Text>
											based on our interest in keeping users informed about
											important changes to our platform, such as:
											<List>
												<List.Item>
													Updates to our terms, policies, or security features.{" "}
												</List.Item>
												<List.Item>
													New features or improvements relevant to the services
													users have already signed up for.
												</List.Item>
												<List.Item>
													Technical issues, maintenance notifications, or
													service disruptions.
												</List.Item>
											</List>
											This processing benefits users by ensuring they remain
											informed and can continue to use our services effectively.
											The impact on individuals is minimal since these updates
											are directly related to their use of the service, and they
											would reasonably expect to receive such communications. To
											balance our interests with users’ rights, we:
											<List>
												<List.Item>
													Only send essential service-related updates.
												</List.Item>
												<List.Item>
													Provide clear opt-out options where appropriate (e.g.,
													for non-critical feature updates).
												</List.Item>
											</List>
										</List.Item>
									</List>
								</List.Item>
							</List>
							<Title order={4}>
								Dealing with Queries, Complaints or Claims
							</Title>
							<Text>
								Our lawful bases for collecting or using personal information
								for dealing with queries, complaints or claims are:
							</Text>
							<List>
								<List.Item>
									<Title order={5}>Consent</Title>
									<Text>
										We have permission from you after we gave you all the
										relevant information. All of your data protection rights may
										apply, except the right to object. To be clear, you do have
										the right to withdraw your consent at any time.
									</Text>
								</List.Item>
								<List.Item>
									<Title order={5}>Contract</Title>
									<Text>
										We have to collect or use the information so we can enter
										into or carry out a contract with you. All of your data
										protection rights may apply except the right to object.
									</Text>
									<List>
										<List.Item>
											<Text
												span
												inherit
												fw="bold"
											>
												Legal Obligation:{" "}
											</Text>{" "}
											we have to collect or use your information so we can
											comply with the law. All of your data protection rights
											may apply, except the right to erasure, the right to
											object and the right to data portability.
										</List.Item>
										<List.Item>
											<Text
												span
												inherit
												fw="bold"
											>
												Legitimate interests:{" "}
											</Text>
											we’re collecting or using your information because it
											benefits you, our organisation or someone else, without
											causing an undue risk of harm to anyone. All of your data
											protection rights may apply, except the right to
											portability. Our legitimate interests are:
											<List>
												<List.Item>
													To ensure good customer service, improve our services,
													and resolve issues and queries such as:
													<List>
														<List.Item>
															Handling general complaints about website
															performance.
														</List.Item>
														<List.Item>
															Investigating reports of misuse, fraud, or policy
															violations.
														</List.Item>
														<List.Item>
															Addressing legal or reputational risks related to
															a complaint.
														</List.Item>
													</List>
													In balancing our interests with users' rights, we
													ensure that:
													<List>
														<List.Item>
															Personal data is only used for the purpose of
															resolving the query or complaint.
														</List.Item>
														<List.Item>
															Users can request access to or deletion of their
															data where appropriate.
														</List.Item>
													</List>
												</List.Item>
											</List>
										</List.Item>
									</List>
								</List.Item>
							</List>
						</Container>
						<Container>
							<Title order={2}>Where we get personal information from</Title>
							<Title order={3}>Primary Sources</Title>
							<List>
								<List.Item>Directly from you</List.Item>
								<List.Item>
									Schools, colleges, universities or other education
									organisations
								</List.Item>
								<List.Item>Publicly available sources</List.Item>
								<List.Item>
									Providers of marketing lists and other personal information
								</List.Item>
							</List>
							<Title order={3}>Third Parties</Title>
							<Text>
								Since some data is submitted by users rather than directly by
								the individuals concerned, the lawful bases for processing are:
								-{" "}
							</Text>
							<Title order={4}>Legitimate Interest</Title>
							<Text>
								We have a legitimate interest in allowing users to publish
								publicly available or relevant information on their websites, as
								this supports the purpose of the website builder - enabling
								users to share content such as:
							</Text>
							<List>
								<List.Item>
									A producer listing cast members of a production.{" "}
								</List.Item>
								<List.Item>
									A business owner listing employees or partners on a company
									website.
								</List.Item>
								<List.Item>
									An event organiser listing speakers or performers.
								</List.Item>
							</List>
							<Text>
								We balance this interest against the rights of the individuals
								involved by encouraging users to ensure they have the right to
								share third-party data.
							</Text>
							<Title order={4}>Public Interest</Title>
							<Text>
								If the data being published is already public information, such
								as an actor's participation in a play. However, our third party
								users are still responsible for ensuring compliance with
								applicable privacy laws.
							</Text>
							<Title order={4}>When Necessary</Title>
							<Text>
								In cases where the information is not publicly known or its
								inclusion could impact the privacy of the individual, our third
								party users should obtain consent before publishing it. We
								encourage users to ensure that they have the necessary
								permissions before adding third-party data.
							</Text>
						</Container>
						<Container>
							<Title order={2}>How long we keep information</Title>
							<Text>
								We store data for as long as it is deemed necessary by the
								third-party users who add and manage it. Since data is added and
								removed by third-party users, they have control over its
								retention and can update or delete it as needed.
							</Text>
							<Text>
								In addition to user-managed retention, we may periodically purge
								old, unused, or outdated data to maintain system performance,
								improve efficiency, and ensure data relevance. This may include:
							</Text>
							<List>
								<List.Item>
									Removing inactive records that have not been updated for an
									extended period.
								</List.Item>
								<List.Item>
									Clearing outdated or inaccurate information that is no longer
									relevant.
								</List.Item>
								<List.Item>
									Deleting data upon request if required under applicable data
									protection laws.
								</List.Item>
							</List>
							<Text>
								Where legally required (e.g., for compliance, security, or fraud
								prevention), some information may be retained for a specific
								period before deletion.
							</Text>
							<Text>
								Some data is added directly by users, such as information
								submitted by individuals who contact us. We will keep this data
								for as long as necessary to:
							</Text>
							<List>
								<List.Item>Respond to inquiries and provide support.</List.Item>
								<List.Item>
									Fulfill any contractual or legal obligations.
								</List.Item>
								<List.Item>
									Maintain records for legitimate business purposes.
								</List.Item>
							</List>
							<Text>
								Once the data is no longer required, we will securely delete or
								anonymise it unless a longer retention period is required for
								legal or compliance reasons.
							</Text>
						</Container>
						<Container>
							<Title order={2}>Who we share information with</Title>
							<Title order={3}>Data Processors</Title>
							<List>
								<List.Item>
									<Title order={4}>
										Google Firebase - Cloud Service Provider
									</Title>
									<Text>
										This data processor does the following activities for us:
									</Text>
									<List>
										<List.Item>
											Firebase provides user authentication services, enabling
											secure login and identity verification.
										</List.Item>
										<List.Item>
											It also provides cloud storage for media files or other
											assets uploaded by users.
										</List.Item>
									</List>
								</List.Item>
								<List.Item>
									<Title order={4}>
										MongoDB Cloud - Database Management Provider
									</Title>
									<Text>What they do for us:</Text>
									<List>
										<List.Item>
											MongoDB stores and manages all application data, including
											user-generated content and structured information.
										</List.Item>
										<List.Item>
											It provides scalable and flexible NoSQL database solutions
											for efficient data retrieval and management.
										</List.Item>
									</List>
								</List.Item>
								<List.Item>
									<Title order={4}>
										Vercel - Hosting & Deployment Provider
									</Title>
									<Text>What they do for us:</Text>
									<List>
										<List.Item>
											Vercel hosts and deploys our web applications including
											the Web Design For platform (https://wdf.me), your website
											previews and your published websites.
										</List.Item>
										<List.Item>
											Uses Edge Computing to optimise speed and performance
											globally
										</List.Item>
									</List>
								</List.Item>
								<List.Item>
									<Title order={4}>
										Google Workspace - Business Communiations
									</Title>
									<Text>What they do for us:</Text>
									<List>
										<List.Item>
											Google Workspace provides email hosting for business
											communications.
										</List.Item>
									</List>
								</List.Item>
							</List>
							<Title order={3}>Others we share personal information with</Title>
							<Title order={4}>Primary</Title>
							<List>
								<List.Item>Professional or legal advisors</List.Item>
								<List.Item>
									Organisations we’re legally obliged to share personal
									information with
								</List.Item>
								<List.Item>
									Publicly on our website, social media or other marketing and
									information media
								</List.Item>
								<List.Item>Previous employers</List.Item>
								<List.Item>Suppliers and service providers</List.Item>
							</List>
							<Title order={4}>Third Parties</Title>
							<Text>
								We may share the data added to our platform with third-party
								services that pay to access our API for their own purposes.
								These third parties form part of our wider network of brands and
								use the data in various ways that align with the intended
								purpose of making the information publicly available.
							</Text>
							<Text>
								<Text
									span
									inherit
									fw="bold"
								>
									Legitimate Interest for Data Sharing:{" "}
								</Text>
								Since the data is added to be displayed on a website in the
								first place, it is reasonable to assume that users understand it
								will be publicly accessible., Examples of Third-Party Services
								That Use the Data include:
							</Text>
							<List>
								<List.Item>
									A university may use the data to manage a list of their actor
									alumni, tracking their careers and showcasing success
									stories.,
								</List.Item>
								<List.Item>
									Websites that list upcoming productions may use the data to
									ensure accurate and up-to-date information about shows, cast
									members, and venues.
								</List.Item>
								<List.Item>
									Industry-specific job platforms may access the data to show
									current job openings, auditions, and crew opportunities for
									productions.
								</List.Item>
							</List>
							<Text>
								<Text
									span
									inherit
									fw="bold"
								>
									Nature of Data and Flexibility of Use:{" "}
								</Text>
								The data collected is entirely manipulatable, meaning it can be
								adapted and presented in different ways depending on the needs
								of each third-party service., This ensures flexibility in its
								application while maintaining the core principle that it was
								originally intended for public display.
							</Text>
						</Container>
						<Container>
							<Title order={2}>Sharing information outside the UK</Title>
							<Text>
								Where necessary, our data processors may share personal
								information outside of the UK. When doing so, they comply with
								the UK GDPR, making sure appropriate safeguards are in place.
							</Text>
							<Text>
								For further information or to obtain a copy of the appropriate
								safeguard for any of the transfers below, please contact us
								using the contact information provided above.
							</Text>
							<Title order={3}>Google Firebase</Title>
							<Title order={4}>Category of recipient: </Title>
							<Text>Cloud Service Provider</Text>
							<Title order={4}>
								Country the personal information is sent to:{" "}
							</Title>
							<Text>US (Global)</Text>
							<Title order={4}>
								How the transfer complies with UK data protection law:{" "}
							</Title>
							<Text>
								The country or sector has a UK data bridge (also known as
								Adequacy Regulations)
							</Text>
							<Title order={3}>MongoDB</Title>
							<Title order={4}>Category of recipient: </Title>
							<Text>Database Management Provider</Text>
							<Title order={4}>
								Country the personal information is sent to:{" "}
							</Title>
							<Text>US, UK, EU</Text>
							<Title order={4}>
								How the transfer complies with UK data protection law:{" "}
							</Title>
							<Text>
								Addendum to the EU Standard Contractual Clauses (SCCs)
							</Text>
							<Title order={3}>Google Firebase</Title>
							<Title order={4}>Category of recipient: </Title>
							<Text>Cloud Service Provider</Text>
							<Title order={4}>
								Country the personal information is sent to:{" "}
							</Title>
							<Text>US (Global)</Text>
							<Title order={4}>
								How the transfer complies with UK data protection law:{" "}
							</Title>
							<Text>
								The country or sector has a UK data bridge (also known as
								Adequacy Regulations)
							</Text>
							<Title order={3}>Vercel</Title>
							<Title order={4}>Category of recipient: </Title>
							<Text>Hosting & Deployment Provider</Text>
							<Title order={4}>
								Country the personal information is sent to:{" "}
							</Title>
							<Text>US (Global Edge)</Text>
							<Title order={4}>
								How the transfer complies with UK data protection law:{" "}
							</Title>
							<Text>
								Addendum to the EU Standard Contractual Clauses (SCCs)
							</Text>
							<Title order={3}>Google Workspace</Title>
							<Title order={4}>Category of recipient: </Title>
							<Text>Business Communications</Text>
							<Title order={4}>
								Country the personal information is sent to:{" "}
							</Title>
							<Text>US (Global)</Text>
							<Title order={4}>
								How the transfer complies with UK data protection law:{" "}
							</Title>
							<Text>
								Addendum to the EU Standard Contractual Clauses (SCCs)
							</Text>
						</Container>
						<Container>
							<Title order={2}>How to complain</Title>
							<Text>
								If you have any concerns about our use of your personal data,
								you can make a complaint to us using the contact details at the
								top of this privacy notice.
							</Text>
							<Text>
								If you remain unhappy with how we’ve used your data after
								raising a complaint with us, you can also complain to the ICO.
								<br />
								<br />
								<Text
									inherit
									span
									fw="bold"
								>
									The ICO's Address:
									<br />
								</Text>
								Information Commissioner’s Office,
								<br />
								Wycliffe House
								<br />
								Water Lane, <br />
								Wilmslow, <br />
								Cheshire,
								<br /> SK9 5AF
								<br />
								<br />
								Helpline number: 0303 123 1113
								<br />
								<br />
								Website:{" "}
								<Link
									href="https://www.ico.org.uk/make-a-complaint"
									target="_blank"
								>
									https://www.ico.org.uk/make-a-complaint
								</Link>
							</Text>
						</Container>
					</Stack>
				</GridCol>
			</Grid>{" "}
		</TypographyStylesProvider>
	);
}
