"use client";

// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { AppShell, AppShellMain, Grid } from "@mantine/core";

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * DashboardLayout component that provides a layout structure for the dashboard.
 *
 * @param {Object} props - The properties object.
 * @param {React.ReactNode} props.children - The child components to be rendered within the layout.
 *
 * @returns {JSX.Element} The rendered DashboardLayout component.
 */
export default function Layout({ children }: { children: React.ReactNode }) {
	return (
		<AppShell>
			<AppShellMain
				styles={{
					main: { minHeight: "100dvh" },
				}}
			>
				<Grid
					justify="center"
					align="center"
					columns={24}
					styles={{
						inner: { minHeight: "100dvh", alignContent: "space-evenly" },
					}}
					grow
				>
					{children}
				</Grid>
			</AppShellMain>
		</AppShell>
	);
}
