"use client";

// React Imports
import { Fragment, useCallback, useEffect, useRef, useState } from "react";

// Next.js Imports
import Link from "next/link";
import { useRouter } from "next/navigation";

// Lower Order Components
import "@mantine/carousel/styles.css";
import WdfLogo from "./_components/logos/WdfLogo";

// UI Components & Icons
import { Carousel, Embla } from "@mantine/carousel";
import {
	Box,
	Center,
	Flex,
	GridCol,
	LoadingOverlay,
	Stack,
	Text,
	Title,
	Transition,
	UnstyledButton,
} from "@mantine/core";
import { IconCaretUpDownFilled } from "@tabler/icons-react";
import { showPreferences } from "vanilla-cookieconsent";

// Context & Helpers
import { brandMap } from "../_l10n/map";

// Other libraries or utilities
import { isProductionEnvironment } from "@okedia/shared/helpers";
import { WheelGesturesPlugin } from "embla-carousel-wheel-gestures";
// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Page(): JSX.Element {
	const [embla, setEmbla] = useState<Embla | null>(null);
	const router = useRouter();
	const mouseScroll = useRef(WheelGesturesPlugin());
	const [ready, setReady] = useState(false);
	const [loading, setLoading] = useState(false);
	const [selectedIndex, setSelectedIndex] = useState(0);
	const [hasInterracted, setHasInterracted] = useState<boolean>(false);
	const [debouncedIndex, setDebouncedIndex] = useState<number | undefined>(
		undefined
	);
	const types = brandMap;
	const filteredTypes = types.filter((type) => type.isBrand);

	useEffect(() => {
		// Redirec t to login page if the subdomain is already selected
		// This prevents the use from trying to double select the brand
		// E.g. user visits productions.wdf.me they should redirect to /login
		// in order to ensure that they can't re-select a brand and get stuck in a loop
		if (
			isProductionEnvironment &&
			window.location.hostname.split(".").length > 2
		) {
			router.replace("/login");
		}
	}, [router]);

	const onScroll = useCallback(() => {
		if (!embla) return;
		const snapPositions = embla.scrollSnapList();
		const scrollProgress = embla.scrollProgress();

		let newIndex = 0;
		let minDistance = Infinity;

		snapPositions.forEach((snap: number, index: number) => {
			const distance = Math.abs(snap - scrollProgress);
			if (distance < minDistance) {
				minDistance = distance;
				newIndex = index;
			}
		});

		setSelectedIndex(newIndex);
	}, [embla]);

	useEffect(() => {
		if (!embla) return;

		const handleScroll = () => onScroll();
		const handleSelect = () => onScroll();
		const handleSettle = () => {
			const snapPositions = embla.scrollSnapList();
			const scrollProgress = embla.scrollProgress();

			let newIndex = 0;
			let minDistance = Infinity;

			snapPositions.forEach((snap: number, index: number) => {
				const distance = Math.abs(snap - scrollProgress);
				if (distance < minDistance) {
					minDistance = distance;
					newIndex = index;
				}
			});

			setDebouncedIndex(newIndex);
		};

		embla.on("scroll", handleScroll);
		embla.on("select", handleSelect);
		embla.on("settle", handleSettle);

		onScroll(); // Initial call to set the correct active slide

		const longestTypeIndex = types.reduce<number>(
			(longestIndex, type, index, arr) =>
				type.id.length > arr[longestIndex].id.length ? index : longestIndex,
			0
		);
		embla.scrollTo(longestTypeIndex, false);

		// Set state after embla has initialized
		const readyTimeout = setTimeout(() => setReady(true), 2000);

		return () => {
			embla.off("scroll", handleScroll);
			embla.off("select", handleSelect);
			embla.off("settle", handleSettle);
			clearTimeout(readyTimeout);
		};
	}, [embla, onScroll]);

	return (
		<Fragment>
			<GridCol span={24}></GridCol>
			<GridCol span={24}>
				<Box
					style={{ textAlign: "center" }}
					pb="xl"
				>
					<Title
						order={1}
						size="lg"
					>
						Create or update your website using our easy website builder.
					</Title>
					<Title
						order={2}
						size="md"
						mb="xl"
						c="dark.3"
					>
						Select a website type to continue...
					</Title>
				</Box>
				<Flex
					justify="center"
					align="center"
				>
					{" "}
					<LoadingOverlay visible={loading} />
					<WdfLogo
						c="dark"
						w="100%"
						p="xl"
						ml="75px"
						style={{ scale: 2 }}
					>
						<Carousel
							height={150}
							slideSize="15%"
							orientation="vertical"
							loop={true}
							withControls={false}
							align="center"
							slidesToScroll={1}
							getEmblaApi={setEmbla}
							plugins={[mouseScroll.current]}
							onMouseOver={() => setHasInterracted(true)}
							styles={{
								slide: {
									WebkitUserSelect: "none",
									userSelect: "none",
									MozUserSelect: "none",
								},
							}}
						>
							{filteredTypes.map((type, index) => {
								const [isHovered, setIsHovered] = useState(false);
								return (
									<Carousel.Slide
										key={`${type}-${index}`}
										onMouseEnter={() =>
											index === debouncedIndex && setIsHovered(true)
										}
										onMouseLeave={() => setIsHovered(false)}
										onTouchStart={() =>
											index === debouncedIndex && setIsHovered(true)
										}
										onTouchEnd={() => setIsHovered(false)}
										h="100%"
										opacity={
											index === selectedIndex
												? 1
												: index === (selectedIndex + 1) % types.length ||
												  index ===
														(selectedIndex - 1 + types.length) % types.length
												? 0.6
												: 0.1
										}
										style={{
											transition: "opacity 0.3s ease-in-out", // Smooth opacity transition
										}}
										w="fit-content"
									>
										<Flex
											align="center"
											columnGap="xs"
											component={UnstyledButton}
											onClick={() => {
												setLoading(true);
												const timeout = setTimeout(
													() => setLoading(false),
													10000
												); // Set timeout to 10 seconds
												const pageToGo = `dashboard`; // No pre/trailing slashes
												if (isProductionEnvironment) {
													router.replace(
														`https://${type.id}.${window.location.host}/${pageToGo}`
													);
												} else {
													router.push(
														`http://${window.location.host}/${pageToGo}?theme=${type.id}`
													);
												}

												router.refresh();

												return () => clearTimeout(timeout); // Clear timeout on cleanup
											}}
											styles={{
												root: {
													cursor: selectedIndex === index ? "pointer" : "grab",
												},
											}}
										>
											<Title
												order={3}
												c={
													index === selectedIndex
														? type.theme?.colors?.branding?.[5] ?? "branding.5"
														: type.theme?.colors?.branding?.[3] ?? "branding.3"
												}
												size={isHovered ? "1.5em" : "1.3em"}
												lh="1.3em"
												tt="uppercase"
												fw="900"
												style={{
													transition: "font-size 0.3s ease-in-out", // Smooth opacity transition
												}}
											>
												{type.public_name_ends}
											</Title>
											<Box w="30px">
												<Transition
													mounted={
														ready && !hasInterracted && index === debouncedIndex
													}
													transition="fade"
													duration={500}
													enterDelay={200}
													exitDelay={300}
													exitDuration={200}
													timingFunction="ease"
												>
													{(styles) => (
														<div
															style={{
																display: "flex",
																justifyContent: "center",
																...styles,
															}}
														>
															<Stack
																gap={0}
																p={0}
																m={0}
															>
																<IconCaretUpDownFilled
																	size="1em"
																	style={{
																		animation: !hasInterracted
																			? "bounceVertically 0.5s ease-in-out 3"
																			: "none",
																	}}
																/>

																<style jsx>{`
																	@keyframes bounceVertically {
																		0%,
																		100% {
																			transform: translateY(+1px);
																		}
																		50% {
																			transform: translateY(-1px);
																		}
																	}
																`}</style>
															</Stack>
														</div>
													)}
												</Transition>
											</Box>
										</Flex>
									</Carousel.Slide>
								);
							})}
						</Carousel>
					</WdfLogo>
				</Flex>
			</GridCol>

			<GridCol span={24}>
				<Center>
					<Text
						c="gray"
						fw="lighter"
						size="sm"
					>
						<Link
							href="https://okedia.com"
							target="_blank"
						>
							Custom Websites
						</Link>{" "}
						&bull; <Link href="/terms">Terms & Conditions</Link> &bull;{" "}
						<Link href="/privacy">Privacy Policy</Link> &bull;{" "}
						<UnstyledButton onClick={() => showPreferences()}>
							Cookie Policy
						</UnstyledButton>
					</Text>
				</Center>
				<Center>
					<Text
						c="gray"
						fw="lighter"
						size="xs"
					>
						Created by <Text span>OKEDIA</Text>. &copy; 2025 OKEDIA - All Rights
						Reserved
					</Text>
				</Center>
			</GridCol>
		</Fragment>
	);
}
