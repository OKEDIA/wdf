"use server";

// React Imports
import { Suspense } from "react";

// Next.js Imports
import { SpeedInsights } from "@vercel/speed-insights/next";
import Head from "next/head";
import { headers } from "next/headers";

// Lower Order Components
import { VerifyEmailPopup } from "./VerifyEmailPopup";

// UI Components & Icons
//  prettier-ignore
import "@mantine/core/styles.css";
import "@mantine/dates/styles.css";
import "@mantine/dropzone/styles.css";
import "@mantine/notifications/styles.css";
import "vanilla-cookieconsent/dist/cookieconsent.css";

//  prettier-ignore
import "../../globals.css";

import {
	ColorSchemeScript,
	createTheme,
	LoadingOverlay,
	MantineProvider,
	rem,
} from "@mantine/core";
import { DatesProvider } from "@mantine/dates";
import { ModalsProvider } from "@mantine/modals";
import { Notifications } from "@mantine/notifications";

// Context & Helpers
import { UserProvider } from "@/app/_context/User";
import { WebsiteProvider } from "@/app/_context/Websites";
import { getServerBrand } from "@/app/api/_helpers/branding";
import { checkUserAuthentication } from "@okedia/shared/firebase";

// Other libraries or utilities
import { getUser } from "@/app/api/_helpers/firebase_auth/admin";
import subscribe from "@/app/api/_helpers/sendy/subscribe";
import { initMongoose } from "@okedia/core/utils/initMongoose";
import { documentHelpers } from "@okedia/shared/database/documentHelpers";
import { useGlobalQueryParams } from "@okedia/shared/hooks";
import dayjs from "dayjs";
import "dayjs/locale/en-gb";
import customParseFormat from "dayjs/plugin/customParseFormat";

// Types
import { defaultNotificationsProps } from "@/app/_utilities/notificationsConfig";
import { LocalUser } from "@okedia/shared/types/authenticationTypes";
import { PaginitedMongoResponse } from "@okedia/shared/types/documentResponses";
import { MongoDocumentResponse } from "@okedia/shared/types/mongoTypes";
import { Production } from "@okedia/shared/types/productionTypes";
import { Profile } from "@okedia/shared/types/profileTypes";
import {
	Website,
	WebsiteFormConfiguration,
} from "@okedia/shared/types/websiteTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * A global container component that sets up the application's theme, authentication, and data fetching.
 * This component serves as the root wrapper for the application, providing context and styling.
 *
 * @component
 * @async
 *
 * @param {Object} props - Component props
 * @param {React.ReactNode} props.children - Child components to be wrapped by the GlobalContainer
 *
 * Features:
 * - Sets up base and brand-specific themes
 * - Handles user authentication
 * - Fetches user-related data (profiles, websites)
 * - Provides context through UserProvider and WebsiteProvider
 * - Configures Mantine theming
 * - Loads Figtree font family
 *
 * @returns {Promise<JSX.Element>} A Promise that resolves to the rendered container component
 *
 * @example
 * <GlobalContainer>
 *   <App />
 * </GlobalContainer>
 */
export default async function GlobalContainer({
	children,
}: Readonly<{
	children: React.ReactNode;
}>) {
	const currentUrl = (await headers()).get("x-current-url");
	if (!currentUrl) return;
	const url = new URL(currentUrl);
	const searchParams = new URLSearchParams(url.search);
	const globalParams = useGlobalQueryParams(searchParams);
	const queryParams = globalParams.mongoQuery();
	await initMongoose();

	const baseTheme = createTheme({
		primaryShade: 5,
		fontSizes: {
			sm: rem(15),
		},
		headings: {
			fontFamily: "Figtree, sans-serif",
			sizes: {
				h1: { fontWeight: "700" },
				h2: { fontWeight: "500" },
				h3: { fontWeight: "400" },
				h4: { fontWeight: "400" },
				h5: { fontWeight: "300" },
				h6: { fontWeight: "300" },
			},
		},
		fontFamily: "Figtree, sans-serif",
		black: "#404042",
	});

	const brand = await getServerBrand(currentUrl);
	const theme = createTheme({ ...baseTheme, ...brand.theme });

	// https://mantine.dev/dates/getting-started/#custom-parse-format
	dayjs.extend(customParseFormat);

	// Get User
	const { tokens } = await checkUserAuthentication();

	let websites: MongoDocumentResponse<Website<any[]>>[] = [];
	let profiles: MongoDocumentResponse<Profile<unknown[]>>[] = [];
	let productions: MongoDocumentResponse<Production>[] = [];
	let localUser: LocalUser | null = null;
	let type: WebsiteFormConfiguration | undefined = undefined;

	/**
	 * Fetches and assembles user-related data from the database when a user is authenticated.
	 *
	 * This asynchronous function performs the following operations:
	 * 1. Retrieves local user data using the Firebase user's decoded token
	 * 2. If the user has profiles:
	 *    - Fetches each profile's data
	 *    - For profiles with websites:
	 *      - Retrieves website data
	 *      - Merges profile and website data into a combined object
	 * 3. Fetches website type information based on brand ID
	 *
	 * @async
	 * @function fetchUserData
	 * @requires user.decodedToken - Firebase decoded token containing uid
	 * @requires documentHelpers - Database interaction utility
	 * @requires ObjectId - MongoDB ObjectId type
	 * @mutates {Array} profiles - Stores fetched profile data
	 * @mutates {Array} websites - Stores merged profile and website data
	 * @mutates {WebsiteType} type - Stores fetched website type information
	 * @throws Will throw an error if database operations fail
	 */
	async function fetchUserData() {
		if (tokens?.decodedToken) {
			const user = await getUser(tokens?.decodedToken?.uid);

			// Ensure the user is subscribed to Sendy Users
			// Sending this every time will also update "last activity" in Sendy
			// Which allows segmenting of users based on last signed in activity
			// No need to await this as nothing depends on its response

			subscribe({
				email: tokens?.decodedToken?.email,
				name: tokens?.decodedToken?.name,
				list: process.env.SENDY_USERS_LIST_ID,
				referrer: "https://wdf.site",
			});

			if (!user) {
				return;
			}

			// Get the users data (local user data rather than firebase user data) from the database (profiles, websites etc)
			localUser = await documentHelpers
				.find<LocalUser>({
					collectionName: "users",
					filter: { firebaseUID: user?.uid },
					paginition: {
						limit: 1,
						startAfter: 0,
						callback: queryParams.paginition.callback,
					},
					expand: [
						{
							from: "profiles",
							localField: "profiles",
							foreignField: "_id",
							as: "profiles",
						},
						{
							from: "websites",
							localField: "websites",
							foreignField: "_id",
							as: "websites",
						},
						{
							from: "productions",
							localField: "productions",
							foreignField: "_id",
							as: "productions",
						},
					],
				})
				.then((res) => res as LocalUser);

			// Get a list of profiles, filtered by if the user can edit them
			// Expand the profiles to include the websites
			const profilesUserCanEdit = await documentHelpers
				.find<Profile<unknown>[]>({
					...queryParams,
					collectionName: "profiles",
					filter: {
						$or: [
							{ "permissions.owners": user?.customClaims?.localUID ?? "" },
							{ "permissions.editors": user?.customClaims?.localUID ?? "" },
						],
					},
					expand: [
						{
							from: "websites",
							localField: "websites",
							foreignField: "_id",
							as: "websites",
						},
					],
				})
				.then(
					(res) => res as unknown as PaginitedMongoResponse<Profile<unknown>>
				);
			profiles = profilesUserCanEdit.data as unknown as MongoDocumentResponse<
				Profile<unknown[]>
			>[];

			// With the expanded profiles, set the websites from the profiles
			profiles.forEach((profile) => {
				if (profile?.websites && profile?.websites.length > 0) {
					websites = websites.concat(
						profile?.websites?.filter(
							(website): website is MongoDocumentResponse<Website<any[]>> =>
								typeof website !== "string"
						) as MongoDocumentResponse<Website<any[]>>[]
					);
					profile.websites.filter(
						(website): website is Website<unknown> =>
							typeof website !== "string"
					);
				}
			});
			type = await documentHelpers
				.find<WebsiteFormConfiguration>({
					collectionName: "forms",
					...queryParams,
					filter: { id: searchParams.get("type") },
					paginition: {
						limit: 1,
						startAfter: 0,
						callback: queryParams.paginition.callback,
					},
				})
				.then((res) => res as WebsiteFormConfiguration);
		}
	}

	await fetchUserData();

	// Get Types
	return (
		<>
			<Head>
				<ColorSchemeScript defaultColorScheme="auto" />
				<link
					rel="icon"
					href="/static/favicon.ico"
				/>
			</Head>
			<body>
				<MantineProvider theme={theme}>
					<Notifications {...defaultNotificationsProps} />
					<ModalsProvider
						modalProps={{ size: "lg" }}
						modals={{
							verifyEmail: VerifyEmailPopup,
						}}
					>
						<DatesProvider
							settings={{
								consistentWeeks: true,
								locale: "en-gb",
								timezone: "etc/utc",
							}}
						>
							<Suspense fallback={<LoadingOverlay visible />}>
								<UserProvider tokens={tokens}>
									<WebsiteProvider
										currentBrand={brand}
										websites={websites}
										profiles={profiles}
										user={tokens}
										type={type}
									>
										{children}
										{/* Vercel Speed Insights */}
										<SpeedInsights />
									</WebsiteProvider>
								</UserProvider>
								<link
									href="https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,300..900;1,300..900&display=swap"
									rel="stylesheet"
								/>
							</Suspense>
						</DatesProvider>
					</ModalsProvider>
				</MantineProvider>
				<script
					async
					src="https://creativeindustries.group/hub/addons/Channels/HelpWidget/Views/js/supportpal.min.js?v=5.6.1"
				></script>
				<script>
					{`
						window.supportpalAsyncInit = function () {
							window.SupportPal.mount({
								baseURL: "https://creativeindustries.group/hub/en/helpwidget",
								hash: "KAoCWPAXCz",
								colour: \`#404042\`,
								knowledgebase: {
									enabled: true,
									typeId: "6"
								},
								submitTicket: {
									enabled: true,
									departmentId: "6",
									subject: true,
									defaults: {
										${tokens?.decodedToken.email ? `email: "${tokens?.decodedToken.email}",` : ""}
										${tokens?.decodedToken.name ? `name: "${tokens?.decodedToken.name}",` : ""}

									}
								},
								type: "popup",
								position: "right",
								buttonIcon: "lifebuoy",
								
							});
						};
					`}
				</script>
			</body>
		</>
	);
}
