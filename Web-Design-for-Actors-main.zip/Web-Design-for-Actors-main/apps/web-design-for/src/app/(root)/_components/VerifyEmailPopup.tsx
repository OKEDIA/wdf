"use client";

// React Imports
import { useState, useTransition } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { Alert, Button, Text, useMantineTheme } from "@mantine/core";

// Context & Helpers

// Other libraries or utilities
import { firebaseAuthErrorsMap } from "@/app/_utilities/authenticationFunctions";
import { defaultNotificationProps } from "@/app/_utilities/notificationsConfig";
import { sendEmailVerificationLink } from "@/app/_utilities/serverAuthFunctions";
import { notifications } from "@mantine/notifications";

// Types
import { ContextModalProps } from "@mantine/modals";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export function VerifyEmailPopup({
	context,
	id,
	innerProps,
}: ContextModalProps<{ modalBody: string; email: string }>) {
	const [isPending, startTransition] = useTransition();
	const [error, setError] = useState<string | null>(null);
	const theme = useMantineTheme();
	return (
		<>
			<Text size="sm">{innerProps.modalBody}</Text>
			<Button
				fullWidth
				mt="md"
				loading={isPending}
				onClick={() => {
					setError(null);
					startTransition(async () => {
						return await sendEmailVerificationLink({
							to: innerProps.email,
							brand: theme.other.id,
						})
							.then(() => {
								notifications.show({
									...defaultNotificationProps,
									title: "Verification Email Sent",
									message:
										"Please click on the link we sent to your email inbox. It may take a few minutes to arrive.",
								});
								context.closeModal(id);
							})
							.catch((error: { code: keyof typeof firebaseAuthErrorsMap }) => {
								if (error.code in firebaseAuthErrorsMap) {
									setError(firebaseAuthErrorsMap[error.code]);
								} else {
									console.error("Error signing in with provider:", error);
									setError(
										"An unexpected error occured when sending the email. Please ensure your email address is correcy and contact support if the problem persists."
									);
								}
							});
					});
				}}
			>
				Send Verification Link to {innerProps.email}
			</Button>
			{error && (
				<Alert
					mt="lg"
					color="yellow"
					title="There was an error"
				>
					{error}
				</Alert>
			)}
		</>
	);
}
