// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import {
	Flex,
	FlexProps,
	PolymorphicComponentProps,
	Stack,
	Title,
} from "@mantine/core";

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function WdfLogo(
	props: PolymorphicComponentProps<"div", FlexProps>
) {
	return (
		<Flex
			{...props}
			align="center"
			justify="center"
			gap={0}
			style={props.style ? props.style : { scale: 1.5 }}
		>
			<Flex align="center">
				<Stack
					gap={0}
					mr="xs"
					h="100%"
					styles={{
						root: {
							paddingRight: "5px",
							borderRight: `4px solid`,
						},
					}}
				>
					<Title
						px="0"
						m="0"
						order={6}
						ta="right"
						fw="bold"
						styles={{
							root: {
								lineHeight: "100%",
							},
						}}
					>
						WEB
					</Title>

					<Title
						px="0"
						m="0"
						order={6}
						ta="right"
						fw="bold"
						styles={{
							root: {
								lineHeight: "100%",
							},
						}}
					>
						DESIGN
					</Title>

					<Title
						px="0"
						m="0"
						order={6}
						ta="right"
						fw="bold"
						styles={{
							root: {
								lineHeight: "100%",
							},
						}}
					>
						FOR
					</Title>
				</Stack>
				{props?.children}
			</Flex>
		</Flex>
	);
}
