// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import whoisFromVercel from "@/app/api/_helpers/vercel/whois";
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { generateApiResponse as response } from "@okedia/shared/helpers";

// Types
import { NextRequest, NextResponse } from "next/server";
import { handleError } from "@okedia/shared/logging";
import { apiLogging } from "@okedia/shared/logging/api";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Handles GET requests for performing a WHOIS lookup on a domain name.
 *
 * @param {NextRequest} req - The incoming request object.
 * @param {NextResponse} res - The outgoing response object.
 * @returns {Promise<NextResponse>} The response object containing the WHOIS lookup result or an error message.
 *
 * @throws {Error} If an unexpected error occurs during the WHOIS lookup process.
 */
export async function GET(
	req: NextRequest,
	{ params }: { params: Promise<{ pathParams?: string[] }> }
) {
	try {
		const domainName = (await params).pathParams?.[0];
		const { isAuthenticated, tokens } = await checkUserAuthentication();
		const logger = await apiLogging(req, tokens);

		if (!isAuthenticated) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		if (!domainName) {
			logger.custom.debug("Missing required data (domainName).");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		const data = await whoisFromVercel(req, domainName);

		return response(NextResponse, 200, data);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}
