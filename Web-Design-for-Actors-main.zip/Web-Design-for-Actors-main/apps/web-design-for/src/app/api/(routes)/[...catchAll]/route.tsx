/**
 * Catch-al route for any routes that do not exist. Returns a 404 error.
 *
 * @returns {NextResponse} The response object.
 */

// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities

// Types
import { NextResponse } from "next/server";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export function GET() {
	return NextResponse.json({ error: "API route not found" }, { status: 404 });
}

export function POST() {
	return NextResponse.json({ error: "API route not found" }, { status: 404 });
}

export function PUT() {
	return NextResponse.json({ error: "API route not found" }, { status: 404 });
}

export function DELETE() {
	return NextResponse.json({ error: "API route not found" }, { status: 404 });
}
