// React Imports

// Next.js Imports
import { NextRequest, NextResponse } from "next/server";

// Firebase Imports

// Helpers
import { signInWithCustomToken } from "firebase/auth";
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { authForClientSide } from "@okedia/shared/firebase/standard";
import { generateApiResponse as response } from "@okedia/shared/helpers";
import { isProductionEnvironment } from "@okedia/shared/helpers/isProductionEnvironment";
import { handleError } from "@okedia/shared/logging";
import { apiLogging } from "@okedia/shared/logging/api";
import { createCustomToken } from "../../../_helpers/firebase_auth/admin";

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Handles the POST request for the development session authentication.
 *
 * This function is intended to be used only in a development environment.
 * It checks for the presence of required environment variables and validates
 * the provided authentication key. If the key is valid, it generates a custom
 * token and signs in the user with that token, returning the ID token.
 *
 * @param {NextRequest} req - The incoming request object.
 * @returns {Promise<NextResponse>} - The response object with the appropriate status and message.
 *
 * @throws {Error} - If an error occurs during the authentication process.
 */
export async function POST(req: NextRequest) {
	const { tokens } = await checkUserAuthentication();
	const logger = await apiLogging(req, tokens);
	if (isProductionEnvironment) {
		// Do not allow this method if in production environment
		logger.custom.error(
			"Development Session API Endpoint was attempted to be accessed in Production Mode."
		);
		return logger.error({
			response: {
				instance: NextResponse,
				status: 405,
			},
		});
	}
	const devKey = process.env.DEV_BYPASS_KEY as string;
	const devUser = process.env.DEV_USER_ID as string;

	if (!devKey || !devUser) {
		return logger.error({
			response: {
				instance: NextResponse,
				status: 401,
				message: "Missing Required Environment Variables",
			},
		});
	}

	try {
		const authKey = req.nextUrl.searchParams.get("authKey") as string;

		if (!authKey) {
			logger.custom.debug("Missing required data (authKey).");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		if (authKey !== devKey) {
			logger.custom.debug("Invalid authKey provided.");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		logger.custom.debug("Generating custom token for dev user.");
		const customToken = await createCustomToken(devUser);

		logger.custom.debug("Signing in with custom token.");
		const auth = await signInWithCustomToken(authForClientSide, customToken);

		logger.custom.debug("Login Successful");
		const idToken = await auth.user.getIdToken();

		return response(NextResponse, 200, idToken);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}
