// React Imports

// Next.js Imports
import { NextRequest, NextResponse } from "next/server";

// Firebase Imports

// Helpers
import { getAllUsers } from "@/app/api/_helpers/firebase_auth/getAllusers";
import { refreshNextResponseCookiesWithToken } from "next-firebase-auth-edge/lib/next/cookies";
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { generateApiResponse as response } from "@okedia/shared/helpers";

// Other libraries or utilities
import { documentHelpers } from "@okedia/shared/database";
import { useGlobalQueryParams } from "@okedia/shared/hooks";
import {
	deleteUser,
	getUser,
	getUserByEmail,
	setCustomUserClaims,
	updateUser,
} from "../../../../_helpers/firebase_auth/admin";

// Types
import { commonOptions } from "@/middleware";
import { handleError } from "@okedia/shared/logging";
import { apiLogging } from "@okedia/shared/logging/api";
import { LocalUser } from "@okedia/shared/types/authenticationTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Handles GET requests for user authentication and retrieval.
 *
 * @param req - The incoming request object.
 * @param res - The outgoing response object.
 * @returns A promise that resolves to a NextResponse object.
 *
 * The function performs the following operations:
 * - Checks user authentication and authorization.
 * - If the user is not an admin or not authenticated, returns a 403 response.
 * - If the `method` query parameter is "all", retrieves all users with pagination.
 * - If the `method` or `id` query parameters are missing, returns a 400 response.
 * - If the `method` query parameter is "email", retrieves a user by email.
 * - If the `method` query parameter is "uid", retrieves a user by UID.
 * - Catches any errors and returns a 520 response with the error message.
 */
export async function GET(
	req: NextRequest,
	{ params }: { params: Promise<{ pathParams?: string[] }> }
) {
	try {
		const method = req.nextUrl.searchParams.get("method") as string;
		const userId = (await params).pathParams?.[0];
		const { isAdmin, isAuthenticated, tokens } =
			await checkUserAuthentication();
		const logger = await apiLogging(req, tokens);
		const globalQuery = useGlobalQueryParams(req.nextUrl.searchParams);
		const queryParams = globalQuery.parse();

		if (!isAdmin || !isAuthenticated) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		if (method === "all") {
			logger.custom.info("Fetching all Users");
			const data = await getAllUsers({
				req,
				paginition: {
					startAfter: queryParams.afterId,
					limit: queryParams.limit,
				},
			});

			return response(NextResponse, 200, {
				...data,
				paginition: globalQuery.paginitionResult({
					body: data?.users,
					idSelector: "uid",
					count: data.users?.length,
				}),
			});
		}

		if (!method || !userId) {
			logger.custom.debug(
				"Missing required data (method|userId) and did not have method=all."
			);
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		if (method === "email") {
			logger.custom.info("Fetching user by email");
			return response(
				NextResponse,
				200,
				await getUserByEmail(decodeURIComponent(userId))
			);
		}

		if (method === "uid") {
			logger.custom.info("Fetching user by uid");
			return response(NextResponse, 200, await getUser(userId));
		}
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}

/**
 * Handles the PATCH request to update user information.
 *
 * @param {NextRequest} req - The incoming request object.
 * @param {NextResponse} res - The outgoing response object.
 * @returns {Promise<NextResponse>} - The response object with the status and data.
 *
 * @throws {Error} - Throws an error if the request fails.
 *
 * The function performs the following steps:
 * 1. Extracts the user ID from the request URL search parameters.
 * 2. Parses the request body to get the user data.
 * 3. Checks if the user is authenticated and authorized to perform the update.
 * 4. If the user is not authenticated or authorized, returns a 403 response.
 * 5. If the user is authenticated and authorized, updates the user information.
 * 6. Returns a 200 response with the updated user data.
 * 7. If an error occurs, returns a 520 response with the error message.
 */
export async function PATCH(
	req: NextRequest,
	{ params }: { params: Promise<{ pathParams?: string[] }> }
) {
	try {
		const userId = (await params).pathParams?.[0];
		let body = await req.json();

		const { isAdmin, isAuthenticated, tokens } =
			await checkUserAuthentication();
		const logger = await apiLogging(req, tokens);

		if (!userId) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		if (!isAuthenticated) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		if (!isAdmin && userId !== tokens?.decodedToken.uid) {
			// Non-administrative user attempting to edit another user
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		if (!isAdmin && (body.disabled || body.emailVerified)) {
			// OR Non-administrative user attempting to set privelaged values
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}
		const data = await updateUser(userId, { ...body });

		return response(NextResponse, 200, data);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}

/**
 * Handles the DELETE request to delete a user.
 *
 * @param {NextRequest} req - The incoming request object.
 * @returns {Promise<NextResponse>} The response object indicating the result of the delete operation.
 *
 * @throws {Error} If an error occurs during the delete operation.
 *
 * The function performs the following steps:
 * 1. Extracts the user ID from the request URL search parameters.
 * 2. Checks user authentication and authorization.
 * 3. If the user is not authenticated, returns a 403 response.
 * 4. If the user is not an admin and is attempting to delete another user, returns a 403 response.
 * 5. Deletes the user with the specified ID.
 * 6. Returns a 200 response with the result of the delete operation.
 * 7. If an error occurs, returns a 520 response with the error message.
 */
export async function DELETE(req: NextRequest) {
	try {
		const id = req.nextUrl.searchParams.get("id") as string;

		const { isAdmin, isAuthenticated, tokens } =
			await checkUserAuthentication();
		const logger = await apiLogging(req, tokens);

		if (!isAuthenticated) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		if (!isAdmin && id !== tokens?.decodedToken.uid) {
			// Non-administrative user attempting to edit another user
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		const data = await deleteUser(id);

		return response(NextResponse, 200, data);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}

/**
 * Handles the POST request for user authentication and creation.
 *
 * @param {NextRequest} req - The incoming request object.
 * @returns {Promise<NextResponse>} - The response object with the appropriate status and message.
 *
 * @throws {Error} - If an error occurs during the process.
 *
 * The function performs the following steps:
 * 1. Checks user authentication and retrieves tokens.
 * 2. Parses the request body to get the user ID.
 * 3. Validates the presence of the user ID in the request body.
 * 4. Retrieves user data based on the user ID.
 * 5. Validates the authentication status, tokens, user data, and whether the request is for a different user.
 * 6. Creates a new user document in the "users" collection.
 * 7. Merges custom claims with the new user document ID.
 * 8. Sets custom user claims for the user.
 * 9. Returns a response with status 200 on success.
 * 10. Catches and logs any errors, returning a response with status 520 and the error message.
 */
export async function POST(req: NextRequest) {
	try {
		const { isAdmin, isAuthenticated, tokens } =
			await checkUserAuthentication();

		const logger = await apiLogging(req, tokens);

		if (!isAuthenticated || !tokens?.token) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		const body = await req.json();

		if (!body.uid) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		const userData = await getUser(body.uid);

		if (!userData) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		const newUserDoc = await documentHelpers.create<LocalUser>({
			collectionName: "users",
			body: { firebaseUID: body.uid },
		});

		const mergedClaims = {
			...(userData?.customClaims || {}),
			localUID: newUserDoc.id,
			profiles: [],
			websites: [],
		};

		await setCustomUserClaims(userData.uid, { ...mergedClaims });

		const res = response(NextResponse, 200, newUserDoc);

		return refreshNextResponseCookiesWithToken(
			tokens.token,
			req,
			res,
			commonOptions
		);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}
