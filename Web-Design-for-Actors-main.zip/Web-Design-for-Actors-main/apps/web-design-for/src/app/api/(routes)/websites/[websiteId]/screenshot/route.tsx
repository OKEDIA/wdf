// React Imports

// Next.js Imports
import * as https from "https";
import { NextRequest, NextResponse } from "next/server";

// Firebase Imports

// Helpers
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { firebaseAdmin } from "@okedia/shared/firebase/admin";
import {
	isProductionEnvironment,
	generateApiResponse as response,
} from "@okedia/shared/helpers";
import { useServersideDatabase } from "@okedia/shared/hooks/database/useServersideDatabase";
import { handleError } from "@okedia/shared/logging";
import { apiLogging } from "@okedia/shared/logging/api";

// Other libraries or utilities

// Types
import { ScreenshotResponse } from "@okedia/shared/types/fileTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Handles the GET request for retrieving or generating a website screenshot.
 *
 * @param req - The incoming `NextRequest` object containing request details.
 * @param context - An object containing route parameters, including `websiteId`.
 * @returns A `NextResponse` object containing the screenshot metadata and public URL.
 *
 * @throws Will handle and log any errors that occur during the process.
 *
 * ### Process:
 * 1. Authenticates the user and retrieves user tokens.
 * 2. Logs the request details using a custom logger.
 * 3. Extracts query parameters (`brand`, `template`, `colorScheme`) and `websiteId` from the request.
 * 4. Checks if the requested screenshot already exists in Firestore storage:
 *    - If it exists, retrieves its metadata and public URL and returns them.
 *    - If it does not exist, generates a new screenshot using an external API.
 * 5. Converts the generated screenshot into a buffer and uploads it to Firestore storage.
 * 6. Returns the metadata and public URL of the uploaded screenshot.
 *
 * ### Query Parameters:
 * - `brand` - The brand associated with the screenshot.
 * - `template` - The template used for the website.
 * - `colorScheme` - The color scheme of the website.
 *
 * ### Route Parameters:
 * - `websiteId` - The domain or identifier for the website.
 *
 * ### External Dependencies:
 * - `checkUserAuthentication` - Validates user authentication and retrieves user tokens.
 * - `apiLogging` - Logs request details for debugging and monitoring.
 * - `firebaseAdmin` - Provides access to Firestore storage.
 * - `useServersideDatabase` - Interacts with the screenshot generation API.
 * - `https` - Fetches the generated screenshot from the external API.
 *
 * ### Error Handling:
 * - Logs and handles errors using `handleError` to ensure proper response and debugging.
 */
export async function GET(
	req: NextRequest,
	{ params }: { params: Promise<{ websiteId: string }> }
) {
	try {
		const {
			isAuthenticated,
			isAdmin,
			tokens: user,
		} = await checkUserAuthentication();
		const logger = await apiLogging(req, user);
		const domain = (await params).websiteId; //websiteId is the domain for this method
		const brand = req.nextUrl.searchParams.get("brand");
		const template = req.nextUrl.searchParams.get("template");
		const colorScheme = req.nextUrl.searchParams.get("colorScheme");
		const firestore = (await firebaseAdmin()).storage().bucket();
		const fileRef = firestore.file(
			`website-screenshots/${brand}/${template}/${colorScheme}.png`
		);
		const [exists] = await fileRef.exists();
		logger.custom.debug(
			{ domain, brand, template, colorScheme },
			"User has requested a website screenshot"
		);

		// if (!isAuthenticated) {
		// 	return response(NextResponse, 403);
		// }

		if (exists) {
			logger.custom.debug("File already exists, returning existing file");
			const publicUrl = fileRef.publicUrl();
			const [metadata] = await fileRef.getMetadata();
			const res = {
				...metadata,
				downloadUrl: publicUrl,
			};
			return response(NextResponse, 200, res);
		} else {
			if (!isProductionEnvironment) {
				throw new Error(
					"Screenshot generation is not allowed in development to prevent unnecessary API Calls"
				);
			}
			logger.custom.debug("Screenshot does not exist, creating new screenshot");

			const db = useServersideDatabase(
				process.env.SCREENSHOT_API_URL as string,
				"screenshot"
			);

			const url = `https://${domain}/?brand=${brand}&template=${template}&colorScheme=${colorScheme}`;
			logger.custom.info(`Generating a screenshot for the URL ${url}`);

			const screenshot = await db.post<ScreenshotResponse>({
				url: "/screenshot",
				body: {
					url,
					wait: 5,
					full_page: false,
					return_as_file: false,
				},
			});

			logger.custom.debug(
				screenshot,
				"Screenshot generated, converting into a Buffer"
			);

			const screenshotBuffer = await new Promise<Buffer>((resolve, reject) => {
				https.get(screenshot.screenshot_url, (response) => {
					const chunks: Buffer[] = [];

					// Collect data chunks
					response.on("data", (chunk) => {
						chunks.push(chunk);
					});

					// Once the response is complete, resolve the buffer
					response.on("end", () => {
						resolve(Buffer.concat(chunks));
					});

					// Handle errors
					response.on("error", (err) => {
						reject(err);
					});
				});
			});
			logger.custom.debug("Screenshot buffer created, uploading to Firestore");

			await fileRef.save(screenshotBuffer, {
				contentType: "image/png",
				public: true,
			});

			logger.custom.debug("Screenshot uploaded, generating public URL");

			const publicUrl = fileRef.publicUrl();
			const [metadata] = await fileRef.getMetadata();
			const res = {
				...metadata,
				downloadUurl: publicUrl,
			};
			logger.custom.debug(res, "Returning file metadata to user");
			return response(NextResponse, 200, res);
		}
	} catch (e: any) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}
