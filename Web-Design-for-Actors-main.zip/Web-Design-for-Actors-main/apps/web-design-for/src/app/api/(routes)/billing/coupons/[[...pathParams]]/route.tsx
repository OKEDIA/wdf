// React Imports

// Next.js Imports
import { NextRequest, NextResponse } from "next/server";

// Firebase Imports

// Helpers

// Other libraries or utilities
import getCouponById from "@/app/api/_helpers/billing/getCouponById";
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { generateApiResponse as response } from "@okedia/shared/helpers";
import { handleError } from "@okedia/shared/logging";
import { apiLogging } from "@okedia/shared/logging/api";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Handles the GET request to retrieve a coupon by its code.
 *
 * @param {NextRequest} req - The incoming request object.
 * @param {NextResponse} res - The outgoing response object.
 * @returns {Promise<NextResponse>} The response containing the coupon data or an error message.
 *
 * @throws {Error} If an unexpected error occurs during the process.
 */
export async function GET(
	req: NextRequest,
	{ params }: { params: Promise<{ pathParams?: string[] }> }
) {
	try {
		const couponCode = (await params).pathParams?.[0];
		const { isAuthenticated, tokens } = await checkUserAuthentication();
		const logger = await apiLogging(req, tokens);

		if (!isAuthenticated) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		if (!couponCode) {
			logger.custom.debug("Missing required data (couponCode).");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		const data = await getCouponById(couponCode);

		return response(NextResponse, 200, data);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}
