// React Imports

// Next.js Imports
import { NextRequest, NextResponse } from "next/server";

// Firebase Imports

// Helpers
import findCustomer from "@/app/api/_helpers/billing/findACustomer";
import findSubscription from "@/app/api/_helpers/billing/findASubscription";
import getCustomerSubscriptions from "@/app/api/_helpers/billing/getSubscriptions";
import removeSubscription from "@/app/api/_helpers/billing/removeSubscription";
import updateSubscription from "@/app/api/_helpers/billing/updateSubscription";
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { generateApiResponse as response } from "@okedia/shared/helpers";

// Other libraries or utilities

// Types
import getCustomer from "@/app/api/_helpers/billing/getACustomer";
import getSubscription from "@/app/api/_helpers/billing/getASubscription";
import { useGlobalQueryParams } from "@okedia/shared/hooks";
import { handleError } from "@okedia/shared/logging";
import { apiLogging } from "@okedia/shared/logging/api";
import Stripe from "stripe";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Handles GET requests to retrieve customer subscription information.
 *
 * @param {NextRequest} req - The incoming request object.
 * @param {NextResponse} res - The outgoing response object.
 * @returns {Promise<NextResponse>} - The response containing the subscription data or an error message.
 *
 * The function performs the following steps:
 * 1. Extracts `customerId`, `domain`, and `websiteId` from the request's query parameters.
 * 2. Checks user authentication.
 * 3. If the user is not authenticated, returns a 403 response.
 * 4. If `customerId` is provided:
 *    - Retrieves the customer data.
 *    - Checks if the customer metadata contains `firebaseUID`.
 *    - Verifies if the authenticated user's UID matches the customer's UID.
 *    - Retrieves and returns the customer's subscription data.
 * 5. If `domain` is provided and `websiteId` is not:
 *    - Retrieves and returns the subscription data based on the domain.
 * 6. If `websiteId` is provided and `domain` is not:
 *    - Retrieves and returns the subscription data based on the websiteId.
 * 7. If both `domain` and `websiteId` are provided, returns a 405 response indicating that only one should be provided.
 * 8. Catches any errors and returns a 520 response with the error message.
 */
export async function GET(
	req: NextRequest,
	{ params }: { params: Promise<{ customerId: string; pathParams?: string[] }> }
) {
	try {
		const customerId = (await params).customerId;
		const subscriptionId = (await params).pathParams?.[0];
		const globalQuery = useGlobalQueryParams(req.nextUrl.searchParams);
		const queryParams = globalQuery.parse();
		const { isAuthenticated, tokens } = await checkUserAuthentication();
		const logger = await apiLogging(req, tokens);

		if (!isAuthenticated) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		if (!customerId) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		const customerData = await getCustomer(customerId);

		if (!("metadata" in customerData)) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 500,
				},
			});
		}

		const firebaseUIDAtStripe = customerData.metadata.firebaseUID;

		if (subscriptionId) {
			const data = await findSubscription({
				query: `id:\"${subscriptionId}\"`,
			});

			return response(NextResponse, 200, data);
		}

		if (tokens?.decodedToken.uid !== firebaseUIDAtStripe) {
			// Admins or other users cannot access other users' subscription info through their own account
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		if (Array.isArray(queryParams.filter)) {
			const data = await findSubscription({
				query: globalQuery.stripeQuery().filters,
			});

			return response(NextResponse, 200, data);
		}

		const data = await getCustomerSubscriptions({ customer: customerId });

		return response(NextResponse, 200, data);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}

/**
 * Handles the PATCH request to update a subscription.
 *
 * @param {NextRequest} req - The incoming request object.
 * @param {NextResponse} res - The outgoing response object.
 * @returns {Promise<NextResponse>} - The response object with the status and data.
 *
 * @throws {Error} - Throws an error if the request fails.
 *
 * The function performs the following steps:
 * 1. Extracts the subscription ID from the request URL.
 * 2. Parses the request body.
 * 3. Checks user authentication.
 * 4. Validates the presence of the user's email and subscription ID.
 * 5. Finds the customer based on the user's email.
 * 6. Validates the presence of customer metadata.
 * 7. Updates the subscription with the provided data.
 * 8. Returns the updated subscription data in the response.
 */
export async function PATCH(
	req: NextRequest,
	{ params }: { params: Promise<{ customerId: string; pathParams?: string[] }> }
) {
	try {
		const subscriptionId = (await params).pathParams?.[0];
		const body = await req.json();
		const { isAuthenticated, tokens: user } = await checkUserAuthentication();
		const logger = await apiLogging(req, user);

		if (!isAuthenticated) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		if (!user?.decodedToken.email || !subscriptionId) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		const customer = await findCustomer({
			query: `email:\"${user?.decodedToken.email}\"`,
		});

		const customerData = customer.data[0];
		if (!("metadata" in customerData)) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 500,
				},
			});
		}
		const firebaseUIDAtStripe = customerData.metadata.firebaseUID;

		// if (user?.decodedToken.uid !== firebaseUIDAtStripe) {
		// 	// Cannot update subscription of another customer
		// 	return response(NextResponse, 403);
		// }

		const data = await updateSubscription(subscriptionId, body);

		return response(NextResponse, 200, data);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}

/**
 * Handles the deletion of a subscription.
 *
 * @param {NextRequest} req - The incoming request object.
 * @param {NextResponse} res - The outgoing response object.
 * @returns {Promise<NextResponse>} - The response object indicating the result of the operation.
 *
 * @throws {Error} - If an error occurs during the deletion process.
 *
 * The function performs the following steps:
 * 1. Extracts the `subscriptionId` and `reason` from the request's query parameters.
 * 2. Checks user authentication and authorization.
 * 3. Validates the presence of the `subscriptionId`.
 * 4. Finds the subscription by its ID.
 * 5. Finds the customer associated with the authenticated user.
 * 6. Verifies that the authenticated user is authorized to cancel the subscription.
 * 7. Cancels the subscription and returns a success response.
 * 8. Handles any errors that occur during the process and returns an appropriate error response.
 */
export async function DELETE(
	req: NextRequest,
	{ params }: { params: Promise<{ customerId: string; pathParams?: string[] }> }
) {
	try {
		const customerId = (await params).customerId;
		const subscriptionId = (await params)?.pathParams?.[0];
		const reason = req.nextUrl.searchParams.get("reason") as
			| Stripe.SubscriptionCancelParams.CancellationDetails.Feedback
			| undefined;
		const {
			isAuthenticated,
			tokens: user,
			isAdmin,
		} = await checkUserAuthentication();
		const logger = await apiLogging(req, user);

		if (!isAuthenticated || !user?.decodedToken) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		if (!subscriptionId) {
			logger.custom.debug("Missing required data (subscriptionId).");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		const subscription = await getSubscription({
			id: subscriptionId,
		});

		if (!subscription.id) {
			logger.custom.debug("Subscription not found.");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 404,
				},
			});
		}

		const customer = await findCustomer({
			query: `metadata[\"firebaseUID\"]:\"${user.decodedToken.uid}\"`,
		});

		const customerData = customer.data[0];
		if (!("metadata" in customerData)) {
			logger.custom.debug(
				"The customer does not have metadata. There is likely an issue with the Stripe customer or local customer account."
			);
			return logger.error({
				response: {
					instance: NextResponse,
					status: 500,
				},
			});
		}
		const firebaseUIDAtStripe = customerData.metadata.firebaseUID;

		if (user?.decodedToken.uid !== firebaseUIDAtStripe && !isAdmin) {
			// Only admins can cancel a subscription for another customer
			logger.custom.debug("User does not have access to this subscription.");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		const data = await removeSubscription(subscriptionId, reason);

		return response(NextResponse, 200, data);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}
