// React Imports

// Next.js Imports
import { NextRequest, NextResponse } from "next/server";

// Firebase Imports

// Helpers
import { documentHelpers } from "@okedia/shared/database";
import { generateApiResponse as response } from "@okedia/shared/helpers";

// Other libraries or utilities
import { stripeAdmin } from "@okedia/shared/stripe";

// Types
import addDomainToVercel from "@/app/api/_helpers/vercel/addDomain";
import registerDomainWithVercel from "@/app/api/_helpers/vercel/registerDomain";
import removeDomainFromVercel from "@/app/api/_helpers/vercel/removeDomain";
import updateVercelDomain from "@/app/api/_helpers/vercel/updateDomain";
import { useGlobalQueryParams } from "@okedia/shared/hooks";
import { handleError } from "@okedia/shared/logging";
import { apiLogging } from "@okedia/shared/logging/api";
import {
	Website,
	WebsiteFormConfiguration,
} from "@okedia/shared/types/websiteTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Handles incoming POST requests for Stripe webhooks.
 *
 * @param {NextRequest} req - The incoming request object.
 * @returns {Promise<NextResponse>} - The response to be sent back to the client.
 *
 * This function processes various Stripe webhook events such as:
 * - `customer.subscription.created`: Handles actions when a subscription is created.
 * - `invoice.payment_succeeded`: Handles actions when an invoice payment succeeds.
 * - `customer.subscription.updated`: Handles actions when a subscription is updated.
 * - `customer.subscription.deleted`: Handles actions when a subscription is deleted.
 *
 * Each event type triggers specific actions such as updating website data, managing domain aliases,
 * and registering or renewing domains.
 *
 * If an error occurs during processing, a 520 status code is returned along with the error message.
 */
export async function POST(req: NextRequest) {
	try {
		const logger = await apiLogging(req);
		const sig = req.headers.get("stripe-signature") as string;
		const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET as string;
		let event;
		const globalQuery = useGlobalQueryParams(new URLSearchParams());
		const mongoQuery = globalQuery.mongoQuery();

		event = stripeAdmin.webhooks.constructEvent(
			await req.text(),
			sig,
			endpointSecret
		);

		// Handle the event
		switch (event.type) {
			case "customer.subscription.created": {
				logger.custom.info("[Webhook] Subscription Created");
				const website = await documentHelpers.get<Website<unknown>>({
					collectionName: "websites",
					documentName: event.data.object.metadata.websiteId,
				});

				const websiteType =
					(await documentHelpers.find<WebsiteFormConfiguration>({
						...mongoQuery,
						collectionName: "forms",
						filter: { id: website.type },
						paginition: { ...mongoQuery.paginition, limit: 1 },
					})) as WebsiteFormConfiguration;

				const domain = event.data.object.metadata.domain;
				const isTemporaryDomain = domain.endsWith(websiteType.data.tld);

				// Register the domain name
				if (!isTemporaryDomain) {
					logger.custom.info(domain, "[Webhook] Registering Domain Name");
					await registerDomainWithVercel(req, domain);

					logger.custom.info(domain, "[Webhook] Adding Domain To Vercel");
					await addDomainToVercel(req, domain);
				}

				// Add the domain alias

				logger.custom.info(
					event.data.object.id,
					"[Webhook] Updating the website data with Subscription ID"
				);
				await documentHelpers.update<Website<unknown>>({
					collectionName: "websites",
					documentName: event.data.object.metadata.websiteId,
					body: {
						...website,
						domain: domain,
						subscriptionId: event.data.object.id,
					},
				});

				logger.custom.info("[Webhook] Finished");

				break;
			}

			case "invoice.payment_succeeded": {
				logger.custom.info("[Webhook] Invoice Payment Succeeded");
				const invoiceData = event.data.object;
				const prevData = event.data.previous_attributes;

				const getSubscription = async () => {
					const subscription = invoiceData.subscription;
					if (typeof subscription === "string") {
						logger.custom.info(
							"[Webhook] Subscription not found, getting it from Stripe"
						);
						return await stripeAdmin.subscriptions.retrieve(subscription);
					} else {
						return subscription;
					}
				};

				const subscription = await getSubscription();
				logger.custom.info(
					subscription?.id,
					"[Webhook] Subscription Found, getting website data"
				);

				if (!subscription) {
					throw new Error("Unable to get subscription from invoice data.");
				}

				const website = await documentHelpers.get<Website<unknown>>({
					collectionName: "websites",
					documentName: subscription.metadata.websiteId,
				});

				const websiteType =
				(await documentHelpers.find<WebsiteFormConfiguration>({
						...mongoQuery,
						collectionName: "forms",
						filter: { id: website.type },
						paginition: { ...mongoQuery.paginition, limit: 1 },
					})) as WebsiteFormConfiguration;

				invoiceData.lines.data.forEach(async (paidItem) => {
					const domain = paidItem.metadata?.domain;
					const isTemporaryDomain = domain?.endsWith(websiteType.data.tld);

					if (invoiceData.billing_reason === "subscription_cycle") {
						logger.custom.info("[Webhook] Reason: Subscription Cycled");
					}

					if (invoiceData.billing_reason === "subscription_update") {
						logger.custom.info("[Webhook] Reason: Subscription Updated");

						logger.custom.info(`[Webhook] Checking Domain Name ${domain} againts ${website.domain}`)
						if (domain !== website.domain) {
							logger.custom.info("[Webhook] Detected New Domain Name");
							if (!isTemporaryDomain) {
								logger.custom.info("Registering New Domain", domain);
								await registerDomainWithVercel(req, domain).then((res) => logger.custom.info(res))
								
								if ( !website.domain.endsWith( websiteType.data.tld ) ) {
									await removeDomainFromVercel( req, website.domain ).catch( err => logger.custom.warn( "Error removing domain from Vercel", err ) );
								}
								
								logger.custom.info(
									"Updating Domain Alias",
									website.domain,
									domain
								);
								await addDomainToVercel(req, domain);
							}
						}

						if (website.package !== paidItem.plan?.nickname) {
							logger.custom.info("[Webhook] Updating Website Plan");
						}

						await documentHelpers.update<Partial<Website<unknown>>>({
							collectionName: "websites",
							documentName: website.id as string,
							body: {
								...website,
								status: "online",
								domain: domain,
								package: paidItem.plan?.nickname ?? website.package,
							},
						});
					}
				});

				break;
			}

			case "customer.subscription.updated": {
				logger.custom.info("[Webhook]: Subscription Updated");

				const subscription = event.data.object;
				const getInvoice = async () => {
					const latestInvoice = subscription.latest_invoice;
					if (typeof latestInvoice === "string") {
						logger.custom.info(
							"[Webhook] Subscription not found, getting it from Stripe"
						);
						return await stripeAdmin.invoices.retrieve(latestInvoice);
					} else {
						return latestInvoice;
					}
				};

				const invoice = await getInvoice();
				logger.custom.info(
					invoice?.id,
					"[Webhook] Invoice Found, getting website data"
				);

				const prevData = event.data.previous_attributes;
				const website = await documentHelpers.get<Website<unknown>>({
					collectionName: "websites",
					documentName: subscription.metadata.websiteId,
				});

				if (!website) {
					throw new Error("Unable to get current website data.");
				}

				if (invoice?.billing_reason === "subscription_cycle") {
					// Handle actions for subscription cycles
					logger.custom.info("[Webhook] Reason: Subscription: Cycle");

					const isSuspendedStatus = [
						"incomplete",
						"incomplete_expired",
						"past_due",
						"unpaid",
					];

					if (
						prevData &&
						prevData.status === "active" &&
						isSuspendedStatus.includes(subscription.status)
					) {
						logger.custom.info("[Webhook] Suspending the website");
						// Suspend the website

						await updateVercelDomain(req, event.data.object.metadata.domain, {
							renew: false,
						});

						await documentHelpers.update<Partial<Website<unknown>>>({
							collectionName: "websites",
							documentName: subscription.metadata.websiteId,
							body: {
								...website,
								status: "Suspended",
							},
						});
					}

					if (
						prevData &&
						prevData.status !== "active" &&
						subscription.status === "active"
					) {
						// Activate the website
						logger.custom.info("[Webhook] Activating the website");
						await updateVercelDomain(req, event.data.object.metadata.domain, {
							renew: true,
						});

						await documentHelpers.update<Partial<Website<unknown>>>({
							collectionName: "websites",
							documentName: subscription.metadata.websiteId,
							body: {
								...website,
								status: "Online",
							},
						});
					}
				}

				if (invoice?.billing_reason === "subscription_update") {
					logger.custom.info("[Webhook] Reason: Subscription Updated");

					const website = await documentHelpers.get<Website<unknown>>({
						collectionName: "websites",
						documentName: event.data.object.metadata.websiteId,
					});

					const websiteType =
						(await documentHelpers.find<WebsiteFormConfiguration>({
							...mongoQuery,
							collectionName: "forms",
							filter: { id: website.type },
							paginition: { ...mongoQuery.paginition, limit: 1 },
						})) as WebsiteFormConfiguration;

					const domain = event.data.object.metadata.domain;
					const isTemporaryDomain = domain.endsWith(websiteType.data.tld);

					// Handle actions for subscription updates

					if (
						prevData?.metadata?.domain &&
						subscription.metadata.domain !== prevData?.metadata?.domain
					) {
						if (!isTemporaryDomain) {
							// Update the domain alias
							logger.custom.info(
								"Renaming the domain alias",
								prevData.metadata.domain,
								subscription.metadata.domain
							);
							if (!prevData.metadata.domain.endsWith(websiteType.data.tld)) {
								logger.custom.info(
									"Previous domain is not temporary, removing it from vercel."
								);
								await removeDomainFromVercel(
									req,
									prevData.metadata.domain
								).catch((err) =>
									logger.custom.warn("Error removing domain from Vercel", err)
								);
							}
							await addDomainToVercel(req, subscription.metadata.domain);
						}

						await documentHelpers.update<Partial<Website<unknown>>>({
							collectionName: "websies",
							documentName: subscription.metadata.websiteId,
							body: {
								...website,
								domain: subscription.metadata.domain,
							},
						});
					}
				}

				console.log("[Webhook] Finished");

				break;
			}

			case "customer.subscription.deleted": {
				console.log("[Webhook] Subscription Cancelled");

				const deletedSubscription = event.data.object;
				const domain = event.data.object.metadata.domain;

				const website = await documentHelpers.get<Website<unknown> | undefined>(
					{
						collectionName: "websites",
						documentName: event.data.object.metadata.websiteId,
					}
				);

				if (!website?.length) {
					logger.custom.warn(
						`No website to delete, attempting to remove domain ${domain}`
					);
					await removeDomainFromVercel(req, domain).catch((e) => {
						logger.error({
							error: e,
						});
					});

					return response(NextResponse, 200);
				}

				logger.custom.info(
					deletedSubscription.metadata.domain,
					"[Webhook] Deleting Website"
				);
				const websiteType =
					(await documentHelpers.find<WebsiteFormConfiguration>({
						...mongoQuery,
						collectionName: "forms",
						filter: { id: website.type },
						paginition: { ...mongoQuery.paginition, limit: 1 },
					})) as WebsiteFormConfiguration;

				const isTemporaryDomain =
					domain.endsWith(websiteType?.data?.tld) || !websiteType?.data?.tld;

				if (!isTemporaryDomain) {
					logger.custom.info(domain, "Removing Domain Alias");
					await updateVercelDomain(req, domain, { renew: false });
					await removeDomainFromVercel(req, domain);
				}

				await documentHelpers.remove({
					collectionName: "websites",
					documentName: deletedSubscription.metadata.websiteId,
				});

				// Delete the domain alias
				if (!isTemporaryDomain) {
					logger.custom.info(domain, "Removing Domain Alias");
					await updateVercelDomain(req, domain, { renew: false });
					await removeDomainFromVercel(req, domain);
				}

				logger.custom.info("[Webhook] Finished");

				break;
			}

			default:
				logger.custom.debug(`[Webhook] Unhandled event type ${event.type}`);
		}

		return response(NextResponse, 200);
	} catch (e: unknown) {
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
		});
	}
}
