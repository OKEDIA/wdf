// React Imports

// Next.js Imports
import { NextRequest, NextResponse } from "next/server";

// Firebase Imports

// Helpers
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { generateApiResponse as response } from "@okedia/shared/helpers";

// Other libraries or utilities
import { documentHelpers } from "@okedia/shared/database/documentHelpers";
// Types
import { ObjectId } from "mongodb";
import { sanitiseHtml } from "@okedia/shared/helpers/string/sanitise/server";
import { useGlobalQueryParams } from "@okedia/shared/hooks";
import { handleError } from "@okedia/shared/logging";
import { apiLogging } from "@okedia/shared/logging/api";
import { Message } from "@okedia/shared/types/messageTypes";
import { Profile } from "@okedia/shared/types/profileTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export async function POST(
	req: NextRequest,
	{ params }: { params: Promise<{ pathParams?: string[] }> }
) {
	try {
		const collectionName = "messages";
		const body = sanitiseHtml(await req.json());
		const { isAuthenticated, tokens: user } = await checkUserAuthentication();
		const logger = await apiLogging(req, user);

		const documentName = new ObjectId().toString();
		const profileId = (await params).pathParams?.[0];
		const globalQuery = useGlobalQueryParams(req.nextUrl.searchParams);

		if (!profileId) {
			logger.custom.debug("Missing required data (profileId)");
			return logger.error({
				user,
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		const message = await documentHelpers.create<Message>({
			documentName,
			collectionName,
			body: {
				...body,
				profile: new ObjectId(profileId),
			},
		});

		const profile = await documentHelpers
			.get<Profile<unknown>>({
				collectionName: "profiles",
				documentName: profileId,
			})
			.then((res) => sanitiseHtml(res));

		const profilesMessages: ObjectId[] =
			(profile?.messages as ObjectId[]) || [];
		profilesMessages.push(new ObjectId(documentName));

		await documentHelpers.update<Profile<unknown>>({
			collectionName: "profiles",
			documentName: profileId,
			body: {
				...profile,
				messages: profilesMessages,
			},
		});

		return response(NextResponse, 200, {
			...message,
			id: `${documentName.toString()}`,
		});
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}
