// React Imports

// Next.js Imports
import { NextRequest, NextResponse } from "next/server";

// Firebase Imports

// Helpers

// Other libraries or utilities
import getCustomer from "@/app/api/_helpers/billing/getACustomer";
import getInvoiceById from "@/app/api/_helpers/billing/getInvoiceById";
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { generateApiResponse as response } from "@okedia/shared/helpers";
import { handleError } from "@okedia/shared/logging";
import { apiLogging } from "@okedia/shared/logging/api";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Handles GET requests to retrieve an invoice by its ID.
 *
 * @param {NextRequest} req - The incoming request object.
 * @param {NextResponse} res - The outgoing response object.
 * @returns {Promise<NextResponse>} - The response containing the invoice data or an error message.
 *
 * @throws {Error} - Throws an error if the request fails.
 *
 * The function performs the following steps:
 * 1. Extracts the `invoiceId` from the request's query parameters.
 * 2. Checks user authentication and retrieves tokens.
 * 3. Validates the presence of `invoiceId` and user authentication.
 * 4. Finds the customer based on the user's Firebase UID.
 * 5. Validates the customer's metadata and Firebase UID.
 * 6. Retrieves the invoice data by its ID.
 * 7. Returns the invoice data or an appropriate error response.
 */
export async function GET(
	req: NextRequest,
	{ params }: { params: Promise<{ pathParams?: string[] }> }
) {
	try {
		const invoiceId = (await params).pathParams?.[0];
		const { isAuthenticated, tokens } = await checkUserAuthentication();
		const logger = await apiLogging(req, tokens);

		if (!invoiceId) {
			logger.custom.debug("Missing required data (invoiceId).");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		if (!isAuthenticated || !tokens?.decodedToken) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		const invoice = await getInvoiceById(invoiceId);

		const customerData = await getCustomer(invoice?.customer as string);

		if (!("metadata" in customerData)) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 500,
				},
			});
		}

		const firebaseUIDAtStripe = customerData.metadata.firebaseUID;

		if (tokens?.decodedToken.uid !== firebaseUIDAtStripe) {
			// Admins or other users cannot access other users' subscription info through their own account
			logger.custom.debug("User does not have access to this invoice.");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		return response(NextResponse, 200, invoice);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}
