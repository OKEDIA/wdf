// React Imports

// Next.js Imports
import { NextRequest, NextResponse } from "next/server";

// Firebase Imports

// Helpers
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { generateApiResponse as response } from "@okedia/shared/helpers";
import { isProductionEnvironment } from "@okedia/shared/helpers/isProductionEnvironment";
import { handleError } from "@okedia/shared/logging";
import { apiLogging } from "@okedia/shared/logging/api";

// Other libraries or utilities
import removeSubscription from "@/app/api/_helpers/billing/removeSubscription";
import { documentHelpers } from "@okedia/shared/database/documentHelpers";
import createSubscription from "../../../_helpers/billing/createSubscription";
import findCustomer from "../../../_helpers/billing/findACustomer";
import listPricesForProduct from "../../../_helpers/billing/listPricesForProduct";

// Types
import { getUser } from "@/app/api/_helpers/firebase_auth/admin";
import { ObjectId } from "mongodb";
import { sanitiseHtml } from "@okedia/shared/helpers/string/sanitise/server";
import { useGlobalQueryParams } from "@okedia/shared/hooks";
import { Profile } from "@okedia/shared/types/profileTypes";
import {
	Website,
	WebsiteFormConfiguration,
} from "@okedia/shared/types/websiteTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Handles GET requests for website data with authentication and authorization.
 *
 * @param req - Next.js request object containing query parameters:
 *   - documentName (optional) - Name of specific website document to retrieve
 *   - getAll (optional) - Flag for admin users to retrieve all websites
 * @param res - Next.js response object
 *
 * @returns NextResponse with:
 * - 200 and website data if successful
 * - 400 if missing required data or unauthorized
 * - 404 if specific website not found
 * - 520 for server errors
 *
 * @remarks
 * - Public access allowed for specific website lookups via documentName
 * - Authentication required for listing websites
 * - Regular users can only access their own websites
 * - Admin users can access all websites with getAll parameter
 * - Supports pagination
 */
export async function GET(
	req: NextRequest,
	{ params }: { params: Promise<{ websiteId: string }> }
) {
	try {
		const {
			isAuthenticated,
			isAdmin,
			tokens: user,
		} = await checkUserAuthentication();
		const logger = await apiLogging(req, user);
		const collectionName = "websites";
		const shouldGetAll = isAdmin && req.nextUrl.searchParams.has("getAll");
		const websiteId = (await params).websiteId;
		const globalQuery = useGlobalQueryParams(req.nextUrl.searchParams);
		const mongoQuery = globalQuery.mongoQuery();

		if (!collectionName) {
			return logger.error({
				user,
				response: {
					instance: NextResponse,
					status: 400,
					message: "Missing Required Data",
				},
			});
		}

		// If documentName is provided, fetch the specific document (PUBLIC RESPONSE)
		if (websiteId) {
			logger.custom.debug("User provided a specific document name to fetch");
			const website = await documentHelpers
				.get<Website<unknown>>({
					...mongoQuery,
					collectionName,
					documentName: websiteId,
				})
				.then((res) => sanitiseHtml(res));

			if (!website) {
				return logger.error({
					user,
					response: {
						instance: NextResponse,
						status: 404,
						message: "Website Not Found.",
					},
				});
			}

			return response(NextResponse, 200, website);
		}

		// If documentName is not provided, do not continue if unauthenticated
		if (!isAuthenticated || !user) {
			return logger.error({
				user,
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		// If the user is authenticated but not an admin, fetch only the user's websites
		if (isAuthenticated && !isAdmin) {
			logger.custom.debug(
				"User is authenticated but not an admin, fetching only their websites"
			);
			const userDocuments = await documentHelpers
				.find<Website<unknown>[]>({
					collectionName,
					...mongoQuery,
					filter: [
						mongoQuery?.filter ? { ...mongoQuery.filter } : undefined,
						{ "data.ownerId": user.decodedToken.uid }, // Ensure the current user is beign serached for
					],
				})
				.then((res) => sanitiseHtml(res));

			return response(NextResponse, 200, userDocuments);
		}

		if (shouldGetAll) {
			logger.custom.debug(
				"Admin user is authenticated and requested all websites"
			);
			const documents = await documentHelpers
				.find<Website<unknown>[]>({
					...mongoQuery,
					collectionName,
					filter: mongoQuery?.filter ? { ...mongoQuery.filter } : {}, // {} is get all
				})
				.then((res) => sanitiseHtml(res));

			return response(NextResponse, 200, documents);
		} else {
			logger.custom.debug(
				"!! Defaulted to last action: User is authenticated but not an admin, fetching only their websites"
			);
			// Fetch only the user's documents if not requesting all
			const userDocuments = await documentHelpers
				.find<Website<unknown>[]>({
					collectionName,
					...mongoQuery,
					filter: [
						mongoQuery?.filter ? { ...mongoQuery.filter } : undefined,
						{ "data.ownerId": user.decodedToken.uid }, // Ensure the current user is beign serached for
					],
				})
				.then((res) => sanitiseHtml(res));

			return response(NextResponse, 200, userDocuments);
		}
	} catch (e: any) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}

/**
 * Handles POST requests to create a new website with a demo subscription.
 *
 * @param req - Next.js request object containing:
 *   - JSON body with addon selections
 *   - Authentication tokens in cookies
 *   - Brand cookie value
 *   - Profile ID in query params
 *
 * @throws {Error} 403 if user is not authenticated
 * @throws {Error} 400 if profileId or required data is missing
 * @throws {Error} 520 for other errors during website creation
 *
 * @returns {Promise<NextResponse>} 200 with created website data including:
 *   - Website configuration
 *   - Domain name
 *   - Subscription details
 *   - Owner information
 *   - Selected addons
 */
export async function POST(
	req: NextRequest,
	{ params }: { params: Promise<{ websiteId: string }> }
) {
	try {
		const collectionName = "websites";
		const body = sanitiseHtml(await req.json());
		const { isAuthenticated, tokens } = await checkUserAuthentication();
		const logger = await apiLogging(req, tokens);
		const documentName = new ObjectId().toString();
		const currentBrand = req.cookies.get("brand")?.value ?? "actors";
		const profileId = (await params).websiteId; // website id is used as profileId in this method
		const globalQuery = useGlobalQueryParams(req.nextUrl.searchParams);
		const mongoQuery = globalQuery.mongoQuery();
		const typeId = body.type ? body.type : currentBrand;

		if (!isAuthenticated || !tokens?.decodedToken) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		const user = await getUser(tokens.decodedToken.uid);

		if (!profileId) {
			logger.custom.warn("Missing profileId in request");
			return logger.error({
				user: tokens,
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		const type = await documentHelpers
			.find<WebsiteFormConfiguration>({
				collectionName: "forms",
				...mongoQuery,
				filter: [
					mongoQuery?.filter ? { ...mongoQuery.filter } : undefined,
					{ id: typeId }, // Ensure the current brand is beign serached for
				],
				paginition: { ...mongoQuery.paginition, limit: 1 },
			})
			.then((res) => sanitiseHtml(res));

		const customer = await findCustomer({
			query: `metadata[\"firebaseUID\"]: \"${user?.uid}\"`,
		});

		if (!customer) {
			throw new Error("Unable to find the billing profile for the customer.");
		}

		const prices = await listPricesForProduct({
			product: type.data.productId,
			lookup_keys: [
				`${type.id}_${process.env.STRIPE_DEMO_PACKAGE_LOOKUP_KEY as string}`,
			],
		});

		const demoPrice = prices.data[0];

		if (!body || !collectionName || !documentName) {
			logger.custom.warn(
				"Missing required data (body|collectionName|doucmentName) in request"
			);
			return logger.error({
				user: tokens,
				response: {
					instance: NextResponse,
					status: 400,
					message: "Missing Required Data",
				},
			});
		}

		const website = {
			...body,
			status: "online",
			package: demoPrice.lookup_key,
			domain: `${documentName}.${type.data.tld}`,
			permissions: {
				creator: ObjectId.createFromHexString(
					user?.customClaims?.localUID as string
				),
				owners: [
					ObjectId.createFromHexString(user?.customClaims?.localUID as string),
				],
			},
			development: !isProductionEnvironment,
			type: typeId,
			addons: Object.keys(body).reduce((acc: Record<string, boolean>, key) => {
				acc[key] = true;
				return acc;
			}, {}),
			productId: type.data.productId,
			profileId: ObjectId.createFromHexString(profileId),
		};
		logger.custom.debug("Website data: ", website);

		const subscription = await createSubscription({
			customer: customer.data[0].id,
			cancel_at_period_end: true,
			items: [{ price: demoPrice.id }],
			metadata: {
				domain: `${documentName}.${type.data.tld}`,
				websiteId: documentName.toString(),
			},
			payment_settings: { save_default_payment_method: "on_subscription" },
		});
		logger.custom.debug(subscription, "Stripe Subscription created");

		const data = await documentHelpers.create<Partial<Website<unknown>>>({
			documentName,
			collectionName,
			body: website,
		});

		const profile = await documentHelpers
			.get<Profile<unknown>>({
				collectionName: "profiles",
				documentName: profileId,
			})
			.then((res) => sanitiseHtml(res));

		const profilesWebsites: ObjectId[] = (profile.websites as ObjectId[]) || [];
		profilesWebsites.push(new ObjectId(documentName));

		await documentHelpers.update<Profile<unknown>>({
			collectionName: "profiles",
			documentName: profileId,
			body: {
				...profile,
				websites: profilesWebsites,
			},
		});

		return response(NextResponse, 200, {
			...data,
			id: `${documentName.toString()}`,
		});
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}

/**
 * Updates a website document in the database.
 *
 * @param req - Next.js request object containing the website update data
 * @param res - Next.js response object
 *
 * @remarks
 * This endpoint requires authentication. Admin users have full update privileges,
 * while regular users can only update certain fields and must own the website.
 *
 * Required query parameters:
 * - documentName: string - The unique identifier of the website document
 *
 * Protected fields for non-admin users:
 * - type
 * - package
 * - domain
 * - ownerId
 * - development
 * - addons
 * - productId
 * - subscriptionId
 *
 * @throws {400} - When documentName is missing
 * @throws {403} - When user is not authenticated or doesn't have permission
 * @throws {404} - When website document is not found
 * @throws {520} - When an unexpected error occurs
 *
 * @returns {Promise<NextResponse>} Response containing the updated website data
 */
export async function PATCH(
	req: NextRequest,
	{ params }: { params: Promise<{ websiteId: string }> }
) {
	try {
		const websiteId = (await params).websiteId;
		const collectionName = "websites";
		const body = sanitiseHtml(await req.json());
		const {
			isAuthenticated,
			isAdmin,
			tokens: user,
		} = await checkUserAuthentication();
		const logger = await apiLogging(req, user);

		if (!websiteId) {
			logger.custom.warn("Missing required data (documentName) in request");
			return logger.error({
				user: user,
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		const existingDocument = await documentHelpers
			.get<Website<unknown>>({
				collectionName,
				documentName: websiteId,
			})
			.then((res) => sanitiseHtml(res));

		if (!isAuthenticated) {
			logger.custom.warn("User is not authenticated");
			return logger.error({
				user: user,
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		if (!existingDocument) {
			logger.custom.warn("Website does not exist");
			return logger.error({
				user: user,
				response: {
					instance: NextResponse,
					status: 404,
				},
			});
		}

		const owners: string[] | undefined = existingDocument.permissions
			?.owners as string[];

		if (!isAdmin && !owners.includes(user?.decodedToken?.localUID as string)) {
			logger.custom.warn("User is not an admin and does not own the document");
			return logger.error({
				user: user,
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		// Merge existing data with the new data, preserving some of the existing values
		const updatedData = {
			...existingDocument,
			...body,
			data: {
				...existingDocument.data,
				...body.data,
			},
		};

		delete updatedData._id; // Do not try to update this field

		// If the user is not an admin, restrict changes to certain fields
		if (!isAdmin) {
			updatedData.type = existingDocument.type;
			updatedData.package = existingDocument.package;
			updatedData.domain = existingDocument.domain;
			updatedData.development = existingDocument.development;
			updatedData.addons = existingDocument.addons;
			updatedData.productId = existingDocument.productId;
			updatedData.subscriptionId = existingDocument.subscriptionId;
			updatedData.permissions = existingDocument.permissions;
		}

		await documentHelpers.update<Website<unknown>>({
			collectionName,
			documentName: websiteId,
			body: updatedData,
		});

		return response(NextResponse, 200, {
			...updatedData,
			id: `${existingDocument._id.toString()}`,
		});
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}

export async function DELETE(
	req: NextRequest,
	{ params }: { params: Promise<{ websiteId: string }> }
) {
	try {
		const websiteId = (await params).websiteId;
		const collectionName = "websites";
		const {
			isAuthenticated,
			isAdmin,
			tokens: user,
		} = await checkUserAuthentication();
		const logger = await apiLogging(req, user);

		if (!collectionName || !websiteId) {
			logger.custom.warn("Missing profileId in request");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		const existingDocument = await documentHelpers.get<Website<unknown>>({
			collectionName,
			documentName: websiteId,
		});

		const owners = (existingDocument.permissions?.owners as ObjectId[]) || [];

		if (
			!isAuthenticated ||
			(!isAdmin && !owners.includes(new ObjectId(user?.decodedToken.uid)))
		) {
			logger.custom.warn("");
			return logger.error({
				user: user,
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		if (existingDocument?.subscriptionId) {
			logger.custom.debug("Found a matching subscription, removing it.");
			// Remove the subscription. Stripe webhooks will handle the rest
			await removeSubscription(existingDocument.subscriptionId as string);
			logger.custom.debug(
				"Subcsription removed. Stripe Webhooks should handle the document deletion."
			);
		} else {
			// No subscription found, remove the document manually
			logger.custom.debug(
				"No subscription found, removing the document manually"
			);
			await documentHelpers
				.remove({ collectionName, documentName: websiteId })
				.then(() => response(NextResponse, 200));
		}

		return response(NextResponse, 200);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}
