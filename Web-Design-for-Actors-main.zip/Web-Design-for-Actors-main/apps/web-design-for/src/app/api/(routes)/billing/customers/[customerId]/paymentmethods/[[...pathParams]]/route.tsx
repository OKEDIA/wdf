// React Imports

// Next.js Imports
import { NextRequest, NextResponse } from "next/server";

// Firebase Imports

// Helpers

// Other libraries or utilities
import getCustomer from "@/app/api/_helpers/billing/getACustomer";
import getPaymentMethods from "@/app/api/_helpers/billing/getPaymentMethods";
import removePaymentMethod from "@/app/api/_helpers/billing/removePaymentMethod";
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { generateApiResponse as response } from "@okedia/shared/helpers";
import { handleError } from "@okedia/shared/logging";
import { apiLogging } from "@okedia/shared/logging/api";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Handles GET requests to retrieve payment methods for a customer.
 *
 * @param {NextRequest} req - The incoming request object.
 * @param {NextResponse} res - The outgoing response object.
 * @returns {Promise<NextResponse>} - The response containing the payment methods or an error message.
 *
 * @throws {Error} - Throws an error if there is an issue with the request or processing.
 *
 * The function performs the following steps:
 * 1. Retrieves the customerId from the request's query parameters.
 * 2. Checks if the user is authenticated.
 * 3. Validates the presence of the customerId.
 * 4. Finds the customer using the provided customerId.
 * 5. Verifies that the authenticated user matches the customer.
 * 6. Retrieves the payment methods for the customer.
 * 7. Returns the payment methods in the response.
 *
 * Possible response statuses:
 * - 200: Successfully retrieved payment methods.
 * - 400: Missing required data (customerId).
 * - 403: User is not authenticated or does not have access to the requested data.
 * - 500: Customer metadata not found.
 * - 520: Unknown error occurred.
 */
export async function GET(
	req: NextRequest,
	{ params }: { params: Promise<{ customerId: string }> }
) {
	try {
		const customerId = (await params).customerId;
		const { isAuthenticated, tokens } = await checkUserAuthentication();
		const logger = await apiLogging(req, tokens);

		if (!isAuthenticated) {
			logger.custom.debug("User does not have access to this subscription.");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		if (!customerId) {
			logger.custom.debug("User does not have access to this subscription.");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		const customerData = await getCustomer(customerId);

		if (!("metadata" in customerData)) {
			logger.custom.debug("User does not have access to this subscription.");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 500,
				},
			});
		}
		const firebaseUIDAtStripe = customerData.metadata.firebaseUID;

		if (tokens?.decodedToken.uid !== firebaseUIDAtStripe) {
			// Admins or other users cannot access other users' card info through their account
			logger.custom.debug("User does not have access to this subscription.");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		const data = await getPaymentMethods(customerId, {});

		return response(NextResponse, 200, data);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}

/**
 * Handles the DELETE request to remove a payment method for a customer.
 *
 * @param {NextRequest} req - The incoming request object.
 * @param {NextResponse} res - The outgoing response object.
 * @returns {Promise<NextResponse>} - The response object with the status and data.
 *
 * @throws {Error} - Throws an error if the request fails.
 *
 * The function performs the following steps:
 * 1. Checks user authentication.
 * 2. Retrieves the payment method ID from the request URL.
 * 3. Validates the authentication and required data.
 * 4. Finds the customer using the decoded token UID.
 * 5. Verifies the customer's metadata.
 * 6. Ensures the user is authorized to delete the payment method.
 * 7. Removes the payment method and returns a success response.
 * 8. Catches and handles any errors, returning an appropriate error response.
 */
export async function DELETE(
	req: NextRequest,
	{ params }: { params: Promise<{ customerId: string; pathParams?: string[] }> }
) {
	try {
		const { isAuthenticated, tokens } = await checkUserAuthentication();
		const customerId = (await params).customerId;
		const methodId = (await params).pathParams?.[0];
		const logger = await apiLogging(req, tokens);

		if (!isAuthenticated) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		if (!tokens?.decodedToken || !methodId) {
			logger.custom.debug("Missing required data (email|token|amount).");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		const customerData = await getCustomer(customerId);

		if (!("metadata" in customerData)) {
			logger.custom.debug(
				"Customer metadata not found. There is likely a problem with the Stripe Customer or local customer account."
			);
			return logger.error({
				response: {
					instance: NextResponse,
					status: 500,
				},
			});
		}
		const firebaseUIDAtStripe = customerData.metadata.firebaseUID;

		if (tokens?.decodedToken.uid !== firebaseUIDAtStripe) {
			// Admins or other users cannot access other users' card info through their account
			logger.custom.debug("User does not have access to this payment method.");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		const data = await removePaymentMethod(methodId);

		return response(NextResponse, 200, data);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}
