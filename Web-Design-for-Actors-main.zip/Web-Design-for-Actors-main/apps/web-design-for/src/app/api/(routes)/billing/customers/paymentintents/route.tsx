// React Imports

// Next.js Imports
import { NextRequest, NextResponse } from "next/server";

// Firebase Imports

// Helpers

// Other libraries or utilities
import createPaymentIntent from "@/app/api/_helpers/billing/createPaymentIntent";
import findCustomer from "@/app/api/_helpers/billing/findACustomer";
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { generateApiResponse as response } from "@okedia/shared/helpers";
import { handleError } from "@okedia/shared/logging";
import { apiLogging } from "@okedia/shared/logging/api";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Handles the POST request to create a payment intent for a customer.
 *
 * @param {NextRequest} req - The incoming request object.
 * @param {NextResponse} res - The outgoing response object.
 * @returns {Promise<NextResponse>} - The response object with the status and data.
 *
 * @throws {Error} - Throws an error if the request fails.
 *
 * The function performs the following steps:
 * 1. Retrieves the token and amount from the request's query parameters.
 * 2. Checks user authentication and authorization.
 * 3. Validates the presence of required data (email, token, amount).
 * 4. Finds the customer based on the authenticated user's email.
 * 5. Verifies the customer's metadata and user permissions.
 * 6. Creates a payment intent with the provided token, amount, and customer ID.
 * 7. Returns the response with the appropriate status and data.
 */
export async function POST(
	req: NextRequest,
	{ params }: { params: Promise<{ pathParams?: string[] }> }
) {
	try {
		const token = req.nextUrl.searchParams.get("confirmationToken");
		const amount = req.nextUrl.searchParams.get("amount");
		const { isAuthenticated, isAdmin, tokens } =
			await checkUserAuthentication();
		const logger = await apiLogging(req, tokens);

		if (!isAuthenticated) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		if (!tokens?.decodedToken.email || !token || !amount) {
			logger.custom.debug("Missing required data (email|token|amount).");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		const customer = await findCustomer({
			query: `email:\"${tokens.decodedToken.email}\"`,
		});

		if (!customer.data.length) {
			logger.custom.debug("Customer not found.");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 404,
				},
			});
		}

		const customerData = customer.data[0];
		if (!("metadata" in customerData)) {
			logger.custom.debug(
				"Customer metadata not found. There is likely an issue with the customer's local account."
			);
			return logger.error({
				response: {
					instance: NextResponse,
					status: 500,
				},
			});
		}

		if (
			!isAdmin &&
			tokens?.decodedToken.uid !== customerData.metadata.firebaseUID
		) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		const data = await createPaymentIntent({
			confirmationTokenId: token,
			amount: parseInt(amount, 10),
			customerId: customerData.id,
		});

		return response(NextResponse, 200, data);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}
