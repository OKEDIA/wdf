// React Imports

// Next.js Imports
import { NextRequest, NextResponse } from "next/server";

// Firebase Imports

// Helpers

// Other libraries or utilities
import createNewCustomer from "@/app/api/_helpers/billing/createNewCustomer";
import createStripeCustomerSession from "@/app/api/_helpers/billing/createSession";
import findCustomer from "@/app/api/_helpers/billing/findACustomer";
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { generateApiResponse as response } from "@okedia/shared/helpers";
import { useGlobalQueryParams } from "@okedia/shared/hooks";
import { handleError } from "@okedia/shared/logging";
import { apiLogging } from "@okedia/shared/logging/api";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Handles GET requests to retrieve customer information based on the provided email address.
 *
 * @param {NextRequest} req - The incoming request object.
 * @param {NextResponse} res - The outgoing response object.
 * @returns {Promise<NextResponse>} - The response containing the customer data or an error message.
 *
 * @throws {Error} - Throws an error if the request fails.
 *
 * The function performs the following steps:
 * 1. Extracts the email address from the request's query parameters.
 * 2. Checks user authentication and authorization.
 * 3. Validates the presence of the email address.
 * 4. Searches for the customer using the provided email address.
 * 5. Validates the existence of customer data and metadata.
 * 6. Checks if the authenticated user is authorized to access the customer data.
 * 7. Returns the customer data if all checks pass.
 * 8. Returns appropriate error responses for various failure scenarios.
 */
export async function GET(
	req: NextRequest,
	{ params }: { params: Promise<{ customerId: string }> }
) {
	try {
		const emailAddress = (await params).customerId;
		const globalQuery = useGlobalQueryParams(req.nextUrl.searchParams);
		const queryParams = globalQuery.parse();
		const { isAuthenticated, isAdmin, tokens } =
			await checkUserAuthentication();
		const logger = await apiLogging(req, tokens);

		let customer;

		if (!isAuthenticated) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		if (emailAddress) {
			logger.custom.debug("Email address was for customer search.");
			customer = await findCustomer({
				query: `email:\"${emailAddress}\"`,
			});
		} else {
			logger.custom.debug("Missing required data (email).");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		if (!customer?.data.length) {
			logger.custom.debug("A matching customer was not found.");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 404,
				},
			});
		}

		const customerData = customer.data[0];
		if (!("metadata" in customerData)) {
			logger.custom.debug(
				"Customer metadata not found. This is likely an issue with the Stripe customer or local customer account."
			);
			return logger.error({
				response: {
					instance: NextResponse,
					status: 500,
				},
			});
		}

		if (
			!isAdmin &&
			tokens?.decodedToken.uid !== customerData.metadata.firebaseUID
		) {
			logger.custom.debug("User does not have access to this user.");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		return response(NextResponse, 200, customer);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}

/**
 * Handles the POST request to create a new customer and initiate a Stripe customer session.
 *
 * @param {NextRequest} req - The incoming request object.
 * @returns {Promise<NextResponse>} - The response object with the status and data.
 *
 * @throws {Error} - If an error occurs during the process, it returns a response with the error message.
 */
export async function POST(req: NextRequest) {
	try {
		const body = await req.json();
		const { isAuthenticated, tokens } = await checkUserAuthentication();
		const logger = await apiLogging(req, tokens);

		if (!isAuthenticated || !tokens?.decodedToken) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		const customer = await createNewCustomer({
			...body,
			name: tokens.decodedToken.displayName,
			email: tokens.decodedToken.email,
			metadata: { firebaseUID: tokens.decodedToken.uid },
		});

		const data = await createStripeCustomerSession(customer.id);

		return response(NextResponse, 200, data);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}
