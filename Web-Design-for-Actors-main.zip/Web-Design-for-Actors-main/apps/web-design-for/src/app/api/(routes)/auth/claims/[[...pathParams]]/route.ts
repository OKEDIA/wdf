// React Imports

// Next.js Imports
import { NextRequest, NextResponse } from "next/server";

// Firebase Imports

// Helpers
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { generateApiResponse as response } from "@okedia/shared/helpers";
import { handleError } from "@okedia/shared/logging";
import { apiLogging } from "@okedia/shared/logging/api";
import {
	getUser,
	setCustomUserClaims,
} from "../../../../_helpers/firebase_auth/admin";

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Handles the POST request to set custom user claims.
 *
 * @param {NextRequest} req - The incoming request object.
 * @param {NextResponse} res - The outgoing response object.
 * @returns {Promise<NextResponse>} The response object with the appropriate status and data.
 *
 * @throws {Error} If there is an issue processing the request.
 *
 * The function performs the following steps:
 * 1. Parses the request body to get the claims.
 * 2. Retrieves the `uid` and `merge` parameters from the request URL.
 * 3. Checks if the user is authenticated and has admin privileges.
 * 4. If the user is not authenticated or not an admin, returns a 403 response.
 * 5. If `uid` or `claims` are missing, returns a 400 response.
 * 6. If `merge` is true, merges the new claims with existing custom claims and updates the user.
 * 7. If `merge` is false, sets the new claims directly for the user.
 * 8. Returns a 200 response with the updated claims.
 * 9. Catches any errors and returns a 520 response with the error message.
 */
export async function POST(
	req: NextRequest,
	{ params }: { params: Promise<{ pathParams?: string[] }> }
) {
	try {
		const claims = await req.json();
		const uid = (await params).pathParams?.[0];
		const merge = req.nextUrl.searchParams.get("merge") as string;
		const { isAdmin, isAuthenticated, tokens } =
			await checkUserAuthentication();
		const logger = await apiLogging(req, tokens);

		if (!isAdmin || !isAuthenticated) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		if (!uid || !claims) {
			logger.custom.debug("Missing required data (uid|claims).");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		if (merge === "true") {
			logger.custom.debug(
				"User opted to merge. Merging claims with existing custom claims."
			);
			logger.custom.debug("Fetching existing custom claims.");
			const userData = await getUser(uid);
			const mergedClaims = { ...userData?.customClaims, ...claims };
			logger.custom.debug("Merging User Claims");
			await setCustomUserClaims(uid, { ...mergedClaims });
			return response(NextResponse, 200, mergedClaims);
		}

		logger.custom.debug("User opted to overwrite. Overwriting claims.");
		await setCustomUserClaims(uid, claims);
		return response(NextResponse, 200, claims);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}
