import { NextRequest, NextResponse } from "next/server";
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { generateApiResponse as response } from "@okedia/shared/helpers";
import { useServersideDatabase } from "@okedia/shared/hooks/database/useServersideDatabase";
import { handleError } from "@okedia/shared/logging";
import { apiLogging } from "@okedia/shared/logging/api";

export async function GET(req: NextRequest) {
	const params = req.nextUrl.searchParams;

	const defaultParams = {
		subset: "latin",
		capability: "VF",
		sort: "alpha",
	};

	for (const key in defaultParams) {
		if (!params.get(key)) {
			params.set(key, defaultParams[key as keyof typeof defaultParams]);
		}
	}

	try {
		const { tokens } = await checkUserAuthentication();
		const logger = await apiLogging(req, tokens);

		const db = useServersideDatabase(
			`https://www.googleapis.com/webfonts/v1/webfonts?key=${process.env.GOOGLE_FONTS_API_KEY}`,
			""
		);

		const paramsString = params
			.toString()
			.padStart(params.toString().length + 1, "&"); // Add the & to the start as we are concatenating the above endpoint's query

		const fontlist = await db.get({
			url: paramsString,
		});
		return response(NextResponse, 200, fontlist);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}
