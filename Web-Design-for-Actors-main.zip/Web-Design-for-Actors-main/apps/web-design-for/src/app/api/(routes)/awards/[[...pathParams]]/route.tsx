// React Imports

// Next.js Imports
import { NextRequest, NextResponse } from "next/server";

// Firebase Imports

// Helpers
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { generateApiResponse as response } from "@okedia/shared/helpers";
import { isProductionEnvironment } from "@okedia/shared/helpers/isProductionEnvironment";

// Other libraries or utilities
import { getUser } from "@/app/api/_helpers/firebase_auth/admin";
import { documentHelpers } from "@okedia/shared/database/documentHelpers";
import { convertStringKeys } from "@okedia/shared/helpers/object";
// Types
import { ObjectId } from "mongodb";
import { getFromObjectByPath } from "@okedia/shared/helpers";
import { sanitiseHtml } from "@okedia/shared/helpers/string/sanitise/server";
import { useGlobalQueryParams } from "@okedia/shared/hooks";
import { handleError } from "@okedia/shared/logging";
import { apiLogging } from "@okedia/shared/logging/api";
import { CommonFormDataProps, FormProps } from "@okedia/shared/types/formTypes";
import { Profile } from "@okedia/shared/types/profileTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export async function GET(
	req: NextRequest,
	{ params }: { params: Promise<{ pathParams?: string[] }> }
) {
	try {
		const awardId = (await params).pathParams?.[0];
		const collectionName = "awards";
		const globalQuery = useGlobalQueryParams(req.nextUrl.searchParams);
		const mongoQuery = globalQuery.mongoQuery();
		const { tokens } = await checkUserAuthentication();
		const logger = await apiLogging(req, tokens);

		if (!collectionName) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		if (awardId) {
			const award = await documentHelpers
				.get<Profile<unknown>>({
					...mongoQuery,
					collectionName,
					documentName: awardId,
				})
				.then((res) => sanitiseHtml(res));

			return response(NextResponse, 200, award);
		}

		const filteredProfiles = await documentHelpers
			.find<Profile<unknown>[]>({
				...mongoQuery,
				collectionName,
			})
			.then((res) => sanitiseHtml(res));

		return response(NextResponse, 200, filteredProfiles);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}

/**
 * Handles the POST request to create a new profile.
 *
 * @param {NextRequest} req - The incoming request object.
 * @returns {Promise<NextResponse>} - The response object with the status and data.
 *
 * @throws {Error} - Throws an error if the request fails.
 *
 * The function performs the following steps:
 * 1. Extracts the request body and checks user authentication.
 * 2. Generates a new document ID and retrieves the current brand from cookies.
 * 3. Validates the required data.
 * 4. Constructs the profile object with the provided data and additional metadata.
 * 5. Creates a new profile document in the specified collection.
 * 6. Logs the new profile ID and returns a success response with the profile data.
 * 7. Catches and handles any errors, returning an appropriate error response.
 */
//(await params).pathParams?.[0];
export async function POST(
	req: NextRequest,
	{ params }: { params: Promise<{ pathParams?: string[] }> }
) {
	try {
		const collectionName = "awards";
		const body = sanitiseHtml(await req.json());
		const { isAuthenticated, tokens: user } = await checkUserAuthentication();
		const logger = await apiLogging(req, user);
		const documentName = new ObjectId().toString();
		const globalParams = useGlobalQueryParams(req.nextUrl.searchParams);
		const mongoQuery = globalParams.mongoQuery();
		const claimProfile = req.nextUrl.searchParams.get("claim") === "true";

		if (!isAuthenticated || !user?.decodedToken) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		const claims = (await getUser(user.decodedToken.uid))?.customClaims;

		if (!body || !collectionName || !documentName || !body.type) {
			logger.custom.debug(
				"Missing required data (body|collectionName|documentName|body.type)."
			);
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		const form = await documentHelpers
			.find<FormProps>({
				...mongoQuery,
				collectionName: "forms",
				filter: { id: body.type },
				paginition: { ...mongoQuery.paginition, limit: 1 },
			})
			.then(async (res) => await sanitiseHtml(res));

		const commonFormDataMap = form.commonFormDataMap as CommonFormDataProps;

		const commonFormDataValues: CommonFormDataProps = {
			title: getFromObjectByPath(body, commonFormDataMap?.title),
			image: getFromObjectByPath(body, commonFormDataMap?.image),
			tags: Array.isArray(getFromObjectByPath(body, commonFormDataMap?.tags))
				? (getFromObjectByPath(body, commonFormDataMap?.tags) as string[]).map(
						(tag) => getFromObjectByPath(body, tag)
				  )
				: [],
		};

		logger.custom.debug(commonFormDataValues, "Created common form values");
		const processedBody = documentHelpers.convertToObjectIdIfNeeded(
			convertStringKeys(body)
		);

		logger.custom.debug(
			{ processed: processedBody, original: body },
			"Processed Body with ObjectId Conversion"
		);

		const award = {
			...processedBody,
			permissions: {
				creator: ObjectId.createFromHexString(claims?.localUID as string),
				owners: claimProfile
					? [ObjectId.createFromHexString(claims?.localUID as string)]
					: undefined,
			},
			commonFormDataValues: {
				...processedBody.commonFormDataValues,
				...commonFormDataValues,
			},
			development: !isProductionEnvironment,
			type: body.type,
		};

		const data = await documentHelpers.create<Profile<unknown>>({
			documentName,
			collectionName,
			body: award,
		});

		// if (claimProfile) {
		// 	const mongoUser = await documentHelpers.get<MongoUser>({
		// 		collectionName: "users",
		// 		documentName: user.decodedToken.localUID as string,
		// 	});

		// 	const profiles = mongoUser.profiles || [];
		// 	profiles.push(data._id);

		// 	await documentHelpers.update<Partial<MongoUser>>({
		// 		collectionName: "users",
		// 		documentName: user.decodedToken.localUID as string,
		// 		body: {
		// 			profiles,
		// 		},
		// 	});
		// }

		return response(NextResponse, 200, {
			...data,
			id: `${documentName.toString()}`,
		});
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}

// /**
//  * Handles the PATCH request to update a profile document in the "profiles" collection.
//  *
//  * @param {NextRequest} req - The incoming request object.
//  * @returns {Promise<NextResponse>} - The response object with the status and data.
//  *
//  * @throws {Error} - Throws an error if the update operation fails.
//  *
//  * The function performs the following steps:
//  * 1. Extracts the `documentName` from the request's URL search parameters.
//  * 2. Parses the request body to get the update data.
//  * 3. Checks user authentication and authorization.
//  * 4. Validates the presence of the `documentName`.
//  * 5. Retrieves the existing document from the "profiles" collection.
//  * 6. Verifies if the user is authenticated and authorized to update the document.
//  * 7. Updates the document in the collection with the new data.
//  * 8. Returns a response with the updated document data or an appropriate error message.
//  */
// export async function PATCH(
// 	req: NextRequest,
// 	{ params }: { params: Promise<{ pathParams?: string[] }> }
// ) {
// 	try {
// 		const profileId = (await params).pathParams?.[0];
// 		const collectionName = "profiles";
// const body = sanitiseHtml(await req.json());// 		const {
// 			isAuthenticated,
// 			isAdmin,
// 			tokens: user,
// 		} = await checkUserAuthentication();

// 		if (!profileId) {
// 			return response(NextResponse, 400, "Missing Required Data");
// 		}

// 		const existingDocument = await documentHelpers.get<Profile<unknown>>({
// 			collectionName,
// 			documentName: profileId,
// 		});

// 		const claims = (await getUser(user?.decodedToken.uid as string))
// 			?.customClaims;

// 		if (!isAuthenticated || !user || !claims?.localUID) {
// 			return response(NextResponse, 403);
// 		}

// 		if (!existingDocument) {
// 			return response(NextResponse, 404);
// 		}

// 		const owners: string[] | undefined = existingDocument.permissions
// 			?.owners as string[];

// 		if (!isAdmin && !owners.includes(claims.localUID as string)) {
// 			return response(NextResponse, 403);
// 		}

// 		await documentHelpers.update<Profile<unknown>>({
// 			collectionName,
// 			documentName: profileId,
// 			body,
// 		});

// 		return response(NextResponse, 200, {
// 			...body,
// 			id: `${profileId}`,
// 		});
// 	} catch (e: unknown) {
// 		const { tokens } = await checkUserAuthentication();
// return handleError({
// 	response: { instance: NextResponse },
// 	error: e instanceof Error ? e : new Error(String(e)),
// 	request: req,
// 	user: tokens,
// });
// 	}
// }

// // export async function DELETE(req: NextRequest) {
// // 	try {
// // 		const documentName = req.nextUrl.searchParams.get("documentName");
// // 		const collectionName = "websites";
// // 		const {
// // 			isAuthenticated,
// // 			isAdmin,
// // 			tokens: user,
// // 		} = await checkUserAuthentication();

// // 		if (!collectionName || !documentName) {
// // 			return response(NextResponse, 400, "Missing Required Data");
// // 		}

// // 		const existingDocument = await documentHelpers.get<Website>({
// // 			collectionName,
// // 			documentName,
// // 		});

// // 		if (!isAuthenticated) {
// // 			return response(NextResponse, 403);
// // 		}

// // 		if (!isAdmin && existingDocument.data.ownerId !== user?.decodedToken.uid) {
// // 			return response(NextResponse, 403);
// // 		}

// // 		return await documentHelpers
// // 			.remove({ collectionName, documentName })
// // 			.then(() => response(NextResponse, 200))
// // 			.catch((e: unknown) => {
// // 				throw e;
// // 			});
// // 	} catch (e: unknown) {
// const { tokens } = await checkUserAuthentication();
// return handleError({
// 	response: { instance: NextResponse },
// 	error: e instanceof Error ? e : new Error(String(e)),
// 	request: req,
// 	user: tokens,
// });// // 	}
// // }
