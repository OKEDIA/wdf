// React Imports

// Next.js Imports
import { NextRequest, NextResponse } from "next/server";

// Firebase Imports

// Helpers
import { documentHelpers } from "@okedia/shared/database/documentHelpers";
import { checkUserAuthentication } from "@okedia/shared/firebase";
import {
	getErrorMessage,
	generateApiResponse as response,
} from "@okedia/shared/helpers";
import { handleError } from "@okedia/shared/logging";

// Other libraries or utilities

// Types
import { useGlobalQueryParams } from "@okedia/shared/hooks";
import { apiLogging } from "@okedia/shared/logging/api";
import { Template } from "@okedia/shared/types/formTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Handles GET requests to retrieve a template document from the "templates" collection.
 *
 * @param {NextRequest} req - The incoming request object.
 * @param {NextResponse} res - The outgoing response object.
 * @returns {Promise<NextResponse>} The response object containing the status and data or error message.
 *
 * @throws {Error} If an unexpected error occurs during the process.
 *
 * The function performs the following steps:
 * 1. Extracts the `documentName` from the request's query parameters.
 * 2. Checks if the user is authenticated.
 * 3. Validates the presence of required data (`collectionName` and `documentName`).
 * 4. Retrieves the document from the "templates" collection based on the provided `documentName`.
 * 5. Returns the retrieved data with a 200 status code if successful.
 * 6. Returns appropriate error responses for authentication failure, missing data, or unexpected errors.
 */
export async function GET(
	req: NextRequest,
	{ params }: { params: Promise<{ pathParams?: string[] }> }
) {
	try {
		const templateId = (await params).pathParams?.[0];
		const collectionName = "templates";
		const { isAuthenticated, tokens } = await checkUserAuthentication();
		const logger = await apiLogging(req, tokens);

		const globalQuery = useGlobalQueryParams(req.nextUrl.searchParams);
		const mongoQuery = globalQuery.mongoQuery();

		if (!isAuthenticated) {
			return logger.error({
				user: tokens,
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		if (!collectionName) {
			return logger.error({
				user: tokens,
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		if (templateId) {
			logger.custom.debug("User specified a specific template id");
			const data = await documentHelpers.find<Template>({
				collectionName,
				...mongoQuery,
				filter: [
					mongoQuery?.filter ? { ...mongoQuery.filter } : undefined,
					{ id: templateId }, // Ensure the current template is beign serached for
				],
				paginition: { ...mongoQuery.paginition, limit: 1 },
			});
			return response(NextResponse, 200, data);
		}

		logger.custom.debug(
			"User did not specify a template id, will get all if no filter"
		);
		const data = await documentHelpers.find<Template>({
			collectionName,
			...mongoQuery,
			filter: [mongoQuery?.filter ? { ...mongoQuery.filter } : {}], // {} is get all
		});

		return response(NextResponse, 200, data);
	} catch (e: unknown) {
		return response(NextResponse, 520, getErrorMessage(e));
	}
}

/**
 * Handles the POST request to update a template document in the "templates" collection.
 *
 * @param {NextRequest} req - The incoming request object.
 * @param {NextResponse} res - The outgoing response object.
 * @returns {Promise<NextResponse>} - The response object with the status and data.
 *
 * @throws {Error} - If an error occurs during the process.
 *
 * The function performs the following steps:
 * 1. Retrieves the document name from the request URL's search parameters.
 * 2. Checks user authentication and authorization.
 * 3. Validates the request body and required parameters.
 * 4. Updates the specified document in the "templates" collection.
 * 5. Returns the appropriate response based on the operation's success or failure.
 */
export async function POST(
	req: NextRequest,
	{ params }: { params: Promise<{ pathParams?: string[] }> }
) {
	try {
		const templateId = (await params).pathParams?.[0];
		const collectionName = "templates";
		const body = await req.json();
		const { isAuthenticated, isAdmin, tokens } =
			await checkUserAuthentication();
		const logger = await apiLogging(req, tokens);

		if (!isAuthenticated || !isAdmin) {
			logger.custom.warn("User not authenticated or not an admin.");
			return logger.error({
				user: tokens,
				response: {
					instance: NextResponse,
					status: 404,
					message: "Website Not Found.",
				},
			});
		}

		if (!body || !collectionName || !templateId) {
			logger.custom.warn(
				"Missing required data (body|collectionName|templateId)."
			);
			return logger.error({
				user: tokens,
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		const data = await documentHelpers.create<Template>({
			collectionName,
			body: { ...body, id: templateId },
		});

		return response(NextResponse, 200, data);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}
