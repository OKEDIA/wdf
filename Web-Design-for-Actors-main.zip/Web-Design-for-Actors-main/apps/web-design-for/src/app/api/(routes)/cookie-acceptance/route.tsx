// React Imports

// Next.js Imports
import { NextRequest, NextResponse } from "next/server";

// Firebase Imports

// Helpers

// Other libraries or utilities
import { documentHelpers } from "@okedia/shared/database/documentHelpers";
import { generateApiResponse as response } from "@okedia/shared/helpers";

// Types
import { ObjectId } from "mongodb";
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { useGlobalQueryParams } from "@okedia/shared/hooks";
import { handleError } from "@okedia/shared/logging";
import { apiLogging } from "@okedia/shared/logging/api";
import { UnpaginitedMongoResponse } from "@okedia/shared/types/documentResponses";
import { CookieValue } from "vanilla-cookieconsent";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export async function POST(req: NextRequest) {
	try {
		const { tokens } = await checkUserAuthentication();
		const logger = await apiLogging(req, tokens);
		const collectionName = "cookieAcceptance";
		const body = (await req.json()) as CookieValue;
		const documentName = new ObjectId().toString();

		if (!body.consentId) {
			logger.custom.debug("Missing required data (consentId)");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		const cookieAcceptance = await documentHelpers.create<CookieValue>({
			documentName,
			collectionName,
			body,
		});

		return response(NextResponse, 200, {
			...cookieAcceptance,
			id: `${documentName.toString()}`,
		});
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}

export async function PATCH(req: NextRequest) {
	try {
		const logger = await apiLogging(req);
		const collectionName = "cookieAcceptance";
		const body = (await req.json()) as CookieValue;
		const globalParams = useGlobalQueryParams(req.nextUrl.searchParams);

		if (!body.consentId) {
			logger.custom.debug("Missing required data (consentId)");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		const foundDoc = (await documentHelpers.find<CookieValue>({
			collectionName,
			filter: { consentId: body.consentId },
			paginition: {
				...globalParams.defaultPaginition().paginition,
				limit: 1,
			},
		})) as UnpaginitedMongoResponse<CookieValue>;

		if (!foundDoc) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 404,
				},
			});
		}

		const cookieAcceptance = await documentHelpers.update<CookieValue>({
			documentName: foundDoc._id.toString(),
			collectionName,
			body,
		});

		return response(NextResponse, 200, {
			...cookieAcceptance,
			id: `${body.consentId.toString()}`,
		});
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}
