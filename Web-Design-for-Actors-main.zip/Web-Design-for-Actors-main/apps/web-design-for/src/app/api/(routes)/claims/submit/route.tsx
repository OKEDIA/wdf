// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import { ObjectId } from "mongodb";
import { NextRequest, NextResponse } from "next/server";
import { documentHelpers } from "@okedia/shared/database/documentHelpers";
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { generateApiResponse as response } from "@okedia/shared/helpers";
import { sanitiseHtml } from "@okedia/shared/helpers/string/sanitise/server";
import { apiLogging } from "@okedia/shared/logging/api";
import { MongoUser, Profile } from "@okedia/shared/types/profileTypes";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
export async function POST(req: NextRequest) {
	const {
		isAuthenticated,
		isAdmin,
		tokens: user,
	} = await checkUserAuthentication();
	const logger = await apiLogging(req, user);
	const body = sanitiseHtml(await req.json());
	const { profileId } = body;

	if (!isAuthenticated || !user?.decodedToken) {
		return logger.error({
			response: {
				instance: NextResponse,
				status: 403,
			},
		});
	}

	if (!profileId) {
		logger.custom.debug("Missing required data (profileId)");
		return logger.error({
			response: {
				instance: NextResponse,
				status: 400,
			},
		});
	}

	const existingProfile = await documentHelpers
		.get<Profile<unknown>>({
			collectionName: "profiles",
			documentName: profileId,
		})
		.then((res) => sanitiseHtml(res));

	const existingUser = await documentHelpers
		.get<MongoUser>({
			collectionName: "users",
			documentName: user.decodedToken.localUID as string,
		})
		.then((res) => sanitiseHtml(res));

	const currentOwners =
		(existingProfile?.permissions?.owners as ObjectId[]) || ([] as ObjectId[]);

	if (!existingProfile || !existingUser || currentOwners.length > 0) {
		logger.custom.debug(
			"Either the profile or user does not exist, or the profile already has owners."
		);
		return logger.error({
			response: {
				instance: NextResponse,
				status: 400,
			},
		});
	}

	currentOwners.push(
		ObjectId.createFromHexString(user.decodedToken.localUID as string)
	);

	const updatedProfileBody = {
		permissions: {
			...existingProfile.permissions,
			owners: currentOwners,
		},
	};

	const updatedProfile = await documentHelpers.update({
		collectionName: "profiles",
		documentName: profileId,
		body: updatedProfileBody,
	});

	// Update the profile with the user who claimed it
	const profilePermissions =
		(existingProfile?.permissions?.owners as ObjectId[]) || ([] as ObjectId[]);
	profilePermissions.push(existingProfile._id);

	// Update the user with the claimed document
	const userPermissions = existingUser.profiles || [];
	userPermissions.push(existingProfile._id);

	await documentHelpers.update<MongoUser>({
		collectionName: "users",
		documentName: user.decodedToken.localUID as string,
		body: {
			...existingUser,
			profiles: userPermissions,
		},
	});

	return response(NextResponse, 200, {
		...existingProfile,
		...updatedProfile,
		id: existingProfile._id,
	});
}
