// React Imports

// Next.js Imports
import { NextRequest, NextResponse } from "next/server";

// Firebase Imports

// Helpers

// Other libraries or utilities
import listPricesForProduct from "@/app/api/_helpers/billing/listPricesForProduct";
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { generateApiResponse as response } from "@okedia/shared/helpers";
import { handleError } from "@okedia/shared/logging";
import { apiLogging } from "@okedia/shared/logging/api";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Handles the GET request to fetch prices for a specific product.
 *
 * @param {NextRequest} req - The incoming request object.
 * @param {NextResponse} res - The outgoing response object.
 * @returns {Promise<NextResponse>} - The response containing the product prices or an error message.
 *
 * @throws {Error} - Throws an error if the request fails.
 *
 * The function performs the following steps:
 * 1. Extracts the `productId` and `package` (lookupKey) from the request's query parameters.
 * 2. Checks if the user is authenticated.
 * 3. Returns a 403 response if the user is not authenticated.
 * 4. Returns a 400 response if either `productId` or `lookupKey` is missing.
 * 5. Fetches the prices for the specified product and lookup key.
 * 6. Returns a 200 response with the product prices if successful.
 * 7. Catches any errors and returns a 520 response with the error message.
 */
export async function GET(
	req: NextRequest,
	{ params }: { params: Promise<{ pathParams?: string[] }> }
) {
	try {
		const productId = (await params).pathParams?.[0];
		const lookupKey = req.nextUrl.searchParams.get("lookupKey");
		const { isAuthenticated, tokens } = await checkUserAuthentication();
		const logger = await apiLogging(req, tokens);

		if (!isAuthenticated) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		if (!productId || !lookupKey) {
			logger.custom.debug("Missing required data (productId|lookupKey).");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		const product = await listPricesForProduct({
			product: productId,
			lookup_keys: [lookupKey],
		});

		return response(NextResponse, 200, product);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}
