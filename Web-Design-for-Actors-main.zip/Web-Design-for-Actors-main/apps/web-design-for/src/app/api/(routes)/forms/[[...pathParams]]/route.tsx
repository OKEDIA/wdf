// React Imports

// Next.js Imports
import { NextRequest, NextResponse } from "next/server";

// Firebase Imports

// Helpers
import { documentHelpers } from "@okedia/shared/database/documentHelpers";
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { generateApiResponse as response } from "@okedia/shared/helpers";

// Other libraries or utilities

// Types
import { useGlobalQueryParams } from "@okedia/shared/hooks";
import { handleError } from "@okedia/shared/logging";
import { apiLogging } from "@okedia/shared/logging/api";
import { MongoDocumentResponse } from "@okedia/shared/types/mongoTypes";
import { WebsiteFormConfiguration } from "@okedia/shared/types/websiteTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Handles GET requests to retrieve a document from the "forms" collection.
 *
 * @param {NextRequest} req - The incoming request object.
 * @param {NextResponse} res - The outgoing response object.
 * @returns {Promise<NextResponse>} The response object with the retrieved data or an error message.
 *
 * @throws {Error} If an unexpected error occurs during the process.
 *
 * The function performs the following steps:
 * 1. Extracts the `documentName` from the request's query parameters.
 * 2. Checks if the user is authenticated.
 * 3. Validates the presence of required data (`collectionName` and `documentName`).
 * 4. Retrieves the document data from the specified collection.
 * 5. Returns the retrieved data or an appropriate error response.
 */
export async function GET(
	req: NextRequest,
	{ params }: { params: Promise<{ pathParams?: string[] }> }
) {
	try {
		const formId = (await params).pathParams?.[0];
		const collectionName = "forms";
		const { isAuthenticated, tokens } = await checkUserAuthentication();
		const logger = await apiLogging(req, tokens);

		const globalQuery = useGlobalQueryParams(req.nextUrl.searchParams);
		const mongoQuery = globalQuery.mongoQuery();

		if (!isAuthenticated) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		if (!collectionName || !formId) {
			logger.custom.debug("Missing required data (collectionName|formId)");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		const data = await documentHelpers.find<WebsiteFormConfiguration>({
			collectionName,
			...mongoQuery,
			filter: [
				mongoQuery?.filter ? { ...mongoQuery.filter } : undefined,
				{ id: formId }, // Ensure the current form is beign serached for
			],
			paginition: { ...mongoQuery.paginition, limit: 1 },
		});
		return response(NextResponse, 200, data);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}

/**
 * Handles the POST request to create a new document in the "forms" collection.
 *
 * @param {NextRequest} req - The incoming request object.
 * @param {NextResponse} res - The outgoing response object.
 * @returns {Promise<NextResponse>} - The response object with the appropriate status and data.
 *
 * @throws {Error} - If an error occurs during the process.
 *
 * The function performs the following steps:
 * 1. Retrieves the `documentName` from the request's URL search parameters.
 * 2. Parses the request body to get the data.
 * 3. Checks if the user is authenticated and is an admin.
 * 4. Validates the presence of required data (`body`, `collectionName`, `documentName`).
 * 5. Creates a new document in the specified collection with the provided data.
 * 6. Returns a response with the created document data or an error message.
 */
export async function POST(
	req: NextRequest,
	{ params }: { params: Promise<{ pathParams?: string[] }> }
) {
	try {
		const formId = (await params).pathParams?.[0];
		const collectionName = "forms";
		const body = await req.json();
		const { isAuthenticated, isAdmin } = await checkUserAuthentication();

		if (!isAuthenticated || !isAdmin || !formId) {
			return response(NextResponse, 403);
		}

		if (!body || !collectionName) {
			return response(NextResponse, 400, "Missing Required Data");
		}

		const data = await documentHelpers.create<WebsiteFormConfiguration>({
			collectionName,
			body: { ...body, id: formId },
		});

		return response(NextResponse, 200, data);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}

/**
 * Handles the PATCH request to update a document in the "forms" collection.
 *
 * @param {NextRequest} req - The incoming request object.
 * @returns {Promise<NextResponse>} - The response object indicating the result of the operation.
 *
 * @throws {Error} - Throws an error if the request fails.
 *
 * The function performs the following steps:
 * 1. Extracts the `documentName` from the request's query parameters.
 * 2. Parses the request body to get the update data.
 * 3. Checks if the user is authenticated and is an admin.
 * 4. Validates the presence of required data (`body`, `collectionName`, `documentName`).
 * 5. Finds the document to update in the "forms" collection.
 * 6. Updates the document with the provided data.
 * 7. Returns a response with the updated document data.
 *
 * If any step fails, an appropriate error response is returned.
 */
export async function PATCH(
	req: NextRequest,
	{ params }: { params: Promise<{ pathParams?: string[] }> }
) {
	try {
		const formId = (await params).pathParams?.[0];
		const globalQuery = useGlobalQueryParams(req.nextUrl.searchParams);
		const mongoQuery = globalQuery.mongoQuery();
		const collectionName = "forms";
		const body = await req.json();

		const { isAuthenticated, isAdmin } = await checkUserAuthentication();

		if (!isAuthenticated || !isAdmin) {
			return response(NextResponse, 403);
		}

		if (!body || !collectionName || !formId) {
			return response(NextResponse, 400, "Missing Required Data");
		}

		const documentToUpdate = await documentHelpers
			.find<MongoDocumentResponse<WebsiteFormConfiguration>>({
				collectionName,
				...mongoQuery,
				filter: [
					mongoQuery?.filter ? { ...mongoQuery.filter } : undefined,
					{ id: formId }, // Ensure the current user is beign serached for
				],
				paginition: { ...mongoQuery.paginition, limit: 1 },
			})
			.then((res) => res as MongoDocumentResponse<WebsiteFormConfiguration>);

		const data = await documentHelpers.update({
			collectionName,
			documentName: documentToUpdate._id.toString(),
			body,
		});

		return response(NextResponse, 200, data);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}
