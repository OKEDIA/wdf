// React Imports

// Next.js Imports
import { NextRequest, NextResponse } from "next/server";

// Firebase Imports

// Helpers
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { generateApiResponse as response } from "@okedia/shared/helpers";
import { handleError } from "@okedia/shared/logging";
import { apiLogging } from "@okedia/shared/logging/api";
import { createCustomToken } from "../../../../_helpers/firebase_auth/admin";

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Handles the GET request to create a custom session token for a user.
 *
 * @param {NextRequest} req - The incoming request object.
 * @param {NextResponse} res - The outgoing response object.
 * @returns {Promise<NextResponse>} The response object with the status and custom token or error message.
 *
 * The function performs the following steps:
 * 1. Retrieves the user ID (uid) from the request's query parameters.
 * 2. Checks if the user is authenticated and is an admin.
 * 3. If the user is not authenticated or not an admin, returns a 403 Forbidden response.
 * 4. Attempts to create a custom token for the user.
 * 5. If successful, returns a 200 OK response with the custom token.
 * 6. If an error occurs, returns a 520 Unknown Error response with the error message.
 */
export async function GET(
	req: NextRequest,
	{ params }: { params: Promise<{ pathParams?: string[] }> }
) {
	const uid = (await params).pathParams?.[0];
	const { isAdmin, isAuthenticated, tokens } = await checkUserAuthentication();
	const logger = await apiLogging(req, tokens);

	if (!isAuthenticated || !isAdmin) {
		return logger.error({
			response: {
				instance: NextResponse,
				status: 403,
			},
		});
	}

	if (!uid) {
		logger.custom.debug("Missing required data (uid).");
		return logger.error({
			response: {
				instance: NextResponse,
				status: 4030,
			},
		});
	}

	try {
		logger.custom.debug("Creating custom token for user:", uid);
		const customToken = await createCustomToken(uid);

		return response(NextResponse, 200, customToken);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}
