// React Imports

// Next.js Imports
import { NextRequest, NextResponse } from "next/server";

// Firebase Imports

// Helpers
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { generateApiResponse as response } from "@okedia/shared/helpers";
import { isProductionEnvironment } from "@okedia/shared/helpers/isProductionEnvironment";

// Other libraries or utilities
import { ObjectId } from "mongodb";
import { documentHelpers } from "@okedia/shared/database/documentHelpers";
import { getFromObjectByPath } from "@okedia/shared/helpers"; // Types
import { sanitiseHtml } from "@okedia/shared/helpers/string/sanitise/server";
import { useGlobalQueryParams } from "@okedia/shared/hooks";
import { handleError } from "@okedia/shared/logging";
import { apiLogging } from "@okedia/shared/logging/api";
import { UnpaginitedMongoResponse } from "@okedia/shared/types/documentResponses";
import { CommonFormDataProps, FormProps } from "@okedia/shared/types/formTypes";
import { Profile } from "@okedia/shared/types/profileTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export async function GET(
	req: NextRequest,
	{ params }: { params: Promise<{ pathParams?: string[] }> }
) {
	try {
		const profileId = (await params).pathParams?.[0];
		const collectionName = "roles";
		const globalQuery = useGlobalQueryParams(req.nextUrl.searchParams);
		const mongoQuery = globalQuery.mongoQuery();
		const { tokens } = await checkUserAuthentication();
		const logger = await apiLogging(req, tokens);

		if (!collectionName) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		if (profileId) {
			logger.custom.debug("User specified a specific profile");
			const profile = await documentHelpers
				.get<Profile<unknown>>({
					...mongoQuery,
					collectionName,
					documentName: profileId,
				})
				.then((res) => sanitiseHtml(res));

			return response(NextResponse, 200, profile);
		}

		logger.custom.debug(
			"User did not specify a specific profile, will find from query filters"
		);
		const filteredProfiles = await documentHelpers
			.find<Profile<unknown>[]>({
				...mongoQuery,
				collectionName,
			})
			.then((res) => sanitiseHtml(res));

		return response(NextResponse, 200, filteredProfiles);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}

/**
 * Handles the POST request to create a new profile.
 *
 * @param {NextRequest} req - The incoming request object.
 * @returns {Promise<NextResponse>} - The response object with the status and data.
 *
 * @throws {Error} - Throws an error if the request fails.
 *
 * The function performs the following steps:
 * 1. Extracts the request body and checks user authentication.
 * 2. Generates a new document ID and retrieves the current brand from cookies.
 * 3. Validates the required data.
 * 4. Constructs the profile object with the provided data and additional metadata.
 * 5. Creates a new profile document in the specified collection.
 * 6. Logs the new profile ID and returns a success response with the profile data.
 * 7. Catches and handles any errors, returning an appropriate error response.
 */
//(await params).pathParams?.[0];
export async function POST(
	req: NextRequest,
	{ params }: { params: Promise<{ pathParams?: string[] }> }
) {
	try {
		const collectionName = "roles";
		const body = sanitiseHtml(await req.json());
		const { isAuthenticated, tokens: user } = await checkUserAuthentication();
		const logger = await apiLogging(req, user);
		const documentName = new ObjectId().toString();
		const globalParams = useGlobalQueryParams(req.nextUrl.searchParams);
		const mongoQuery = globalParams.mongoQuery();
		const claimProfile = req.nextUrl.searchParams.get("claim") === "true";

		if (!isAuthenticated || !user?.decodedToken) {
			logger.custom.debug("User is not authenticated");
			return logger.error({
				user,
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		if (!body || !collectionName || !documentName || !body.type) {
			logger.custom.debug(
				"Missing required data (body|collectionName|documentName||body.type)"
			);
			return logger.error({
				user,
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		const form = (await documentHelpers.find<FormProps>({
			...mongoQuery,
			collectionName: "forms",
			filter: { id: "roles" },
			paginition: { ...mongoQuery.paginition, limit: 1 },
		})) as UnpaginitedMongoResponse<FormProps>;

		const commonFormDataMap = form.commonFormDataMap as CommonFormDataProps;

		console.log(commonFormDataMap);

		const commonFormDataValues: CommonFormDataProps = {
			title: getFromObjectByPath(body, commonFormDataMap?.title),
			image: getFromObjectByPath(body, commonFormDataMap?.image),
			tags: Array.isArray(getFromObjectByPath(body, commonFormDataMap?.tags))
				? (getFromObjectByPath(body, commonFormDataMap?.tags) as string[]).map(
						(tag) => getFromObjectByPath(body, tag)
				  )
				: [],
		};

		logger.custom.debug(
			commonFormDataValues,
			"Calculated common form data values"
		);

		const processedBody = documentHelpers.convertToObjectIdIfNeeded(body);
		logger.custom.debug(
			{ processed: processedBody, original: body },
			"Processed body with ObjectId conversion"
		);

		const role = {
			...processedBody,
			permissions: {
				creator: ObjectId.createFromHexString(
					user.decodedToken?.localUID as string
				),
				owners: claimProfile
					? [
							ObjectId.createFromHexString(
								user.decodedToken?.localUID as string
							),
					  ]
					: undefined,
			},
			commonFormDataValues: {
				...processedBody.commonFormDataValues,
				...commonFormDataValues,
			},
			development: !isProductionEnvironment,
			type: body.type,
		};

		const data = await documentHelpers.create<Profile<unknown>>({
			documentName,
			collectionName,
			body: role,
		});

		return response(NextResponse, 200, {
			...data,
			id: `${documentName.toString()}`,
		});
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}
