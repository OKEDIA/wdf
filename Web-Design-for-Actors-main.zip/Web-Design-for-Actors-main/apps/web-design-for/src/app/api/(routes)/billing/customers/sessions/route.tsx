// React Imports

// Next.js Imports
import { NextRequest, NextResponse } from "next/server";

// Firebase Imports

// Helpers

// Other libraries or utilities
import createStripeCustomerSession from "@/app/api/_helpers/billing/createSession";
import findCustomer from "@/app/api/_helpers/billing/findACustomer";
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { generateApiResponse as response } from "@okedia/shared/helpers";
import { handleError } from "@okedia/shared/logging";
import { apiLogging } from "@okedia/shared/logging/api";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Handles the GET request to create a Stripe customer session.
 *
 * @param {NextRequest} req - The incoming request object.
 * @returns {Promise<NextResponse>} - The response object with the appropriate status and data.
 *
 * @throws {Error} - If an error occurs during the process, it returns a response with the error message.
 *
 * The function performs the following steps:
 * 1. Checks user authentication and authorization.
 * 2. Validates the presence of the user's email in the decoded token.
 * 3. Finds the customer based on the email.
 * 4. Validates the presence of customer metadata.
 * 5. Checks if the user is an admin or if the user's UID matches the customer's metadata UID.
 * 6. Creates a Stripe customer session and returns the session data.
 */
export async function GET(req: NextRequest) {
	try {
		const { isAuthenticated, isAdmin, tokens } =
			await checkUserAuthentication();
		const logger = await apiLogging(req, tokens);

		if (!isAuthenticated) {
			return logger.error({
				response: {
					instance: NextResponse,
					status: 403,
				},
			});
		}

		if (!tokens?.decodedToken.email) {
			logger.custom.debug("Missing required data (email).");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 400,
				},
			});
		}

		const customer = await findCustomer({
			query: `email:\"${tokens.decodedToken.email}\"`,
		});

		if (!customer.data.length) {
			logger.custom.debug("Customer not found.");
			return logger.error({
				response: {
					instance: NextResponse,
					status: 404,
				},
			});
		}

		const customerData = customer.data[0];
		if (!("metadata" in customerData)) {
			logger.custom.debug(
				"The customer does not have metadata. There is likely an issue with the Stripe customer or local customer account."
			);
			return logger.error({
				response: {
					instance: NextResponse,
					status: 500,
				},
			});
		}

		if (
			!isAdmin &&
			tokens?.decodedToken.uid !== customerData.metadata.firebaseUID
		) {
			logger.custom.debug(
				"User is not an admin and does not match the customer metadata."
			);
			return logger.error({
				response: {
					instance: NextResponse,
					status: 500, // Likely a misconfiguration in the stripe customer or local customer account
				},
			});
		}

		const data = await createStripeCustomerSession(customerData.id);

		return response(NextResponse, 200, data);
	} catch (e: unknown) {
		const { tokens } = await checkUserAuthentication();
		return handleError({
			response: { instance: NextResponse },
			error: e instanceof Error ? e : new Error(String(e)),
			request: req,
			user: tokens,
		});
	}
}
