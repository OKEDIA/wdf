// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import {
	Price,
	PriceListParams,
	stripeAdmin,
	StripeResponse,
} from "@okedia/shared/stripe";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default async function listPricesForProduct(
	params: PriceListParams
): Promise<StripeResponse<Price>> {
	return await stripeAdmin.prices.list({ ...params });
}
