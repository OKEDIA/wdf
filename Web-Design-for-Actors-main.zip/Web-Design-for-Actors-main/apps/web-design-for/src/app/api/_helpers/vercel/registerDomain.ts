// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import { isProductionEnvironment } from "@okedia/shared/helpers";
import { useServersideDatabase } from "@okedia/shared/hooks/database/useServersideDatabase";
import { apiLogging } from "@okedia/shared/logging/api";
import { NextRequest } from "next/server";

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

interface DomainResponse {
	domain: {
		uid: string;
		ns: string[];
		verified: boolean;
		created: number;
		pending: boolean;
	};
}

interface DomainPrice {
	price?: number;
	period?: number;
}

interface VercelError {
	error: {
		code: string;
		message: string;
	};
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default async function registerDomainWithVercel(
	req: NextRequest,
	domainName: string
): Promise<DomainResponse> {
	const logger = await apiLogging(req);
	const db = useServersideDatabase(
		process.env.VERCEL_API_BASE_URL as string,
		"vercel"
	);

	logger.custom.info(`[Vercel API] Registering domain ${domainName}`);

	if (!isProductionEnvironment) {
		logger.custom.info(
			`[Vercel API] Skipping domain registration in development environment`
		);
		return {
			domain: {
				uid: "fake-uid-dev-env",
				ns: ["ns1.fake.com", "ns2.fake.com"],
				verified: true,
				created: Date.now(),
				pending: false,
			},
		};
	}

	logger.custom.info(`[Vercel API] Fetching domain price for ${domainName}`);
	const price = await db
		.get<DomainPrice>({
			url: `v4/domains/price/?name=${domainName}&type=new`,
		})
		.catch((error) => {
			logger.custom.error(`[Vercel API] Error fetching domain price: ${error}`);
			throw error(error);
		});

	if (
		!price?.price ||
		price.price > Number(process.env.VERCEL_MAX_DOMAIN_COST_USD)
	) {
		throw new Error("Error getting cost or cost is too high.");
	}

	logger.custom.info(`[Vercel API] Domain Price is ${price.price}`);

	const response = await db
		.post<DomainResponse | VercelError>({
			url: `v5/domains/buy`,
			body: JSON.stringify({
				name: domainName,
				expectedPrice: isProductionEnvironment ? price.price : 0,
				renew: true,
				...JSON.parse(process.env.VERCEL_DOMAIN_REG_CONFIG || "{}"),
			}),
		})
		.catch((error) => {
			logger.custom.error(`[Vercel API] Error registering domain: ${error}`);
			throw error(error);
		});

	logger.custom.info(
		`[Vercel API] Domain registration response: ${JSON.stringify(response)}`
	);

	if ("error" in response) {
		throw new Error(response.error.message);
	}

	logger.custom.info(`[Vercel API] Done!`);

	return response;
}
