// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import { stripeAdmin } from "@okedia/shared/stripe";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default async function createStripeCustomerSession(customer: string) {
	return await stripeAdmin.customerSessions.create({
		customer,
		components: {
			payment_element: {
				enabled: true,
				features: {
					payment_method_redisplay: "enabled",
					payment_method_save: "enabled",
					payment_method_save_usage: "off_session",
					payment_method_remove: "enabled",
				},
			},
		},
		expand: ["customer"],
	});
}
