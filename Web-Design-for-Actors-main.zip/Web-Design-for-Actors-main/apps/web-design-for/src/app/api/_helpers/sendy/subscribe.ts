// React Imports

import { checkIsEmpty } from "@okedia/shared/helpers";
import { useServersideDatabase } from "@okedia/shared/hooks/database/useServersideDatabase";

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import { logger } from "@okedia/shared/logging";
import {
	handleSendyResponse,
	SendyResponse,
	SendySubscribersProperties,
} from "./handleSendyResponse";

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default async function subscribe(
	query: SendySubscribersProperties & {
		customFields?: {
			[key: string]: string;
		};
	}
): Promise<SendyResponse> {
	logger.info(query, "Subscribing a User to Sendy");
	const db = useServersideDatabase(
		process.env.SENDY_API_URL as string,
		"sendy",
		"text/html"
	);

	logger.debug("Converting query to FormData");
	const formData = new FormData();
	formData.append("boolean", "true");
	formData.append("api_key", process.env.SENDY_API_KEY as string);

	Object.entries(query).forEach(([key, value]) => {
		if (key === "customFields" && typeof value === "object" && value !== null) {
			Object.entries(value).forEach(([customKey, customValue]) => {
				if (!checkIsEmpty(customValue as any)) {
					formData.append(customKey, String(customValue));
				}
			});
		} else if (!checkIsEmpty(value as any)) {
			formData.append(key, String(value));
		}
	});

	logger.debug(formData.toString(), "Sending request to Sendyu");
	return await db
		.post<SendyResponse>({
			url: "/subscribe",
			body: formData,
		})
		.then((res) => handleSendyResponse(res));
}
