// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities

// Types
import { FirebaseResult } from "@okedia/shared/types/serviceStatusTypes";

interface FirebaseStatus {
	[key: string]: {
		id: string;
		created: string;
		end: string;
		desc: string;
		impact: string;
		severity: string;
		service: string;
	};
}

interface FirebaseIncident {
	id?: string;
	created?: string;
	end?: string;
	external_desc?: string;
	status_impact?: string;
	severity?: string;
	service_name: string;
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Fetches the current status of Firebase services from the Firebase status page.
 *
 * @returns {Promise<FirebaseResult>} A promise that resolves to an object representing the status of Firebase services.
 * If there are no ongoing incidents, the object will have a status of "up". Otherwise, it will contain details of the incidents.
 *
 * The returned object will have keys corresponding to the service names (in lowercase) and values containing incident details:
 * - `id`: The incident ID.
 * - `created`: The creation timestamp of the incident.
 * - `end`: The end timestamp of the incident (if any).
 * - `desc`: The external description of the incident.
 * - `impact`: The impact status of the incident.
 * - `severity`: The severity level of the incident.
 * - `service`: The name of the service affected by the incident.
 */
export default async function getFirebaseStatus(): Promise<FirebaseResult> {
	const response = await fetch(
		"https://status.firebase.google.com/incidents.json"
	);
	const data: FirebaseIncident[] = await response.json();

	const related = data
		.filter((incident) => {
			return (
				["Authentication", "Firestore", "Storage"].includes(
					incident.service_name
				) && !incident.end
			);
		})
		.reduce<FirebaseStatus>((result, incident) => {
			result[incident.service_name.toLowerCase()] = {
				id: incident.id ?? "",
				created: incident.created ?? "",
				end: incident.end ?? "",
				desc: incident.external_desc ?? "",
				impact: incident.status_impact ?? "",
				severity: incident.severity ?? "",
				service: incident.service_name ?? "",
			};
			return result;
		}, {});

	return Object.keys(related).length === 0 ? { status: "up" } : related;
}
