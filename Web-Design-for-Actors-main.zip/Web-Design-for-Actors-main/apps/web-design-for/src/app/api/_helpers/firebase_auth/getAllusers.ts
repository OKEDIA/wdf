import { UsersList } from "next-firebase-auth-edge/lib/auth";
import { NextRequest } from "next/server";
import { apiLogging } from "@okedia/shared/logging/api";
import "server-only";
import { listUsers } from "./admin";

// React Imports

// Next.js Imports

// Firebase Imports
// Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
interface GetUsersProps {
	paginition?: {
		limit: number;
		startAfter: string;
	};
	req: NextRequest;
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Retrieves a list of users from Firebase Authentication with optional pagination.
 *
 * @param {GetUsersProps} props - The properties for retrieving users.
 * @param {Object} props.paginition - The pagination options.
 * @param {number} [props.paginition.limit] - The maximum number of users to retrieve.
 * @param {string} [props.paginition.startAfter] - The token to start retrieving users after.
 * @returns {Promise<{ users: UsersList[], nextPageToken: string | null }>} A promise that resolves to an object containing the list of users and the next page token.
 */
export async function getAllUsers({ paginition, req }: GetUsersProps) {
	const logger = await apiLogging(req);

	logger.custom.info("[Firebase API] Fetching all users");
	const users: UsersList[] = [];
	const maxResults =
		paginition?.limit ?? parseInt(process.env.PAGINITION_LIMIT as string, 10);

	const listUsersResult = await listUsers(
		paginition?.startAfter?.toString(),
		maxResults
	)
		.then((result) => result)
		.catch((error) => {
			logger.error({
				error,
			});

			throw error;
		});

	listUsersResult?.users.forEach((userRecord) => {
		users.push(userRecord.toJSON() as UsersList);
	});

	return {
		users: users ?? [],
		nextPageToken: listUsersResult?.nextPageToken || null,
	};
}
