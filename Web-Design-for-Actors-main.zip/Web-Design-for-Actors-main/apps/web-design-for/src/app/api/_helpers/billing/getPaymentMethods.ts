// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import { PaymentMethodParams, stripeAdmin } from "@okedia/shared/stripe";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default async function getPaymentMethods(
	customerId: string,
	params: PaymentMethodParams
) {
	return await stripeAdmin.customers.listPaymentMethods(customerId, {
		...params,
	});
}
