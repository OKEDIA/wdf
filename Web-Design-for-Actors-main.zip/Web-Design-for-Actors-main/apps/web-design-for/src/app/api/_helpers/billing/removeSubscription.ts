// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import { stripeAdmin } from "@okedia/shared/stripe";
import Stripe from "stripe";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default async function removeSubscription(
	subscriptionId: string,
	reason?: Stripe.SubscriptionCancelParams.CancellationDetails.Feedback
) {
	if (reason) {
		return await stripeAdmin.subscriptions.cancel(subscriptionId, {
			cancellation_details: { feedback: reason },
		});
	} else {
		return await stripeAdmin.subscriptions.cancel(subscriptionId);
	}
}
