// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import {
	CrispResult,
	FirebaseResult,
	ServiceStatusResult,
	StripeResult,
} from "@okedia/shared/types/serviceStatusTypes";
import getCrispStatus from "./getCrispStatus";
import getFirebaseStatus from "./getFirebaseStatus";
import getStripeStatus from "./getStripeStatus";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Retrieves the status of various services used by the application.
 *
 * This function asynchronously fetches the status of Firebase, Stripe, and Crisp services,
 * and returns an array of objects containing the service name, description, friendly name,
 * and the result of the status check.
 *
 * @returns {Promise<ServiceStatusResult[]>} A promise that resolves to an array of service status results.
 */
export default async function getServiceStatus() {
	const firebase = (await getFirebaseStatus()) as FirebaseResult;
	const stripe = (await getStripeStatus()) as StripeResult;
	const crisp = (await getCrispStatus()) as CrispResult;

	return [
		{
			service: "firebase",
			description: "Stores your website & login information",
			friendly_name: "Storage & Authentication",
			result: firebase,
		},
		{
			service: "stripe",
			description: "For your payments and subscriptions",
			friendly_name: "Billing",
			result: stripe,
		},
		{
			service: "crisp",
			description: "For your to be able to speak to our team",
			friendly_name: "Support",
			result: crisp,
		},
	] as ServiceStatusResult[];
}
