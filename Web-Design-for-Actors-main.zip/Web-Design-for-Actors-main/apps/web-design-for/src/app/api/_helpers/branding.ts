// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import { brandMap } from "@/app/_l10n/map";

// Component Imports
import { cookies } from "next/headers";

// Types
import { l10nType } from "@okedia/shared/types/l10n";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Determines the brand to be used based on the provided URL, URL parameters, and the last used brand.
 *
 * @param url - The URL object which may contain the host information.
 * @param params - The URLSearchParams object which may contain the "theme" parameter.
 * @param lastBrandUsed - The last brand that was used, if any.
 * @returns The determined brand as an l10nType.
 */
export function determineBrand(
	url: URL | undefined,
	params: URLSearchParams,
	lastBrandUsed: string | undefined
): l10nType {
	const brandInUrlParams = params.get("theme");

	function findBrandInBrandMapArray(id?: string): l10nType {
		const foundBrand = brandMap.find((brand) => {
			return brand.id === id;
		});

		if (foundBrand) {
			return foundBrand;
		} else {
			return brandMap[0];
		}
	}

	// If there is a brand specified in the URL Parameters
	if (brandInUrlParams) {
		return findBrandInBrandMapArray(brandInUrlParams);
	}

	// If there is a subdomain, return the corresponding brand
	const subdomain = url?.host.split(".")[0];
	if (
		subdomain &&
		subdomain !== "www" && // Exclude www
		subdomain !== "dev" && // Exclude development environments
		subdomain !== "d" // Exclude webside demo pages
	) {
		return findBrandInBrandMapArray(subdomain);
	}

	// If none of the above, but the value of the last brand is available
	if (lastBrandUsed) {
		findBrandInBrandMapArray(lastBrandUsed);
	}

	// If all else fails, return the default brand
	return findBrandInBrandMapArray(undefined);
}

export async function getServerBrand(urlString: string | undefined) {
	const url = new URL(urlString ?? "");
	const lastBrandUsed = (await cookies()).get("brand")?.value;

	return determineBrand(url, url.searchParams, lastBrandUsed);
}
