// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import generateId from "../generateId";

// Types
import { CrispResult } from "@okedia/shared/types/serviceStatusTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Fetches the status of the Crisp service.
 *
 * @returns {Promise<CrispResult>} A promise that resolves to a CrispResult object.
 * If the service status is not "healthy", the result will include an id, impact level, and description.
 * Otherwise, the result will indicate that the status is "up".
 */
export default async function getCrispStatus(): Promise<CrispResult> {
	const response = await fetch("https://status.crisp.chat/status/text/");
	const textData = await response.text();

	if (textData !== "healthy") {
		return {
			id: await generateId(5),
			impact: "medium",
			desc: textData,
		};
	} else {
		return { status: "up" };
	}
}
