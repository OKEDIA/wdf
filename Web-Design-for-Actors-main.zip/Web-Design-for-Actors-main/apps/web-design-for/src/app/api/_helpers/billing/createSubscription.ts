// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import { stripeAdmin, SubscriptionCreateParams } from "@okedia/shared/stripe";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default async function createSubscription(
	params: SubscriptionCreateParams
) {
	return await stripeAdmin.subscriptions.create({
		...params,
	});
}
