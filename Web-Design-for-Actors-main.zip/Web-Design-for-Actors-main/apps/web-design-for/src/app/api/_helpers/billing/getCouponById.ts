// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import { stripeAdmin } from "@okedia/shared/stripe";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default async function getCouponById(couponId: string, limit = 1) {
	return await stripeAdmin.promotionCodes.list({
		limit, // Limits the amount of matching coupons to return, defaults to 1
		active: true, // Return only active coupons
		code: couponId, // Filter the response by a matching Coupon Code
		expand: ["data.coupon.applies_to"], // Expand the response to include the applicable_to field
	});
}
