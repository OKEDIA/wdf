// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import { stripeAdmin } from "@okedia/shared/stripe";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default async function removePaymentMethod(methodId: string) {
	return await stripeAdmin.paymentMethods.detach(methodId);
}
