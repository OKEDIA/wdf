// React Imports

import { StripeResult } from "@okedia/shared/types/serviceStatusTypes";
import generateId from "../generateId";

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities

// Types
type StripeStatus = {
	id: string;
	UptimeStatus: string;
	message: string;
};
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Fetches the current status of the Stripe service.
 *
 * @returns {Promise<StripeResult>} A promise that resolves to an object containing the Stripe service status.
 * If the service is not "up", the object includes an id, impact, and description of the issue.
 * Otherwise, it returns an object with the status "up".
 *
 * @throws {Error} If the fetch request fails or the response cannot be parsed as JSON.
 */
export default async function getStripeStatus(): Promise<StripeResult> {
	const response = await fetch("https://status.stripe.com/current/full");
	const stripedata: StripeStatus = await response.json();

	if (stripedata.UptimeStatus !== "up") {
		return {
			id: await generateId(5),
			impact: stripedata.UptimeStatus,
			desc: stripedata.message,
		};
	} else {
		return { status: "up" };
	}
}
