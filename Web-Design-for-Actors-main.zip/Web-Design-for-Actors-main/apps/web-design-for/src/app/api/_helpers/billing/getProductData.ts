// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import { stripeAdmin } from "@okedia/shared/stripe";
import Stripe from "stripe";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default async function getProductData(
	params: Stripe.ProductListParams | { productId: string }
) {
	if ("productId" in params) {
		return await stripeAdmin.products.retrieve(params.productId as string);
	}

	return await stripeAdmin.products.list({ ...params });
}
