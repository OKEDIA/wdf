// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import { stripeAdmin } from "@okedia/shared/stripe";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default async function createPaymentIntent({
	confirmationTokenId,
	amount,
	customerId,
}: {
	confirmationTokenId: string;
	amount: number;
	customerId: string;
}) {
	return await stripeAdmin.paymentIntents.create({
		confirm: true,
		amount: amount,
		currency: "gbp",
		confirmation_token: confirmationTokenId,
		automatic_payment_methods: { enabled: true },
		setup_future_usage: "off_session",
		return_url: "https://app.webdesignforactors.com/",
		customer: customerId,
	});
}
