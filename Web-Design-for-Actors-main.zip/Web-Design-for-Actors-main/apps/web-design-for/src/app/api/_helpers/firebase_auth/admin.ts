import "server-only";

// React Imports

// Next.js Imports

// Firebase Imports
import { getFirebaseAuth } from "next-firebase-auth-edge";
import { formatPrivateKey } from "@okedia/shared/helpers/string";

// Helpers

// Other libraries or utilities

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export const {
	// getCustomIdAndRefreshTokens,
	// verifyIdToken,
	createCustomToken,
	// handleTokenRefresh,
	getUser,
	listUsers,
	getUserByEmail,
	// createUser,
	updateUser,
	deleteUser,
	// verifyAndRefreshExpiredIdToken,
	setCustomUserClaims,
} = getFirebaseAuth({
	apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY as string,
	serviceAccount: {
		projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID as string,
		clientEmail: process.env.NEXT_PUBLIC_FIREBASE_CLIENT_EMAIL as string,
		privateKey: formatPrivateKey(process.env.FIREBASE_PRIVATE_KEY),
	},
});
