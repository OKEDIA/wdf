// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import { stripeAdmin } from "@okedia/shared/stripe";
import Stripe from "stripe";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default async function updateSubscription(
	subscriptionId: string,
	params: Stripe.SubscriptionUpdateParams
) {
	return await stripeAdmin.subscriptions.update(subscriptionId, { ...params });
}
