// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import { logger } from "@okedia/shared/logging";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export type SendySubscribersProperties = Partial<{
	email: string;
	name: string;
	list: string;
	country: string;
	ipaddress: string;
	referrer: string;
	gdpr: boolean;
	silent: boolean;
	hp: boolean;
}>;

type SendySuccessResponse = "1";
type SendyErrorResponse =
	| "Some fields are missing."
	| "API key not passed"
	| "Invalid API key"
	| "Invalid email address."
	| "Already subscribed."
	| "Bounced email address."
	| "Email is suppressed."
	| "Invalid list ID."
	| "Email does not exist.";

export type SendyResponse = SendySuccessResponse | SendyErrorResponse;

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export function handleSendyResponse(res: SendyResponse) {
	const okayResponses = ["1", "Already subscribed."];
	const warningResponses = ["Bounced email address.", "Email is suppressed."];

	if (!res) {
		logger.error("Sendy response is empty");
		throw new Error("Unexpected response from Sendy");
	}

	if (okayResponses.includes(res)) {
		logger.info("The sendy request was fulfilled.");
		return res;
	} else if (warningResponses.includes(res)) {
		logger.warn(`Warning: The Sendy Request was not fulfilled due to ${res}`);
		return res;
	} else {
		logger.error(`Error: The Sendy Request was not fulfilled due to ${res}`);
		throw new Error(res);
	}
}
