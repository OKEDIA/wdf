// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

import crypto from "crypto";

/**
 * Generates a random ID string of the specified length.
 *
 * This function uses the `crypto` module to generate a random sequence of bytes,
 * converts it to a base64 string, and then removes any non-alphanumeric characters.
 * The resulting string is truncated to the specified length and converted to lowercase.
 *
 * @param {number} length - The length of the ID to generate.
 * @returns {Promise<string>} A promise that resolves to the generated ID string.
 * @throws {Error} If the ID cannot be generated.
 */
export default async function generateId(length: number): Promise<string> {
	return new Promise((resolve, reject) => {
		try {
			const id = crypto
				.randomBytes(length)
				.toString("base64")
				.replace(/\+/g, "")
				.replace(/\//g, "")
				.substr(0, length)
				.toLowerCase();

			if (!id) {
				throw new Error("Unable to generate ID");
			}

			resolve(id);
		} catch (error) {
			reject(error);
		}
	});
}
