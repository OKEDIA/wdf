// React Imports

import { checkIsEmpty } from "@okedia/shared/helpers";
import { useServersideDatabase } from "@okedia/shared/hooks/database/useServersideDatabase";

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import { logger } from "@okedia/shared/logging";
import {
	handleSendyResponse,
	SendyResponse,
	SendySubscribersProperties,
} from "./handleSendyResponse";

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default async function unsubscribe(
	query: Pick<SendySubscribersProperties, "email" | "list">
): Promise<SendyResponse> {
	logger.info(query, "Unsubscribing a User to Sendy");
	const db = useServersideDatabase(
		process.env.SENDY_API_URL as string,
		"sendy",
		"text/html"
	);

	logger.debug("Converting query to FormData");
	const formData = new FormData();
	formData.append("boolean", "true");
	formData.append("api_key", process.env.SENDY_API_KEY as string);

	Object.entries(query).forEach(([key, value]) => {
		if (!checkIsEmpty(value as any)) {
			formData.append(key, String(value));
		}
	});

	logger.debug(formData.toString(), "Sending request to Sendyu");
	return await db
		.post<SendyResponse>({
			url: "/unsubscribe",
			body: formData,
		})
		.then((res) => handleSendyResponse(res));
}
