// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import { stripeAdmin } from "@okedia/shared/stripe";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default async function getCustomer(id: string) {
	const customer = await stripeAdmin.customers.retrieve(id);

	return customer;
}
