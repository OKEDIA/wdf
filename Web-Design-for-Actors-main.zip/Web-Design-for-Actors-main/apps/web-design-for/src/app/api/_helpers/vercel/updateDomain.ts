// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import { NextRequest } from "next/server";
import { useServersideDatabase } from "@okedia/shared/hooks/database/useServersideDatabase";
import { apiLogging } from "@okedia/shared/logging/api";

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

interface DomainResponse {
	boughtAt: number | null;
	createdAt: number;
	expiresAt: number | null;
	id: string;
	name: string;
	renew: boolean;
	serviceType: string;
	transferredAt: number | null;
	userId: string;
	teamId: string | null;
	cdnEnabled: boolean;
	verified: boolean;
	nameservers: string[];
	intendedNameservers: string[];
	creator: {
		id: string;
		customerId: string;
		email: string;
		username: string;
	};
	zone: boolean;
	configVerifiedAt: number | null;
	txtVerifiedAt: number | null;
	nsVerifiedAt: number | null;
	verificationRecord: string;
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default async function updateVercelDomain(
	req: NextRequest,
	domainName: string,
	body: {
		renew?: boolean;
		customNameservers?: string[];
		zone?: boolean;
	}
): Promise<DomainResponse> {
	const logger = await apiLogging(req);
	const db = useServersideDatabase(
		process.env.VERCEL_API_BASE_URL as string,
		"vercel"
	);
	logger.custom.info(`[Vercel API] Updating domain status for ${domainName}`);

	const response = await db.patch<DomainResponse>({
		url: `v3/domains/${domainName}`,
		body: JSON.stringify({
			op: "update",
			...body,
		}),
	});

	logger.custom.info("[Vercel API] Done!");

	return response;
}
