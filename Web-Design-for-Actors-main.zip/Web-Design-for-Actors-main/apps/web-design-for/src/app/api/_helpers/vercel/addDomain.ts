// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import { NextRequest } from "next/server";
import { useServersideDatabase } from "@okedia/shared/hooks/database/useServersideDatabase";
import { apiLogging } from "@okedia/shared/logging/api";

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

interface DomainResponse {
	boughtAt: number | null;
	createdAt: number;
	expiresAt: number | null;
	id: string;
	name: string;
	renew: boolean;
	serviceType: string;
	transferredAt: number | null;
	userId: string;
	teamId: string | null;
	cdnEnabled: boolean;
	verified: boolean;
	nameservers: string[];
	intendedNameservers: string[];
	creator: {
		id: string;
		customerId: string;
		email: string;
		username: string;
	};
	zone: boolean;
	configVerifiedAt: number | null;
	txtVerifiedAt: number | null;
	nsVerifiedAt: number | null;
	verificationRecord: string;
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default async function addDomainToVercel(
	req: NextRequest,
	domainName: string
): Promise<DomainResponse> {
	const logger = await apiLogging(req);
	const db = useServersideDatabase(
		process.env.VERCEL_API_BASE_URL as string,
		"vercel"
	);
	logger.custom.info(
		`[Vercel API] Adding domain ${domainName} to Vercel Account`
	);

	const response = await db.post<DomainResponse>({
		url: `v5/domains`,
		body: {
			method: "add",
			name: domainName,
			cdnEnabled: true,
			zone: false,
		},
	});

	logger.custom.info(
		`[Vercel API] Adding domain ${domainName} to Vercel Project`
	);

	const projectResponse = await db.post<DomainResponse>({
		url: `v10/projects/${process.env.VERCEL_WEBSITES_PROJECT_ID}/domains`,
		body: {
			name: domainName,
		},
	});

	if (projectResponse.verified === true) {
		logger.custom.info(`[Vercel API] Done!`);
		return response;
	} else {
		throw new Error("Unable to verify the domain.");
	}
}
