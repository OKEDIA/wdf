// React Imports

// Next.js Imports

// Firebase Imports

// Helpers

// Other libraries or utilities
import { CustomerCreateParams, stripeAdmin } from "@okedia/shared/stripe";

// Types
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default async function createNewCustomer(params: CustomerCreateParams) {
	return await stripeAdmin.customers.create({
		...params,
		description: "Web Design for Actors customer",
	});
}
