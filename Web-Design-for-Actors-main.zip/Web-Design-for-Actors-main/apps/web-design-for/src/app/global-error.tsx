"use client";
import {
	Alert,
	Box,
	Button,
	Code,
	Container,
	createTheme,
	Flex,
	Group,
	MantineProvider,
	Portal,
	rem,
	Spoiler,
	Text,
	Title,
} from "@mantine/core";
import { IconMeteorFilled } from "@tabler/icons-react";
import Link from "next/link";
import { isProductionEnvironment } from "@okedia/shared/helpers";
import { useEffect, useState } from "react";
import { brandMap } from "./_l10n/map";

// Error boundaries must be Client Components

// React Imports

// Next.js Imports

// Lower Order Components
import "@mantine/core/styles.css";
import WdfLogo from "./(root)/_components/logos/WdfLogo";

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function GlobalError({
	reset,
	error,
}: {
	error: Error & { digest?: string };
	reset: () => void;
}) {
	useEffect(() => {
		console.error(error);
	}, [error]);

	const [stackSpoilerExtended, setStackSpoilerExtended] = useState(false);
	const [time, setTime] = useState<number>(5);
	const [viewError, setViewError] = useState<boolean>(!isProductionEnvironment);

	const baseTheme = createTheme({
		primaryShade: 5,
		fontSizes: {
			sm: rem(15),
		},
		headings: {
			fontFamily: "Figtree, sans-serif",
			sizes: {
				h1: { fontWeight: "700" },
				h2: { fontWeight: "500" },
				h3: { fontWeight: "400" },
				h4: { fontWeight: "400" },
				h5: { fontWeight: "300" },
				h6: { fontWeight: "300" },
			},
		},
		fontFamily: "Figtree, sans-serif",
	});

	const theme = createTheme({ ...baseTheme, ...brandMap[0].theme });

	useEffect(() => {
		const intervalId = setInterval(() => {
			setTime((prevTime) => {
				if (prevTime < 1) {
					clearInterval(intervalId);
					return 0; // Ensure we return a number (0) here
				} else {
					return prevTime - 1;
				}
			});
		}, 1000);

		// Clear the interval when the component unmounts or when the time reaches 0
		return () => {
			clearInterval(intervalId);
		};
	}, [time]);

	function handleTryAgain() {
		setTime(10);
		reset();
	}

	return (
		// global-error must include html and body tags
		<html>
			<body>
				<MantineProvider theme={theme}>
					<Box
						bg="branding"
						c="white"
						h="100vh"
					>
						<Container h="100%">
							<Flex
								direction="column"
								justify="center"
								align="center"
								gap="lg"
								h="100%"
							>
								<IconMeteorFilled size="10rem" />
								<Title
									style={{ textAlign: "center" }}
									mb={0}
								>
									Something went wrong
								</Title>
								<Text
									mt="-20px"
									mb="xl"
								>
									Try again or come back later.
								</Text>

								<Group
									justify="middle"
									align="center"
								>
									<Button
										variant="white"
										fullWidth
										type="button"
										onClick={handleTryAgain}
										disabled={time > 0}
									>
										{`Try Again${time ? ` (${time})` : ""}`}
									</Button>
									<Button
										fullWidth
										type="button"
										component={Link}
										href="/"
										variant="white"
									>
										Go to Homepage
									</Button>
								</Group>
								{viewError && (
									<Alert
										variant="white"
										title={`${error.name ?? "Unknown"}: ${
											error.message ?? "(No Error Message Available)"
										}`}
										mt="5vh"
									>
										{error.stack && (
											<Spoiler
												showLabel="More"
												hideLabel="Less"
												expanded={stackSpoilerExtended}
												onExpandedChange={setStackSpoilerExtended}
											>
												<b>Stack: </b>
												<Code>{error.stack}</Code>
											</Spoiler>
										)}

										{error.digest && (
											<Text>
												<b>Digest: </b>
												<Code>{error.digest ?? ""}</Code>
											</Text>
										)}
									</Alert>
								)}
							</Flex>
						</Container>
						<Portal>
							<WdfLogo
								style={{
									position: "absolute",
									bottom: "10vh",
									left: "10vh",
									scale: "2",
									color: "white",
								}}
							/>
						</Portal>
					</Box>
				</MantineProvider>
			</body>
		</html>
	);
}
