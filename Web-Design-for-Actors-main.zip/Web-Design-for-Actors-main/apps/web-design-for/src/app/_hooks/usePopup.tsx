// React Imports
import { ReactNode, useCallback, useState } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { Alert, Button, Group, Modal, Portal } from "@mantine/core";
import { Confetti } from "@neoconfetti/react";

// Context & Helpers

// Other libraries or utilities
import { useViewportSize } from "@mantine/hooks";

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
interface PopupModalProps {
	opened: boolean;
	title: string;
	/**
	 * @deprecated use children instead
	 */ body?: ReactNode;
	submit?: string;
	cancel?: string;
	onSubmit: () => void | Promise<void>;
	onCancel?: () => void | Promise<void>;
	forceAction?: boolean;
	withConfetti?: boolean;
}

export interface UsePopupReturns {
	Element: (props: { children?: ReactNode }) => JSX.Element;
	modalConfig: PopupModalProps;
	setModalConfig: (config: PopupModalProps) => void;
	handleSubmit: () => Promise<any>;
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Custom hook to manage the state and behavior of a popup modal.
 *
 * @returns {Object} An object containing the following properties and methods:
 * - `Element`: A React component that renders the modal.
 * - `modalConfig`: The current configuration of the modal.
 * - `setModalConfig`: A function to update the modal configuration.
 * - `handleSubmit`: A function to handle the submit action of the modal.
 *
 * @typedef {Object} PopupModalProps
 * @property {boolean} opened - Indicates whether the modal is open.
 * @property {string} title - The title of the modal.
 * @property {ReactNode | null} body - The body content of the modal. (deprecated)
 * @property {string | undefined} submit - The text for the submit button.
 * @property {string | undefined} cancel - The text for the cancel button.
 * @property {Function} onSubmit - The function to call when the submit button is clicked.
 * @property {Function} onCancel - The function to call when the cancel button is clicked.
 * @property {boolean} forceAction - If true, the modal cannot be closed by clicking outside or pressing escape.
 * @property {boolean} withConfetti - If true, confetti animation will be shown when the modal is open.
 *
 * @typedef {Object} Error
 * @property {string} message - The error message.
 *
 * @typedef {Object} ViewportSize
 * @property {number} height - The height of the viewport.
 * @property {number} width - The width of the viewport.
 *
 * @function handleClose
 * Closes the modal by setting `opened` to false in the modal configuration.
 *
 * @function handleSubmit
 * Handles the submit action of the modal. Calls the `onSubmit` function from the modal configuration.
 * If `onSubmit` is successful, the modal is closed. If an error occurs, it is set in the state.
 *
 * @function handleCancel
 * Handles the cancel action of the modal. Calls the provided `onCancel` function or the `onCancel` function
 * from the modal configuration. If no `onCancel` function is provided, the modal is closed.
 *
 * @component Element
 * A React component that renders the modal with the current configuration.
 * Displays confetti animation if `withConfetti` is true.
 * Displays an error alert if an error occurs.
 * Renders submit and cancel buttons if they are provided in the modal configuration.
 *
 * @param {Object} props - The props for the Element component.
 * @param {ReactNode} [props.children] - The children to render inside the modal.
 */
export default function usePopup(): UsePopupReturns {
	const [modalConfig, setModalConfig] = useState<PopupModalProps>({
		opened: false,
		title: "",
		body: null,
		submit: undefined,
		cancel: undefined,
		onSubmit: () => {},
		onCancel: () => {},
		forceAction: false,
		withConfetti: false,
	});

	const [error, setError] = useState<Error | undefined>(undefined);
	const [isLoading, setIsLoading] = useState(false);
	const { height, width } = useViewportSize();

	const handleClose = async () => {
		setModalConfig((prevValues) => ({
			...prevValues,
			opened: false,
		}));
	};

	const handleSubmit = async () => {
		try {
			setIsLoading(true);

			if (!(typeof modalConfig.onSubmit === "function")) {
				throw new Error("No function");
			}
			const res = await modalConfig.onSubmit();
			handleClose(); // Only close the modal if onSubmit is successful

			return res;
		} catch (error) {
			setError(error as Error);
			throw error; // Re-throw the error to be caught by the caller
		} finally {
			setIsLoading(false);
		}
	};

	const handleCancel = async () => {
		try {
			setIsLoading(true);

			if (!(typeof modalConfig.onCancel === "function")) {
				throw new Error("No function");
			}
			const res = await modalConfig.onCancel();
			handleClose(); // Only close the modal if onCancel is successful

			return res;
		} catch (error) {
			setError(error as Error);
			throw error; // Re-throw the error to be caught by the caller
		} finally {
			setIsLoading(false);
		}
	};
	/**
	 * Element component renders a modal with optional confetti, error alert, and action buttons.
	 *
	 * @param {Object} props - The props for the Element component.
	 * @param {ReactNode} [props.children] - Optional children to be rendered inside the modal.
	 *
	 * @returns {JSX.Element} The rendered modal component.
	 *
	 * @example
	 * <Element>
	 *   <div>Content goes here</div>
	 * </Element>
	 *
	 * @remarks
	 * - The modal configuration is controlled by `modalConfig` which includes properties like `body`, `forceAction`, `withConfetti`, `submit`, and `cancel`.
	 * - The modal displays confetti if `modalConfig.withConfetti` is true.
	 * - An error alert is shown if `error` is defined.
	 * - The modal includes submit and cancel buttons if `modalConfig.submit` and `modalConfig.cancel` are defined respectively.
	 * - The `handleClose`, `handleSubmit`, and `handleCancel` functions are used to handle respective actions.
	 */
	function Element({ children }: { children?: ReactNode }) {
		const renderChildren = useCallback(() => {
			return children || modalConfig.body;
		}, [children, modalConfig.body]);

		return (
			<Modal
				onClose={handleClose}
				withCloseButton={!modalConfig.forceAction}
				closeOnClickOutside={!modalConfig.forceAction}
				closeOnEscape={!modalConfig.forceAction}
				opened={modalConfig.opened}
				size="xl"
			>
				{modalConfig.withConfetti && (
					<Portal>
						<Confetti />
					</Portal>
				)}
				{renderChildren()}
				{error && (
					<Alert
						color="red"
						variant="light"
						withCloseButton
						title="Error"
						onClose={() => {
							setError(undefined);
							setIsLoading(false);
						}}
					>
						{error.message ?? ""}
					</Alert>
				)}

				<Group
					mt="lg"
					justify="flex-end"
				>
					{modalConfig.submit && (
						<Button
							type="button"
							onClick={() => handleSubmit()}
							disabled={isLoading}
							loading={isLoading}
						>
							{modalConfig.submit}
						</Button>
					)}
					{modalConfig.cancel && (
						<Button
							type="button"
							onClick={() => handleCancel()}
							disabled={isLoading}
							loading={isLoading}
						>
							{modalConfig.cancel}
						</Button>
					)}
				</Group>
			</Modal>
		);
	}

	return {
		Element,
		modalConfig,
		setModalConfig,
		handleSubmit,
	};
}
