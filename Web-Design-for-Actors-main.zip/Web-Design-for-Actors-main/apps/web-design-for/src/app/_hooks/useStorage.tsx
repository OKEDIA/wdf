"use client";

// React Imports
import { useContext, useState } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { Container, Group, Stack, Text } from "@mantine/core";

// Context & Helpers

import { UserContext } from "../_context/User";
import FilePreview from "../dashboard/_components/FilePreview";

// Other libraries or utilities
import {
	FullMetadata,
	getDownloadURL,
	getMetadata,
	ref,
	uploadBytes,
	UploadResult,
} from "firebase/storage";
import { storage } from "@okedia/shared/firebase/standard";
import usePopup from "./usePopup";

// Types
import { AuthContextValues } from "@okedia/shared/types/contextTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

interface FileRef {
	file?: File;
	metadata: FullMetadata;
	downloadUrl?: string;
}

export interface UseStorageReturns {
	upload: (params: {
		file: File;
		onChange: any;
	}) => Promise<UploadResult | undefined>;
	uploadData: UploadResult | undefined;
	ConfirmOverwriteModal: React.ComponentType;
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Retrieves a file's metadata and download URL from Firebase storage.
 *
 * @param {string} filePath - The path to the file in Firebase storage.
 * @returns {Promise<FileRef | null>} A promise that resolves to an object containing the file's metadata and download URL, or null if the file does not exist.
 * @throws Will throw an error if there is an issue retrieving the file, other than the file not existing.
 */
async function getFile(filePath: string): Promise<FileRef | null> {
	const fileRef = ref(storage, filePath);

	try {
		const metadata = await getMetadata(fileRef);
		const downloadUrl = await getDownloadURL(fileRef);
		return { metadata: metadata, downloadUrl };
	} catch (error: any) {
		if (error.code === "storage/object-not-found") {
			return null; // File does not exist
		}
		throw error; // Other errors
	}
}

/**
 * PopupBody component displays a comparison between a new file and an existing file.
 * It shows a preview of both files along with their metadata.
 *
 * @param {Object} props - The properties object.
 * @param {File} props.file - The new file to be compared.
 * @param {FileRef} props.existingFile - The existing file reference.
 *
 * @throws {Error} Throws an error if the existing file is not provided.
 *
 * @returns {JSX.Element} The JSX element representing the popup body.
 */
function PopupBody({
	file,
	existingFile,
}: {
	file: File;
	existingFile: FileRef;
}) {
	if (!existingFile) {
		throw new Error("Unable to generate popup body, no existing file found.");
	}

	return (
		<Container>
			<Text py="sm">
				A file with this name already exists. What would you like to do?
			</Text>
			<Group
				justify="center"
				py="lg"
			>
				<Stack
					align="stretch"
					justify="center"
					gap={0}
					bd="1px solid branding.5"
					p="sm"
				>
					<Text fw={700}>New File</Text>
					<FilePreview
						file={file}
						props={{ alt: file.name, height: "200px", width: "100%" }}
					/>
					<Text
						truncate
						lineClamp={1}
						inline
						fw={600}
					>
						{file.name}
					</Text>
					<Text
						truncate
						lineClamp={1}
						inline
					>
						Last Modified: {new Date(file.lastModified).toDateString()}
					</Text>
				</Stack>
				<Stack
					align="stretch"
					justify="center"
					gap={0}
					bd="1px solid branding.5"
					p="sm"
				>
					<Text fw={700}>Original File</Text>
					<FilePreview
						fileUrl={existingFile.downloadUrl}
						props={{ alt: file.name, height: "200px", width: "100%" }}
					/>
					<Text
						truncate
						lineClamp={1}
						inline
						fw={600}
					>
						{existingFile.metadata?.name ?? "Hello"}
					</Text>
					<Text
						truncate
						lineClamp={1}
						inline
					>
						Last Modified:{" "}
						{new Date(existingFile.metadata.timeCreated).toDateString()}
					</Text>
				</Stack>
			</Group>
		</Container>
	);
}

/**
 * Custom hook to handle file storage operations.
 *
 * @returns {Object} An object containing the upload data, upload function, and the confirm overwrite modal element.
 *
 * @typedef {Object} UploadParams
 * @property {File} file - The file to be uploaded.
 * @property {Function} onChange - Callback function to handle changes after upload.
 *
 * @typedef {Object} UploadResult
 * @property {Object} metadata - Metadata of the uploaded file.
 * @property {string} downloadUrl - URL to download the uploaded file.
 *
 * @function upload
 * @param {UploadParams} params - Parameters for the upload function.
 * @returns {Promise<UploadResult | undefined>} The result of the upload operation.
 *
 * @throws {Error} Throws an error if the upload operation fails.
 */
export default function useStorage(): UseStorageReturns | undefined {
	const [uploadData, setUploadData] = useState<UploadResult>();
	const user = useContext(UserContext) as AuthContextValues;
	if (!user?.states?.userAuthData) return;

	const userId = user.states.userAuthData?.decodedToken?.user_id;
	const confirmOverwriteModal = usePopup();

	if (!userId) {
		return;
	}

	async function upload({ file, onChange }: { file: File; onChange: any }) {
		if (!file) {
			return;
		}

		try {
			const filepath = `${userId}/${file.name}`;
			const existingFile = await getFile(filepath);
			const fileRef = ref(storage, filepath);

			if (existingFile?.metadata) {
				console.log("File already exists, showing keep or replace prompt");

				confirmOverwriteModal.setModalConfig({
					opened: true,
					title: "Duplicate File Detected",
					body: PopupBody({ file, existingFile }),
					onSubmit: async () => {
						await uploadBytes(fileRef, file).then((snapshot) => {
							console.log("Uploaded a file!");
							setUploadData(snapshot);

							return onChange({
								...snapshot.metadata,
								downloadUrl: existingFile.downloadUrl,
							});
						});
					},
					onCancel: () => {
						console.log("Keeping Old File");
						const fileToReturn = {
							ref: fileRef,
							metadata: existingFile.metadata,
						};
						setUploadData(fileToReturn);

						return onChange({
							...fileToReturn.metadata,
							downloadUrl: existingFile.downloadUrl,
						});
					},
					submit: "Overwrite",
					cancel: "Keep Original",
					forceAction: true,
				});
			} else {
				await uploadBytes(fileRef, file).then(async (snapshot) => {
					console.log("Uploaded a file!");
					setUploadData(snapshot);
					const downloadUrl = await getDownloadURL(snapshot.ref);

					return onChange({
						...snapshot.metadata,
						downloadUrl: downloadUrl,
					});
				});
			}
		} catch (e: any) {
			throw new Error(e.message);
		}

		return uploadData;
	}

	return {
		uploadData,
		upload,
		ConfirmOverwriteModal: confirmOverwriteModal.Element,
	};
}
