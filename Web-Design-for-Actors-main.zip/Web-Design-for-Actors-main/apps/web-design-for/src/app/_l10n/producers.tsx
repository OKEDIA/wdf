// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { MantineColorsTuple } from "@mantine/core";
import Logo from "../../../public/Producers_Logo.png";

// Context & Helpers

// Other libraries or utilities

// Types
import { l10nType, Localisation } from "@okedia/shared/types/l10n";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

const localisation: Localisation = {
	l10n: {
		websiteBuilder: {
			intro: {
				title: "Advertise your show within the hour",
				subtitle:
					"Create a website that your target audience are used to with our website builder. We include all the tools that you will need in order to easily & effectively manage your website.",
				secondaryCta: "Find out More",
				primaryCta: "Get Started",
				smallprint:
					"You can preview your website online before making it public.",
				secondaryCtaUrl:
					"https://creativeindustries.group/hub/en/wdf/article/producers-asset-guideline",
				smallprintUrl:
					"https://creativeindustries.group/hub/en/wdf/article/general",
			},
		},
	},
	logoURL: Logo,
	article: "a",
	singular: "producer",
};

export const producers: l10nType = {
	id: "producers",
	public_name_ends: "Producers",
	isBrand: true,
	theme: {
		colors: {
			branding: [
				"#ffeaea",
				"#fed5d8",
				"#f2a9ad",
				"#e97b82",
				"#e1545c",
				"#dd3a44",
				"#db2c37",
				"#c31e2a",
				"#ae1724",
				"#9a091d",
			] as MantineColorsTuple,
		},
		primaryColor: "branding",
		other: { ...localisation, id: "producers" },
	},
	...localisation,
};
