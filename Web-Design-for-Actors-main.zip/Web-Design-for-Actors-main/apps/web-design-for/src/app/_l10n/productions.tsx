// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { MantineColorsTuple } from "@mantine/core";
import Logo from "../../../public/Producers_Logo.png";

// Context & Helpers

// Other libraries or utilities

// Types
import { l10nType, Localisation } from "@okedia/shared/types/l10n";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

const localisation: Localisation = {
	l10n: {
		websiteBuilder: {
			intro: {
				title: "Promote your production within the hour",
				subtitle:
					"To kickstart your production's new website, simply gather the essential information and assets and let the WDF platform do the rest! Get ready for a seamless, hassle-free website creation experience.",
				secondaryCta: "View Asset Guidelines",
				primaryCta: "Get Started",
				smallprint:
					"Previewing your website online before making it public is free. Once published, our monthly subscription starts at £14.99 and includes a free domain name and email address. It is subject to availability and terms and conditions. To find out more, click here.",
				secondaryCtaUrl:
					"https://creativeindustries.group/hub/en/wdf/article/producers-asset-guideline",
				smallprintUrl:
					"https://creativeindustries.group/hub/en/wdf/article/general",
			},
		},
	},
	article: "a",
	singular: "production",
	logoURL: Logo,
};

export const productions: l10nType = {
	id: "productions",
	public_name_ends: "Productions",
	isBrand: false,
	theme: {
		colors: {
			branding: [
				"#ffeaea",
				"#fed5d8",
				"#f2a9ad",
				"#e97b82",
				"#e1545c",
				"#dd3a44",
				"#db2c37",
				"#c31e2a",
				"#ae1724",
				"#9a091d",
			] as MantineColorsTuple,
		},
		primaryColor: "branding",
		other: { ...localisation, id: "productions" },
	},
	...localisation,
};
