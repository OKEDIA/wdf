// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { MantineColorsTuple } from "@mantine/core";
import Logo from "../../../public/Actors_Logo.png";

// Context & Helpers

// Other libraries or utilities

// Types
import { l10nType, Localisation } from "@okedia/shared/types/l10n";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

const localisation: Localisation = {
	l10n: {
		websiteBuilder: {
			intro: {
				title: "Build your website in minutes",
				subtitle:
					"Tell us some information about you and your skills, upload your CV and Headshot, and we'll handle the rest. Update it here, at any time. It's as simple as that.",
				secondaryCta: "Learn More",
				primaryCta: "Create a Website",
				smallprint:
					"You can preview your website online before making it public. Our yearly subscription starts from £23.99 per year, which includes a free domain name and email address. Subject to availability & terms and conditions. To find out more, click here.",
				secondaryCtaUrl:
					"https://creativeindustries.group/hub/en/wdf/article/producers-asset-guideline",
				smallprintUrl:
					"https://creativeindustries.group/hub/en/wdf/article/general",
			},
		},
	},
	logoURL: Logo,
	article: "an",
	singular: "actor",
};

export const actors: l10nType = {
	isBrand: true,
	id: "actors",
	public_name_ends: "Actors",
	theme: {
		colors: {
			branding: [
				"#fef7e4",
				"#f6ebd4",
				"#ead6af",
				"#dcbf86",
				"#d2ac63",
				"#cba04c",
				"#c8993e",
				"#b18530",
				"#9d7627",
				"#89651a",
			] as MantineColorsTuple,
		},
		primaryColor: "branding",
		other: { ...localisation, id: "actors" },
	},
	...localisation,
};
