import { actors } from "./actors";
import { producers } from "./producers";
import { productions } from "./productions";

export const brandMap = [
	actors,
	producers,
	productions,
	// Add other brands i10n objects here
];
