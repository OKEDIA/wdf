"use server";

// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { Box, LoadingOverlay, MantineProvider } from "@mantine/core";

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * A React functional component that displays a loading overlay.
 *
 * This component uses the MantineProvider to provide theming and other context
 * to the child components. It renders a Box component containing a LoadingOverlay
 * component which is set to be visible.
 *
 * @returns {JSX.Element} The JSX code for the loading overlay component.
 */
export default async function Loading() {
	return (
		<MantineProvider>
			<Box>
				<LoadingOverlay visible />
			</Box>
		</MantineProvider>
	);
}
