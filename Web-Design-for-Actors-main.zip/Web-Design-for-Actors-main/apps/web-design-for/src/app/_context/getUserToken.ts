"use server";

// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers
import { signInWithCustomToken } from "firebase/auth";
import { Tokens } from "next-firebase-auth-edge";
import { DecodedIdToken } from "next-firebase-auth-edge/auth";
import {
	getValidCustomToken,
	getValidIdToken,
} from "next-firebase-auth-edge/lib/next/client";
import { checkUserAuthentication } from "@okedia/shared/firebase";
import { authForClientSide } from "@okedia/shared/firebase/standard";

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export async function getServerToken() {
	const { tokens } = await checkUserAuthentication();
	// See https://next-firebase-auth-edge-docs.vercel.app/docs/usage/client-side-apis#getvalidcustomtoken

	if (!tokens || !tokens.customToken) {
		return null;
	}

	const idToken = await getValidIdToken({
		serverIdToken: tokens?.token,
		refreshTokenUrl: "/api/refresh-token",
	});

	if (!idToken) {
		throw new Error("Invalid token");
	}

	const customToken = await getValidCustomToken({
		serverCustomToken: tokens?.customToken,
		refreshTokenUrl: "/api/refresh-token",
	});

	if (!customToken) {
		throw new Error("Invalid custom token");
	}

	// Should update the client-side auth state.
	await signInWithCustomToken(authForClientSide, customToken);

	// Sign in the client with the custom token.
	const userCredential = await signInWithCustomToken(
		authForClientSide,
		customToken
	);

	// Force a refresh of the ID token to update the client's auth state.
	const idTokenResult = await userCredential.user.getIdTokenResult(true);
	const updatedTokens: Tokens = {
		token: idTokenResult.token,
		customToken: customToken,
		decodedToken: idTokenResult.claims as unknown as DecodedIdToken,
	};

	return updatedTokens || null;
}
