"use client";

// React Imports
import React, { createContext, useEffect, useState } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers
import { useLocalStorage } from "@mantine/hooks";
import { authForClientSide } from "@okedia/shared/firebase/standard";
import { isProductionEnvironment } from "@okedia/shared/helpers";

// Other libraries or utilities
import { signInWithCustomToken } from "firebase/auth";
import LogRocket from "logrocket";
import { useDatabase } from "@okedia/shared/hooks";
import { handleSignOut } from "../_utilities/authenticationFunctions";

// Types
import { modals } from "@mantine/modals";
import { notifications } from "@mantine/notifications";
import { Tokens } from "next-firebase-auth-edge";
import { useSearchParams } from "next/navigation";
import { CustomerWithSession } from "@okedia/shared/stripe";
import { AuthContextValues } from "@okedia/shared/types/contextTypes";
import * as CookieConsent from "vanilla-cookieconsent";
import { defaultNotificationProps } from "../_utilities/notificationsConfig";
import { cookieConfig } from "./cookieConfig";
import { getServerToken } from "./getUserToken";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

const UserContext = createContext({});

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

function UserProvider({
	children,
	tokens,
}: {
	children?: React.ReactNode;
	tokens: Tokens | null;
}) {
	LogRocket.init("turuof/web-design-for", {
		rootHostname: "." + process.env.VERCEL_PROJECT_PRODUCTION_URL,
		shouldDebugLog: !isProductionEnvironment,
	});
	const params = useSearchParams();
	const [userAuthData, setUserAuthData] = useState<Tokens | null>(tokens);
	const [authLoading, setAuthLoading] = useState<boolean>(false);
	const [isFormValidating, setIsFormValidating] = useLocalStorage<boolean>({
		key: "validation",
		defaultValue: isProductionEnvironment,
	});
	const [billingUserData, setBillingUserData] = useState<
		CustomerWithSession | undefined
	>(undefined);
	const db = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);
	const [isLocalStorageEmailVerified, setLocalStorageEmailVerified] =
		useLocalStorage<string | null>({
			key: "email_verified",
			defaultValue: null,
			getInitialValueInEffect: false,
		});

	useEffect(() => {
		// Initialize cookie consent
		CookieConsent.run({
			onFirstConsent: ({ cookie }) => {
				db.post("/cookie-acceptance", cookie);
			},

			onChange: ({ cookie, changedCategories, changedServices }) => {
				db.patch("/cookie-acceptance", {
					...cookie,
					categories: changedCategories,
					services: changedServices,
				});
			},

			...(cookieConfig as CookieConsent.CookieConsentConfig),
		});
	}, []);

	async function refreshAuthState() {
		return await getServerToken()
			.then((res) => {
				signInWithCustomToken(authForClientSide, res?.customToken as string);
			})
			.catch((error) => {
				console.error("Error fetching server token:", error);
			})
			.finally(() => {
				setAuthLoading(false);
			});
	}

	useEffect(() => {
		window?.localStorage?.setItem(
			"validating",
			isFormValidating ? "enabled" : "disabled"
		);
	}, [isFormValidating]);

	useEffect(() => {
		if (!userAuthData) return;
		setAuthLoading(true);

		if (!authForClientSide.currentUser) {
			refreshAuthState();
		} else if (!userAuthData.decodedToken.localUID) {
			refreshAuthState();
		}

		if (
			!userAuthData.decodedToken.email_verified &&
			isLocalStorageEmailVerified !== "true"
		) {
			console.log(isLocalStorageEmailVerified);
			modals.openContextModal({
				modal: "verifyEmail",
				title: "⚠️ Verify your email",
				innerProps: {
					modalBody:
						"We need to verify your email address before you can use the app. Please check your inbox for a verification email or click the button below to resend it. If you don't see it, check your spam folder. You will not be able to publish your website until your email is verified.",
					email: userAuthData.decodedToken.email,
				},
			});
		}
	}, [userAuthData]);

	useEffect(() => {
		if (params.has("email_verified")) {
			modals.closeAll();
			notifications.show({
				...defaultNotificationProps,
				title: "✅ Email Verified",
				message: "Your email has been verified successfully.",
				color: "green",
			});
			setLocalStorageEmailVerified("true"); // Persist the verification status until the user re-authenticates
			const newParams = new URLSearchParams(params.toString());
			newParams.delete("email_verified");
			window.history.replaceState(
				{},
				document.title,
				`${window.location.pathname}?${newParams.toString()}`
			);
		}
	}, [params]);

	useEffect(() => {
		if (
			isProductionEnvironment &&
			userAuthData?.decodedToken?.isAdmin === true
		) {
			notifications.show({
				...defaultNotificationProps,
				title: "⚠️ Administrator Account using Live Data",
				message:
					"You are connected to the production database. All changes here are permanent and public.",
				color: "orange",
			});
		} else if (!isProductionEnvironment) {
			notifications.show({
				...defaultNotificationProps,
				title: "✅ Using Development Mode",
				message:
					"You're using the development database. Changes here won't be published to the real world.",
				color: "green",
			});
		}

		if (!userAuthData) return;

		if (!(userAuthData.decodedToken.localUID as string | undefined)) {
			console.warn(
				"No localUID found in claims yet so not looking for billing user."
			);
			return;
		}

		const abortController = new AbortController();
		const signal = abortController.signal;

		async function getStripeUser() {
			try {
				console.log("Fetching Stripe user data...");
				const res = await db
					.get<CustomerWithSession>(`/billing/customers/sessions`)
					.then((res) => {
						setBillingUserData(res as CustomerWithSession);
						console.log("Stripe user data fetched successfully!");
					});
			} catch (err: any) {
				if (signal.aborted) {
					console.log("Fetch aborted");
					return;
				}
				if (err.message.endsWith("Not Found")) {
					console.error(
						"Middleware did not create user in stripe. Will retry soon."
					);
					setTimeout(() => {
						if (!signal.aborted) {
							console.log("Retrying to fetch Stripe user data...");
							getStripeUser();
						}
					}, 10000);
				} else {
					console.error("Error fetching Stripe user data:", err);
				}
			} finally {
				if (!signal.aborted && authForClientSide.currentUser) {
					const user = authForClientSide.currentUser;
					LogRocket.identify(user.uid, {
						name: user.displayName ?? "",
						email: user.email ?? "",
						localUID:
							(tokens?.decodedToken?.localUID as string | undefined) ?? "",
						isAdmin:
							(tokens?.decodedToken?.isAdmin as boolean | undefined) ?? false,
						isDeveloper:
							(tokens?.decodedToken?.isDeveloper as boolean | undefined) ??
							false,
						isFormValidating: isFormValidating,
						stripeId: billingUserData?.id ?? "",
						productionEnvironment: isProductionEnvironment,
					});
				}
			}
		}

		getStripeUser();

		return () => {
			abortController.abort();
		};
	}, [userAuthData]);

	/**
	 * Signs out the current user.
	 *
	 * This function checks if the user authentication data contains a token.
	 * If no token is found, it throws an error indicating that sign out is not possible.
	 * If a token is found, it calls the `handleSignOut` function with the token,
	 * and upon successful sign out, it calls `authForClientSide.signOut()` to complete the process.
	 *
	 * @throws {Error} If no user token is found.
	 * @returns {Promise<void>} A promise that resolves when the sign out process is complete.
	 */
	async function signOut() {
		if (!userAuthData) {
			return await authForClientSide.signOut();
		} else {
			await handleSignOut(userAuthData.token);
			return await authForClientSide.signOut();
		}
	}

	const setters = { setAuthLoading, setUserAuthData, setIsFormValidating };
	const states = {
		authLoading,
		userAuthData,
		billingUserData,
		isFormValidating,
	};

	const contextValues: AuthContextValues = {
		setters,
		states,
		authForClientSide,
		signOut,
	};

	return (
		<UserContext.Provider value={contextValues}>
			{children}
		</UserContext.Provider>
	);
}

export { UserContext, UserProvider };
