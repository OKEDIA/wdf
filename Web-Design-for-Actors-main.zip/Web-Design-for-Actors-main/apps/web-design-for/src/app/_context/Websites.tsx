"use client";

// React Imports
import { createContext, useEffect, useState } from "react";

// Next.js Imports
import { useRouter } from "next/navigation";

// Lower Order Components

// UI Components & Icons

// Context & Helpers
import { arrayHelpers } from "@okedia/shared/helpers";

// Other libraries or utilities
import { useDatabase } from "@okedia/shared/hooks";

// Types
import { ObjectId } from "mongodb";
import {
	ContextProps,
	WebsiteContextValues,
} from "@okedia/shared/types/contextTypes";
import { FormValues } from "@okedia/shared/types/formTypes";
import { l10nType } from "@okedia/shared/types/l10n";
import { MongoDocumentResponse } from "@okedia/shared/types/mongoTypes";
import { Profile } from "@okedia/shared/types/profileTypes";
import {
	Website,
	WebsiteFormConfiguration,
} from "@okedia/shared/types/websiteTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

const WebsiteContext = createContext({});

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

interface WebsiteContextProps extends ContextProps {
	currentBrand: l10nType;
	websites?: MongoDocumentResponse<Website<any[]>>[];
	profiles?: MongoDocumentResponse<Profile<any[]>>[];
	user: unknown;
	type?: WebsiteFormConfiguration;
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Provider component for managing website-related state and operations.
 *
 * @component
 * @param {Object} props - The component props
 * @param {ReactNode} props.children - Child components to be wrapped by the provider
 * @param {Brand} props.currentBrand - The current brand context
 * @param {Website[]} [props.websites] - Initial array of website data
 * @param {Profile[]} [props.profiles] - Initial array of profile data
 * @param {User} props.user - The current user context
 * @param {WebsiteType} props.type - The website type configuration
 *
 * @returns {JSX.Element} A context provider wrapping the children components
 *
 * @example
 * ```tsx
 * <WebsiteProvider
 *   currentBrand={brand}
 *   websites={websites}
 *   profiles={profiles}
 *   user={user}
 *   type={websiteType}
 * >
 *   <ChildComponent />
 * </WebsiteProvider>
 * ```
 */
function WebsiteProvider({
	children,
	currentBrand,
	websites: foundWebsites,
	profiles: foundProfiles,
	user,
	type,
}: React.PropsWithChildren<WebsiteContextProps>) {
	const [typeData, setTypeData] = useState<
		WebsiteFormConfiguration | undefined
	>(type);
	const [websites, setWebsites] = useState<
		MongoDocumentResponse<Website<any[]>>[]
	>(foundWebsites ?? []);
	const [profiles, setProfiles] = useState<
		MongoDocumentResponse<Profile<any[]>>[]
	>(foundProfiles ?? []);
	const [isLoading, setIsLoading] = useState(false);
	const db = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);
	const router = useRouter();

	useEffect(() => {
		console.log("Website", websites);
	}, [websites]);
	useEffect(() => {
		console.log("Profiles", profiles);
	}, [profiles]);

	/**
	 * Retrieves website type data based on the current brand ID.
	 * If type data is not available, fetches it from the database.
	 * If type data exists, returns the cached data.
	 *
	 * @async
	 * @returns {Promise<WebsiteType | undefined>} The website type data or undefined
	 */
	async function getTypeData(type = "actors") {
		return await db
			.get<WebsiteFormConfiguration[]>(`/forms/${type}`, { cache: "no-store" })
			.then((res) => {
				setTypeData(res[0]);
				return res;
			})
			.then((res) => res);
	}

	/**
	 * Retrieves all websites from the database if not already loaded in state
	 * @returns {Promise<Website[]>} A promise that resolves to an array of Website objects
	 * @description If websites are already loaded in state, returns the cached websites array.
	 * Otherwise, fetches websites from the database endpoint, updates state, and returns the response.
	 */
	async function getAll() {
		if (websites.length < 1) {
			return await db
				.get<MongoDocumentResponse<Website<unknown>>[]>("/websites/?filter={}")
				.then((res) => {
					setWebsites(res as MongoDocumentResponse<Website<any[]>>[]);
					return res;
				});
		} else {
			return websites;
		}
	}

	/**
	 * Creates a new website and profile with the provided form data
	 * @param newProfileData - Form values containing profile information
	 * @returns Promise that resolves to the newly created Website object
	 * @throws Error if the creation process fails
	 * @remarks
	 * This function performs two sequential operations:
	 * 1. Creates a new profile using the provided form data
	 * 2. Creates a new website associated with a hardcoded profileId (132)
	 *
	 * There is an artificial delay of 3 seconds (3000ms) before the creation process begins
	 */
	async function create(newProfileData: FormValues): Promise<Profile<unknown>> {
		try {
			await new Promise((resolve) => setTimeout(resolve, 3000));

			const newProfile = await db.post<MongoDocumentResponse<Profile<unknown>>>(
				"/profiles/?claim=true",
				newProfileData
			);

			setProfiles((prevData) => {
				return [
					...prevData,
					newProfile as MongoDocumentResponse<Profile<unknown[]>>,
				];
			});

			setIsLoading(false);

			return newProfile;
		} catch (e) {
			const error = e as Error;
			console.error(error);
			throw new Error(error.message);
		}
	}

	async function createWebsite(
		newWebsiteData: FormValues,
		profileId: string
	): Promise<Website<unknown>> {
		try {
			await new Promise((resolve) => setTimeout(resolve, 3000));
			const profile = profiles.find(
				(profile) => profile._id.toString() === profileId
			);

			if (!profile) {
				throw new Error("Unable to find the profile properties");
			}

			const dataToAdd = { ...newWebsiteData, type: profile.type };

			const newWebsite = await db.post<
				MongoDocumentResponse<Website<unknown[]>>
			>(`/websites/${profileId}`, dataToAdd);

			setWebsites((prevData) => {
				return [
					...prevData,
					newWebsite as MongoDocumentResponse<Website<unknown[]>>,
				];
			});

			return newWebsite;
		} catch (e) {
			const error = e as Error;
			console.error(error);
			throw new Error(error.message);
		}
	}

	/**
	 * Updates a website document in the database and updates the local state.
	 *
	 * @param id - The unique identifier of the website to update
	 * @param updatedWebsiteData - The new website data to be saved
	 * @returns A Promise that resolves to the updated Website object
	 * @throws Will throw an error if the update operation fails
	 */
	async function update(
		id: string,
		updatedWebsiteData: Website<unknown>
	): Promise<Website<unknown>> {
		try {
			const website = websites.find((website) => website.id === id);

			if (!website) {
				throw new Error("Unable to find the website properties");
			}

			const response = await db.patch<Website<unknown>>(
				`/websites/${website.id}`,
				updatedWebsiteData
			);

			// Merge the existing website data with the updated data
			const index = arrayHelpers.find.index(websites, "id", id);
			const newData = [...websites];
			newData[index] = { ...website, ...response } as MongoDocumentResponse<
				Website<unknown[]>
			>;

			setWebsites(newData);

			return newData[index];
		} catch (e) {
			const error = e as Error;
			console.error(error);
			throw new Error(error.message);
		}
	}

	async function updateProfile(
		id: string,
		updatedProfileData: Profile<unknown>
	): Promise<Profile<unknown>> {
		try {
			const profile = profiles.find((profile) => profile._id.toString() === id);

			if (!profile) {
				throw new Error("Unable to find the profile properties");
			}

			const response = await db.patch<Profile<unknown>>(
				`/profiles/${id}`,
				updatedProfileData
			);

			// Merge the existing website data with the updated data
			const index = arrayHelpers.find.index(profiles, "id", id);
			const newData = [...profiles];
			newData[index] = {
				...profiles[index],
				...response,
				websites: response.websites as unknown[] | ObjectId[],
			};

			setProfiles(newData);

			return response;
		} catch (e) {
			const error = e as Error;
			console.error(error);
			throw new Error(error.message);
		}
	}

	/**
	 * Deletes a website from the database and updates the local state.
	 * @param id - The unique identifier of the website to delete
	 * @returns A Promise that resolves when the deletion is complete
	 * @throws {Error} If the deletion operation fails
	 */
	async function deleter(id: string): Promise<void> {
		try {
			// router.push("/dashboard");
			const profileToUpdate = profiles.find((profile) => {
				return profile.websites?.find((website) => website.id === id);
			});

			const updatedWebsitesArray = profileToUpdate?.websites
				?.filter((website) => website.id !== id)
				.map((website) => website.id);

			if (profileToUpdate) {
				// Remove the website from the profile's websites array
				await db
					.patch<Profile<unknown>>(`/profiles/${profileToUpdate.id}`, {
						websites: updatedWebsitesArray,
					})
					.then((res) => {
						updateProfile(profileToUpdate.id as string, {
							...profileToUpdate,
							websites: updatedWebsitesArray,
						});
					});
			}

			await db
				.deleter<Website<unknown>>(`/websites/${id}`)
				.then(() => router.push("/dashboard"));
		} catch (e) {
			const error = e as Error;
			console.error(error);
			throw new Error(error.message);
		}
	}

	const setters = { setWebsites, setProfiles, setIsLoading };
	const states = { websites, profiles, isLoading, typeData };

	const contextValues: WebsiteContextValues = {
		setters,
		states,
		create,
		createWebsite,
		update,
		updateProfile,
		deleter,
		getTypeData,
	};

	return (
		<WebsiteContext.Provider value={contextValues}>
			{children}
		</WebsiteContext.Provider>
	);
}

export { WebsiteContext, WebsiteProvider };
