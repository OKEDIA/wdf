// React Imports

// Next.js Imports
import { cookies, headers } from "next/headers";

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities
import { getTokens } from "next-firebase-auth-edge";
import { isProductionEnvironment } from "@okedia/shared/helpers/isProductionEnvironment";
import { formatPrivateKey } from "@okedia/shared/helpers/string";

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

interface TokenOptions {
	sendHeaders: boolean;
	withToken: boolean;
}

/**
 * Retrieves and decodes a token based on the provided options.
 *
 * @param {TokenOptions} options - The options for retrieving and decoding the token.
 * @param {boolean} options.sendHeaders - Whether to include headers in the request.
 * @param {boolean} options.withToken - Whether to return the full token or just the decoded token.
 * @returns {Promise<Tokens | DecodedIdToken | null | undefined>} A promise that resolves to the token or decoded token, or null/undefined if not available.
 */
export default async function useDecodedToken(options: TokenOptions) {
	const { sendHeaders, withToken } = options;
	const token = await getTokens(await cookies(), {
		debug: isProductionEnvironment,
		apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY as string,
		cookieName: process.env.NEXT_PUBLIC_FIREBASE_COOKIE_NAME as string,
		cookieSignatureKeys: [
			process.env.NEXT_PUBLIC_FIREBASE_COOKIE_KEY_1 as string,
			process.env.NEXT_PUBLIC_FIREBASE_COOKIE_KEY_2 as string,
		],
		serviceAccount: {
			projectId: process.env.FIREBASE_CLIENT_PROJECT_ID as string,
			clientEmail: process.env.FIREBASE_CLIENT_EMAIL as string,
			privateKey: formatPrivateKey(process.env.FIREBASE_PRIVATE_KEY) as string,
		},

		headers: sendHeaders ? await headers() : undefined,
	});

	if (withToken) {
		return token;
	} else {
		return token?.decodedToken;
	}
}
