"use server";

// React Imports

// Next.js Imports
import type { Metadata } from "next";

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export async function getMetadata(
	title?: string,
	absolute?: boolean
): Promise<Metadata> {
	// read route params

	return {
		title: absolute
			? title
			: title
			? `Web Design For | ${title}`
			: "Web Design For | Seamless, hassle-free website creation experience",

		applicationName: "Web Design For",
		referrer: "origin-when-cross-origin",
		keywords: [
			"actor website builder",
			"musician website creator",
			"filmmaker website builder",
			"artist portfolio website",
			"easy website for entertainers",
			"drag-and-drop website for performers",
			"custom website for actors",
			"no-code website for creatives",
			"professional website for musicians",
			"model portfolio website",
			"director website maker",
			"hassle-free website for artists",
			"best website builder for entertainment industry",
			"personal brand website",
			"dancer website creator",
			"showcase website for performers",
			"simple website for showbiz",
			"stage performer website builder",
			"theater artist website",
			"fast website for content creators",
		],
		description:
			"Simply gather the ssets and let the WDF platform do the rest! Get ready for a seamless, hassle-free website creation experience.",
		creator: "Joseph Berry",
		appLinks: {
			web: {
				url: "https://wdf.me",
				should_fallback: true,
			},
		},

		formatDetection: {
			email: false,
			address: false,
			telephone: false,
		},
		icons: {
			icon: [
				{ url: "/icons/favicon-96x96.png", type: "image/png", sizes: "96x96" },
				{ url: "/icons/favicon.svg", type: "image/svg+xml" },
			],
			shortcut: "/icons/favicon.ico",
			apple: { url: "/icons/apple-touch-icon.png", sizes: "180x180" },
		},
		appleWebApp: {
			title: "Web Design",
		},
		manifest: "/icons/site.webmanifest",
	};
}
