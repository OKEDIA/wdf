"use server";

// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities
import { generateEmailTemplate, sendEmail } from "@okedia/shared/email";
import { firebaseAdmin } from "@okedia/shared/firebase/admin";
import { logger } from "@okedia/shared/logging";
import { firebaseAuthErrorsMap } from "./authenticationFunctions";

// Type

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
interface EmailLink {
	url: string;
	params: {
		mode: "verifyEmail";
		oobCode: string;
		apiKey: string;
		continueUrl: string;
		lang: string;
		email: string;
		[key: string]: string;
	};
}
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export async function sendEmailVerificationLink({
	to,
	brand,
}: {
	to: string;
	brand: string;
}): Promise<void> {
	// Import the HTML Template
	const verificationLinkEmail = await import(
		"../../emails/compiled/verifyemail.html"
	).catch((err) => {
		logger.error(err, "Error importing password reset email template");
		throw new Error("Error importing password reset email template");
	});

	// Get the Email Verification Link from Firebase
	const admin = await firebaseAdmin();
	const res = await admin
		.auth()
		.generateEmailVerificationLink(to, {
			url: `https://${brand ?? "actors"}.wdf.me/dashboard?email_verified=true`,
		})
		.catch((err: { code: string }) => {
			if (err.code === "auth/user-not-found") {
				return;
			}
			const userFriendlyError =
				err.code in firebaseAuthErrorsMap
					? firebaseAuthErrorsMap[
							err.code as keyof typeof firebaseAuthErrorsMap
					  ]
					: undefined;
			if (err.code && userFriendlyError) {
				throw new Error(userFriendlyError);
			}
			console.log(err.code);
			throw err;
		});

	if (!res) {
		// Pretend to do something before returning
		// This is just to simulate a delay for the user who might be brute forcing email addresses
		// As the email address is likely not found
		await new Promise((resolve) => setTimeout(resolve, 5000));
		return;
	}

	const template = await generateEmailTemplate({
		templateFile: verificationLinkEmail.default,
		dynamicData: {
			verificationLink: res,
		},
	});

	// Send the email
	await sendEmail({
		to,
		from: process.env.AWS_SEND_FROM_EMAIL as string,
		subject: "Click to continue using Web Design For",
		message: { html: template.html, text: template.text },
	}).catch((err) => {
		throw err;
	});
}

export async function sendPasswordResetLink({
	to,
	brand,
}: {
	to: string;
	brand: string;
}): Promise<void> {
	// Import the HTML Template
	const resetPasswordEmail = await import(
		"../../emails/compiled/passwordresetlink.html"
	).catch((err) => {
		logger.error(err, "Error importing password reset email template");
		throw new Error("Error importing password reset email template");
	});

	// Get the Email Verification Link from Firebase
	const admin = await firebaseAdmin();
	const res = await admin
		.auth()
		.generatePasswordResetLink(to, {
			url: "https://wdf.me/dashboard?password_reset=true",
		})
		.catch((err: { code: string }) => {
			logger.error(err, "Error generating password reset link");
			if (err.code === "auth/user-not-found") {
				return;
			}
			const userFriendlyError =
				err.code in firebaseAuthErrorsMap
					? firebaseAuthErrorsMap[
							err.code as keyof typeof firebaseAuthErrorsMap
					  ]
					: undefined;
			if (err.code && userFriendlyError) {
				throw new Error(userFriendlyError);
			}
			throw err;
		});

	if (!res) {
		// Pretend to do something before returning
		// This is just to simulate a delay for the user who might be brute forcing email addresses
		// As the email address is likely not found
		await new Promise((resolve) => setTimeout(resolve, 5000));
		return;
	}

	const url = new URL(res);
	const params = Object.fromEntries(new URLSearchParams(url.search));

	const template = await generateEmailTemplate({
		templateFile: resetPasswordEmail.default,
		dynamicData: {
			verificationLink: `https://${
				brand ?? "actors"
			}.wdf.me/login/?passwordreset=true&mode=${params.mode}&oobCode=${
				params.oobCode
			}&email=${to}`,
		},
	});

	// Send the email
	await sendEmail({
		to,
		from: process.env.AWS_SEND_FROM_EMAIL as string,
		subject: "Reset your Password",
		message: { html: template.html, text: template.text },
	}).catch((err) => {
		logger.error(err, "Error sending password reset email");
		throw err;
	});
}
