import {
	Auth,
	createUserWithEmailAndPassword,
	signInWithEmailAndPassword,
	signInWithPopup,
	User,
	UserCredential,
} from "firebase/auth";
import { providers } from "@okedia/shared/firebase/standard";
import { AuthContextValues } from "@okedia/shared/types/contextTypes";
import { getServerToken } from "../_context/getUserToken";

interface AuthCredential {
	auth: Auth;
	provider?: keyof typeof providers;
}

interface AuthCredentialWithEmail extends AuthCredential {
	email: string;
	password: string;
	user: AuthContextValues;
}

interface AuthHandlerProps {
	res: UserCredential;
	user: AuthContextValues;
}

export const firebaseAuthErrorsMap = {
	"auth/admin-restricted-operation": "Admin restricted operation.",
	"auth/argument-error": "Argument error.",
	"auth/app-not-authorized": "Server not authorised for login.",
	"auth/captcha-check-failed": "Please complete the captcha.",
	"auth/code-expired": "Code expired.",
	"auth/cors-unsupported": "Domain name not configured ot use login.",
	"auth/credential-already-in-use": "Credential already in use.",
	"auth/custom-token-mismatch": "Custom token mismatch.",
	"auth/requires-recent-login": "Please re-login to continue.",
	"auth/email-change-needs-verification":
		"Please verify your new email address.",
	"auth/email-already-in-use": "Cannot sign up with this account at this time.",
	"auth/expired-action-code":
		"The password reset code has expired. Please try to reset your password again or contact support.",
	"auth/invalid-action-code":
		"Unable to verify the password reset code. Please try creating a new password reset link or contact support.",
	"auth/cancelled-popup-request": "Sign in was cancelled.",
	"auth/internal-error": "Internal Server Error with Authentication",
	"auth/invalid-api-key": "Invalid API Key.",
	"auth/invalid-app-credential": "Invalid App Credential.",
	"auth/invalid-user-token": "Invalid User Token.",
	"auth/invalid-verification-code": "Invalid verification code.",
	"auth/invalid-continue-uri": "Unable to redirect.",
	"auth/invalid-custom-token": "Invalid user credentials,",
	"auth/invalid-email": "Invalid email address.",
	"auth/invalid-login-credentials": "Invalid login credentials.",
	"auth/unauthorized-domain": "Domain not authorized for authentication.",
	"auth/wrong-password": "Unable to sign in. Please try again.",
	"auth/popup-blocked":
		"Popup blocked. Please allow popups for this site to continue.",
	"auth/popup-closed-by-user": "Sign in was cancelled by the user.",
	"auth/quota-exceeded":
		"Not able to process sign in/up at this time, please come back later",
	"auth/user-token-expired": "Please sign in again to continue.",
	"auth/timeout": "Request timed out. Please try again.",
	"auth/too-many-requests": "Try again later.",
	"auth/unverified-email": "Please verify your email address to continue.",
	"auth/user-deleted": "Cannot sign in with this account.",
	"auth/user-disabled": "Cannot sign in with this account at this time.",
	"auth/weak-password": "Password is too weak. Please try again.",
};

/**
 * Signs in a user with the specified authentication provider.
 *
 * @param {Object} params - The parameters for signing in.
 * @param {string} [params.provider="email"] - The authentication provider to use. Defaults to "email".
 * @param {string} params.email - The email address of the user. Required if provider is "email".
 * @param {string} params.password - The password of the user. Required if provider is "email".
 * @param {Object} params.user - The user object containing authentication information.
 * @param {Object} params.user.authForClientSide - The client-side authentication object.
 *
 * @throws {Error} If the email or password is not provided when using the "email" provider.
 *
 * @returns {Promise<void>} A promise that resolves when the sign-in process is complete.
 */
export async function signInWithProvider({
	provider = "email",
	email,
	password,
	user,
}: AuthCredentialWithEmail): Promise<void> {
	if (provider === "email") {
		if (!email || !password) {
			throw new Error("No Email Address or Password Provided");
		}
		await signInWithEmail({
			auth: user.authForClientSide,
			email,
			password,
			user,
		}).catch((error: { code: keyof typeof firebaseAuthErrorsMap }) => {
			if (error.code in firebaseAuthErrorsMap) {
				throw new Error(firebaseAuthErrorsMap[error.code]);
			} else {
				// TODO: Log an error online!
				console.error("Error signing in with provider:", error);
				throw new Error(
					"An unknown error occurred during sign-in. Please try again."
				);
			}
		});
		// Return early to avoid triggering a popup sign in flow.
		return;
	}

	await signInWithPopup(user.authForClientSide, providers[provider])
		.then(async (res: UserCredential) => {
			return await handleSuccessfulAuth({ res, user });
		})
		.catch((error: { code: keyof typeof firebaseAuthErrorsMap }) => {
			if (error.code in firebaseAuthErrorsMap) {
				throw new Error(firebaseAuthErrorsMap[error.code]);
			} else {
				// TODO: Log an error online!
				console.error("Error signing in with provider:", error);
				throw new Error(
					"An unknown error occurred during sign-in. Please try again."
				);
			}
		});
}

/**
 * Signs in a user with email and password. If the sign-in fails due to an invalid credential,
 * it attempts to create a new account with the provided email and password.
 *
 * @param {Object} params - The parameters for the sign-in function.
 * @param {Auth} params.auth - The authentication object.
 * @param {string} params.email - The email address of the user.
 * @param {string} params.password - The password of the user.
 * @param {User} params.user - The user object.
 * @returns {Promise<UserCredential>} A promise that resolves to the user credential object upon successful sign-in.
 * @throws {Error} Throws an error if the sign-in or sign-up process fails.
 */
async function signInWithEmail({
	auth,
	email,
	password,
	user,
}: AuthCredentialWithEmail) {
	return signInWithEmailAndPassword(auth, email, password)
		.then(async (res: UserCredential) => {
			return await handleSuccessfulAuth({ res, user });
		})

		.catch(async (error) => {
			console.log("COULDNT SIGN IN", error);
			if (
				error.code === "auth/invalid-credential" ||
				error.code === "auth/user-not-found"
			) {
				console.log("Invalid credential, trying to create a new account");
				return await signUpWithEmail({ auth, email, password, user });
			}
			throw error; // Return the error back to the notification
		});
}

/**
 * Signs up a new user with email and password.
 *
 * @param {Object} params - The parameters for the sign-up function.
 * @param {Auth} params.auth - The authentication object.
 * @param {string} params.email - The email address of the user.
 * @param {string} params.password - The password for the user.
 * @returns {Promise<void>} A promise that resolves when the sign-up process is complete.
 */
async function signUpWithEmail({
	auth,
	email,
	password,
	user,
}: AuthCredentialWithEmail) {
	return await createUserWithEmailAndPassword(auth, email, password)
		.then(async (res: UserCredential) => {
			return await handleSuccessfulAuth({ res, user });
		})
		.catch((error) => {
			throw error;
		});
}

/**
 * Handles successful authentication by sending a login request to the server
 * and creating a new user in the database if the user is new.
 *
 * @param {AuthHandlerProps} param0 - The authentication handler properties.
 * @param {Object} param0.res - The response object containing user information.
 * @returns {Promise<void>} A promise that resolves when the authentication handling is complete.
 * @throws {Error} Throws an error if the login request fails.
 */
export async function handleSuccessfulAuth({ res, user }: AuthHandlerProps) {
	await fetch("/api/auth/login", {
		method: "POST",
		headers: {
			Authorization: `Bearer ${await res.user.getIdToken(true)}`,
		},
	}).then(async (response) => {
		if (response.status !== 200) {
			throw new Error(response.statusText);
		} else {
			const tokens = await getServerToken();
			user.setters.setUserAuthData(tokens);

			const urlParams = new URLSearchParams(window.location.search);
			const redirectUrl = urlParams.get("redirect");
			if (redirectUrl) {
				window.location.href = redirectUrl;
			}
		}
	});
}

/**
 * Handles the sign-out process by making a POST request to the logout endpoint.
 *
 * @param {string} idToken - The ID token used for authorization.
 * @returns {Promise<void>} - A promise that resolves when the sign-out process is complete.
 * @throws {Error} - Throws an error if the response status is not 200.
 */
export async function handleSignOut(idToken: string) {
	return await fetch("/api/auth/logout", {
		method: "POST",
		headers: {
			Authorization: `Bearer ${idToken}`,
		},
	}).then((response) => {
		if (response.status !== 200) {
			throw new Error(response.statusText);
		}

		window.location.reload();

		return response;
	});
}
