// React Imports

import { NotificationData, NotificationsProps } from "@mantine/notifications";

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export const defaultNotificationProps: Partial<NotificationData> = {
	withCloseButton: true,
	color: "branding",
};

export const defaultNotificationsProps: Partial<NotificationsProps> = {
	limit: 5,
	autoClose: 10000,
	position: "top-right",
};
