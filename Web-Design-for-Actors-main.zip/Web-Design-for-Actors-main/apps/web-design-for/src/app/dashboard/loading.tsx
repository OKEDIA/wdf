import {
	Card,
	Flex,
	Grid,
	GridCol,
	Group,
	Paper,
	Skeleton,
	Stack,
	Title,
} from "@mantine/core";

/**
 * A React functional component that renders a loading skeleton for a dashboard.
 * It displays three skeleton cards in a grid layout.
 *
 * @component
 * @example
 * return (
 *   <Loading />
 * )
 */
export default function Loading() {
	function SkeletonDesign() {
		return (
			<GridCol span={{ base: 24, sm: 24, lg: 12, xl: 8 }}>
				<Card>
					<Paper
						bg="gray.0"
						p="xl"
						h="100%"
						pos="relative"
						styles={{
							root: {
								display: "flex",
								justifyContent: "center",
								alignItems: "stretch",
							},
						}}
					>
						<Flex
							direction="column"
							justify="space-between"
							align="center"
						>
							<Skeleton
								height={100}
								width="75%"
								mb="md"
							/>
							<Stack
								gap={0}
								align="center"
							>
								<Skeleton
									h="lg"
									w="150px"
								/>
								<Skeleton
									h="lg"
									mt="xs"
									w="100px"
								/>
							</Stack>
							<Flex
								justify="center"
								my="xl"
								align="center"
								gap="md"
							>
								<Skeleton
									w="150px"
									h="md"
								/>
								<Skeleton
									w="150px"
									h="md"
								/>
							</Flex>
							<Group w="100%">
								<Flex
									direction="row"
									w="100%"
									columnGap="md"
								>
									<Skeleton
										h="40px"
										w="50%"
									/>
									<Skeleton
										h="40px"
										w="50%"
									/>
								</Flex>
								<Skeleton
									h="40px"
									w="100%"
								/>
							</Group>
						</Flex>
					</Paper>
				</Card>
			</GridCol>
		);
	}

	return (
		<Grid
			columns={24}
			styles={{ inner: { alignItems: "stretch" } }}
			p="xl"
		>
			<GridCol span={24}>
				<Title mb="xl">Your Websites</Title>
				<Grid
					grow
					columns={24}
					styles={{ inner: { alignItems: "stretch" } }}
				>
					<SkeletonDesign />
					<SkeletonDesign />
					<SkeletonDesign />
					<SkeletonDesign />
				</Grid>
			</GridCol>
		</Grid>
	);
}
