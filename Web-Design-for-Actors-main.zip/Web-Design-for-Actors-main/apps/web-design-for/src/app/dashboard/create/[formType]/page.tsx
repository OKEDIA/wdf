"use server";

import { documentHelpers } from "@okedia/shared/database";
import { useGlobalQueryParams } from "@okedia/shared/hooks";
import { WebsiteFormConfiguration } from "@okedia/shared/types/websiteTypes";
import Landing from "./_components/Landing";

// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default async function Page(props: {
	params: Promise<{ formType: string }>;
}) {
	const params = await props.params;
	const formType = params.formType;
	const globalQuery = useGlobalQueryParams(new URLSearchParams());
	const mongoQuery = globalQuery.mongoQuery();

	const formConfig = await documentHelpers
		.find<WebsiteFormConfiguration>({
			...mongoQuery,
			collectionName: "forms",
			filter: { id: formType },
			paginition: { ...mongoQuery.paginition, limit: 1 },
		})
		.then((res) => res as WebsiteFormConfiguration);

	if (!formConfig) {
		throw new Error("Unable to find form configuration.");
	}

	return (
		<Landing
			formConfig={formConfig}
			formType={formType}
		/>
	);
}
