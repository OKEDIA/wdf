"use client";

import { WebsiteContext } from "@/app/_context/Websites";
import CreateWebsiteCard from "@/app/dashboard/_components/CreateWebsiteCard";
import WebsiteBuilderWizard from "@/app/dashboard/_components/WebsiteBuilderWizard";
import { Paper } from "@mantine/core";
import { useRouter } from "next/navigation";
import { WebsiteContextValues } from "@okedia/shared/types/contextTypes";
import {
	CommonFormDataProps,
	FormValues,
	Input,
	Step,
} from "@okedia/shared/types/formTypes";
import { Profile } from "@okedia/shared/types/profileTypes";
import { WebsiteFormConfiguration } from "@okedia/shared/types/websiteTypes";
import { BaseSyntheticEvent, useContext } from "react";

// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Landing({
	formConfig,
	formType,
}: {
	formConfig: WebsiteFormConfiguration;
	formType: string;
}) {
	const websites = useContext(WebsiteContext) as WebsiteContextValues;
	const router = useRouter();
	const validateAndSubmit = async (
		data: FormValues,
		e?: BaseSyntheticEvent
	): Promise<void> => {
		e?.preventDefault();

		websites.setters.setIsLoading(true);

		const dataToAdd: Partial<Profile<unknown>> = { type: formType, ...data };

		await websites.create(dataToAdd).then((res: FormValues) => {
			return router.push(`/dashboard/edit/${res.id}?created=true`);
		});
	};

	return (
		<Paper>
			<WebsiteBuilderWizard
				formFields={formConfig.inputs as Input[]}
				formSteps={formConfig.builderSteps as Step[]}
				LandingElement={({ onCreateWebsiteClick }) => (
					<CreateWebsiteCard
						formType={formType}
						onCreateWebsiteClick={onCreateWebsiteClick}
					/>
				)}
				options={{ brand: formType, shouldValidate: true }}
				commonFormDataMap={formConfig.commonFormDataMap as CommonFormDataProps}
				onSubmit={validateAndSubmit}
			/>
		</Paper>
	);
}
