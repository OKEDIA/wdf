"use client";

// React Imports
import { useTransition } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import {
	Badge,
	Button,
	Flex,
	Grid,
	GridCol,
	Group,
	Image,
	LoadingOverlay,
	Paper,
	rem,
	Select,
	Stack,
	Title,
} from "@mantine/core";
import { IconNewSection } from "@tabler/icons-react";
import Link from "next/link";

// Context & Helpers

// Other libraries or utilities

// Types
import { useRouter, useSearchParams } from "next/navigation";
import { distanceToNow } from "@okedia/shared/helpers/date";
import { WebsiteContextValues } from "@okedia/shared/types/contextTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Dashboard({
	websites,
}: {
	websites: WebsiteContextValues;
}) {
	const router = useRouter();
	const create = useSearchParams().get("create") === "true";
	const profilesList = websites.states.profiles;
	const [isPending, startTransition] = useTransition();

	return (
		<Grid
			columns={24}
			styles={{ inner: { alignItems: "stretch" } }}
			p="xl"
		>
			<GridCol span={24}>
				<Title mb="xl">Your Websites</Title>
				<Grid
					columns={24}
					styles={{ inner: { alignItems: "stretch" } }}
				>
					{profilesList.map((profile) => {
						const [isPending, startTransition] = useTransition();

						return (
							<GridCol
								span={{ base: 24, sm: 24, lg: 12, xl: 8 }}
								key={profile.id.toString()}
							>
								<Paper
									bg="gray.0"
									p="xl"
									h="100%"
									pos="relative"
									styles={{
										root: {
											display: "flex",
											justifyContent: "center",
											alignItems: "stretch",
										},
									}}
								>
									<LoadingOverlay visible={isPending} />
									<Flex
										direction="column"
										justify="space-between"
										align="center"
									>
										<Image
											src={profile.commonFormDataValues.image}
											px="xl"
											py="md"
											maw={rem(300)}
										/>
										<Stack
											gap={0}
											align="center"
										>
											<Title order={4}>
												{profile.commonFormDataValues.title ?? profile.id}
											</Title>
											<Title
												size="lg"
												variant="subtle"
												tt="capitalize"
											>
												{profile.type} Profile
											</Title>
										</Stack>
										<Flex
											justify="center"
											my="xl"
											align="center"
											gap="md"
										>
											<Badge variant="dot">
												Created {distanceToNow(profile.created.toString())}
											</Badge>
											{profile?.updated && (
												<Badge variant="dot">
													Updated {distanceToNow(profile.updated.toString())}
												</Badge>
											)}
										</Flex>
										<Group w="100%">
											{profile?.websites && profile.websites.length > 0 && (
												<Flex
													direction="row"
													w="100%"
													columnGap="md"
												>
													<Button
														variant="light"
														color="branding.5"
														w="50%"
														onClick={() => {
															startTransition(() => {
																router.push(
																	`/dashboard/edit/${profile.id}/website`
																);
															});
														}}
													>
														Website Settings
													</Button>
													{profile.websites[0].domain && (
														<Button
															variant="light"
															color="branding.5"
															w="50%"
															component={Link}
															href={`https://${
																profile.websites[0].domain
															}?noCache=${Date.now().toString()}`}
															target="_blank"
															onClick={(e) => {
																e.preventDefault();
																startTransition(() => {
																	router.push(
																		`https://${
																			profile.websites?.[0].domain
																		}?noCache=${Date.now().toString()}`
																	);
																});
															}}
														>
															Preview Website
														</Button>
													)}
												</Flex>
											)}
											<Button
												variant="filled"
												fullWidth
												onClick={() => {
													startTransition(() => {
														router.push(`/dashboard/edit/${profile.id}`);
													});
												}}
											>
												Edit Website
											</Button>
										</Group>
									</Flex>
								</Paper>
							</GridCol>
						);
					})}
					<GridCol span="auto">
						<Paper
							bg="gray.0"
							p="xl"
							h="100%"
							pos="relative"
						>
							<Flex
								direction="column"
								justify="space-between"
								align="center"
							>
								<LoadingOverlay visible={isPending} />
								<IconNewSection size="5rem" />
								<Stack
									gap={0}
									ml="sm"
									align="center"
								>
									<Title order={2}>Create a new website</Title>
									<Title order={4}>
										Create a website for an individual, production or company.
									</Title>
								</Stack>
							</Flex>
							<Flex
								align="center"
								justify="center"
								mt="lg"
							>
								<Select
									py="lg"
									maw="45dvw"
									w="100%"
									label="Select the type of website you would like to
										create."
									placeholder="Choose website type to cont"
									data={["Actors", "Producers", "Productions"]}
									styles={{
										root: { textAlign: "center" },
										label: { marginBottom: "10px" },
									}}
									onChange={(value) => {
										startTransition(() => {
											redirectToCreateWebsite(value);
										});
									}}
								/>
							</Flex>
						</Paper>
					</GridCol>
				</Grid>
			</GridCol>
		</Grid>
	);

	function redirectToCreateWebsite(value: string | null) {
		if (!value) return;
		router.push(`/dashboard/create/${value.toLowerCase()}`);
	}
}
