// React Imports
import { useState } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { Alert, Button, Stack } from "@mantine/core";
import {
	PaymentElement,
	PaymentElementProps,
	useElements,
	useStripe,
} from "@stripe/react-stripe-js";
// Context & Helpers

// Other libraries or utilities
import { useDatabase } from "@okedia/shared/hooks";

// Types
import { ConfirmationToken, StripeError } from "@stripe/stripe-js";
import { PaymentIntent } from "@okedia/shared/stripe";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
/**
 * StripeCheckout component handles the Stripe payment process.
 *
 * @param {Object} props - The properties object.
 * @param {React.ElementType} props.SubmitButton - The button component to submit the payment form.
 * @param {PaymentElementProps} [props.paymentElementProps] - Optional properties for the PaymentElement.
 * @param {number} props.amount - The amount to be charged.
 * @param {PaymentIntent} [props.paymentIntent] - Optional existing payment intent.
 * @param {() => Promise<void>} props.handleComplete - Callback function to be called upon successful payment completion.
 *
 * @returns {JSX.Element} The StripeCheckout component.
 *
 * @example
 * <StripeCheckout
 *   SubmitButton={MySubmitButton}
 *   paymentElementProps={{ layout: 'tabs' }}
 *   amount={5000}
 *   handleComplete={handlePaymentSuccess}
 * />
 */
export default function StripeCheckout({
	SubmitButton,
	paymentElementProps,
	amount,
	handleComplete,
	paymentIntent,
}: {
	SubmitButton: any;
	paymentElementProps?: PaymentElementProps;
	amount: number;
	paymentIntent?: PaymentIntent;
	handleComplete: () => Promise<void>;
}) {
	const stripe = useStripe();
	const elements = useElements();
	const db = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);
	const [errorMessage, setErrorMessage] = useState<string | undefined>(
		undefined
	);
	const [loading, setLoading] = useState(false);

	/**
	 * Handles errors from Stripe operations.
	 *
	 * @param {StripeError} error - The error object returned from a Stripe operation.
	 * @returns {void}
	 *
	 * This function sets the loading state to false and updates the error message
	 * based on the provided error. If the error has a message property, it uses that
	 * message. If the error is a string, it uses the string as the error message.
	 * Otherwise, it sets a generic error message.
	 */
	function handleStripeError(error: StripeError) {
		setLoading(false);

		if (error.message) {
			setErrorMessage(error.message);
		} else if (typeof error === "string") {
			setErrorMessage(error);
		} else {
			setErrorMessage("An error occured");
		}
	}

	/**
	 * Handles the payment intent process with Stripe.
	 *
	 * @param {PaymentIntent} paymentIntent - The payment intent object from Stripe.
	 * @returns {Promise<PaymentIntent | void>} - Returns the payment intent if succeeded, otherwise handles the next action or confirms the payment.
	 * @throws {Error} - Throws an error if unable to continue with payment.
	 */
	async function handlePaymentIntent(paymentIntent: PaymentIntent) {
		if (!stripe || !elements) {
			return;
		}

		if (!paymentIntent) {
			throw new Error("Unable to continue with payment.");
		}

		if (paymentIntent.status === "requires_action") {
			return stripe.handleNextAction({
				clientSecret: paymentIntent.client_secret as string,
			});
		} else if (paymentIntent.status === "succeeded") {
			return paymentIntent;
		} else {
			await stripe.confirmPayment({
				elements,
				confirmParams: { return_url: window.location.href },
			});

			return paymentIntent;
		}
	}
	/**
	 * Asynchronously retrieves a Stripe confirmation token.
	 *
	 * This function interacts with the Stripe API to create a confirmation token
	 * using the provided Stripe elements. If the Stripe instance or elements are
	 * not available, the function returns immediately. If an error occurs during
	 * the token creation process, the error is handled by `handleStripeError`.
	 *
	 * @returns {Promise<ConfirmationToken | undefined | void>} A promise that resolves to the confirmation token,
	 *          or undefined/void if an error occurs or if Stripe/elements are not available.
	 */
	async function getStripeConfirmationToken(): Promise<
		ConfirmationToken | undefined | void
	> {
		if (!stripe || !elements) {
			return;
		}

		const { error, confirmationToken } = await stripe.createConfirmationToken({
			elements,
		});

		if (error) {
			return handleStripeError(error);
		} else {
			return confirmationToken;
		}
	}
	/**
	 * Handles the form submission for the Stripe checkout process.
	 *
	 * @param {React.FormEvent} event - The form submission event.
	 * @returns {Promise<void>} - A promise that resolves when the submission process is complete.
	 *
	 * @throws {Error} - Throws an error if there is an issue with the payment process.
	 *
	 * The function performs the following steps:
	 * 1. Prevents the default form submission behavior.
	 * 2. Checks if the Stripe and elements objects are available.
	 * 3. Sets the loading state to true.
	 * 4. Submits the elements and handles any errors.
	 * 5. Processes the payment intent if available.
	 * 6. Retrieves a Stripe confirmation token if no payment intent is available.
	 * 7. Creates a new payment intent using the confirmation token and amount.
	 * 8. Handles the payment intent and any errors.
	 * 9. Calls the handleComplete function if provided.
	 * 10. Resets the loading state.
	 */
	async function handleSubmit(event: React.FormEvent) {
		event.preventDefault();
		let paymentResult;

		if (!stripe || !elements) {
			return;
		}

		setLoading(true);

		try {
			await elements.submit().then(async (res) => {
				if (res.error) {
					throw new Error(res.error.message);
				}
			});

			if (paymentIntent) {
				paymentResult = await handlePaymentIntent(paymentIntent);
			}

			if (!paymentIntent) {
				const confirmationToken = await getStripeConfirmationToken();

				if (!confirmationToken) {
					return;
				}

				const _paymentIntent = await db
					.post<PaymentIntent>(
						`/billing/customers/paymentintents?confirmation_token=${confirmationToken?.id}&amount=${amount}`,
						{}
					)
					.catch((e) => {
						throw new Error(e.message);
					});

				return await handlePaymentIntent(_paymentIntent);
			}

			if ("error" in (paymentResult || {})) {
				return handleStripeError((paymentResult as any).error);
			} else if (typeof handleComplete === "function") {
				return await handleComplete().then(() => {
					setLoading(false);
				});
			} else {
				return setLoading(false);
			}
		} catch (error: any) {
			return handleStripeError(error.message);
		}
	}
	return (
		<form>
			<PaymentElement
				{...paymentElementProps}
				onChange={() => {
					setErrorMessage(undefined);
				}}
			/>

			{!errorMessage && (
				<SubmitButton
					onClick={handleSubmit}
					loading={loading}
					disabled={!stripe || !elements || errorMessage !== undefined}
					my="sm"
					fullWidth
				>
					Submit
				</SubmitButton>
			)}
			{errorMessage !== undefined && (
				<Alert
					mt="lg"
					color="red"
					variant="light"
					withCloseButton
					title="Error"
					onClose={() => setErrorMessage(undefined)}
				>
					<Stack>
						{errorMessage}
						<Button
							variant="transparent"
							color="red"
							onClick={() => setErrorMessage(undefined)}
						>
							Try Again
						</Button>
					</Stack>
				</Alert>
			)}
		</form>
	);
}
