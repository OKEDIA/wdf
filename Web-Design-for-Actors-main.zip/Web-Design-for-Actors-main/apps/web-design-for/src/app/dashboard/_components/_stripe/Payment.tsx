// React Imports
import { useContext, useState } from "react";

// Next.js Imports

// Lower Order Components
import StripeCheckout from "./Checkout";

// UI Components & Icons
import {
	Alert,
	Button,
	Card,
	LoadingOverlay,
	useMantineTheme,
} from "@mantine/core";
import { Elements } from "@stripe/react-stripe-js";

// Context & Helpers
import { UserContext } from "@/app/_context/User";

// Other libraries or utilities
import { loadStripe, StripeElementsOptions } from "@stripe/stripe-js";
import { useDatabase } from "@okedia/shared/hooks";

// Types
import {
	PaymentIntent,
	Price,
	Product,
	PromotionCode,
	StripeResponse,
	Subscription,
} from "@okedia/shared/stripe";
import { AuthContextValues } from "@okedia/shared/types/contextTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

import { Website } from "@okedia/shared/types/websiteTypes";

/**
 * Custom hook to handle Stripe payment processing.
 *
 * @param {Object} params - The parameters for the hook.
 * @param {Website} [params.website] - The website information.
 * @param {PromotionCode} [params.promotionCode] - The promotion code details.
 * @param {Object} params.product - The product details.
 * @param {string} params.product.productId - The product ID.
 * @param {string} params.product.package - The package name.
 * @param {Object} params.product.metadata - The metadata for the product.
 * @param {string} params.product.metadata.websiteId - The website ID.
 * @param {string} params.product.metadata.domain - The domain name.
 * @param {any} params.Body - The body component to render.
 * @param {Function} params.onComplete - The callback function to execute on completion.
 *
 */
export default function useStripePayment({
	website,
	promotionCode,
	product,
	Body,
	onComplete,
}: {
	website?: Website<unknown>;
	promotionCode?: PromotionCode;
	product?: {
		productId: string;
		package: string;
		metadata: { websiteId: string; domain: string; type: string };
	};
	Body: any;
	onComplete: () => Promise<void>;
}) {
	const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_API_KEY!);
	const user = useContext(UserContext) as AuthContextValues;
	const db = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);

	const [isInitialLoading, setIsInitialLoading] = useState<boolean>(true);
	const [isLoading, setIsLoading] = useState<boolean>(true);

	const [amount, setAmount] = useState<number>(0);
	const [subscription, setSubscription] = useState<Subscription | undefined>(
		undefined
	);
	const [packageData, setPackageData] = useState<Price | undefined>(undefined);
	const [productData, setProductData] = useState<Product | undefined>(
		undefined
	);
	const [paymentIntent, setPaymentIntent] = useState<PaymentIntent | undefined>(
		undefined
	);
	const [hasSubmitted, setHasSubmitted] = useState<boolean>(false);

	const isTestMode = user.states.billingUserData?.customer?.livemode === false;
	const isDevUser = user.states.userAuthData?.decodedToken.isDeveloper === true;
	const theme = useMantineTheme();

	const options: StripeElementsOptions = {
		// mode: "subscription",
		// amount: amount,
		// currency: "gbp",
		// paymentMethodCreation: "manual",
		// setup_future_usage: "on_session",
		customerSessionClientSecret: user.states.billingUserData?.client_secret,
		clientSecret: paymentIntent?.client_secret as string,
		// Fully customizable with appearance API.
		appearance: {
			theme: "stripe",
			variables: {
				colorPrimary: theme.colors?.branding[7],
				colorBackground: theme.colors?.gray[0],
				colorText: theme.black,
				colorDanger: theme.colors?.red[6],
				fontFamily: theme.fontFamily,
				fontSmooth: theme.fontSmoothing ? "always" : "never",
			},
		},
		fonts: [
			{
				family: "Figtree",
				src: "url(ttps://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,300..900;1,300..900&display=swap)",
				weight: "500",
			},
		],
		loader: "always",
	};

	function SubmitButton({ ...props }) {
		return <Button {...props}>Submit</Button>;
	}

	/**
	 * Collects and processes Stripe data for a subscription upgrade.
	 *
	 * This function performs the following steps:
	 * 1. Retrieves the current subscription for the website.
	 * 2. Retrieves the price for the specified product and applies any promotion code.
	 * 3. Updates the subscription with the new price and promotion code.
	 * 4. Retrieves the product details.
	 *
	 * @throws {Error} If website or product data is not available.
	 * @throws {Error} If unable to find a subscription to upgrade.
	 * @throws {Error} If unable to find pricing.
	 *
	 * @returns {Promise<void>} A promise that resolves when all data has been collected and processed.
	 */
	async function collectStripeData() {
		let subId: string = "";

		if (!website || !product) {
			throw new Error("Unable to find website or product data.");
		}

		const _subscription = await db
			.get<StripeResponse<Subscription>>(
				`/billing/customers/${user.states.billingUserData?.customer?.id}/subscriptions/?websiteId=${website.id}`
			)
			.then((res) => {
				if (!res.data.length || res.data.length < 1) {
					throw new Error("Unable to find subscription to upgrade.");
				}

				subId = res.data[0].id;
				setSubscription(res.data[0]);

				return res.data[0];
			})
			.catch((e) => {
				console.log(e);
			});

		/**
		 * Fetches the price of a product from the database and applies any valid promotion codes.
		 *
		 * @async
		 * @function
		 * @param {Product} product - The product for which the price is being fetched.
		 * @param {PromotionCode} [promotionCode] - An optional promotion code to apply to the price.
		 * @returns {Promise<Price>} The price data of the product.
		 * @throws Will throw an error if the pricing information cannot be found.
		 *
		 * @example
		 * const product = { productId: '123', package: 'basic' };
		 * const promotionCode = { coupon: { valid: true, amount_off: 500 } };
		 * const price = await _price(product, promotionCode);
		 * console.log(price.unit_amount); // Outputs the unit amount after applying the promotion code
		 */
		const _price = await db
			.get<StripeResponse<Price>>(
				`/billing/products/prices/${product.productId}/?lookupKey=${product.metadata.type}_${product.package}`
			)
			.then((res) => {
				const amount = res.data[0].unit_amount;

				if (!amount) {
					throw new Error("Unable to find pricing.");
				}

				setAmount(amount);

				if (promotionCode?.coupon?.valid) {
					const couponData = promotionCode.coupon;
					if (couponData.amount_off !== null) {
						setAmount((prevTotal) => prevTotal - (couponData.amount_off ?? 0));
					} else if (couponData.percent_off !== null) {
						const discount = (amount * (couponData.percent_off ?? 0)) / 100;
						const discountedAmount = amount - discount;
						setAmount(Math.floor(discountedAmount));
					}
				}

				setPackageData(res.data[0]);
				return res.data[0];
			})
			.catch((e) => {
				console.log(e);
			});

		/**
		 * Updates the subscription details for a customer.
		 *
		 * @async
		 * @function
		 * @param {string} subId - The subscription ID to update.
		 * @param {object} promotionCode - The promotion code object containing the coupon ID.
		 * @param {object} product - The product object containing metadata.
		 * @param {object} _subscription - The current subscription object.
		 * @param {object} _price - The price object containing the new price ID.
		 * @returns {Promise<Subscription>} The updated subscription object.
		 *
		 * @throws Will log an error to the console if the update fails.
		 */
		const _updatedSubscription = await db
			.patch<Subscription>(
				`/billing/customers/${user.states.billingUserData?.customer?.id}/subscriptions/${subId}`,
				{
					cancel_at_period_end: false,
					items: [
						{
							id: _subscription?.items.data[0].id,
							price: _price?.id,
						},
					],
					payment_behavior: "default_incomplete",

					...(promotionCode?.coupon.id && {
						discounts: [{ coupon: promotionCode.coupon.id }],
					}),

					metadata: { ...product.metadata },
					expand: ["latest_invoice.payment_intent"],
				}
			)
			.then((res) => {
				setSubscription(res);
				const paymentIntent = res.latest_invoice.payment_intent;
				setPaymentIntent(paymentIntent as PaymentIntent);
				return res;
			})
			.catch((e) => {
				console.log(e);
			});

		/**
		 * Fetches product data from the billing API using the provided product ID.
		 * The fetched data is then set to the state using `setProductData`.
		 *
		 * @async
		 * @function
		 * @returns {Promise<Product | void>} The fetched product data or void if an error occurs.
		 * @throws Will log an error message to the console if the request fails.
		 */
		const _product = await db
			.get<Product>(`/billing/products/?productId=${product.productId}`)
			.then((res) => {
				setProductData(res);
				return res;
			})
			.catch((e) => {
				console.log(e);
			});

		setIsLoading(false);
	}

	/**
	 * The `Element` component handles the payment process using Stripe.
	 *
	 * @returns {JSX.Element} The rendered component.
	 *
	 * @remarks
	 * - If the user's billing data is not available, an alert is displayed prompting the user to contact support.
	 * - When billing data is available, the Stripe Elements component is rendered to handle the payment process.
	 * - A loading overlay is shown while the payment process is initializing or loading.
	 * - The `StripeCheckout` component is used to handle the actual payment submission.
	 *
	 * @component
	 * @example
	 * ```tsx
	 * <Element />
	 * ```
	 */
	function Element() {
		if (!user.states.billingUserData) {
			return (
				<Alert>
					Unable to continue with payment. No billing account found, please
					contact support.
				</Alert>
			);
		}

		return (
			<Elements
				stripe={stripePromise}
				options={options}
			>
				<Card pt="md">
					<LoadingOverlay visible={isInitialLoading || isLoading} />

					<Body />
					<Card mt="md">
						{!isLoading && (
							<StripeCheckout
								handleComplete={onComplete}
								SubmitButton={SubmitButton}
								paymentElementProps={{
									onReady: () => setIsInitialLoading(false),
								}}
								amount={amount}
								paymentIntent={paymentIntent}
							/>
						)}
					</Card>
				</Card>
			</Elements>
		);
	}

	return {
		Element,
		amount,
		subscription,
		packageData,
		productData,
		coupon: promotionCode?.coupon,
		state: { isLoading, setIsLoading },
		isTestMode,
		isDevUser,
		collectStripeData,
		hasSubmitted,
	};
}
