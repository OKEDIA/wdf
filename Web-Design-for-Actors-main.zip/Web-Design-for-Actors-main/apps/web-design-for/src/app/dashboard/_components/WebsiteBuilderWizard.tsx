// React Imports
import { BaseSyntheticEvent, useContext, useState } from "react";

// Next.js Imports
import { useSearchParams } from "next/navigation";

// Lower Order Components
import CheckEntryExists from "./CheckEntryExists";

// UI Components & Icons
import {
	Box,
	Button,
	Grid,
	GridCol,
	Group,
	LoadingOverlay,
	Stack,
	Stepper,
	StepperStep,
	Timeline,
	Title,
	Tooltip,
} from "@mantine/core";
import Form, { FormPropsOptions } from "@okedia/shared/form/Form";

// Context & Helpers

// Other libraries or utilities
import usePopup from "@/app/_hooks/usePopup";
import { useScrollIntoView, useWindowScroll } from "@mantine/hooks";
import { generateInitialFormValues } from "@okedia/shared/helpers/form";
import { useForm } from "react-hook-form";

// Types
import { UserContext } from "@/app/_context/User";
import { WebsiteContext } from "@/app/_context/Websites";
import { defaultNotificationProps } from "@/app/_utilities/notificationsConfig";
import { notifications } from "@mantine/notifications";
import { IconProgressCheck, IconRefreshAlert } from "@tabler/icons-react";
import {
	AuthContextValues,
	WebsiteContextValues,
} from "@okedia/shared/types/contextTypes";
import {
	CommonFormDataProps,
	FormConfig,
	FormValues,
} from "@okedia/shared/types/formTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

interface WebsiteBuilderProps extends FormConfig {
	LandingElement?: React.ComponentType<{ onCreateWebsiteClick: () => void }>;
	options: WebsiteBuilderOptions;
	onSubmit: (data: FormValues, e?: BaseSyntheticEvent) => Promise<void>;
}

interface WebsiteBuilderOptions extends FormPropsOptions {
	shouldValidate?: boolean;
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * WebsiteBuilderWizard component is a multi-step form wizard for creating a website.
 * It handles form steps, validation, and submission.
 *
 * @param {FormConfig} props - The configuration for the form, including form fields and steps.
 * @param {FormField[]} props.formFields - The fields to be included in the form.
 * @param {FormStep[]} props.formSteps - The steps to be included in the form wizard.
 *
 * @returns {JSX.Element} The rendered WebsiteBuilderWizard component.
 *
 * @component
 * @example
 * const formFields = [
 *   { id: 'name', label: 'Name', type: 'text' },
 *   { id: 'email', label: 'Email', type: 'email' },
 * ];
 * const formSteps = [
 *   { id: 1, stepTitle: 'Step 1', stepDescription: 'Enter your name', shortTitle: 'Name' },
 *   { id: 2, stepTitle: 'Step 2', stepDescription: 'Enter your email', shortTitle: 'Email' },
 * ];
 *
 * <WebsiteBuilderWizard formFields={formFields} formSteps={formSteps} />
 */

export default function WebsiteBuilderWizard({
	formFields,
	formSteps,
	commonFormDataMap,
	options,
	LandingElement,
	onSubmit,
}: WebsiteBuilderProps): JSX.Element {
	if (!formSteps) {
		return (
			<Box
				style={{ marginLeft: "10rem", marginRight: "10rem" }}
				py="10vh"
			>
				<LoadingOverlay visible />
				{LandingElement && (
					<LandingElement onCreateWebsiteClick={handleStartWebsiteClick} />
				)}
			</Box>
		);
	}

	if (!options.brand) {
		throw new Error("Brand is required for WebsiteBuilderWizard");
	}

	const websites = useContext(WebsiteContext) as WebsiteContextValues;
	const user = useContext(UserContext) as AuthContextValues;
	const params = useSearchParams();
	const [currentFormStep, setCurrentFormStep] = useState<number>(1);
	const [currentStepperStep, setCurrentStepperStep] = useState<number>(
		Number(params.get("step")) ?? 0
	);
	const websiteCreatedPopup = usePopup();
	const stepConfig = formSteps.find((step) => step.id === currentFormStep);
	const isLastStep = formSteps.length === currentFormStep;
	const [_, scrollTo] = useWindowScroll();
	const { scrollIntoView, targetRef } = useScrollIntoView<HTMLDivElement>({
		offset: 60,
	});
	const initialFormValues = generateInitialFormValues({
		generateEmpty: true,
		formFields: formFields,
	});

	const form = useForm({
		defaultValues: initialFormValues,
		shouldFocusError: true,
		mode: "all",
	});

	function handleStartWebsiteClick() {
		setCurrentStepperStep(currentStepperStep + 1);
		scrollIntoView();
	}

	function handleStepChange(step: number) {
		setCurrentFormStep(step);
		scrollIntoView();
	}

	return (
		<Stepper
			ref={targetRef}
			active={currentStepperStep}
			onStepClick={(stepIndex) => {
				scrollTo({ y: 0 });

				if (stepIndex === 0 && currentStepperStep === 0) {
					return setCurrentStepperStep(1);
				}

				setCurrentStepperStep(stepIndex);
			}}
			styles={{ steps: { marginLeft: "10vw", marginRight: "10vw" } }}
			py="10vh"
		>
			{LandingElement && (
				<StepperStep label="Get Started">
					<LandingElement onCreateWebsiteClick={handleStartWebsiteClick} />
				</StepperStep>
			)}
			{options.shouldValidate && (
				<StepperStep label="Search Existing">
					<CheckEntryExists
						options={options}
						onNextStepClick={handleStartWebsiteClick}
						formType={options.brand}
					/>
				</StepperStep>
			)}
			<StepperStep label="Add your info">
				<Grid
					columns={24}
					grow
					px="5rem"
					align="stretch"
					gutter={0}
				>
					{formSteps.length > 1 && (
						<GridCol
							span="auto"
							visibleFrom="lg"
							ml="-7rem"
						>
							<Timeline
								active={currentFormStep - 1}
								styles={{ root: { maxWidth: "75%" } }}
								lineWidth={1}
								align="right"
								mt="4em"
							>
								{formSteps.map((step, index) => {
									return (
										<Timeline.Item
											key={index}
											bullet={step.id}
											title={step.shortTitle}
										/>
									);
								})}
							</Timeline>
						</GridCol>
					)}
					<GridCol>
						<Stack
							align="center"
							gap={0}
							style={{ textAlign: "center" }}
						>
							<Title
								mt="3rem"
								order={1}
								textWrap="balance"
							>
								{stepConfig?.stepTitle}
							</Title>
							<Title
								mb="2rem"
								order={4}
								textWrap="balance"
								px="md"
							>
								{stepConfig?.stepDescription}
							</Title>
						</Stack>
						<form onSubmit={form.handleSubmit(onSubmit)}>
							<Form
								formFields={formFields}
								formInstance={form}
								stepConfig={stepConfig}
								options={options}
								commonFormDataMap={commonFormDataMap as CommonFormDataProps}
							/>
							<Group grow>
								<Button
									variant={isLastStep ? "light" : "default"}
									disabled={currentFormStep <= 1 || websites.states.isLoading}
									onClick={async () => {
										if (!user.states.isFormValidating) {
											// Skip Validation
											return handleStepChange(currentFormStep - 1);
										}

										await form.trigger().then(() => {
											return handleStepChange(currentFormStep - 1);
										});
									}}
									style={{ height: isLastStep ? "300px" : undefined }}
									type="button"
								>
									{isLastStep ? "Go Back" : "Previous Step"}
								</Button>
								<Tooltip
									label="Complete all fields to continue"
									disabled={
										user.states.isFormValidating && form.formState.isValid
									}
								>
									<Button
										disabled={
											form.formState.isSubmitted ||
											(user.states.isFormValidating &&
												!form.formState.isValid) ||
											websites.states.isLoading
										}
										style={{ height: isLastStep ? "300px" : undefined }}
										onClick={async (e) => {
											e.preventDefault();

											if (!isLastStep) {
												return handleStepChange(currentFormStep + 1);
											}

											try {
												notifications.show({
													...defaultNotificationProps,
													title: "Saving Changes",
													message: "Please wait while we save your changes.",
													id: "saving-changes",
													loading: true,
												});

												if (!user.states.isFormValidating) {
													// Form is NOT validating

													return await onSubmit(form.getValues()).then(() => {
														notifications.update({
															...defaultNotificationProps,
															message:
																"All done! Your changes have been saved successfully.",
															loading: false,
															icon: <IconProgressCheck />,
															id: "saving-changes",
															color: "branding",
														});
													});
												} else {
													// Form IS validating
													return await form
														.handleSubmit(onSubmit)()
														.then(() => {
															notifications.update({
																...defaultNotificationProps,
																message:
																	"All done! Your changes have been saved successfully.",
																loading: false,
																icon: <IconProgressCheck />,
																id: "saving-changes",
																color: "branding",
															});
														});
												}
											} catch (e) {
												console.log("ERROR");
												//TODO: Submit error
												console.log(e);

												notifications.update({
													...defaultNotificationProps,
													message:
														"An error occurred while submitting the form. Please try again later or contact support.",
													loading: false,
													icon: <IconRefreshAlert />,
													id: "saving-changes",
													color: "red",
												});
											}
										}}
										type={isLastStep ? "submit" : "button"}
									>
										{isLastStep ? "Save Changes" : "Next Step"}
									</Button>
								</Tooltip>
							</Group>
						</form>
					</GridCol>
				</Grid>
				<websiteCreatedPopup.Element />
			</StepperStep>
			<StepperStep
				label="Save Changes"
				allowStepClick={false}
				allowStepSelect={false}
			/>
		</Stepper>
	);
}
