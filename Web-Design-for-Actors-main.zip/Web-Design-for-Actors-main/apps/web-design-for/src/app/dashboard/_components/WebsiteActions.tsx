// React Imports
import { ReactElement, useContext, useState } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import {
	Badge,
	Group,
	LoadingOverlay,
	Menu,
	MenuDropdown,
	MenuLabel,
	MenuTarget,
} from "@mantine/core";

// Context & Helpers
import { UserContext } from "@/app/_context/User";

// Other libraries or utilities

// Types
import { WebsiteContext } from "@/app/_context/Websites";
import { useRouter } from "next/navigation";
import {
	AuthContextValues,
	WebsiteContextValues,
} from "@okedia/shared/types/contextTypes";
import { FormValues } from "@okedia/shared/types/formTypes";
import { StateSetter } from "@okedia/shared/types/stateTypes";
import { MenuItemAsButton } from "./MenuItemAsButton";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
/**
 * A component that renders a menu with various actions related to a website.
 *
 * @param {Object} props - The properties object.
 * @param {FormValues} props.website - The website data.
 * @param {ReactElement} props.target - The target element that triggers the menu.
 * @param {boolean} [props.showBadges=false] - Whether to show badges with website information.
 * @param {Object} [props.state] - The state object for loading state management.
 * @param {boolean} props.state.isLoading - The loading state.
 * @param {StateSetter<boolean>} props.state.setIsLoading - The function to set the loading state.
 *
 * @returns {JSX.Element} The rendered component.
 */
export default function WebsiteActions({
	website,
	target,
	showBadges = false,
	state,
}: {
	website: FormValues;
	target: ReactElement;
	showBadges?: boolean;
	state?: { isLoading: boolean; setIsLoading: StateSetter<boolean> };
}) {
	const user = useContext(UserContext) as AuthContextValues;
	const isAdmin: boolean = user.states.userAuthData?.decodedToken
		?.isAdmin as boolean;
	const [menuIsLoading, setMenuIsLoading] = useState<boolean>(false);
	const websites = useContext(WebsiteContext) as WebsiteContextValues;
	const router = useRouter();

	function setIsLoading(value: boolean) {
		setMenuIsLoading(value);
		if (state) {
			state.setIsLoading(value);
		}
	}

	return (
		<Menu
			width="25em"
			offset={20}
			position="top"
			trigger="click-hover"
			shadow="#c8c5c5 -2px 2px 7px"
		>
			<MenuTarget>{target}</MenuTarget>
			<MenuDropdown
				style={{ border: "unset" }}
				pb="sm"
			>
				<LoadingOverlay visible={menuIsLoading} />
				{showBadges && (
					<MenuLabel mt="sm">
						<Group>
							<Badge variant="light">{website.domain ?? "Your Website"}</Badge>
							<Badge variant="light">
								{website.package ?? "Unknown"} Package
							</Badge>
							<Badge variant="light">
								Website is {website.status ?? "Unknwon"}
							</Badge>
						</Group>
					</MenuLabel>
				)}
				<MenuLabel mt="sm">Your Website</MenuLabel>
				<MenuItemAsButton
					href={`https://${
						website.domain ?? ""
					}?noCache=${Date.now().toString()}`}
				>
					View Website
				</MenuItemAsButton>
				<MenuItemAsButton href={`https://${website.domain ?? ""}`}>
					Contact Support
				</MenuItemAsButton>
				{isAdmin && (
					<>
						<MenuLabel mt="sm">Administration</MenuLabel>
						{website.status !== "suspended" && (
							<MenuItemAsButton
								onClick={() => {
									setIsLoading(true);
									websites
										.update(website.id, {
											status: "suspended",
										})
										.finally(() => setIsLoading(false));
								}}
							>
								Suspend Website
							</MenuItemAsButton>
						)}
						{website.status === "suspended" && (
							<MenuItemAsButton
								onClick={() => {
									setIsLoading(true);
									websites
										.update(website.id, { status: "online" })
										.finally(() => setIsLoading(false));
								}}
							>
								Unsuspend Website
							</MenuItemAsButton>
						)}
						<MenuItemAsButton
							disabled={!website?.websiteViews}
							onClick={() => {
								setIsLoading(true);
								websites
									.update(website.id, { websiteViews: 0 })
									.finally(() => setIsLoading(false));
							}}
						>
							Reset Website Views
						</MenuItemAsButton>
						<MenuItemAsButton
							disabled={!website.cvViews}
							onClick={() => {
								setIsLoading(true);
								websites
									.update(website.id, {
										cvViews: 0,
									})
									.finally(() => setIsLoading(false));
							}}
						>
							Reset CV Views
						</MenuItemAsButton>
					</>
				)}

				<MenuLabel mt="sm">Danger Zone</MenuLabel>
				{website.status === "online" && (
					<MenuItemAsButton
						onClick={() => {
							setIsLoading(true);
							websites
								.update(website.id, { status: "offline" })
								.finally(() => setIsLoading(false));
						}}
					>
						Deactivate Website
					</MenuItemAsButton>
				)}
				{website.status === "offline" && (
					<MenuItemAsButton
						onClick={() => {
							setIsLoading(true);
							websites
								.update(website.id, { status: "online" })
								.finally(() => setIsLoading(false));
						}}
					>
						Reactivate Website
					</MenuItemAsButton>
				)}
				<MenuItemAsButton
					onClick={() => {
						setIsLoading(true);
						websites
							.deleter(website.id)
							.then(() => router.push("/dashboard"))
							.finally(() => setIsLoading(false));
					}}
					color="red"
				>
					Delete Website
				</MenuItemAsButton>
			</MenuDropdown>
		</Menu>
	);
}
