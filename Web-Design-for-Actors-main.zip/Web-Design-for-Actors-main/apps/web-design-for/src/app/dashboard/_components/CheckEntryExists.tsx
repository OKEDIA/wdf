// React Imports
import { useContext, useEffect, useRef, useState } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import {
	Button,
	Center,
	Container,
	Divider,
	Fieldset,
	Flex,
	GridCol,
	Group,
	Image,
	Loader,
	Space,
	Stack,
	Text,
	TextInput,
	Title,
	Tooltip,
} from "@mantine/core";
import {
	IconChevronRight,
	IconLock,
	IconReportSearch,
	IconSearch,
} from "@tabler/icons-react";

// Context & Helpers

// Other libraries or utilities
import { useDebouncedValue } from "@mantine/hooks";
import { useDatabase } from "@okedia/shared/hooks";

// Types
import { UserContext } from "@/app/_context/User";
import { WebsiteContext } from "@/app/_context/Websites";
import { brandMap } from "@/app/_l10n/map";
import { ObjectId } from "mongodb";
import { useRouter } from "next/navigation";
import { FormPropsOptions } from "@okedia/shared/form/Form";
import {
	AuthContextValues,
	WebsiteContextValues,
} from "@okedia/shared/types/contextTypes";
import { PaginitedMongoResponse } from "@okedia/shared/types/documentResponses";
import { l10nType } from "@okedia/shared/types/l10n";
import { MongoDocumentResponse } from "@okedia/shared/types/mongoTypes";
import { Profile } from "@okedia/shared/types/profileTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function CheckEntryExists({
	options,
	onNextStepClick,
	formType,
}: {
	options: FormPropsOptions;
	onNextStepClick: (
		event: React.MouseEvent<HTMLButtonElement, MouseEvent>
	) => void;
	formType: l10nType["id"];
}) {
	const [searchValue, setSearchValue] = useState("");
	const [_debouncedSearchValue] = useDebouncedValue(searchValue, 500);
	const [searchResults, setSearchResults] = useState<
		MongoDocumentResponse<Profile<unknown>>[] | []
	>([]);
	const db = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);
	const abortController = useRef<AbortController>(undefined);
	const [loading, setLoading] = useState(false);
	const l10n = brandMap.find((brand) => brand.id === formType);

	if (!l10n?.theme.other?.article || !l10n?.theme.other?.singular) {
		throw new Error(
			"l10n object is missing the 'article' or 'singular' property"
		);
	}

	const article = l10n?.theme.other?.article;
	const singular = l10n?.theme.other?.singular;

	useEffect(() => {
		if (_debouncedSearchValue?.length) {
			fetchOptions(_debouncedSearchValue);
		}
	}, [_debouncedSearchValue]);

	function getAsyncData(searchQuery: string, signal: AbortSignal) {
		return new Promise((resolve, reject) => {
			signal.addEventListener("abort", () => {
				reject(new Error("Request aborted"));
			});

			const filterObject = [
				{ type: options.brand },
				{ "commonFormDataValues.title": searchQuery },
			];

			db.get<PaginitedMongoResponse<MongoDocumentResponse<Profile<unknown>[]>>>(
				`/profiles/?filter=${encodeURIComponent(JSON.stringify(filterObject))}`,
				{ cache: "no-cache" }
			)
				.then((res) => resolve(res.data))
				.catch((e) => {
					console.error(e);
				});
		});
	}

	function immutablyAddArrayToData(dataToAdd: any[]) {
		setSearchResults((prevData) => {
			const newData = Array.isArray(prevData) ? [...prevData] : [];
			dataToAdd.forEach((item) => {
				if (
					!newData.some((dataItem: any) => dataItem._id === (item as any)._id)
				) {
					newData.push(item);
				}
			});
			return newData;
		});
	}

	const fetchOptions = (query: string) => {
		abortController.current?.abort();
		abortController.current = new AbortController();

		if (query.length <= 0) {
			return;
		}

		setLoading(true);

		getAsyncData(query, abortController.current.signal)
			.then((result) => {
				if (Array.isArray(result) && result.length > 0) {
					immutablyAddArrayToData(result);
				}
				setLoading(false);
				abortController.current = undefined;
			})
			.catch(() => {});
	};

	useEffect(() => {
		if (searchValue && searchValue !== "") {
			db.get<PaginitedMongoResponse<MongoDocumentResponse<Profile<unknown>>>>(
				`/profiles/?filter=${encodeURIComponent(
					JSON.stringify({ type: options.brand })
				)}`,
				{ cache: "no-cache" }
			).then((res) => {
				setSearchResults(res.data);
			});
		}
	}, [searchValue]);

	const profileOptions = searchResults?.filter((result) =>
		result.commonFormDataValues.title
			.toLowerCase()
			.includes(_debouncedSearchValue.toLowerCase())
	);

	return (
		<GridCol>
			<Stack
				align="center"
				gap={0}
				style={{ textAlign: "center" }}
				pt="xl"
			>
				<IconReportSearch size="10em" />
				<Title
					mt="3rem"
					order={1}
					textWrap="balance"
				>
					Find or add {article} {singular}
				</Title>
				<Title
					order={4}
					textWrap="balance"
					px="md"
				>
					Before we can continue, we need to check if your website is already on
					the WDF platform.
				</Title>
				<Title
					mb="2rem"
					order={4}
					textWrap="balance"
					px="md"
				>
					This occurs when colleagues or agents have already started creating a
					website.
				</Title>
			</Stack>
			<Container
				pb="xl"
				mt="xl"
			>
				<TextInput
					size="xl"
					leftSection={<IconSearch size="2em" />}
					rightSection={loading ? <Loader size="sm" /> : null}
					placeholder={`Search for ${options.brand}`}
					onChange={(e) => {
						e.preventDefault();
						setSearchValue(e.currentTarget.value);
					}}
				/>

				{searchValue && searchValue.length && (
					<Fieldset
						mt="lg"
						p="xl"
					>
						<Flex
							justify="space-between"
							align="center"
							pb="5px"
						>
							<Title
								order={3}
								fw="bold"
							>
								Search Results
							</Title>
							{_debouncedSearchValue && searchResults?.length > 0 && (
								<Title order={5}>
									{profileOptions?.length ?? 0}{" "}
									{profileOptions.length === 1
										? singular
										: l10n.public_name_ends}{" "}
									found
								</Title>
							)}
						</Flex>
						<Divider mb="xl" />
						{searchResults?.length > 0 &&
							profileOptions.map((result, index) => {
								return (
									<ProfileOption
										result={result}
										key={`option_${result.id}`}
									/>
								);
							})}

						{profileOptions?.length > 0 && (
							<Fieldset
								variant="filled"
								p="lg"
								my="lg"
							>
								<Center>
									<Title order={4}>
										If your website doesn't appear above, create a new one.
									</Title>
									<Button
										variant="transparent"
										onClick={onNextStepClick}
									>
										Create a new website
									</Button>
								</Center>
							</Fieldset>
						)}
						{profileOptions?.length <= 0 && (
							<Fieldset
								variant="filled"
								p="lg"
							>
								<Center>
									<Title
										order={3}
										c="gray"
									>
										No websites found.
									</Title>
								</Center>
							</Fieldset>
						)}
					</Fieldset>
				)}
			</Container>
			<Container mt="xl">
				<Flex justify="space-between">
					<Space />
					<Button
						disabled={searchValue.length === 0 && profileOptions.length === 0}
						onClick={onNextStepClick}
					>
						Create a new website
					</Button>
				</Flex>
			</Container>
		</GridCol>
	);
}

function ProfileOption({
	result,
}: {
	result: MongoDocumentResponse<Profile<unknown>>;
}) {
	const user = useContext(UserContext) as AuthContextValues;
	const websites = useContext(WebsiteContext) as WebsiteContextValues;
	const db = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);
	const router = useRouter();
	const image = result.commonFormDataValues.image;
	const isClaimed = (result.permissions?.owners?.length ?? 0) > 0;
	const owners = (result.permissions?.owners as ObjectId[]) ?? [];
	const isOwnedByCurrentOwner: boolean =
		owners?.includes(
			user.states.userAuthData?.decodedToken?.localUID as unknown as ObjectId
		) ?? false;

	const editors = (result.permissions?.editors as ObjectId[]) ?? [];
	const isEditableByCurrentUser: boolean =
		editors?.includes(
			user.states.userAuthData?.decodedToken?.localUID as unknown as ObjectId
		) ?? false;
	const [isLoading, setIsLoading] = useState(false);

	function handleClaim(profileId: string) {
		setIsLoading(true);
		// Claim the profile
		db.post<MongoDocumentResponse<Profile<unknown>>>(`/claims/submit`, {
			profileId: profileId,
		})
			.then((res) => {
				websites.setters.setProfiles((prevValues) => {
					const existingProfileIndex = prevValues.findIndex(
						(profile) => profile._id === res._id
					);

					if (existingProfileIndex !== -1) {
						const updatedProfiles = [...prevValues];
						updatedProfiles[existingProfileIndex] = res;
						return updatedProfiles;
					} else {
						return [...prevValues, res];
					}
				});

				return res;
			})
			.then((res) => {
				router.replace(`/dashboard/edit/${res._id}`);
			})
			.finally(() => {
				setIsLoading(false);
			});
	}

	return (
		<Fieldset
			variant="filled"
			p="lg"
			my="lg"
			key={result._id.toString()}
		>
			<Flex
				justify="space-between"
				align="center"
			>
				<Flex columnGap="lg">
					{image && (
						<Image
							src={result.commonFormDataValues.image}
							alt={`Image for Profile Name: ${result.commonFormDataValues.title}`}
							height="50px"
						/>
					)}
					<Stack gap="0">
						<Title
							order={4}
							fw="bold"
						>
							{result.commonFormDataValues.title}
						</Title>
						<Text>
							{result.commonFormDataValues.tags
								.map((item) => item)
								.filter((item) => item !== undefined && item !== "")
								.join(" • ")}
						</Text>
					</Stack>
				</Flex>
				<Group>
					{!isClaimed && (
						<Button
							variant="light"
							rightSection={isLoading && <Loader size="1em" />}
							disabled={isLoading}
							onClick={() => handleClaim(result.id as string)}
						>
							Claim Profile
						</Button>
					)}
					{isClaimed && (
						<Tooltip
							label="Already Claimed! Contact the original creator for access to edit this website."
							disabled={isEditableByCurrentUser || isOwnedByCurrentOwner}
						>
							<Button
								disabled={!isEditableByCurrentUser && !isOwnedByCurrentOwner}
								rightSection={
									isEditableByCurrentUser || isOwnedByCurrentOwner ? (
										<IconChevronRight width="1.3em" />
									) : (
										<IconLock width="1.3em" />
									)
								}
								onClick={() => {
									if (!isEditableByCurrentUser && !isOwnedByCurrentOwner) {
										return;
									}

									// Redirect to profile editor
									router.replace(`/dashboard/edit/${result.id}`);
								}}
								variant="filled"
								color="dark"
							>
								{isEditableByCurrentUser || isOwnedByCurrentOwner
									? "Edit"
									: "Claimed"}
							</Button>
						</Tooltip>
					)}
				</Group>
			</Flex>
		</Fieldset>
	);
}
