// React Imports
import { MouseEventHandler } from "react";

// Next.js Imports
import Link from "next/link";
import { useRouter } from "next/navigation";

// Lower Order Components

// UI Components & Icons
import { brandMap } from "@/app/_l10n/map";
import { Button, Flex, Group, Text, Title } from "@mantine/core";
import { IconTools } from "@tabler/icons-react";

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * A functional component that renders a card for creating a website.
 *
 * @param {Object} props - The component props.
 * @param {MouseEventHandler} props.onCreateWebsiteClick - The event handler for the primary button click.
 *
 * @returns {JSX.Element} The rendered CreateWebsiteCard component.
 */
export default function CreateWebsiteCard({
	onCreateWebsiteClick,
	formType,
}: {
	onCreateWebsiteClick: MouseEventHandler;
	formType: string;
}) {
	const l10n = brandMap.find((brand) => brand.id === formType)?.theme.other
		?.l10n;
	const router = useRouter();

	return (
		<Flex
			px="10vw"
			py="10vh"
			pb="0"
			direction="column"
			justify="middle"
			align="center"
			gap="lg"
		>
			<IconTools size="10rem" />
			<Title style={{ textAlign: "center" }}>
				{l10n.websiteBuilder.intro.title}
			</Title>
			<Title
				order={4}
				textWrap="balance"
				px="lg"
				style={{ textAlign: "center" }}
			>
				{l10n.websiteBuilder.intro.subtitle}
			</Title>
			<Group
				justify="middle"
				align="center"
			>
				<Button
					component={Link}
					variant="outline"
					fullWidth
					type="button"
					href={l10n.websiteBuilder.intro.secondaryCtaUrl}
					target="_blank"
					// onClick={() => router.push(l10n.websiteBuilder.intro.secondaryCtaUrl)}
				>
					{l10n.websiteBuilder.intro.secondaryCta}
				</Button>
				<Button
					fullWidth
					type="button"
					onClick={onCreateWebsiteClick}
				>
					{l10n.websiteBuilder.intro.primaryCta}
				</Button>
			</Group>
			<Link
				href={l10n.websiteBuilder.intro.smallprintUrl}
				target="_blank"
			>
				<Text
					style={{ textAlign: "center" }}
					size="xs"
					pt="10vh"
					pb="5vh"
				>
					{l10n.websiteBuilder.intro.smallprint}
				</Text>
			</Link>
		</Flex>
	);
}
