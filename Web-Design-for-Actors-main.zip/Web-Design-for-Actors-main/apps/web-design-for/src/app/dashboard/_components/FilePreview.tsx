// React Imports

import { LoadingOverlay } from "@mantine/core";
import { fileTypeMap } from "@okedia/shared/types/formTypes";
import { useEffect, useState } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * FilePreview component renders a preview of a given file or file URL.
 * It supports image, audio, and PDF file types.
 *
 * @param {Object} props - The properties object.
 * @param {File} [props.file] - The file object to preview.
 * @param {string} [props.fileUrl] - The URL of the file to preview.
 * @param {Object} [props.props] - Additional properties to pass to the rendered elements.
 *
 * @returns {JSX.Element} The rendered preview component.
 *
 * @example
 * <FilePreview file={file} />
 * <FilePreview fileUrl="https://example.com/file.pdf" />
 */
export default function FilePreview({
	file,
	fileUrl,
	props,
}: {
	file?: File;
	fileUrl?: string;
	props?: {};
}) {
	const [previewUrl, setPreviewUrl] = useState("");
	const [fileType, setFileType] = useState("");
	const [isLoading, setIsLoading] = useState(true);

	useEffect(() => {
		const loadFile = async () => {
			if (file) {
				const objectUrl = URL.createObjectURL(file);
				setPreviewUrl(objectUrl);
				setFileType(file.type);

				// Clean up the URL object when component unmounts or file changes
				return () => URL.revokeObjectURL(objectUrl);
			} else if (fileUrl) {
				setPreviewUrl(fileUrl);
				await determineFileType(fileUrl);
			}
		};

		const delay = (ms: number) => new Promise((res) => setTimeout(res, ms));

		const loadWithDelay = async () => {
			// Set loading state to true
			setIsLoading(true); // Assuming you have a setIsLoading state

			// Start loading the file
			await loadFile();

			// Wait for a minimum of 2 seconds
			await delay(2000);

			// Set loading state to false
			setIsLoading(false); // Assuming you have a setIsLoading state
		};

		loadWithDelay();
	}, [file, fileUrl]);

	/**
	 * Determines the file type of a given URL by making a HEAD request to fetch the Content-Type header.
	 * If the request fails, it falls back to determining the file type based on the URL extension.
	 *
	 * @param {string} url - The URL of the file to determine the type for.
	 * @returns {Promise<void>} - A promise that resolves when the file type has been determined and set.
	 * @throws {Error} - If there is an error fetching the file type.
	 */
	const determineFileType = async (url: string) => {
		try {
			const response = await fetch(url, { method: "HEAD" });
			const contentType = response.headers.get("Content-Type");
			setFileType(contentType || "");
		} catch (error) {
			console.error("Error fetching file type:", error);
			// Fallback to URL extension-based type detection
			setFileType(getFileTypeFromUrl(url));
		}
	};

	const getFileTypeFromUrl = (url: string) => {
		const ext = url.split(".").pop()?.toLowerCase() as keyof typeof typeMap;
		const typeMap = fileTypeMap;

		return typeMap[ext] ?? "unknown";
	};

	if (!isLoading && !file && !fileUrl) return <p>Preview Unavailable.</p>;

	return (
		<div style={{ display: "flex", justifyContent: "center" }}>
			<LoadingOverlay visible={isLoading} />
			{fileType.startsWith("image") && (
				<img
					src={previewUrl}
					{...props}
				/>
			)}
			{fileType.startsWith("audio") && (
				<audio controls>
					<source
						src={previewUrl}
						type={fileType}
						{...props}
					/>
					Your browser does not support the audio element.
				</audio>
			)}
			{fileType === "application/pdf" && (
				<iframe
					src={previewUrl}
					{...props}
					allow=""
					allowFullScreen={false}
					loading="lazy"
					style={{ pointerEvents: "none", border: "inherit" }}
					scrolling="false"
				/>
			)}
			{!isLoading &&
				!fileType.startsWith("image") &&
				!fileType.startsWith("audio") &&
				fileType !== "application/pdf" && (
					<p>Preview not available for this file type.</p>
				)}
		</div>
	);
}
