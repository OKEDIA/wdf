// React Imports

// Next.js Imports
import Link from "next/link";

// Lower Order Components

// UI Components & Icons
import {
	Box,
	Flex,
	MenuItem,
	PolymorphicComponentProps,
	UnstyledButton,
	UnstyledButtonProps,
} from "@mantine/core";

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

interface MenuItemAsButtonProps extends UnstyledButtonProps {
	leftSection?: React.ReactNode;
	children?: React.ReactNode;
	href?: string;
	target?: "_blank" | "_self" | "_parent" | "_top";
}

/**
 * A polymorphic button component that renders a `MenuItem` as a button.
 *
 * @param props - The properties for the component.
 * @param props.leftSection - The content to be displayed on the left side of the button.
 * @param props.children - The content to be displayed inside the button.
 *
 * @returns A button component styled as a `MenuItem`.
 */
export function MenuItemAsButton(
	props: PolymorphicComponentProps<any, MenuItemAsButtonProps>
) {
	if (props.href) {
		return (
			<MenuItem
				component={Link}
				href={props.href}
				target={props.target ?? "_blank"}
			>
				<Flex gap="xs">
					<Box>{props?.leftSection}</Box>
					<Box>{props?.children}</Box>
				</Flex>
			</MenuItem>
		);
	}

	return (
		<UnstyledButton
			component={MenuItem}
			type="button"
			{...props}
		>
			<Flex gap="xs">
				<Box>{props?.leftSection}</Box>
				<Box>{props?.children}</Box>
			</Flex>
		</UnstyledButton>
	);
}
