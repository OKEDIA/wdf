"use client";

// React Imports
import { Fragment, useContext, useTransition } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { UserContext } from "@/app/_context/User";
import {
	Avatar,
	Flex,
	Group,
	LoadingOverlay,
	Menu,
	MenuItem,
	MenuTarget,
	rem,
	Stack,
	Text,
	useMantineTheme,
} from "@mantine/core";
import {
	IconCodeVariablePlus,
	IconDoorExit,
	IconHelpHexagon,
	IconInputX,
	IconSettings,
} from "@tabler/icons-react";

// Context & Helpers

// Other libraries or utilities

// Types
import { handleSuccessfulAuth } from "@/app/_utilities/authenticationFunctions";
import { useLocalStorage } from "@mantine/hooks";
import { signInWithCustomToken } from "firebase/auth";
import { useRouter } from "next/navigation";
import { AuthContextValues } from "@okedia/shared/types/contextTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * UserCard component renders a user interface card with various navigation links and user-specific options.
 *
 * @component
 *
 * @returns {JSX.Element} The rendered UserCard component.
 *
 * @remarks
 * This component uses several hooks and context values to manage user state and navigation:
 * - `useContext(UserContext)` to access user authentication and state values.
 * - `useRouter()` to handle navigation.
 * - `usePathname()` to get the current path.
 * - `useLocalStorage<string>` to manage a session key in local storage.
 *
 * @function returnToAdmin
 * Signs in the user with a custom token and navigates to the admin users dashboard.
 *
 * @function AdminMenu
 * Renders the administration menu with options to enable or disable form validation.
 *
 * @example
 * ```tsx
 * <UserCard />
 * ```
 *
 * @dependencies
 * - `useContext`
 * - `useRouter`
 * - `usePathname`
 * - `useLocalStorage`
 * - `signInWithCustomToken`
 * - `handleSuccessfulAuth`
 * - `Box`
 * - `Alert`
 * - `NavLink`
 * - `Menu`
 * - `UserButton`
 *
 * @see {@link https://reactjs.org/docs/hooks-reference.html#usecontext | useContext}
 * @see {@link https://nextjs.org/docs/api-reference/next/router | useRouter}
 * @see {@link https://mantine.dev/docs/core/box/ | Box}
 * @see {@link https://mantine.dev/docs/core/alert/ | Alert}
 * @see {@link https://mantine.dev/docs/core/navlink/ | NavLink}
 * @see {@link https://mantine.dev/docs/core/menu/ | Menu}
 * @see {@link https://mantine.dev/docs/core/userbutton/ | UserButton}
 */
export default function UserCard() {
	const user = useContext(UserContext) as AuthContextValues;
	const isAdmin = user.states.userAuthData?.decodedToken?.isAdmin;
	const router = useRouter();
	const theme = useMantineTheme();
	const [isPending, startTransition] = useTransition();
	const [returnSessionKey, setReturnSessionKey, removeSessionKey] =
		useLocalStorage<string>({
			key: "return-session-key",
			defaultValue: undefined,
		});

	/**
	 * Authenticates the user with a custom token and redirects to the users dashboard.
	 *
	 * This function performs the following steps:
	 * 1. Signs in the user with a custom token.
	 * 2. Removes the session key.
	 * 3. Handles successful authentication.
	 * 4. Redirects the user to the "/dashboard/users" route.
	 *
	 * @returns {Promise<void>} A promise that resolves when the user is redirected.
	 */
	async function returnToAdmin() {
		await signInWithCustomToken(user.authForClientSide, returnSessionKey)
			.then((res) => {
				handleSuccessfulAuth({ res, user });
			})
			.then(() => {
				router.push("/dashboard/users");
			})
			.finally(() => removeSessionKey());
	}

	function AdminSection(): JSX.Element | undefined {
		if (!isAdmin && !returnSessionKey) return;

		return (
			<Fragment>
				<Menu.Label>Administration</Menu.Label>
				{returnSessionKey && (
					<Menu.Item
						leftSection={<IconSettings size={14} />}
						onClick={() => {
							startTransition(async () => {
								await returnToAdmin();
							});
						}}
					>
						Return to Admin
					</Menu.Item>
				)}
				{!!isAdmin && !user.states.isFormValidating && (
					<MenuItem
						leftSection={
							<IconCodeVariablePlus
								style={{ width: rem(16), height: rem(16) }}
							/>
						}
						onClick={() => {
							startTransition(() => {
								user.setters.setIsFormValidating(true);
							});
						}}
					>
						Enable Validation
					</MenuItem>
				)}
				{!!isAdmin && user.states.isFormValidating && (
					<MenuItem
						leftSection={
							<IconInputX style={{ width: rem(16), height: rem(16) }} />
						}
						onClick={() => {
							startTransition(() => {
								user.setters.setIsFormValidating(false);
							});
						}}
					>
						Disable Validation
					</MenuItem>
				)}
			</Fragment>
		);
	}

	return (
		<Menu>
			<Menu.Dropdown
				px="sm"
				py="sm"
			>
				<LoadingOverlay visible={isPending} />
				<Flex
					style={{ flex: 1 }}
					p="sm"
					bg="gray.0"
					mb="sm"
				>
					<Group gap="sm">
						<Stack gap={0}>
							{returnSessionKey && (
								<Text
									size="xs"
									fw={200}
								>
									Masquerading:
								</Text>
							)}
							<Text
								size="sm"
								fw={500}
								fs={returnSessionKey ? "italic" : "inherit"}
							>
								{String(user.states.userAuthData?.decodedToken?.name ?? "")}
							</Text>

							<Text
								c="dimmed"
								size="xs"
							>
								{String(user.states.userAuthData?.decodedToken?.email ?? "")}
							</Text>
						</Stack>
					</Group>
				</Flex>
				<Menu.Label>Your Account</Menu.Label>
				<Menu.Item
					leftSection={<IconHelpHexagon size={14} />}
					onClick={() => {
						startTransition(() => {
							router.push("https://webdesignforactors.com");
						});
					}}
				>
					Get Help
				</Menu.Item>
				<Menu.Item
					leftSection={<IconSettings size={14} />}
					onClick={() => {
						startTransition(() => {
							router.push("/dashboard/settings");
						});
					}}
				>
					Settings & Billing
				</Menu.Item>
				<AdminSection />
				<Menu.Divider my="sm" />
				<Menu.Item
					leftSection={<IconDoorExit size={14} />}
					onClick={() => {
						startTransition(async () => {
							await user.signOut().then(() => router.push("/login"));
						});
					}}
					variant="light"
				>
					Sign Out of Account
				</Menu.Item>
			</Menu.Dropdown>
			<MenuTarget>
				<Avatar
					src={user.states.userAuthData?.decodedToken?.picture as string}
					bd={`3px solid ${theme.colors.branding[5]}`}
					size="md"
				/>
			</MenuTarget>
		</Menu>
	);
}
