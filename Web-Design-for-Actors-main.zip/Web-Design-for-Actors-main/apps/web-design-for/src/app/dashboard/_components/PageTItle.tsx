// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { Paper, Title } from "@mantine/core";

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function PageTitle({
	title,
	subtitle,
}: {
	title: string;
	subtitle: string;
}) {
	return (
		<Paper>
			<Title>{title}</Title>
			<Title order={5}>{subtitle}</Title>
		</Paper>
	);
}
