"use client";

// React Imports
import { useContext, useEffect, useState } from "react";

// Next.js Imports
import { useRouter } from "next/navigation";

// Lower Order Components
import { Form } from "@okedia/shared/form";

// UI Components & Icons
import {
	Avatar,
	Badge,
	Box,
	Button,
	Card,
	Flex,
	Grid,
	GridCol,
	Group,
	Stack,
	Title,
} from "@mantine/core";
import {
	IconCrown,
	IconCrownOff,
	IconLockExclamation,
	IconLockOpen2,
	IconMailCheck,
	IconMailExclamation,
	IconMailFast,
	IconTrash,
} from "@tabler/icons-react";

// Context & Helpers
import { UserContext } from "@/app/_context/User";
import { handleSuccessfulAuth } from "@/app/_utilities/authenticationFunctions";
import { arrayHelpers } from "@okedia/shared/helpers";
import { distanceToNow } from "@okedia/shared/helpers/date";
import { generateInitialFormValues } from "@okedia/shared/helpers/form";

// Other libraries or utilities
import usePopup from "@/app/_hooks/usePopup";
import { signInWithCustomToken } from "firebase/auth";
import { useDatabase } from "@okedia/shared/hooks";
import { SubmitHandler, useForm } from "react-hook-form";

// Types
import type { UserRecord } from "firebase-admin/auth";
import { UsersList } from "next-firebase-auth-edge/lib/auth";
import { AuthContextValues } from "@okedia/shared/types/contextTypes";
import { FormValues, Input } from "@okedia/shared/types/formTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * The `Page` component is responsible for rendering the user management dashboard.
 * It fetches user data from the database, displays user information, and provides
 * functionalities to update user details, delete users, and manage user roles.
 *
 * @component
 * @returns {JSX.Element} The rendered component.
 *
 * @example
 * ```tsx
 * import Page from './path/to/Page';
 *
 * function App() {
 *   return <Page />;
 * }
 * ```
 *
 * @remarks
 * This component uses several hooks and context values:
 * - `useDatabase`: Custom hook to interact with the database.
 * - `useState`: React hook to manage user data state.
 * - `useMantineTheme`: Hook to access the Mantine theme.
 * - `usePopup`: Custom hook to manage popup state.
 * - `useContext`: React hook to access the current user context.
 * - `useRouter`: Next.js hook to manage routing.
 *
 * The component includes the following main functionalities:
 * - `getUserData`: Fetches user data from the database and updates the state.
 * - `handleDeleteUser`: Deletes a user from the database and updates the state.
 * - `updateUserInState`: Updates user information in the state.
 * - `updateCustomClaims`: Updates custom claims for a user and updates the state.
 * - `handleLoginAsUser`: Logs in as a specific user and redirects to the dashboard.
 *
 * The `PopupBody` sub-component is used to render a form for updating user details.
 * It includes form validation and submission logic.
 *
 * The component renders a grid of user cards, each displaying user information and
 * providing actions to update or delete the user. A "Load More" button is provided
 * to fetch additional user data if available.
 */
export default function Page() {
	const db = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);
	const [userData, setUserData] = useState<UsersList>({
		users: [],
		nextPageToken: undefined,
	});
	const popup = usePopup();
	const currentUser = useContext(UserContext) as AuthContextValues;
	const router = useRouter();

	/**
	 * Fetches user data from the server and updates the state with the retrieved data.
	 *
	 * - Constructs the URL for the API request, optionally appending the `startingFrom` parameter if `nextPageToken` exists.
	 * - Sends a GET request to the constructed URL to fetch the user data.
	 * - Updates the state with the fetched user data:
	 *   - If the existing user data is empty, sets the state with the initial response.
	 *   - Otherwise, merges the existing users with the new users, avoiding duplicates based on user UID.
	 *   - Updates the `nextPageToken` in the state with the new token from the response, or sets it to `undefined` if not present.
	 *
	 * @returns {void}
	 */
	const getUserData = () => {
		let url = `/auth/user/?method=all`;

		// Conditionally append the startingFrom parameter if nextPageToken exists
		if (userData?.nextPageToken) {
			url += `&startingFrom=${userData.nextPageToken}`;
		}

		db.get<UsersList>(url).then((res) => {
			setUserData((prevData) => {
				if (!prevData.users?.length) {
					// If `userData` is empty, set it with the initial response
					return res;
				} else {
					// Merge existing users with new users, avoiding duplicates
					const existingUids = new Set(prevData.users.map((user) => user.uid));
					const newUsers = res.users.filter(
						(user) => !existingUids.has(user.uid)
					);

					return {
						...prevData,
						users: [...prevData.users, ...newUsers],
						nextPageToken: res.nextPageToken || undefined, // Use undefined instead of null
					};
				}
			});
		});
	};

	/**
	 * Deletes a user by their unique identifier (uid).
	 *
	 * This function finds the user in the userData array, removes them from the list,
	 * updates the state with the new user list, and then sends a request to delete
	 * the user from the database.
	 *
	 * @param {string} uid - The unique identifier of the user to be deleted.
	 * @returns {Promise<void>} A promise that resolves when the user has been deleted.
	 */
	async function handleDeleteUser(uid: string) {
		const index = arrayHelpers.find.index(userData.users, "uid", uid);
		const newUsersList = arrayHelpers.remove.atIndex(userData.users, index);

		setUserData((prevValues) => ({
			...prevValues,
			users: newUsersList,
		}));

		return await db.deleter(`/auth/user/${uid}`);
	}

	/**
	 * Updates a user in the state by their unique identifier (uid).
	 *
	 * @param {string} uid - The unique identifier of the user to update.
	 * @param {any} body - The new data to update the user with.
	 *
	 * This function finds the user in the state by their uid and updates their data
	 * with the provided body. If the user is found, it updates the state with the
	 * new user data while preserving the rest of the state.
	 */
	function updateUserInState(uid: string, body: any) {
		const userIndex = arrayHelpers.find.index(userData.users, "uid", uid);
		if (userIndex !== -1) {
			setUserData((prevValues) => ({
				...prevValues,
				users: prevValues.users.map((user, index) =>
					index === userIndex ? { ...user, ...body } : user
				),
			}));
		}
	}

	/**
	 * Updates the custom claims for a user with the specified UID.
	 *
	 * @param {string} uid - The unique identifier of the user whose custom claims are to be updated.
	 * @param {any} body - The body of the request containing the custom claims to be updated.
	 * @returns {Promise<void>} A promise that resolves when the custom claims have been successfully updated.
	 *
	 * This function sends a POST request to the `/auth/claims/` endpoint with the specified UID and body.
	 * Upon successful response, it finds the user in the `userData.users` array, updates the user's custom claims,
	 * and then updates the user in the state.
	 */
	async function updateCustomClaims(uid: string, body: any) {
		await db.post(`/auth/claims/${uid}&merge=true`, body).then((res) => {
			const userIndex = arrayHelpers.find.index(userData.users, "uid", uid);
			const updatedUser = { ...userData.users[userIndex], customClaims: res };
			updateUserInState(uid, updatedUser);
		});
	}

	/**
	 * Handles the process of logging in as a different user.
	 *
	 * This function performs the following steps:
	 * 1. Creates a session for the current user and stores the session key in local storage.
	 * 2. Creates a session for the specified user (by UID) and signs in with a custom token.
	 * 3. On successful authentication, redirects the user to the dashboard.
	 *
	 * @param {string} uid - The unique identifier of the user to log in as.
	 * @returns {Promise<void>} A promise that resolves when the login process is complete.
	 */
	async function handleLoginAsUser(uid: string) {
		await db
			.get(
				`/auth/createsession/${currentUser.authForClientSide.currentUser?.uid}`,
				{ cache: "no-cache" }
			)
			.then((res) =>
				localStorage?.setItem("return-session-key", res as string)
			);

		await db
			.get(`/auth/createsession/${uid}`, { cache: "no-store" })
			.then((res) => {
				signInWithCustomToken(currentUser.authForClientSide, res as string)
					.then((res) => handleSuccessfulAuth({ res, user: currentUser }))
					.then(() => {
						router.push("/dashboard");
					});
			});
	}

	/**
	 * PopupBody component renders a form to update user data and provides quick actions for user management.
	 *
	 * @param {Object} props - The component props.
	 * @param {UserRecord} props.user - The user record to be managed.
	 *
	 * @returns {JSX.Element} The rendered PopupBody component.
	 *
	 * @component
	 *
	 * @example
	 * const user = {
	 *   uid: '123',
	 *   email: 'user@example.com',
	 *   emailVerified: true,
	 *   displayName: 'John Doe',
	 *   photoURL: 'http://example.com/photo.jpg',
	 *   disabled: false,
	 *   customClaims: { isAdmin: false }
	 * };
	 *
	 * <PopupBody user={user} />
	 */
	function PopupBody({ user }: { user: UserRecord }) {
		const validateAndSubmit: SubmitHandler<FormValues> = async (data, e) => {
			e?.preventDefault();
			const updatedData = {
				email: data.email.email[0].email,
				emailVerified: data.email.email[0].isVerified,
				displayName: data.profile.profile[0].displayName,
				photoURL: data.profile.profile[0].photoURL.downloadUrl,
				disabled: data.profile.profile[0].isDisabled,
			} as Partial<UserRecord>;
			await db
				.patch<UserRecord>(`/auth/user/${user.uid}`, updatedData)
				.then((res) => {
					popup.setModalConfig({
						...popup.modalConfig,
						opened: false,
					});

					updateUserInState(user.uid, res);
				});
		};
		const formConfig: Input[] = [
			{
				inputGroup: "email",
				id: "email",
				label: "Email Address",
				helpText: "Manage Email Address & Verification",
				fieldComponents: [
					{
						component: "text",
						id: "email",
						inputWeight: 0,
						attributes: {
							label: "Email Address",
							placeholder: "my@email.com",
							width: "75%",
						},
						validators: {
							required: true,
							pattern: "email",
						},
					},
					{
						component: "switch",
						id: "isVerified",
						inputWeight: 1,
						attributes: {
							size: "md",
							label: "Email Address Verification",
							width: "25%",
							onLabel: <IconMailCheck size="18" />,
							offLabel: <IconMailExclamation size="18" />,
						},
					},
				],
			},
			{
				inputGroup: "profile",
				id: "profile",
				label: "User Profile",
				helpText: "Name and Profile Photo",
				fieldComponents: [
					{
						component: "text",
						id: "displayName",
						inputWeight: 3,
						attributes: {
							label: "Display Name",
							placeholder: "Mike McGuire",

							width: "50%",
						},
						validators: {
							pattern: "name",
						},
					},
					{
						component: "upload",
						id: "photoURL",
						inputWeight: 4,
						attributes: {
							label: "Profile Photo",
							width: "50%",
							forceCrop: true,
							placeholder: "Upload an Image",
						},
						validators: {
							accept: "image",
						},
					},
					{
						component: "switch",
						id: "isDisabled",
						inputWeight: 5,
						attributes: {
							label: "Ban Account",
							width: "100%",
							size: "md",
							onLabel: <IconLockExclamation size="18" />,
							offLabel: <IconLockOpen2 size="18" />,
						},
					},
				],
			},
		];

		const initialValues = {
			email: {
				email: [
					{
						email: user.email,
						isVerified: user.emailVerified,
					},
				],
			},
			profile: {
				profile: [
					{
						displayName: user.displayName,
						photoURL: user.photoURL,
						isDisabled: user.disabled,
					},
				],
			},
			password: {
				password: [
					{
						pass1: "",
					},
				],
			},
		};

		const form = useForm({
			defaultValues: generateInitialFormValues({
				formFields: formConfig,
				websiteData: initialValues,
			}),
			shouldFocusError: true,
			mode: "all",
		});

		return (
			<Box>
				<Flex
					bd="4px dashed #efefef"
					p="10px"
					mb="md"
					justify="space-between"
				>
					<Title order={5}>Quick Actions</Title>
					<Group>
						{!user.customClaims?.isAdmin && (
							<Button
								size="compact-sm"
								leftSection={<IconTrash size="18" />}
								color="red"
								variant="light"
								onClick={() =>
									handleDeleteUser(user.uid).finally(() =>
										popup.setModalConfig({
											...popup.modalConfig,
											opened: false,
										})
									)
								}
								disabled={true}
							>
								Delete User
							</Button>
						)}

						{!user.customClaims?.isAdmin && (
							<Button
								size="compact-sm"
								leftSection={<IconCrown size="18" />}
								variant="light"
								onClick={() =>
									updateCustomClaims(user.uid, { isAdmin: true }).finally(() =>
										popup.setModalConfig({
											...popup.modalConfig,
											opened: false,
										})
									)
								}
							>
								Make Admin
							</Button>
						)}
						{user.customClaims?.isAdmin && !user.customClaims?.isDeveloper && (
							<Button
								size="compact-sm"
								leftSection={<IconCrownOff size="18" />}
								variant="light"
								onClick={() =>
									updateCustomClaims(user.uid, { isAdmin: false }).finally(() =>
										popup.setModalConfig({
											...popup.modalConfig,
											opened: false,
										})
									)
								}
							>
								Demote Admin
							</Button>
						)}
						<Button
							size="compact-sm"
							leftSection={<IconMailFast size="18" />}
							variant="light"
							disabled={true}
						>
							Send Password Reset Email
						</Button>
					</Group>
				</Flex>
				<form
					onSubmit={form.handleSubmit(validateAndSubmit)}
					style={{ border: "4px dashed #efefef", padding: "10px" }}
				>
					<Title order={5}>Update Data</Title>
					<Form
						formFields={formConfig}
						formInstance={form}
						options={{ isHorizontal: true }}
					/>
					<Group
						grow
						mt="md"
					>
						<Button
							type="reset"
							variant="light"
							size="sm"
						>
							Reset
						</Button>
						<Button
							type="submit"
							size="sm"
						>
							Save Changes
						</Button>
					</Group>
				</form>
			</Box>
		);
	}

	useEffect(() => {
		getUserData();
	}, []);

	if (!userData.users?.length) {
		return;
	}

	return (
		<Grid
			columns={24}
			styles={{ inner: { alignItems: "stretch" } }}
		>
			{userData.users?.map((user) => {
				return (
					<GridCol
						span={{ base: 24, sm: 24, xl: 8, lg: 12, md: 12 }}
						key={user.uid}
					>
						<Card
							p="lg"
							h="100%"
							styles={{ root: { justifyContent: "space-between" } }}
						>
							<Group
								justify="center"
								my="lg"
							>
								<Avatar
									src={user.photoURL}
									radius="xl"
									bd="3px solid branding.5"
									size="lg"
								/>
								<Stack gap={0}>
									<Group
										gap="xs"
										justify={user.displayName ? "center" : "initial"}
									>
										{user.displayName && (
											<Title order={3}>{user.displayName}</Title>
										)}
									</Group>
									<Title order={4}>{user.email}</Title>
								</Stack>
							</Group>

							<Group
								gap="xs"
								justify="center"
								mt="sm"
								my="lg"
							>
								<Badge variant="outline">
									Signed Up {distanceToNow(user.metadata.creationTime)}
								</Badge>
								<Badge variant="outline">
									Signed In {distanceToNow(user.metadata.lastSignInTime)}
								</Badge>
								{!user.disabled && <Badge variant="dot">Account Enabled</Badge>}
								{user.disabled && (
									<Badge
										variant="dot"
										color="red"
									>
										Account Disabled
									</Badge>
								)}
								{user.emailVerified && (
									<Badge variant="dot">Email Verified</Badge>
								)}
								{!user.emailVerified && (
									<Badge
										variant="dot"
										color="red"
									>
										Email Not Verified
									</Badge>
								)}
							</Group>
							<Group
								grow
								my="lg"
							>
								<Button
									variant="light"
									onClick={() => {
										return popup.setModalConfig({
											opened: true,
											title: `Update Settings for ${user.email}`,
											body: <PopupBody user={user as UserRecord} />,
											submit: "Close",
											onSubmit: () => {
												popup.setModalConfig({
													...popup.modalConfig,
													opened: false,
												});
											},
										});
									}}
								>
									Update User
								</Button>
								<Button
									variant="light"
									onClick={() => {
										handleLoginAsUser(user.uid);
									}}
								>
									Sign In as User
								</Button>
							</Group>
						</Card>
					</GridCol>
				);
			})}
			<GridCol span={24}>
				<Button
					size="xl"
					fullWidth
					variant="light"
					loading={db.loading}
					onClick={getUserData}
					disabled={!userData?.nextPageToken}
				>
					{userData?.nextPageToken ? "Load More" : "No more results"}
				</Button>
			</GridCol>
			<popup.Element />
		</Grid>
	);
}
