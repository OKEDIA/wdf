// React Imports
import { useState, useTransition } from "react";

// Next.js Imports
import Link from "next/link";

// Lower Order Components
import WebsiteActions from "@/app/dashboard/_components/WebsiteActions";

// UI Components & Icons
import {
	Badge,
	Button,
	Card,
	Flex,
	GridCol,
	Group,
	Image,
	LoadingOverlay,
	Title,
	Tooltip,
	useMantineTheme,
} from "@mantine/core";
import {
	IconCaretDownFilled,
	IconCertificateOff,
	IconCode,
} from "@tabler/icons-react";
// Context & Helpers

// Other libraries or utilities
import { distanceToNow } from "@okedia/shared/helpers/date";

// Types
import { useRouter } from "next/navigation";
import { Website } from "@okedia/shared/types/websiteTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * A component that displays detailed information about a website in a card format.
 *
 * @component
 * @param {Object} props - The component props
 * @param {Website} props.website - The website object containing all website-related data
 *
 * @returns {JSX.Element} A grid column containing a card with website information including:
 * - Domain name with optional development status indicator
 * - Website preview image
 * - Creation and last update dates
 * - Website status (online/offline)
 * - Package type
 * - Website type
 * - Edit and manage website action buttons
 *
 * @example
 * ```tsx
 * <WebsiteCard website={websiteData} />
 * ```
 */
export default function WebsiteCard({
	website,
	options,
}: {
	website: Website<unknown>;
	options?: { withPreview?: boolean };
}) {
	options = { withPreview: true, ...options };
	const [isLoading, setIsLoading] = useState<boolean>(false);
	const [isPending, startTransition] = useTransition();

	const theme = useMantineTheme();
	const router = useRouter();
	const createdDate = new Date(website.created).toUTCString();
	const updatedDate = new Date(website.updated).toUTCString();

	const dataType = website.type;
	const design = website.template.colorScheme[0].colorScheme.design;
	const colorScheme = website.template.colorScheme[0].colorScheme.colorScheme;

	return (
		<GridCol
			span={{ base: 24, sm: 24, xl: 8, lg: 12, md: 12 }}
			key={website.id}
		>
			<Card
				p="lg"
				h="100%"
				styles={{ root: { justifyContent: "space-between" } }}
			>
				<LoadingOverlay visible={isLoading} />
				<Group
					gap="xs"
					justify="center"
					my="lg"
				>
					<Link
						href={`https://${website.domain}?noCache=${Date.now().toString()}`}
						target="_blank"
					>
						<Title order={3}>https://{website.domain}</Title>
					</Link>

					{website.development && (
						<Tooltip
							label="Developer Website"
							color="branding"
							position="top"
							withArrow
							arrowOffset={50}
							arrowSize={7}
							offset={{ mainAxis: 10, crossAxis: 0 }}
							openDelay={100}
							closeDelay={300}
							transitionProps={{
								transition: "fade-up",
								duration: 300,
							}}
						>
							<IconCode color={theme.colors.branding[5]} />
						</Tooltip>
					)}
					{website.package.toLowerCase().endsWith("demo") && (
						<Tooltip
							label="Temporary Preview Link"
							color="branding"
							position="top"
							withArrow
							arrowOffset={50}
							arrowSize={7}
							offset={{ mainAxis: 10, crossAxis: 0 }}
							openDelay={100}
							closeDelay={300}
							transitionProps={{
								transition: "fade-up",
								duration: 300,
							}}
						>
							<IconCertificateOff color={theme.colors.branding[5]} />
						</Tooltip>
					)}
				</Group>
				<Flex
					gap="sm"
					align="center"
					justify="center"
					my="lg"
				>
					{options.withPreview && (
						<Image
							src={`/website-images/${dataType}/${design}/${colorScheme}.png`}
							alt={`Preview of ${website.template.colorScheme[0].colorScheme.colorScheme}`}
							height="100px"
							p="lg"
							fit="contain"
						/>
					)}
					<Group gap="sm">
						<Badge variant="outline">
							Created {distanceToNow(createdDate.toString())}
						</Badge>
						<Badge variant="outline">
							Last Edited {distanceToNow(updatedDate?.toString())}
						</Badge>
						<Badge
							variant="dot"
							color={
								website.status.toLowerCase() === "online" ? "branding" : "red"
							}
						>
							{website.status}
						</Badge>
						<Badge>{website.package} Package</Badge>
						<Badge>{website.type}</Badge>
					</Group>
				</Flex>
				<Group
					grow
					my="lg"
				>
					<Button
						variant="light"
						onClick={() =>
							startTransition(() =>
								router.push(`/dashboard/edit/${website.profileId}`)
							)
						}
						loading={isPending}
					>
						Edit Website
					</Button>
					<WebsiteActions
						website={website}
						state={{ isLoading, setIsLoading }}
						target={
							<Button
								variant="light"
								rightSection={<IconCaretDownFilled size="18" />}
							>
								Manage Website
							</Button>
						}
					></WebsiteActions>
				</Group>
			</Card>
		</GridCol>
	);
}
