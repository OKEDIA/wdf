"use client";

// React Imports
import { useEffect, useState } from "react";

// Next.js Imports

// Lower Order Components
import WebsiteCard from "./_components/WebsiteCard";

// UI Components & Icons
import { Button, Grid, GridCol } from "@mantine/core";

// Context & Helpers

// Other libraries or utilities
import { useDatabase } from "@okedia/shared/hooks";

// Types
import { PaginitedMongoResponse } from "@okedia/shared/types/documentResponses";
import { FormValues } from "@okedia/shared/types/formTypes";
import { Website } from "@okedia/shared/types/websiteTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Renders a paginated grid of website cards with a "Load More" button.
 *
 * This component fetches website data from the database in paginated chunks and displays them in a grid layout.
 * It handles pagination through a "Load More" button that fetches additional websites when clicked.
 *
 * @returns {JSX.Element | undefined} A Grid component containing WebsiteCards and a "Load More" button,
 * or undefined if no website data is available
 *
 * @example
 * ```tsx
 * <Page />
 * ```
 *
 * @remarks
 * - Uses the database URL from NEXT_PUBLIC_API_BASE_URL environment variable
 * - Implements infinite scroll pagination
 * - Prevents duplicate entries when loading more data
 * - Disables "Load More" button when all data has been fetched
 */
export default function Page() {
	const db = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);
	const [websitesData, setWebsitesData] = useState<Website<unknown>[]>([]);
	const [isMorePages, setIsMorePages] = useState<boolean>(true);

	const getAllWebsitesData = () => {
		let url = `/websites/?getAll`;

		if (websitesData.length >= 1) {
			url += `&afterId=${websitesData[websitesData.length - 1].id}`;
		}

		db.get<PaginitedMongoResponse<Website<unknown>>>(url, {
			cache: "no-cache",
		}).then((res) => {
			if (
				res.paginition &&
				websitesData.length + res.data.length + 1 >= res.paginition.count
			) {
				setIsMorePages(false);
			}

			setWebsitesData((prevData) => {
				// Filter out items in `res.data` that already exist in `prevData` based on `id`
				const newEntries = res.data.filter(
					(newItem: FormValues) =>
						!prevData.some((existingItem) => existingItem.id === newItem.id)
				);

				// Append only unique new entries to `prevData`
				return [...prevData, ...newEntries];
			});
		});
	};

	useEffect(() => {
		getAllWebsitesData();
	}, []);

	if (websitesData?.length <= 0) {
		return;
	}

	return (
		<Grid
			columns={24}
			styles={{ inner: { alignItems: "stretch" } }}
		>
			{websitesData.map((website) => {
				return <WebsiteCard website={website} />;
			})}
			<GridCol span={24}>
				<Button
					size="xl"
					fullWidth
					variant="light"
					loading={db.loading}
					onClick={getAllWebsitesData}
					disabled={!isMorePages}
				>
					{isMorePages ? "Load More" : "No more results"}
				</Button>
			</GridCol>
		</Grid>
	);
}
