"use client";

// React Imports
import { useContext } from "react";

// Next.js Imports

// Lower Order Components
import Dashboard from "./_components/Dashboard";

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types
import { WebsiteContextValues } from "@okedia/shared/types/contextTypes";
import { WebsiteContext } from "../_context/Websites";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Page component that retrieves website data from the WebsiteContext
 * and passes it to the Dashboard component.
 *
 * @returns {JSX.Element} The rendered Dashboard component with website data.
 */
export default function Page() {
	const websites = useContext(WebsiteContext) as WebsiteContextValues;

	return (() => {
		const simulateLoading = async () => {
			await new Promise((resolve) => setTimeout(resolve, 60000));
			return true;
		};

		simulateLoading();
		return <Dashboard websites={websites} />;
	})();
}
