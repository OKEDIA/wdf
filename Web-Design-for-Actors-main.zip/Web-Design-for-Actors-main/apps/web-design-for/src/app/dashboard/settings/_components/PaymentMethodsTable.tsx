// React Imports
import { useEffect, useState } from "react";

// Next.js Imports

// Lower Order Components
import SkeletonTableRow from "./SkeletonTableRow";

// UI Components & Icons
import {
	ActionIcon,
	Card,
	Group,
	Table,
	TableTbody,
	TableTd,
	TableTh,
	TableThead,
	TableTr,
	Text,
} from "@mantine/core";
import {
	IconBrandMastercard,
	IconBrandVisa,
	IconCreditCard,
	IconTrash,
} from "@tabler/icons-react";

// Context & Helpers

// Other libraries or utilities
import { useDatabase } from "@okedia/shared/hooks";

// Types
import {
	CustomerWithSession,
	PaymentMethod,
	StripeResponse,
} from "@okedia/shared/stripe";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
/**
 * PaymentMethodsTable component displays a table of payment methods for a billing user.
 *
 * @param {Object} props - The component props.
 * @param {CustomerWithSession} [props.billingUser] - The billing user whose payment methods are to be displayed.
 *
 * @returns {JSX.Element} The rendered PaymentMethodsTable component.
 *
 * @component
 *
 * @example
 * // Usage example:
 * <PaymentMethodsTable billingUser={billingUser} />
 *
 * @remarks
 * This component fetches the payment methods for the given billing user and displays them in a table.
 * It also allows the user to remove a payment method.
 *
 * @function
 * @name PaymentMethodsTable
 */
export default function PaymentMethodsTable({
	billingUser,
}: {
	billingUser?: CustomerWithSession;
}) {
	const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[] | null>(
		null
	);
	const [isLoading, setIsLoading] = useState(true);
	const [loadingStates, setLoadingStates] = useState<{
		[key: string]: boolean;
	}>({});
	const db = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);

	useEffect(() => {
		setIsLoading(true);
		if (billingUser) {
			if (billingUser.customer.id) {
				db.get<StripeResponse<PaymentMethod>>(
					`/billing/customers/${billingUser.customer.id}/paymentmethods`
				)
					.then((res) => {
						setPaymentMethods(res.data);
					})
					.finally(() => setIsLoading(false));
			}
		}
	}, [billingUser]);

	/**
	 * Handles the removal of a payment method.
	 *
	 * This function sets the loading state for the specified payment method,
	 * sends a request to delete the payment method from the database, updates
	 * the state to remove the payment method from the list, and finally resets
	 * the loading state.
	 *
	 * @param {string} methodId - The ID of the payment method to be removed.
	 * @returns {Promise<void>} A promise that resolves when the payment method has been removed.
	 */
	async function handleRemovePaymentMethod(methodId: string) {
		setLoadingStates((prev) => ({ ...prev, [methodId]: true }));
		await db
			.deleter(
				`/billing/customers/${billingUser?.customer.customerId}/paymentmethods/${methodId}`
			)
			.then((res) => {
				setPaymentMethods(
					(prev) => prev?.filter((method) => method.id !== methodId) || null
				);
			})
			.finally(() => {
				setLoadingStates((prev) => ({ ...prev, [methodId]: false }));
			});
	}

	/**
	 * Generates an array of table rows representing payment methods.
	 *
	 * Each row contains:
	 * - An icon representing the card brand (Visa, Mastercard, or a generic credit card icon).
	 * - The last four digits of the card number.
	 * - The card's expiration date.
	 * - An action icon to remove the payment method.
	 *
	 * @param {Array} paymentMethods - An array of payment method objects.
	 * @param {Function} handleRemovePaymentMethod - A function to handle the removal of a payment method.
	 * @param {Object} loadingStates - An object representing the loading state for each payment method.
	 * @returns {Array} An array of JSX elements representing table rows.
	 */
	const paymentMethodRows = paymentMethods?.map((method, index) => {
		let IconComponent;
		if (method.card?.brand === "visa") {
			IconComponent = <IconBrandVisa size="18" />;
		} else if (method.card?.brand === "mastercard") {
			IconComponent = <IconBrandMastercard size="18" />;
		} else {
			IconComponent = <IconCreditCard size="18" />;
		}

		return (
			<TableTr key={method.id}>
				<TableTd>
					<Text
						display="flex"
						style={{ alignItems: "center" }}
					>
						{IconComponent}
						&nbsp;&nbsp; ••• {method.card?.last4}
					</Text>
				</TableTd>
				<TableTd>
					{method.card?.exp_month}/{method.card?.exp_year}
				</TableTd>
				<TableTd>
					<Group gap="xs">
						<ActionIcon
							color="red.7"
							onClick={() => handleRemovePaymentMethod(method.id)}
							loading={loadingStates[method.id]}
						>
							<IconTrash size="18" />
						</ActionIcon>
					</Group>
				</TableTd>
			</TableTr>
		);
	});

	/**
	 * Renders the content of the payment methods table.
	 *
	 * This function handles three states:
	 * 1. Loading state: Displays skeleton rows to indicate loading.
	 * 2. Loaded state with payment methods: Displays the payment methods.
	 * 3. Loaded state with no payment methods: Displays a message indicating no payment methods are available.
	 *
	 * @returns {JSX.Element} The table body content based on the current state.
	 */
	function TableContent() {
		if (isLoading) {
			return (
				<TableTbody>
					<SkeletonTableRow columns={3} />
					<SkeletonTableRow columns={3} />
				</TableTbody>
			);
		} else if (paymentMethods && paymentMethods.length > 0) {
			return <TableTbody>{paymentMethodRows}</TableTbody>;
		} else {
			return (
				<TableTbody>
					<TableTr>
						<TableTd colSpan={6}>You have no payment methods.</TableTd>
					</TableTr>
				</TableTbody>
			);
		}
	}

	return (
		<Card styles={{ root: { overflowX: "auto" } }}>
			<Table>
				<TableThead>
					<TableTr>
						<TableTh>Card Number</TableTh>
						<TableTh>Expiry Date</TableTh>
						<TableTh>Actions</TableTh>
					</TableTr>
				</TableThead>
				<TableContent />
			</Table>
		</Card>
	);
}
