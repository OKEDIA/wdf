// React Imports
import { useContext, useEffect, useState } from "react";

// Next.js Imports

// Lower Order Components
import SkeletonTableRow from "./SkeletonTableRow";

// UI Components & Icons
import {
	ActionIcon,
	Alert,
	Card,
	Grid,
	Group,
	Table,
	TableTbody,
	TableTd,
	TableTh,
	TableThead,
	TableTr,
} from "@mantine/core";
import { IconReceiptDollar, IconTrash } from "@tabler/icons-react";
import { Form } from "@okedia/shared/form";

// Context & Helpers
import { WebsiteContext } from "@/app/_context/Websites";

// Other libraries or utilities
import usePopup from "@/app/_hooks/usePopup";
import { generateInitialFormValues } from "@okedia/shared/helpers/form";
import { useDatabase } from "@okedia/shared/hooks";
import { useForm } from "react-hook-form";

// Types
import {
	CustomerWithSession,
	StripeResponse,
	Subscription,
} from "@okedia/shared/stripe";
import { WebsiteContextValues } from "@okedia/shared/types/contextTypes";
import { Input } from "@okedia/shared/types/formTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
/**
 * SubscriptionsTable component displays a table of user subscriptions and allows for actions such as
 * downloading invoices and canceling subscriptions.
 *
 * @param {Object} props - The component props.
 * @param {CustomerWithSession} [props.billingUser] - The billing user information.
 *
 * @returns {JSX.Element} The rendered SubscriptionsTable component.
 *
 * @component
 *
 * @example
 * // Usage example:
 * <SubscriptionsTable billingUser={billingUser} />
 *
 * @remarks
 * This component fetches subscription data from the database and displays it in a table format.
 * It also provides functionality to download invoices and cancel subscriptions.
 */
export default function SubscriptionsTable({
	billingUser,
}: {
	billingUser?: CustomerWithSession;
}) {
	const [subscriptions, setSubscriptions] = useState<Subscription[] | null>(
		null
	);
	const [isLoading, setIsLoading] = useState(true);
	const db = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);
	const cancelSubPopup = usePopup();
	const [subscriptionToDelete, setSubscriptionToDelete] = useState("");
	const websites = useContext(WebsiteContext) as WebsiteContextValues;

	useEffect(() => {
		setIsLoading(true);
		if (billingUser) {
			if (billingUser.customer.id) {
				db.get<StripeResponse<Subscription>>(
					`/billing/customers/${billingUser.customer.id}/subscriptions`
				)
					.then((res) => {
						setSubscriptions(res.data);
					})
					.finally(() => setIsLoading(false));
			}
		}
	}, [billingUser]);

	// /**
	//  * Downloads the invoice URL for a given invoice ID.
	//  *
	//  * @param {string} invoiceId - The ID of the invoice to download.
	//  * @returns {Promise<string>} - A promise that resolves to the URL of the hosted invoice.
	//  * @throws {Error} - Throws an error if the invoice link cannot be retrieved.
	//  */
	// async function handleInvoiceDownload(invoiceId: string) {
	// 	const invoiceUrl = await db
	// 		.get<Invoice>(
	// 			`/billing/customers/${billingUser?.customer.id}/invoices/?invoiceId=${invoiceId}`
	// 		)
	// 		.then((res) => {
	// 			if (!res.hosted_invoice_url) {
	// 				// Display error and return if response did not contain an invoice link
	// 				throw new Error("Unable to get your invoice link");
	// 			}

	// 			return res.hosted_invoice_url;
	// 		})
	// 		.catch((error) => {
	// 			throw error;
	// 		});

	// 	return invoiceUrl;
	// }

	const formConfig: Input[] = [
		{
			inputGroup: "cancelation",
			id: "cancelation",
			label: "Reason for Cancellation",
			helpText: "Please give us a vague reason as to why you wish to cancel.",
			fieldComponents: [
				{
					component: "select",
					id: "reason_select",
					inputWeight: 0,

					validators: {
						required: false,
					},
					attributes: {
						width: "100%",
						label: "Reason for Cancellation",
						options: [
							{
								label: "Customer service was less than expected",
								value: "customer_service",
							},
							{ label: "Quality was less than expected", value: "low_quality" },
							{ value: "missing_features", label: "Some features are missing" },
							{
								value: "switched_service",
								label: "I’m switching to a different service",
							},
							{
								value: "too_complex",
								label: "Ease of use was less than expected",
							},
							{ value: "too_expensive", label: "It’s too expensive" },
							{ value: "unused", label: "I don’t use the service enough" },
							{ value: "other", label: "Other" },
						],
					},
				},
			],
		},
	];

	const initialValues = {
		cancelation: {
			reason_select: [
				{
					value: "",
				},
			],
		},
	};

	const form = useForm({
		defaultValues: generateInitialFormValues({
			formFields: formConfig,
			websiteData: initialValues,
		}),
		shouldFocusError: true,
		mode: "all",
	});

	/**
	 * Generates table rows for each subscription, excluding those with a status of "incomplete_expired".
	 *
	 * @param {Array} subscriptions - The list of subscription objects.
	 * @returns {Array} An array of JSX elements representing table rows.
	 *
	 * Each row contains the following columns:
	 * - Domain: The domain metadata of the subscription.
	 * - Status: The current status of the subscription.
	 * - Plan: The nickname of the subscription plan.
	 * - Renewal Date: The renewal date of the subscription or "Cancelled" if the subscription is cancelled.
	 * - Amount: The amount of the subscription plan in the specified currency.
	 * - Actions: Action icons for cancelling the subscription and downloading the latest invoice.
	 *
	 * Notes:
	 * - Subscriptions with a status of "incomplete_expired" are excluded.
	 * - The "Cancel Subscription" action is disabled for incomplete or cancelled subscriptions.
	 * - The "Download Invoice" action opens a new window to download the latest invoice.
	 */
	const subscriptionRows = subscriptions?.map((subscription) => {
		console.log(subscription);
		if (subscription.status === "incomplete_expired") {
			return null;
		}
		const incomplete = subscription.status === "incomplete";
		const cancelled =
			subscription.cancel_at_period_end || subscription.cancel_at !== null; // returns true if the subscription is cancelled
		const isDemo = subscription.plan.nickname?.toLowerCase() === "demo";

		return (
			<TableTr key={subscription.id}>
				<TableTd>{subscription.metadata?.domain}</TableTd>{" "}
				<TableTd>{subscription.status}</TableTd>
				<TableTd>{subscription.plan?.nickname}</TableTd>
				<TableTd>
					{isDemo
						? "Trail Period, does not renew"
						: (!cancelled &&
								new Date(
									subscription.current_period_end * 1000
								).toLocaleDateString()) ||
						  (cancelled && "Cancelled")}
				</TableTd>
				<TableTd>
					{!isDemo && (subscription.plan?.amount ?? 0) / 100}
					{!isDemo && subscription.plan?.currency}
				</TableTd>
				<TableTd>
					<Group gap="xs">
						<ActionIcon
							disabled={(!isDemo && cancelled) || incomplete}
							color="red.7"
							onClick={() => {
								cancelSubPopup.setModalConfig({
									title: "Cancel Subscription",
									submit: "Yes, Cancel",
									cancel: "No, Keep Subscription",
									onSubmit: form.handleSubmit(async (data, e) => {
										e?.preventDefault();

										if (!subscription) {
											throw new Error("No subscription to delete");
										}

										await db.deleter(
											`/billing/customers/${billingUser?.customer.id}/subscriptions/${subscription.id}/?reason=${data.cancelation.cancelation[0].reason_select}`
										);

										const website = websites.states.websites.find(
											(website) => website?.subscriptionId === subscription?.id
										);

										if (website !== undefined) {
											await websites.deleter(website?.id as string);
										}

										setSubscriptions(
											(prevSubscriptions) =>
												prevSubscriptions?.filter(
													(subscription) =>
														subscription.id !== data.subscription
												) ?? null
										);
									}),
									opened: true,
								});
							}}
						>
							<IconTrash size="18" />
						</ActionIcon>
						{subscription.latest_invoice?.hosted_invoice_url && (
							<ActionIcon
								color="blue.7"
								onClick={async () => {
									// Prevent popup blocking
									// Do this here to try and prevent popup blockers as it is a direct result of clicking on this button
									const windowReference = window.open();

									if (!windowReference) {
										return;
									}
									windowReference.location = subscription.latest_invoice
										.hosted_invoice_url as string;
								}}
							>
								<IconReceiptDollar size="18" />
							</ActionIcon>
						)}
					</Group>
				</TableTd>
			</TableTr>
		);
	});

	/**
	 * Renders the content of the subscriptions table based on the loading state and the presence of subscriptions.
	 *
	 * @returns {JSX.Element} The table body with either loading skeletons, subscription rows, or a message indicating no active subscriptions.
	 */
	function TableContent() {
		if (isLoading) {
			return (
				<TableTbody>
					<SkeletonTableRow columns={6} />
					<SkeletonTableRow columns={6} />
				</TableTbody>
			);
		} else if (subscriptions && subscriptions.length > 0) {
			return <TableTbody>{subscriptionRows}</TableTbody>;
		} else {
			return (
				<TableTbody>
					<TableTr>
						<TableTd colSpan={6}>You have no active subscriptions.</TableTd>
					</TableTr>
				</TableTbody>
			);
		}
	}

	return (
		<Card styles={{ root: { overflowX: "auto" } }}>
			<cancelSubPopup.Element>
				<form style={{ marginBottom: "75px" }}>
					<Card>
						<Alert mb="50px">
							This action will cancel your current subscription immediately and
							permently delete your website. If you're sure you wish to
							continue, we would really appreciate it if you could let us know
							why.
						</Alert>
						<Grid
							columns={6}
							justify="center"
							align="middle"
						>
							<Form
								formFields={formConfig}
								formInstance={form}
							/>
						</Grid>
					</Card>
				</form>
			</cancelSubPopup.Element>
			<Table>
				<TableThead>
					<TableTr>
						<TableTh>Domain</TableTh>
						<TableTh>Status</TableTh>
						<TableTh>Plan</TableTh>
						<TableTh>Renewal Date</TableTh>
						<TableTh>Renewal Cost</TableTh>
						<TableTh>Actions</TableTh>
					</TableTr>
				</TableThead>
				<TableContent />
			</Table>
		</Card>
	);
}
