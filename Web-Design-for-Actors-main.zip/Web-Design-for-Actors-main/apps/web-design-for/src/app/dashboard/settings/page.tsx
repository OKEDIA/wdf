"use client";

// React Imports
import { useContext } from "react";
// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { Grid, GridCol, Text, Title } from "@mantine/core";

// Context & Helpers
import { UserContext } from "@/app/_context/User";

// Other libraries or utilities

// Types
import { AuthContextValues } from "@okedia/shared/types/contextTypes";
import PaymentMethodsTable from "./_components/PaymentMethodsTable";
import SubscriptionsTable from "./_components/SubscriptionsTable";
import UserProfileTable from "./_components/UserProfileTable";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
/**
 * The `Page` component renders the settings dashboard for the user.
 * It displays three main sections: "Your Profile", "Billing Details", and "Subscriptions".
 * Each section contains a title, a description, and a corresponding table component.
 *
 * @returns {JSX.Element} The rendered settings dashboard page.
 */
export default function Page() {
	const user = useContext(UserContext) as AuthContextValues;

	return (
		<Grid columns={24}>
			<GridCol span={24}>
				<Grid columns={24}>
					<GridCol
						span={{ base: 24, lg: 8 }}
						p="lg"
					>
						<Title>Your Profile</Title>
						<Text>Update your name, email address or password.</Text>
					</GridCol>
					<GridCol span={{ base: 24, lg: 16 }}>
						<UserProfileTable user={user} />
					</GridCol>
				</Grid>
			</GridCol>
			<GridCol span={24}>
				<Grid columns={24}>
					<GridCol
						span={{ base: 24, lg: 8 }}
						p="lg"
					>
						<Title>Billing Details</Title>
						<Text>Keep your payment details up to date.</Text>
					</GridCol>
					<GridCol span={{ base: 24, lg: 16 }}>
						<PaymentMethodsTable billingUser={user.states.billingUserData} />
					</GridCol>
				</Grid>
			</GridCol>
			<GridCol span={24}>
				<Grid columns={24}>
					<GridCol
						span={{ base: 24, lg: 8 }}
						p="lg"
					>
						<Title>Subscriptions</Title>
						<Text>Stay on top of your subscriptions.</Text>
					</GridCol>
					<GridCol span={{ base: 24, lg: 16 }}>
						<SubscriptionsTable billingUser={user.states.billingUserData} />
					</GridCol>
				</Grid>
			</GridCol>
		</Grid>
	);
}
