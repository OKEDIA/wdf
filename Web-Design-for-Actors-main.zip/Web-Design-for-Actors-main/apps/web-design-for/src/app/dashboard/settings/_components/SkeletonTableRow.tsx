// React Imports

import { Skeleton, TableTd, TableTr, useMantineTheme } from "@mantine/core";

// Next.js Imports

// Lower Order Components

// UI Components & Icons

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * SkeletonTableRow is a functional component that renders a table row with a specified number of skeleton cells.
 * This is useful for displaying loading placeholders in a table while data is being fetched.
 *
 * @param {Object} props - The component props.
 * @param {number} props.columns - The number of columns (skeleton cells) to render in the table row. Defaults to 3.
 *
 * @returns {JSX.Element} A table row element containing the specified number of skeleton cells.
 */
export default function SkeletonTableRow({ columns = 3 }: { columns: number }) {
	const theme = useMantineTheme();
	const cells = Array.from({ length: columns }).map((_, index) => (
		<TableTd key={index}>
			<Skeleton
				height={25}
				width="100%"
				px="lg"
			/>
		</TableTd>
	));

	return <TableTr>{cells}</TableTr>;
}
