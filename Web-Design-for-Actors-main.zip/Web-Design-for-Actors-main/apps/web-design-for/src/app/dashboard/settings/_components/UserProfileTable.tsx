// React Imports
import { BaseSyntheticEvent, useEffect, useState, useTransition } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import {
	ActionIcon,
	Button,
	Card,
	Grid,
	GridCol,
	Group,
	InputDescription,
	InputLabel,
	LoadingOverlay,
	Skeleton,
	Table,
	TableTbody,
	TableTd,
	TableTh,
	TableThead,
	TableTr,
} from "@mantine/core";
import {
	IconChecks,
	IconPlugConnectedX,
	IconProgressCheck,
	IconRefreshAlert,
} from "@tabler/icons-react";
import { Form } from "@okedia/shared/form";

// Context & Helpers

// Other libraries or utilities
import { generateInitialFormValues } from "@okedia/shared/helpers/form";
import { useDatabase } from "@okedia/shared/hooks";
import { useForm } from "react-hook-form";

// Types
import { defaultNotificationProps } from "@/app/_utilities/notificationsConfig";
import { notifications } from "@mantine/notifications";
import type { UserRecord } from "firebase-admin/auth";
import {
	unlink,
	updateEmail,
	updatePassword,
	updateProfile,
	User,
} from "firebase/auth";
import { AuthContextValues } from "@okedia/shared/types/contextTypes";
import { FormValues, Input } from "@okedia/shared/types/formTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * UserProfileTable component renders a user profile management table.
 * It allows users to view and update their email, display name, profile photo, and password.
 * Additionally, it displays linked login providers and allows users to manage them.
 *
 * @param {Object} props - The component props.
 * @param {AuthContextValues} props.user - The user authentication context values.
 *
 * @returns {JSX.Element} The rendered UserProfileTable component.
 *
 * @component
 * @example
 * const user = {
 *   authForClientSide: {
 *     currentUser: {
 *       providerData: [
 *         { providerId: 'google.com', displayName: 'John Doe', email: 'john.doe@gmail.com', uid: '123' }
 *       ]
 *     }
 *   },
 *   states: {
 *     userAuthData: {
 *       claims: {
 *         user_id: '123',
 *         email: 'john.doe@gmail.com',
 *         displayName: 'John Doe',
 *         photoURL: 'http://example.com/photo.jpg',
 *         email_verified: true
 *       }
 *     }
 *   }
 * };
 * return <UserProfileTable user={user} />;
 */
export default function UserProfileTable({
	user,
}: {
	user: AuthContextValues;
}) {
	const providerData = user.authForClientSide.currentUser?.providerData;
	const thisUser = user.authForClientSide.currentUser;
	const db = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);
	const [isLoading, setIsLoading] = useState(true);
	const [isPending, startTransition] = useTransition();
	const [isProviderPending, startProviderTransition] = useTransition();

	const [initialValues, setInitialValues] = useState<any>({
		email: {
			email: [
				{
					email: user.states.userAuthData?.decodedToken?.email,
				},
			],
		},
		profile: {
			profile: [
				{
					displayName: user.states.userAuthData?.decodedToken?.name,
					photoURL: user.states.userAuthData?.decodedToken?.picture,
				},
			],
		},
		password: {
			password: [
				{
					pass1: "",
				},
			],
		},
	});

	useEffect(() => {
		const timer = setTimeout(() => {
			if (user.states.userAuthData) {
				setIsLoading(false);
			}
		}, 5000);

		return () => clearTimeout(timer);
	}, [user.states.userAuthData]);

	const formConfig: Input[] = [
		{
			inputGroup: "email",
			id: "email",
			label: "Email Address",
			helpText: "Manage Email Address & Verification",
			fieldComponents: [
				{
					component: "text",
					id: "email",
					inputWeight: 0,
					attributes: {
						label: "Email Address",
						placeholder: "my@email.com",
						width: "75%",
					},
					append: user.states.userAuthData?.decodedToken.email_verified
						? "Verified"
						: undefined,
					validators: {
						required: true,
						pattern: "email",
					},
				},
			],
		},
		{
			inputGroup: "profile",
			id: "profile",
			label: "User Profile",
			helpText: "Name and Profile Photo",
			fieldComponents: [
				{
					component: "text",
					id: "displayName",
					inputWeight: 3,
					attributes: {
						label: "Display Name",
						placeholder: "Mike McGuire",
						icon: <IconChecks size="xs" />,
						width: "50%",
					},
					validators: {
						pattern: "name",
					},
				},
				{
					component: "upload",
					id: "photoURL",
					inputWeight: 4,
					attributes: {
						label: "Profile Photo",
						width: "50%",
						forceCrop: true,
						placeholder: "Upload an Image",
					},
					validators: {
						accept: "image",
					},
				},
			],
		},
		{
			inputGroup: "password",
			id: "password",
			label: "Your Password",
			helpText: "Set a new password",
			fieldComponents: [
				{
					component: "password",
					id: "pass1",
					inputWeight: 0,
					attributes: {
						label: "New Password",
						placeholder: "Enter a new password",
					},
					validators: {
						pattern: "password",
					},
				},
			],
		},
	];

	const validateAndSubmit = async (
		data: FormValues,
		e?: BaseSyntheticEvent
	) => {
		e?.preventDefault();
		interface ExtendedUserRecord extends Partial<UserRecord> {
			password?: string;
		}

		const updatedData: ExtendedUserRecord = {
			email: data.email?.email?.[0]?.email,
			displayName: data.profile?.profile?.[0]?.displayName,
			photoURL: data.profile?.profile?.[0]?.photoURL?.downloadUrl,
			password: data.password?.password?.[0]?.pass1,
		};

		function handleSuccess() {
			notifications.update({
				...defaultNotificationProps,
				message: "All done! Your changes have been saved successfully.",
				loading: false,
				icon: <IconProgressCheck />,
				id: "saving-changes",
				color: "branding",
			});
		}

		try {
			notifications.show({
				...defaultNotificationProps,
				title: "Saving Changes",
				message: "Please wait while we save your changes.",
				id: "saving-changes",
				loading: true,
			});

			if (updatedData.email || updatedData.photoURL) {
				console.log("Updating Profile Photo or Display Name");
				await updateProfile(thisUser as User, {
					...updatedData,
				}).then(() => {
					handleSuccess();
				});
			}

			if (updatedData.password) {
				console.log("Updating Password");

				await updatePassword(thisUser as User, updatedData.password).then(
					() => {
						handleSuccess();
					}
				);
			}

			if (updatedData.email) {
				console.log("Updating Email");

				await updateEmail(thisUser as User, updatedData.email).then(() => {
					handleSuccess();
				});
			}
		} catch (error) {
			console.log("ERROR");
			//TODO: Submit error
			console.log(e);

			notifications.update({
				...defaultNotificationProps,
				message:
					"An error occurred while submitting the form. Please try again later or contact support.",
				loading: false,
				icon: <IconRefreshAlert />,
				id: "saving-changes",
				color: "red",
			});
		} finally {
			form.reset(
				generateInitialFormValues({
					formFields: formConfig,
					websiteData: data,
				})
			);
		}
	};

	const form = useForm({
		defaultValues: generateInitialFormValues({
			formFields: formConfig,
			websiteData: initialValues,
		}),
		shouldFocusError: true,
		mode: "all",
	});

	const providerRows = providerData?.map((provider) => {
		return (
			<TableTr key={provider.uid}>
				<TableTd>{provider.providerId}</TableTd>
				<TableTd>{provider.displayName}</TableTd>
				<TableTd>{provider.email}</TableTd>
				<TableTd>
					<ActionIcon
						color="red.7"
						disabled={providerData.length === 1 || isProviderPending}
						onClick={() =>
							startProviderTransition(async () => {
								await unlink(thisUser as User, provider.providerId);
							})
						}
					>
						<IconPlugConnectedX size="18" />
					</ActionIcon>
				</TableTd>
			</TableTr>
		);
	});

	return (
		<Card styles={{ root: { overflowX: "auto" } }}>
			<Skeleton visible={isLoading}>
				<LoadingOverlay visible={isPending || isLoading} />
				<form onSubmit={form.handleSubmit(validateAndSubmit)}>
					<Form
						formFields={formConfig}
						formInstance={form}
						options={{ isHorizontal: true }}
					/>

					<Grid columns={12}>
						<GridCol
							p="md"
							span={{ base: 12, lg: 3 }}
						>
							<InputLabel>Login Connections</InputLabel>
							<InputDescription>
								Manage accounts linked for fast sign in
							</InputDescription>
						</GridCol>
						<GridCol
							span={{ base: 12, lg: 9 }}
							p="md"
						>
							<Table styles={{ table: { overflowX: "auto" } }}>
								<TableThead>
									<TableTr>
										<TableTh>Provider</TableTh>
										<TableTh>Acct Name</TableTh>
										<TableTh>Acct Email</TableTh>
										<TableTh>Actions</TableTh>
									</TableTr>
								</TableThead>
								<TableTbody>{providerRows}</TableTbody>
							</Table>
						</GridCol>
					</Grid>
					<Group
						grow
						mt="md"
					>
						{form.formState.isDirty && (
							<Button
								type="reset"
								variant="light"
								size="sm"
								onClick={() => form.reset()}
							>
								Reset
							</Button>
						)}
						{form.formState.isDirty && form.formState.isValid && (
							<Button
								type="submit"
								size="sm"
								onClick={() =>
									startTransition(() => {
										form.handleSubmit(validateAndSubmit)();
									})
								}
							>
								Save Changes
							</Button>
						)}
					</Group>
				</form>{" "}
			</Skeleton>
		</Card>
	);
}
