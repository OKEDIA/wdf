// React Imports
import { BaseSyntheticEvent, useContext, useEffect } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import {
	Button,
	Card,
	Flex,
	LoadingOverlay,
	Stack,
	Text,
	Title,
	useMantineTheme,
} from "@mantine/core";

// Context & Helpers
import { UserContext } from "@/app/_context/User";

// Other libraries or utilities

// Types
import { defaultNotificationProps } from "@/app/_utilities/notificationsConfig";
import { useDisclosure, useMediaQuery } from "@mantine/hooks";
import { notifications } from "@mantine/notifications";
import { IconProgressCheck, IconRefreshAlert } from "@tabler/icons-react";
import { AuthContextValues } from "@okedia/shared/types/contextTypes";
import { FormValues } from "@okedia/shared/types/formTypes";
import { SubmitHandler, UseFormReturn } from "react-hook-form";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * A component that handles the save/cancel dialog for form changes.
 * Shows a dialog on desktop and a card on mobile devices when form changes are detected.
 *
 * @component
 * @param {Object} props - Component props
 * @param {UseFormReturn<FormValues>} props.form - React Hook Form instance
 * @param {SubmitHandler<FormValues>} props.onSubmit - Form submission handler
 * @param {Object} props.state - Loading state object
 * @param {boolean} props.state.isLoading - Current loading state
 * @param {Function} props.state.setIsLoading - Function to update loading state
 *
 * @returns A dialog/card component containing save/cancel actions and validation status
 *
 * @example
 * <SavePrompt
 *   form={form}
 *   onSubmit={handleSubmit}
 *   state={{ isLoading, setIsLoading }}
 * />
 */
export default function SavePrompt({
	form,
	onSubmit,
	state,
}: {
	form: UseFormReturn<FormValues, any, unknown>;
	onSubmit: (data: FormValues, e?: BaseSyntheticEvent) => Promise<unknown>;
	state: { isLoading: boolean; setIsLoading: any };
}) {
	const [isOpen, { open: openDialog, close: closeDialog }] =
		useDisclosure(false);
	const { isLoading, setIsLoading } = state;
	const user = useContext(UserContext) as AuthContextValues;
	const isValid = form.formState.isValid;
	const isDirty = Object.keys(form.formState.dirtyFields).length > 0;
	const theme = useMantineTheme();
	const isTouchSize = useMediaQuery(`(max-width: ${theme.breakpoints.lg})`);

	useEffect(() => {
		if (isLoading) return;

		if (!isDirty || (user.states.isFormValidating && !isValid)) {
			closeDialog();
		} else if (
			(!user.states.isFormValidating ||
				(user.states.isFormValidating && isValid)) &&
			isDirty
		) {
			openDialog();
		}
	}, [form.formState]);

	/**
	 * Handles the click event for resetting the form.
	 * Closes the dialog and resets the form to its initial values.
	 * @returns {void} Returns the result of form.reset()
	 */
	function handleResetClick() {
		closeDialog();
		return form.reset();
	}

	/**
	 * Handles errors that occur during form submission.
	 *
	 * Logs the error to the console (with a TODO to send the error to a logging service),
	 * updates the notification system with an error message, stops the loading state,
	 * and opens a dialog to inform the user.
	 *
	 * @param e - The error object containing details about the error.
	 */
	function handleError(e: Error) {
		console.log(e); // TODO: Send error to logging

		notifications.update({
			...defaultNotificationProps,
			message:
				"An error occurred while submitting the form. Please try again later or contact support.",
			loading: false,
			icon: <IconRefreshAlert />,
			id: "saving-changes",
			color: "red",
		});
		setIsLoading(false);
		openDialog();
	}

	/**
	 * Handles the click event for the submit button. This function validates the form,
	 * submits the data, and provides user feedback through notifications. It also manages
	 * loading states and error handling during the submission process.
	 *
	 * @param e - The mouse event triggered by clicking the submit button.
	 *
	 * @returns A promise that resolves when the submission process is complete.
	 *
	 * @remarks
	 * - If the form is in a validating state, it triggers validation before submission.
	 * - Notifications are used to inform the user about the progress and result of the submission.
	 * - Errors during the submission process are caught and handled appropriately.
	 *
	 * @throws Will call `handleError` if an error occurs during the submission process.
	 */
	async function handleSubmitClick(e: React.MouseEvent<HTMLButtonElement>) {
		// Asyncronously handle the submit function if the form is valid and then close the dialog
		e.preventDefault();
		setIsLoading(true);
		closeDialog();
		notifications.clean(); // Ensure the notification doesn't already exist

		try {
			notifications.show({
				...defaultNotificationProps,
				title: "Saving Changes",
				message: "Please wait while we save your changes.",
				id: "saving-changes",
				loading: true,
			});

			if (user.states.isFormValidating) {
				return await form
					.handleSubmit(onSubmit as SubmitHandler<unknown>)() // Trigger with validation
					.then(() => {
						setIsLoading(false);
						notifications.update({
							...defaultNotificationProps,
							message: "All done! Your changes have been saved successfully.",
							loading: false,
							icon: <IconProgressCheck />,
							id: "saving-changes",
							color: "branding",
						});
					});
			} else {
				return await onSubmit(form.getValues()).then(() => {
					notifications.update({
						...defaultNotificationProps,
						message: "All done! Your changes have been saved successfully.",
						loading: false,
						icon: <IconProgressCheck />,
						id: "saving-changes",
						color: "branding",
					});
					setIsLoading(false);
				});
			}
		} catch (error) {
			return handleError(error as Error);
		}
	}

	/**
	 * A wrapper component that renders its children inside a styled `Card` component.
	 * This wrapper used to allow us to render the children in a Portal 
	 *
	 * @param children - The React nodes to be rendered inside the `Card`.
	 * @returns A `Card` component containing the provided children.
	 
	 */
	function Outer({ children }: { children: React.ReactNode }) {
		return <Card mt="md">{children}</Card>;
	}

	return (
		<Outer>
			<LoadingOverlay visible={isLoading} />
			<Stack>
				<Title size="sm">Publish your website updates</Title>
				<Text size="sm">
					Your website will be updated immediately after saving these changes.
					Alternatively, click "Cancel" to reset.
				</Text>
				<Flex gap="sm">
					<Button
						variant="outline"
						onClick={handleResetClick}
						type="reset"
						fullWidth
						disabled={!form.formState.isDirty}
					>
						Cancel
					</Button>
					<Button
						type="submit"
						onClick={handleSubmitClick}
						disabled={
							!form.formState.isDirty ||
							(user.states.isFormValidating && !form.formState.isValid)
						}
						fullWidth
					>
						Save Changes
					</Button>
				</Flex>
				{form.formState.isValid === false &&
					user.states.isFormValidating === false && (
						<Text
							size="xs"
							mt="xs"
						>
							Field Validation is Disabled. These changes would not be
							publishable usually.
						</Text>
					)}
			</Stack>
		</Outer>
	);
}
