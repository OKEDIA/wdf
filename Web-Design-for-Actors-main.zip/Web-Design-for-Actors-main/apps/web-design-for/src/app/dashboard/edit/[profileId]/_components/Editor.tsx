"use client";

// React Imports
import { useContext, useEffect, useState, useTransition } from "react";

// Next.js Imports
import { useRouter, useSearchParams } from "next/navigation";

// Lower Order Components

// UI Components & Icons
import { Button, Card, Flex, Stack, Text, Title } from "@mantine/core";
import Form from "@okedia/shared/form/Form";
import EditorNav from "./EditorNav";
import SavePrompt from "./SavePrompt";

// Context & Helpers
import { WebsiteContext } from "@/app/_context/Websites";

// Other libraries or utilities
import { generateInitialFormValues } from "@okedia/shared/helpers/form";
import { SubmitHandler, useForm } from "react-hook-form";

// Types
import { modals } from "@mantine/modals";
import { WebsiteContextValues } from "@okedia/shared/types/contextTypes";
import {
	CommonFormDataProps,
	FormConfig,
	FormValues,
} from "@okedia/shared/types/formTypes";
import { Website } from "@okedia/shared/types/websiteTypes";
import { IconWand } from "@tabler/icons-react";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

interface EditorComponentProps extends FormConfig {
	website: any;
	params: any;
	commonFormDataMap: CommonFormDataProps;
}

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * The `Editor` component is responsible for rendering the main dashboard interface
 * for editing a website profile. It provides functionality for managing form steps,
 * validating form data, and guiding users through the process of creating or editing
 * their website.

 * @param {EditorComponentProps} props - The props for the `Editor` component.
 * @param {Website} props.website - The website data associated with the profile being edited.
 * @param {FormField[]} props.formFields - The form fields used to collect data for the website.
 * @param {FormStep[]} props.formSteps - The configuration for the steps in the form wizard.
 * @param {Record<string, any>} props.commonFormDataMap - A map of common form data used across steps.

 * @returns {JSX.Element} The rendered `Editor` component.

 * @remarks
 * - The component uses the `useForm` hook to manage form state and validation.
 * - It calculates the percentage of completed form fields to determine if the user
 *   can proceed to launch a preview of their website.
 * - A welcome modal is displayed for new profiles, guiding users through the next steps.
 * - The component handles routing logic to ensure users are directed to the appropriate
 *   step or page based on their progress.

 * @component
 * @example
 * ```tsx
 * <Editor
 *   website={websiteData}
 *   formFields={formFields}
 *   formSteps={formSteps}
 *   commonFormDataMap={commonFormDataMap}
 * />
 * ```
 */
export default function Editor({
	website,
	formFields,
	formSteps,
	commonFormDataMap,
}: EditorComponentProps) {
	const queryParams = useSearchParams();
	const newProfile = queryParams.get("created") === "true";
	const successfulPayment = queryParams.get("redirect_status") === "succeeded";
	const [isLoading, setIsLoading] = useState(false);
	const websites = useContext(WebsiteContext) as WebsiteContextValues;
	const router = useRouter();
	const currentStep = parseInt(queryParams?.get("step") ?? "0", 10);
	const initialFormValues = generateInitialFormValues({
		formFields: formFields,
		websiteData: website,
	});

	const form = useForm({
		defaultValues: initialFormValues,
		shouldFocusError: true,
		mode: "all",
	});

	function getCompletedValuesPercentage() {
		function countCompletedFields(values: any): {
			total: number;
			completed: number;
		} {
			let total = 0;
			let completed = 0;

			for (const value of Object.values(values)) {
				if (typeof value === "object" && value !== null) {
					const nestedCounts = countCompletedFields(value);
					total += nestedCounts.total;
					completed += nestedCounts.completed;
				} else {
					total += 1;
					if (value !== undefined && value !== null && value !== "") {
						completed += 1;
					}
				}
			}

			return { total, completed };
		}

		const { total, completed } = countCompletedFields(form.getValues());
		return total === 0 ? 0 : Math.round((completed / total) * 100);
	}

	function WelcomeModal() {
		const [modalIsPending, startModalTransition] = useTransition();
		const canCreateWebsite = getCompletedValuesPercentage() >= 60;
		return (
			<Stack
				justify="center"
				align="center"
			>
				<Title order={2}>🕺🏽 Welcome to the Website Dashboard</Title>
				<Text
					ta="center"
					size="lg"
				>
					Now that you've provided some basic information for your website, this
					page is where you can come back to edit your website in future!
				</Text>
				<Stack
					mt="md"
					p="md"
					bg="branding.1"
					styles={{ root: { borderRadius: "3px" } }}
				>
					<Flex w="100%">
						<Title
							order={3}
							fw="bold"
							c="branding.9"
						>
							Next Steps
						</Title>
					</Flex>
					{canCreateWebsite && (
						<>
							<Text fw="bold">
								If you're happy with the information that you've added so far,
								let's launch a preview version of your website.
							</Text>
							<Text>
								You'll be able to choose a design and colour scheme for your
								website and it will be accessible via a temporary preview link
								until you're ready to publish it.
							</Text>
						</>
					)}

					{!canCreateWebsite && (
						<>
							<Text
								fw="bold"
								c="gray.9"
								size="lg"
							>
								You've already added some basic information, but we need to
								collect a bit more information before we can create you a
								webtacular website from the get-go!
							</Text>
							<Text c="gray.8">
								Don't worry; our platform will still do the hard work for you -
								like making sure that your new website works across all phones,
								tablets and computers. For now, continue adding more information
								to unlcok the Launch Website button.
							</Text>
						</>
					)}
					<Flex
						justify=""
						mt="md"
						w="100%"
						columnGap="md"
					>
						<Button
							disabled={!canCreateWebsite}
							variant="outline"
							color="branding"
							loading={modalIsPending}
							leftSection={<IconWand />}
							onClick={() => {
								startModalTransition(() => {
									router.push(
										`/dashboard/edit/${website.id}/website/create?step=0`
									);
									return modals.closeAll();
								});
							}}
						>
							Launch Website
						</Button>
						<Button
							color="dark"
							variant="outline"
							onClick={() => modals.closeAll()}
						>
							Continue Editing
						</Button>
					</Flex>
				</Stack>
			</Stack>
		);
	}

	useEffect(() => {
		if (newProfile) {
			modals.open({
				id: "profile-welcome",
				onClose: () => {
					const params = new URLSearchParams(queryParams.toString());
					params.delete("created");
					router.replace(`?${params.toString()}`);
					return modals.closeAll();
				},
				children: <WelcomeModal />,
			});
		}
	}, [newProfile]);

	const validateAndSubmit = async (
		data: FormValues,
		e?: React.BaseSyntheticEvent
	): Promise<SubmitHandler<FormValues>> => {
		const websiteId = website.id;
		e?.preventDefault();
		setIsLoading(true);

		return await websites
			.updateProfile(websiteId, data)
			.then(() =>
				form.reset(
					generateInitialFormValues({
						formFields: formFields,
						websiteData: data,
					})
				)
			)
			.then((res: FormValues) => {
				return router.push(`/dashboard/edit/${websiteId}?updated=true`);
			});
	};

	useEffect(() => {
		if (!queryParams.get("step")) {
			const params = new URLSearchParams(queryParams.toString());
			params.set("step", "0");
			router.push(`?${params.toString()}`);
		}
	}, []);

	if (!formSteps) {
		throw new Error("Unable to load form configuration");
	}

	function EditWebsiteLanding({ profile }: { profile: Website<unknown> }) {
		useEffect(() => {
			if (!profile.websites?.length) {
				router.push(`/dashboard/edit/${profile.id}/website`);
			}
		}, [profile.websites, profile.id, router]);

		if (!profile.websites?.length) {
			return null; // Prevent rendering while redirecting
		}

		return (
			<>
				{profile.websites.map((website: string) => (
					<Card
						key={website}
						mt="lg"
					>
						<p>{website}</p>
					</Card>
				))}
			</>
		);
	}

	if (queryParams?.get("step") === "manage-websites") {
		if (website.websites?.length === 1) {
			router.push(
				`/dashboard/edit/${website.id}/website/${website.websites[0]}`
			);
		}
		return <EditWebsiteLanding profile={website} />;
	}
	return (
		<>
			<Title my="xl">Website Dashboard</Title>
			<Card visibleFrom="sm">
				<EditorNav
					profile={website}
					formSteps={formSteps}
					currentStep={currentStep}
					canCreateWebsite={getCompletedValuesPercentage() >= 60}
				/>
			</Card>

			{/* {getCompletedValuesPercentage() < 100 && (
				<Card mt="lg">
					<Progress.Root
						size="40"
						autoContrast
						transitionDuration={2000}
					>
						<Progress.Section
							value={getCompletedValuesPercentage()}
							animated
							striped
						>
							<Progress.Label>{`Your profile is ${getCompletedValuesPercentage()}% complete.`}</Progress.Label>
						</Progress.Section>
					</Progress.Root>
				</Card>
			)} */}

			<Card mt="lg">
				<Stack
					align="center"
					gap={0}
					style={{ textAlign: "center" }}
				>
					<Title
						mt="3rem"
						order={1}
						textWrap="balance"
					>
						{formSteps[currentStep ?? 1]?.stepTitle}
					</Title>
					<Title
						mb="2rem"
						order={4}
						textWrap="balance"
						px="md"
					>
						{formSteps[currentStep ?? 1]?.stepDescription}
					</Title>
				</Stack>

				<form onSubmit={form.handleSubmit(validateAndSubmit)}>
					<Form
						formFields={formFields}
						formInstance={form}
						stepConfig={formSteps[currentStep ?? 1]}
						options={{
							isHorizontal: true,
							isDisabled: isLoading,
							brand: website.type,
						}}
						commonFormDataMap={commonFormDataMap}
					/>
				</form>
			</Card>
			<SavePrompt
				form={form}
				onSubmit={validateAndSubmit}
				state={{ isLoading, setIsLoading }}
			/>
		</>
	);
}
