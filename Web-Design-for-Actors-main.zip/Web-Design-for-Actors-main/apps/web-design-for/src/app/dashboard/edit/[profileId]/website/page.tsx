"use client";

// React Imports
import {
	BaseSyntheticEvent,
	use,
	useContext,
	useEffect,
	useState,
} from "react";

// Next.js Imports
import { useRouter } from "next/navigation";

// Lower Order Components
import WebsiteCard from "@/app/dashboard/(admin)/websites/_components/WebsiteCard";
import WebsiteBuilderWizard from "@/app/dashboard/_components/WebsiteBuilderWizard";

// UI Components & Icons
import { LoadingOverlay, Paper } from "@mantine/core";

// Context & Helpers
import { WebsiteContext } from "@/app/_context/Websites";
import { WebsiteContextValues } from "@okedia/shared/types/contextTypes";

// Other libraries or utilities
import { useDatabase } from "@okedia/shared/hooks";

// Types
import { ObjectId } from "bson";
import { FormValues, Input, Step } from "@okedia/shared/types/formTypes";
import { MongoDocumentResponse } from "@okedia/shared/types/mongoTypes";
import {
	Website,
	WebsiteFormConfiguration,
} from "@okedia/shared/types/websiteTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Page(props: {
	params: Promise<{ profileId: string }>;
}) {
	const params = use(props.params);
	const websites = useContext(WebsiteContext) as WebsiteContextValues;
	const db = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);
	const profileId = params.profileId;
	const profile = websites.states.profiles.find(
		(profile) => profile.id === profileId
	);
	const websitesFromProfile = profile?.websites as MongoDocumentResponse<
		Website<unknown>
	>[];
	const router = useRouter();

	const [formFields, setFormFields] = useState<
		WebsiteFormConfiguration | undefined
	>(undefined);

	useEffect(() => {
		db.get<WebsiteFormConfiguration>("/forms/website", {
			cache: "no-store",
		}).then((res) => {
			setFormFields(res);
		});
	}, []);

	const validateAndSubmit = async (
		data: FormValues,
		e?: BaseSyntheticEvent
	) => {
		e?.preventDefault();
		websites.setters.setIsLoading(true);

		const dataToAdd = { ...data };

		await websites
			.createWebsite(dataToAdd, profileId)
			.then((res: FormValues) => {
				return router.replace(
					`/dashboard/edit/${profileId}/website/${res.id}?created=true`
				);
			})
			.finally(() => websites.setters.setIsLoading(false));
	};

	if (profile?.websites && profile.websites?.length === 1) {
		const id =
			typeof profile.websites[0].id === "string"
				? profile.websites[0].id
				: new ObjectId(profile.websites[0].id).toString();

		return router.replace(`/dashboard/edit/${profileId}/website/${id}`);
	} else if (websitesFromProfile?.length > 1) {
		return websitesFromProfile?.map(
			(website: Website<unknown>, index: number) => {
				if (!website) return;

				return (
					<WebsiteCard
						website={website}
						key={index}
					/>
				);
			}
		);
	}

	if (!formFields?.builderSteps) {
		return (
			<Paper
				p="xl"
				mih="75dvh"
			>
				<LoadingOverlay visible />
			</Paper>
		);
	}

	return (
		<Paper p="xl">
			<WebsiteBuilderWizard
				formFields={formFields?.inputs as Input[]}
				formSteps={formFields?.builderSteps as Step[]}
				options={{ brand: profile?.type, shouldValidate: false }}
				onSubmit={validateAndSubmit}
			/>
		</Paper>
	);
}
