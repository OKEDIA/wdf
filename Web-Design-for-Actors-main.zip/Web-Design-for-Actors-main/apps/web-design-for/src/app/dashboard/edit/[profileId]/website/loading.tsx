import {
	Card,
	Fieldset,
	Flex,
	GridCol,
	Group,
	Skeleton,
	Stack,
	Title,
} from "@mantine/core";

/**
 * A React functional component that renders a loading skeleton for a dashboard.
 * It displays three skeleton cards in a grid layout.
 *
 * @component
 * @example
 * return (
 *   <Loading />
 * )
 */
export default function Loading() {
	function SkeletonDesign() {
		return (
			<Fieldset
				mt="xl"
				variant="filled"
				mb="md"
				radius="sm"
				styles={{
					root: {
						columnGap: "sm",
						flexWrap: "wrap",
						display: "flex",
						minWidth: "100%",
					},
					legend: {
						marginLeft: "-15px",
					},
				}}
				display={{
					base: "block",
					lg: "flex",
				}}
			>
				<GridCol
					style={{ alignContent: "center" }}
					span={{ base: 24, lg: 6 }}
					py="sm"
				>
					<Skeleton
						h="md"
						w="200px"
					/>
					<Skeleton
						h="sm"
						w="150px"
						mt="sm"
					/>
				</GridCol>
				<GridCol
					span={{ base: 24, lg: 14 }}
					py="sm"
				>
					<Flex
						rowGap="lg"
						columnGap="lg"
						wrap="wrap"
						align="stretch"
					>
						<div
							style={{
								display: "flex",
								alignItems: "stretch",
								flexDirection: "column",
								width: "100%",
							}}
						>
							<Flex
								w="100%"
								columnGap="sm"
							>
								{" "}
								<Stack
									gap={0}
									w="100%"
								>
									<Skeleton
										h="md"
										w="200px"
									/>
									<Skeleton
										mt="xs"
										h="40px"
										w="100%"
									/>
								</Stack>
								<Stack
									gap={0}
									w="100%"
								>
									<Skeleton
										h="md"
										w="200px"
									/>
									<Skeleton
										mt="xs"
										h="40px"
										w="100%"
									/>
								</Stack>
							</Flex>
						</div>
						<div
							style={{
								display: "flex",
								alignItems: "stretch",
								flexDirection: "column",
								width: "100%",
							}}
						>
							<Skeleton
								h="md"
								w="300px"
							/>
							<Skeleton
								mt="xs"
								h="400px"
								w="100%"
							/>
						</div>
					</Flex>
				</GridCol>
				<GridCol
					span={{ base: 12, lg: 1 }}
					style={{
						display: "flex",
						alignItems: "center",
						justifyContent: "flex-end",
					}}
				>
					<Flex
						pt="lg"
						w="100%"
					>
						<Skeleton
							h="40px"
							w="50%"
						/>
						<Skeleton
							h="40px"
							w="50%"
							ml="xs"
						/>
					</Flex>
				</GridCol>
			</Fieldset>
		);
	}

	return (
		<>
			<Title my="xl">Website Dashboard</Title>
			<GridCol span={{ base: 24, sm: 24, xl: 8, lg: 12, md: 12 }}>
				<Card
					p="lg"
					h="100%"
					styles={{ root: { justifyContent: "space-between" } }}
				>
					<Group
						gap="xs"
						justify="center"
						my="lg"
					>
						<Skeleton
							h="xl"
							w="500px"
						/>
					</Group>
					<Flex
						gap="sm"
						align="center"
						justify="center"
						my="lg"
					>
						<Group gap="sm">
							<Skeleton
								w="150px"
								h="lg"
							/>
							<Skeleton
								w="150px"
								h="lg"
							/>
							<Skeleton
								w="150px"
								h="lg"
							/>
							<Skeleton
								w="150px"
								h="lg"
							/>
						</Group>
					</Flex>
					<Group
						my="lg"
						align="center"
						justify="center"
					>
						<Skeleton
							w="30%"
							h="40px"
						/>

						<Skeleton
							w="30%"
							h="40px"
						/>
					</Group>
				</Card>
			</GridCol>

			<Card
				mt="lg"
				pt="75px"
			>
				<Stack
					align="center"
					gap={0}
					style={{ textAlign: "center" }}
				>
					<Skeleton
						h="xl"
						w="300px"
					/>
					<Skeleton
						h="lg"
						w="200px"
						mt="md"
					/>
				</Stack>
				<Skeleton
					mt="xl"
					h="50dvh"
					w="100%"
				/>
			</Card>
		</>
	);
}
