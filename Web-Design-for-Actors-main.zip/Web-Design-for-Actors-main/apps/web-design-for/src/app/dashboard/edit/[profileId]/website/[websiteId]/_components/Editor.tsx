"use client";

// React Imports
import {
	BaseSyntheticEvent,
	Fragment,
	useContext,
	useEffect,
	useState,
	useTransition,
} from "react";

// Next.js Imports
import { useRouter, useSearchParams } from "next/navigation";

// Lower Order Components
import WebsiteCard from "@/app/dashboard/(admin)/websites/_components/WebsiteCard";
import { Form } from "@okedia/shared/form";
import DomainSearch from "../../../_components/DomainSearch";
import SavePrompt from "../../../_components/SavePrompt";
import UpgradeCTA from "../../../_components/UpgradeCTA";

// UI Components & Icons
import {
	Button,
	Card,
	Flex,
	GridCol,
	Portal,
	Stack,
	Text,
	Title,
} from "@mantine/core";
import { IconComet, IconLink } from "@tabler/icons-react";

// Context & Helpers
import { UserContext } from "@/app/_context/User";
import { WebsiteContext } from "@/app/_context/Websites";

// Other libraries or utilities
import { generateInitialFormValues } from "@okedia/shared/helpers/form";
import { useForm } from "react-hook-form";

// Types
import { useViewportSize } from "@mantine/hooks";
import { modals } from "@mantine/modals";
import {
	AuthContextValues,
	WebsiteContextValues,
} from "@okedia/shared/types/contextTypes";
import { FormValues, Input } from "@okedia/shared/types/formTypes";
import { Website } from "@okedia/shared/types/websiteTypes";
import Confetti from "react-confetti";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default function Editor({
	formFields,
	params,
}: {
	formFields: Input[];
	params: { websiteId: string };
}) {
	const router = useRouter();
	const user = useContext(UserContext) as AuthContextValues;
	const queryParams = useSearchParams();
	const { height, width } = useViewportSize();
	const newWebsite = queryParams.get("created") === "true";
	const [isLoading, setIsLoading] = useState(false);
	const websites = useContext(WebsiteContext) as WebsiteContextValues;
	const website: Website<unknown> | undefined = websites.states.websites.find(
		(website) => website.id === params.websiteId
	);

	if (!website) {
		throw new Error("Unable to retrieve website data.");
	}

	const initialFormValues = generateInitialFormValues({
		formFields: formFields,
		websiteData: website,
	});

	const form = useForm({
		defaultValues: initialFormValues,
		shouldFocusError: true,
		mode: "all",
	});

	const validateAndSubmit = async (
		data: FormValues,
		e?: BaseSyntheticEvent
	): Promise<void> => {
		const websiteId = website.id;
		const profileId = website.profileId;
		e?.preventDefault();
		setIsLoading(true);

		await websites
			.update(websiteId, data)
			.then(() =>
				form.reset(
					generateInitialFormValues({
						formFields: formFields,
						websiteData: data,
					})
				)
			)
			.then((res: FormValues) => {
				return router.push(
					`/dashboard/edit/${profileId}/website/${websiteId}?updated=true`
				);
			});
	};

	function WelcomeModal() {
		const [modalIsPending, startModalTransition] = useTransition();

		return (
			<Stack
				justify="center"
				align="center"
			>
				<Title order={2}>🥳 Your website is ready to preview</Title>
				<Text
					ta="center"
					size="lg"
				>
					You've done it! You can now preview your website using the temporary
					preview link below. Once you're happy with the design and content, you
					can publish your website from this page.
				</Text>
				<Stack
					mt="md"
					p="md"
					bg="branding.1"
					styles={{ root: { borderRadius: "3px" } }}
				>
					<Flex w="100%">
						<Title
							order={3}
							fw="bold"
							c="branding.9"
						>
							Next Steps
						</Title>
					</Flex>
					<Text fw="bold">
						Take a look at your website via the preview link. You can make
						changes to the design, colour scheme or the content that you added
						earlier at any time before (and after) publishing your website.
					</Text>
					<Text>
						Also check out the website settings on this page - this is where you
						can edit your fonts, colours and important Search Engine
						Optimisation such as your website title, description and keywords!
					</Text>
					<Flex
						justify=""
						mt="md"
						w="100%"
						columnGap="md"
					>
						<Button
							variant="outline"
							color="branding"
							loading={modalIsPending}
							leftSection={<IconLink />}
							onClick={async () => {
								const windowReference = window.open();

								if (!windowReference) {
									return;
								}
								windowReference.location = `https://${website?.domain}/?noCache=true`;

								// Intentionally don't close this modal on this action as it will disappear without the user seeing it leave, which leaves a surprise/disappointment when returning back to the editor
								return;
							}}
						>
							Preview Website
						</Button>
						<Button
							color="dark"
							variant="outline"
							onClick={() => modals.closeAll()}
						>
							Continue Editing
						</Button>
					</Flex>
				</Stack>
			</Stack>
		);
	}

	useEffect(() => {
		if (newWebsite) {
			modals.open({
				id: "website-welcome",
				onClose: () => {
					const params = new URLSearchParams(queryParams.toString());
					params.delete("created");
					router.replace(`?${params.toString()}`);
					return modals.closeAll();
				},
				children: <WelcomeModal />,
			});
		}
	}, [newWebsite]);

	return (
		<Fragment>
			{newWebsite && (
				<Portal>
					<Confetti
						width={width}
						height={height}
						numberOfPieces={500}
						confettiSource={{
							w: 0,
							h: 0,
							x: width / 2,
							y: height,
						}}
						initialVelocityY={20}
						initialVelocityX={8}
						recycle={false}
						friction={1}
						style={{ zIndex: 999 }}
					/>
				</Portal>
			)}
			<Title my="xl">Website Settings</Title>

			<WebsiteCard
				website={website}
				options={{ withPreview: false }}
			/>
			<GridCol
				span={{ base: 24, sm: 24, xl: 8, lg: 12, md: 12 }}
				key={website.id}
			>
				{website.package?.toLowerCase().endsWith("demo") && (
					<Card mt="lg">
						<UpgradeCTA
							config={{
								primaryHeading: "Remove usage limits by publising your website",
								secondaryHeading: "Click here to get started.",
								tertiaryHeading: "Choose your website name to get started.",
								Icon: IconComet,
							}}
						>
							<DomainSearch website={website} />
						</UpgradeCTA>
					</Card>
				)}
				<Card mt="lg">
					<form onSubmit={form.handleSubmit(validateAndSubmit)}>
						<Form
							formFields={formFields}
							formInstance={form}
							options={{
								isHorizontal: true,
								isDisabled: isLoading,
								brand: website.type,
							}}
						/>
						{form.formState.isDirty &&
							(form.formState.isValid || !user.states.isFormValidating) && (
								<SavePrompt
									form={form}
									onSubmit={validateAndSubmit}
									state={{ isLoading, setIsLoading }}
								/>
							)}
					</form>
				</Card>
			</GridCol>
		</Fragment>
	);
}
