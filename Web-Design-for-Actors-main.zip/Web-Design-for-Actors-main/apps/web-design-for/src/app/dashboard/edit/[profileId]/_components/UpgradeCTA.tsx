// React Imports
import {
	ForwardRefExoticComponent,
	ReactNode,
	RefAttributes,
	useState,
} from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import {
	Accordion,
	AccordionControl,
	AccordionItem,
	AccordionPanel,
	Box,
	Group,
	Stack,
	Text,
} from "@mantine/core";
import { Icon, IconProps } from "@tabler/icons-react";

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
/**
 * A component that displays an accordion-style call-to-action for upgrades
 *
 * @component
 * @param {Object} props - The component props
 * @param {ReactNode} props.children - The content to be displayed when the accordion is expanded
 * @param {Object} props.config - Configuration object for the CTA
 * @param {string} props.config.primaryHeading - The main heading text
 * @param {string} props.config.secondaryHeading - The secondary heading text (displayed when collapsed)
 * @param {string} props.config.tertiaryHeading - The tertiary heading text (displayed when expanded)
 * @param {ForwardRefExoticComponent<IconProps & RefAttributes<Icon>>} props.config.Icon - The icon component to be displayed
 *
 * @returns {JSX.Element} A collapsible accordion component with configurable headings and an icon
 */
export default function UpgradeCTA({
	children,
	config,
}: {
	children: ReactNode;
	config: {
		primaryHeading: string;
		secondaryHeading: string;
		tertiaryHeading: string;
		Icon: ForwardRefExoticComponent<IconProps & RefAttributes<Icon>>;
	};
}) {
	const [isOpen, setIsOpen] = useState<string | null>(null);

	const calculatedSecondHeading =
		config.tertiaryHeading && isOpen
			? config.tertiaryHeading
			: config.secondaryHeading;

	return (
		<Accordion
			value={isOpen}
			onChange={(value) => setIsOpen(value)}
		>
			<AccordionItem
				value="0"
				bd="none"
			>
				<AccordionControl>
					<Group wrap="nowrap">
						<Box visibleFrom="md">
							<config.Icon />
						</Box>
						<Stack gap="0">
							<Text>{config.primaryHeading}</Text>
							<Text
								size="sm"
								c="dimmed"
								fw={400}
							>
								{calculatedSecondHeading}
							</Text>
						</Stack>
					</Group>
				</AccordionControl>
				<AccordionPanel p="lg">{isOpen && children}</AccordionPanel>
			</AccordionItem>
		</Accordion>
	);
}
