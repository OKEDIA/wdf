// React Imports
import { ReactNode, useReducer } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons

import {
	ActionIcon,
	Badge,
	Button,
	Flex,
	Grid,
	GridCol,
	Group,
	Image,
	Loader,
	rem,
	Skeleton,
	Spoiler,
	Stack,
	Text,
	TextInput,
	Title,
} from "@mantine/core";

import {
	IconAlertTriangle,
	IconChecks,
	IconCircleCheck,
	IconCircleDashedCheck,
	IconTag,
	IconX,
} from "@tabler/icons-react";

// Context & Helpers

// Other libraries or utilities
import usePopup from "@/app/_hooks/usePopup";
import useStripePayment from "@/app/dashboard/_components/_stripe/Payment";
import { useDatabase } from "@okedia/shared/hooks";

// Types
import { Coupon, PromotionCode, StripeResponse } from "@okedia/shared/stripe";
import { WhoisResponse } from "@okedia/shared/types/documentResponses";
import { Website } from "@okedia/shared/types/websiteTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

type DomainSearchProps = {
	showDiscountField: boolean;
	isLoading: boolean;
	couponIsLoading: boolean;
	domainIsAvailable: boolean;
	searchQuery: string;
	searchFieldError?: string;
	couponQuery: string;
	couponFieldError?: string;
	domain: string;
	couponIsValid: boolean;
	promotionCodeData: PromotionCode | undefined;
	tld: string;
	results: any[]; // Adjust the type of results if they are more specific
};

// Define possible action types with payloads where applicable
type DomainSearchActions =
	| { type: "TOGGLE_DISCOUNT_FIELD" }
	| { type: "SET_LOADING"; payload: boolean }
	| { type: "TOGGLE_COUPON_LOADING" }
	| { type: "TOGGLE_DOMAIN_AVAILABLE" }
	| { type: "SET_SEARCH_QUERY"; payload: string }
	| { type: "SET_SEARCH_ERROR"; payload: string | undefined }
	| { type: "SET_COUPON_QUERY"; payload: string }
	| { type: "SET_COUPON_ERROR"; payload: string | undefined }
	| { type: "SET_DOMAIN_NAME"; payload: string }
	| { type: "SET_COUPON_VALID"; payload: boolean }
	| { type: "SET_COUPON_DATA"; payload: PromotionCode | undefined }
	| { type: "SET_DOMAIN_TLD"; payload: string }
	| { type: "ADD_RESULT"; payload: any }
	| { type: "CLEAR_RESULTS" }
	| { type: "RESET_STATE" };

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// Define the initial state type
const initialSearchState: DomainSearchProps = {
	showDiscountField: false,
	isLoading: false,
	couponIsLoading: false,
	domainIsAvailable: false,
	searchQuery: "",
	searchFieldError: undefined,
	couponQuery: "",
	couponFieldError: undefined,
	promotionCodeData: undefined,
	domain: "",
	couponIsValid: false,
	tld: "",
	results: [],
};

/**
 * Reducer function to manage domain search state and actions
 * @param state - Current state of domain search interface
 * @param action - Action object containing type and optional payload
 * @returns New state object after applying the action
 *
 * Actions:
 * - TOGGLE_DISCOUNT_FIELD: Toggles visibility of discount/coupon field
 * - SET_LOADING: Sets loading state for domain search
 * - TOGGLE_COUPON_LOADING: Toggles loading state for coupon validation
 * - TOGGLE_DOMAIN_AVAILABLE: Toggles domain availability status
 * - SET_SEARCH_QUERY: Updates domain search query
 * - SET_SEARCH_ERROR: Sets error message for search field
 * - SET_COUPON_QUERY: Updates coupon code input
 * - SET_COUPON_ERROR: Sets error message for coupon field
 * - SET_DOMAIN_NAME: Sets selected domain name
 * - SET_COUPON_VALID: Updates coupon validity status
 * - SET_COUPON_DATA: Updates promotion code data
 * - SET_DOMAIN_TLD: Sets top-level domain
 * - ADD_RESULT: Adds new result to search results array
 * - CLEAR_RESULTS: Clears all search results
 * - RESET_STATE: Resets state to initial values
 */
function reducer(state: DomainSearchProps, action: DomainSearchActions) {
	switch (action.type) {
		case "TOGGLE_DISCOUNT_FIELD":
			return { ...state, showDiscountField: !state.showDiscountField };
		case "SET_LOADING":
			return { ...state, isLoading: action.payload };
		case "TOGGLE_COUPON_LOADING":
			return { ...state, couponIsLoading: !state.couponIsLoading };
		case "TOGGLE_DOMAIN_AVAILABLE":
			return { ...state, domainIsAvailable: !state.domainIsAvailable };
		case "SET_SEARCH_QUERY":
			return { ...state, searchQuery: action.payload };
		case "SET_SEARCH_ERROR":
			return { ...state, searchFieldError: action.payload };
		case "SET_COUPON_QUERY":
			return { ...state, couponQuery: action.payload };
		case "SET_COUPON_ERROR":
			return { ...state, couponFieldError: action.payload };
		case "SET_DOMAIN_NAME":
			return { ...state, domain: action.payload };
		case "SET_COUPON_VALID":
			return { ...state, couponIsValid: action.payload };
		case "SET_COUPON_DATA":
			return { ...state, promotionCodeData: action.payload };
		case "SET_DOMAIN_TLD":
			return { ...state, tld: action.payload };
		case "ADD_RESULT":
			return {
				...state,
				results: [...state.results, action.payload],
			};
		case "CLEAR_RESULTS":
			return { ...state, results: [] };
		case "RESET_STATE":
			return { ...initialSearchState };
		default:
			return state;
	}
}

/**
 * A component that provides domain search functionality with optional discount code application.
 *
 * Features:
 * - Domain availability checking
 * - Alternative domain suggestions
 * - Discount code validation
 * - Stripe payment integration
 * - Real-time WHOIS lookup
 *
 * @component
 * @param {Object} props - Component props
 * @param {Website} props.website - Website object containing details like productId, template, etc.
 *
 * @example
 * ```tsx
 * <DomainSearch website={websiteData} />
 * ```
 *
 * The component handles:
 * - Domain validation and availability checking
 * - Coupon code validation and application
 * - Alternative domain suggestions when requested domain is unavailable
 * - Integration with Stripe payment processing
 * - Display of pricing information including discounts
 *
 * @returns A form containing domain search interface with optional discount code field
 */
export default function DomainSearch({
	website,
}: {
	website: Website<unknown>;
}) {
	const [state, dispatch] = useReducer(reducer, initialSearchState);
	const db = useDatabase(process.env.NEXT_PUBLIC_API_BASE_URL as string);
	const popup = usePopup();

	console.log(website);

	const stripeElement = useStripePayment({
		product: {
			productId: website.productId,
			package: "basic",
			metadata: {
				websiteId: website.id,
				domain: `${state.domain}${state.tld}`,
				type: website.type,
			},
		},
		website: website,
		Body: () => <PurchasePopup />,
		promotionCode: state?.promotionCodeData,
		onComplete: popup.handleSubmit,
	});

	/**
	 * Handles the domain order process by collecting Stripe payment data and managing UI state.
	 * This function triggers the Stripe payment collection flow and opens a payment completion modal.
	 *
	 * @remarks
	 * This function performs the following operations:
	 * 1. Sets the loading state to true
	 * 2. Collects Stripe payment data
	 * 3. Opens a payment completion modal
	 * 4. Sets the loading state back to false when finished
	 *
	 * @throws {Error} May throw an error if Stripe data collection fails
	 */
	function handleDomainOrder() {
		dispatch({ type: "SET_LOADING", payload: true });

		stripeElement
			.collectStripeData()
			.then(() => {
				popup.setModalConfig({
					...popup.modalConfig,
					title: "Complete Payment",
					opened: true,
				});
			})
			.finally(() => dispatch({ type: "SET_LOADING", payload: false }));
	}

	/**
	 * A component that renders a gradient-styled badge using Mantine UI.
	 * The gradient flows from branding.4 to branding.7 colors at 150 degrees.
	 *
	 * @component
	 * @param {Object} props - Component props
	 * @param {ReactNode} props.children - The content to be displayed inside the badge
	 * @returns {JSX.Element} A badge component with gradient styling
	 */
	function GradientBadge({ children }: { children: ReactNode }) {
		return (
			<Badge
				size="sm"
				variant="gradient"
				gradient={{ from: "branding.4", to: "branding.7", deg: 150 }}
			>
				{children}
			</Badge>
		);
	}

	/**
	 * Renders a purchase popup component that displays website subscription details.
	 *
	 * The component shows:
	 * - Website preview image
	 * - Package type badge
	 * - Domain name badge
	 * - Stripe mode indicators (dev/prod)
	 * - Subscription pricing details with different formats based on coupon type:
	 *   - No coupon: Simple price display
	 *   - One-time coupon: Shows first payment and subsequent pricing
	 *   - Recurring coupon: Shows discounted price duration and next payment date
	 *   - Forever discount: Shows discounted price with original price badge
	 * - Package description in a spoiler
	 *
	 * @returns {JSX.Element} A styled purchase confirmation popup
	 *
	 * @requires stripeElement - Context/prop containing stripe payment and subscription details
	 * @requires website - Context/prop containing website template and configuration
	 * @requires state - Context/prop containing current search state
	 */
	function PurchasePopup() {
		function renderPricing() {
			if (!stripeElement.coupon) {
				return `£${stripeElement.amount / 100} per ${
					stripeElement.subscription?.plan?.interval
				}`;
			}

			const basePrice = stripeElement.packageData?.unit_amount ?? 0;
			const discountedPrice = stripeElement.amount;

			if (stripeElement.coupon.duration === "once") {
				return (
					<Group>
						<Title order={4}> First payment: £{discountedPrice / 100}</Title>
						<Title order={6}>
							Then £{basePrice / 100} per{" "}
							{stripeElement.subscription?.plan?.interval}
						</Title>
					</Group>
				);
			} else if (stripeElement.coupon.duration === "repeating") {
				const nextDue = stripeElement.subscription?.current_period_end;
				return (
					<Stack>
						<Group>
							<Title order={4}>
								£{discountedPrice / 100} for{" "}
								{stripeElement.coupon.duration_in_months} months
							</Title>
							<Title
								order={6}
								mb={0}
							>
								Then £{basePrice / 100} per{" "}
								{stripeElement.subscription?.plan?.interval}
							</Title>
						</Group>
						{nextDue && (
							<Text
								pt={0}
								c="primary"
								tt="uppercase"
								size="xs"
								fw={700}
							>
								Next Due {new Date(nextDue * 1000).toLocaleDateString()}
							</Text>
						)}
					</Stack>
				);
			} else {
				// Forever discount
				return (
					<Group
						gap="sm"
						align="center"
					>
						<Title order={4}>
							£{discountedPrice / 100} per{" "}
							{stripeElement.subscription?.plan?.interval}
						</Title>
						<GradientBadge>Was £{basePrice / 100}</GradientBadge>
					</Group>
				);
			}
		}

		return (
			<Skeleton visible={stripeElement.state.isLoading}>
				<Flex
					gap="md"
					align="center"
				>
					<Image
						src={`/website-images/${website.data.type}/default/${website.template.colorScheme[0].value}.png`}
						alt={`Preview of ${website.template.colorScheme[0].value}`}
						width={200}
						height={200}
						p="lg"
					/>
					<Stack gap={0}>
						<Group my="sm">
							<Badge>{stripeElement.packageData?.nickname} Package</Badge>
							<Badge>{state.searchQuery}</Badge>
							{stripeElement.isTestMode && (
								<Badge
									color="blue.5"
									leftSection={<IconCircleCheck size="15" />}
								>
									STRIPE DEV MODE
								</Badge>
							)}

							{stripeElement.isDevUser && !stripeElement.isTestMode && (
								<Badge
									color="red.7"
									leftSection={<IconAlertTriangle size="15" />}
								>
									PRODUCTION MODE
								</Badge>
							)}
						</Group>
						<Title order={2}>Your website subscription</Title>
						<Title order={4}>{renderPricing()}</Title>
						<Spoiler
							hideLabel="[...]"
							showLabel="[...]"
							maxHeight={100}
						>
							<Text mt="sm">
								{stripeElement.packageData?.metadata.description}
							</Text>
						</Spoiler>
					</Stack>
				</Flex>
			</Skeleton>
		);
	}

	const toggleDiscountField = () => {
		dispatch({ type: "TOGGLE_DISCOUNT_FIELD" });
	};

	const updateSearchQuery = (query: string) => {
		dispatch({ type: "SET_SEARCH_QUERY", payload: query });

		const parts = query.split("."); // split at the first "."
		const domain = parts[0]; // return the first part of the domain
		const tld = parts.slice(1).length > 0 ? "." + parts.slice(1).join(".") : ""; // return TLD or "" if none entered

		dispatch({ type: "SET_DOMAIN_NAME", payload: domain });
		dispatch({
			type: "SET_DOMAIN_TLD",
			payload: tld,
		});
	};

	const updateCouponQuery = (query: string) => {
		dispatch({ type: "SET_COUPON_QUERY", payload: query });
	};

	/**
	 * Handles the domain search process and validates domain availability.
	 *
	 * This function performs the following operations:
	 * 1. Validates and processes any coupon code if present
	 * 2. Validates domain name format
	 * 3. Checks domain availability using WHOIS
	 * 4. Fetches alternative domains if the requested domain is unavailable
	 *
	 * @throws {Error} May throw an error during WHOIS lookup or coupon validation
	 *
	 * @fires {SET_LOADING} Sets loading state during async operations
	 * @fires {SET_COUPON_ERROR} When coupon code is invalid
	 * @fires {SET_COUPON_VALID} When coupon code is valid
	 * @fires {SET_COUPON_DATA} Sets coupon data when valid
	 * @fires {SET_SEARCH_ERROR} When domain format is invalid
	 * @fires {CLEAR_RESULTS} Clears previous search results
	 * @fires {TOGGLE_DOMAIN_AVAILABLE} When domain is available
	 *
	 * @returns {Promise<void>}
	 */
	async function handleDomainSearch() {
		const query = `${state.domain}${state.tld}`;
		dispatch({ type: "SET_LOADING", payload: true });

		if (state.couponQuery) {
			await getCouponInfo(state.couponQuery).then((res) => {
				if (res.data.length < 1) {
					return dispatch({
						type: "SET_COUPON_ERROR",
						payload: "Invalid Code",
					});
				} else {
					dispatch({ type: "SET_COUPON_VALID", payload: true });
					dispatch({ type: "SET_COUPON_DATA", payload: res.data[0] });
				}
			});
		}

		if (
			query === "" ||
			!/^(?!www\.)(?!.*:\/\/)[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(query)
		) {
			dispatch({
				type: "SET_SEARCH_ERROR",
				payload: "Invalid Domain Name",
			});
			return;
		}

		dispatch({ type: "CLEAR_RESULTS" });
		dispatch({
			type: "SET_SEARCH_ERROR",
			payload: undefined,
		});

		await getWhoisInfo(query)
			.then((res: WhoisResponse) => {
				if (!res?.available) {
					getAltAvailableDomains(state.domain);
				} else if (res?.available) {
					dispatch({ type: "TOGGLE_DOMAIN_AVAILABLE" });
				}
			})
			.finally(() => dispatch({ type: "SET_LOADING", payload: false }));
	}

	async function getWhoisInfo(domainName: string): Promise<WhoisResponse> {
		return await db.get<WhoisResponse>(`/domains/whois/${domainName}`);
	}

	/**
	 * Fetches information about a coupon code from the billing API
	 * @param couponCode - The promotional code to validate
	 * @returns Promise containing the Stripe response with promotion code details
	 * @throws May throw an error if the API request fails
	 */
	async function getCouponInfo(
		couponCode: string
	): Promise<StripeResponse<PromotionCode>> {
		dispatch({
			type: "SET_COUPON_ERROR",
			payload: undefined,
		});
		dispatch({ type: "TOGGLE_COUPON_LOADING" });
		return await db
			.get<StripeResponse<PromotionCode>>(`/billing/coupons/${couponCode}`)
			.finally(() => dispatch({ type: "TOGGLE_COUPON_LOADING" }));
	}

	/**
	 * Searches for available domain names across multiple top-level domains (TLDs).
	 * Uses environment variable NEXT_PUBLIC_AVAILABLE_TLDS for allowed TLD list.
	 * Dispatches loading state and results to a reducer.
	 *
	 * @param domain - The base domain name to check without TLD (e.g., "example")
	 *
	 * @remarks
	 * - Splits NEXT_PUBLIC_AVAILABLE_TLDS env var by comma to get TLD array
	 * - Checks domain availability for each TLD using whois
	 * - Dispatches "SET_LOADING" action during checks
	 * - Dispatches "ADD_RESULT" action for available domains
	 */
	async function getAltAvailableDomains(domain: string) {
		dispatch({ type: "SET_LOADING", payload: true });

		const allowedTLDs: string[] = process.env.NEXT_PUBLIC_AVAILABLE_TLDS
			? process.env.NEXT_PUBLIC_AVAILABLE_TLDS.split(",")
			: [];

		const promises = allowedTLDs.map((tld) =>
			getWhoisInfo(`${domain}${tld}`).then((res) => {
				if (res?.available) {
					dispatch({
						type: "ADD_RESULT",
						payload: tld,
					});
				}
			})
		);

		Promise.all(promises).finally(() => {
			dispatch({ type: "SET_LOADING", payload: false });
			if (state.results.length < 1) {
				dispatch({
					type: "SET_SEARCH_ERROR",
					payload: "This domain name is not available for purchase.",
				});
			}
		});
	}

	/**
	 * Renders a discount button component that toggles the visibility of a discount field.
	 * The button appearance and behavior changes based on the coupon validation state.
	 *
	 * @returns {JSX.Element} A button component with different states:
	 * - When coupon is valid: Disabled button with tag icon
	 * - When coupon is invalid: Toggleable button that changes color when discount field is shown
	 *
	 * @depends {state.couponIsValid} - Boolean indicating if a coupon is currently valid
	 * @depends {state.isLoading} - Boolean indicating if the component is in a loading state
	 * @depends {state.showDiscountField} - Boolean controlling the visibility of the discount field
	 * @depends {toggleDiscountField} - Function to toggle the discount field visibility
	 */
	function DiscountButton() {
		if (state.couponIsValid) {
			return (
				<ActionIcon
					onClick={() => {
						toggleDiscountField();
					}}
					disabled={state.isLoading || state.couponIsValid}
				>
					<IconTag style={{ width: rem(20), height: rem(20) }} />
				</ActionIcon>
			);
		}
		return (
			<ActionIcon
				onClick={() => {
					toggleDiscountField();
				}}
				disabled={state.isLoading}
				color={state.showDiscountField ? "branding" : "gray"}
				variant="outline"
			>
				<IconTag style={{ width: rem(20), height: rem(20) }} />
			</ActionIcon>
		);
	}

	function DomainAvailableCheck() {
		return <IconChecks color="green" />;
	}

	if (state.results.length && !state.domainIsAvailable) {
		return (
			<Stack align="center">
				<Title
					order={4}
					fw="bold"
				>
					{state.searchQuery} is not available. How about:
				</Title>
				<Group justify="center">
					{state.results.map((tld) => {
						return (
							<Button
								key={`btn_${tld}`}
								onClick={() => {
									dispatch({ type: "TOGGLE_DOMAIN_AVAILABLE" });
									dispatch({ type: "CLEAR_RESULTS" });

									dispatch({
										type: "SET_SEARCH_QUERY",
										payload: `${state.domain}${tld}`,
									});
								}}
								leftSection={<IconCircleDashedCheck size="17" />}
							>
								{state.domain}
								{tld}
							</Button>
						);
					})}
					<Button
						variant="light"
						leftSection={<IconX size="17" />}
						onClick={() => dispatch({ type: "RESET_STATE" })}
					>
						Reset
					</Button>
				</Group>
			</Stack>
		);
	}

	return (
		<form>
			<popup.Element>
				<stripeElement.Element />
			</popup.Element>

			<Grid columns={12}>
				<GridCol span={{ base: 12, md: 7 }}>
					<TextInput
						size="md"
						placeholder="janedoe.co.uk"
						value={state.searchQuery}
						onChange={(e) => {
							dispatch({
								type: "SET_SEARCH_ERROR",
								payload: undefined,
							});

							if (state.domainIsAvailable) {
								dispatch({ type: "RESET_STATE" });
								e.currentTarget.value = "";
							}
							updateSearchQuery(e.currentTarget.value);
						}}
						error={state.searchFieldError}
						disabled={state.isLoading}
						leftSection={
							<Text
								ml="10px"
								size="md"
							>
								www.
							</Text>
						}
						leftSectionWidth="55px"
						rightSection={
							!state.domainIsAvailable ? (
								<DiscountButton />
							) : (
								<DomainAvailableCheck />
							)
						}
					/>
				</GridCol>
				{state.showDiscountField && (
					<GridCol span={{ base: 12, md: 3 }}>
						<TextInput
							value={state.couponQuery}
							disabled={state.isLoading || state.couponIsLoading}
							onChange={(e) => {
								if (state.couponIsValid) {
									dispatch({ type: "SET_COUPON_VALID", payload: false });
									e.currentTarget.value = "";
								}
								updateCouponQuery(e.currentTarget.value);
							}}
							onMouseLeave={() => {
								if (!state.couponQuery) {
									dispatch({
										type: "SET_COUPON_ERROR",
										payload: undefined,
									});
									return toggleDiscountField();
								}

								if (state.couponIsValid) {
									return;
								}

								function handleCouponInvalid(
									message: string = "Invalid Code."
								) {
									dispatch({
										type: "SET_COUPON_ERROR",
										payload: message,
									});
									updateCouponQuery("");

									return dispatch({
										type: "SET_COUPON_VALID",
										payload: false,
									});
								}
								getCouponInfo(state.couponQuery).then((res) => {
									const promotioCode = res.data[0];
									const coupon: Coupon | undefined = promotioCode?.coupon;

									if (!coupon) {
										// Coupon does not exist
										return handleCouponInvalid();
									}

									if (promotioCode.restrictions?.minimum_amount) {
										throw new Error("Unsupported Coupon. min_amount");
									}

									if (promotioCode.restrictions?.first_time_transaction) {
										throw new Error(
											"Unsupported Coupon. first_time_transaction"
										);
									}

									if (promotioCode.restrictions?.currency_options) {
										throw new Error("Unsupported Coupon. currency_options");
									}

									const isProductRestricted = coupon.applies_to ? true : false;

									if (
										isProductRestricted &&
										!coupon.applies_to?.products.includes(
											website.data.productId
										)
									) {
										// Coupon is not active for this product
										return handleCouponInvalid(
											"Coupon does not apply to this product."
										);
									} else if (coupon && !coupon.valid) {
										// Coupon is not valid
										return handleCouponInvalid("Coupon is no longer valid.");
									} else {
										// Coupon is valid
										dispatch({ type: "SET_COUPON_VALID", payload: true });
									}
								});
							}}
							rightSection={
								state.couponIsLoading ? (
									<Loader
										type="dots"
										size="sm"
									/>
								) : state.couponIsValid ? (
									<IconChecks color="green" />
								) : null
							}
							error={state.couponFieldError}
							width="30%"
							placeholder="Discount Code"
							size="md"
						/>
					</GridCol>
				)}
				<GridCol span={{ base: 12, md: state.showDiscountField ? 2 : 5 }}>
					{!state.domainIsAvailable && (
						<Button
							size="md"
							onClick={handleDomainSearch}
							loading={state.isLoading}
							disabled={state.isLoading || state.couponIsLoading}
							variant={state.domainIsAvailable ? "default" : "light"}
							fullWidth
						>
							Check Availability
						</Button>
					)}

					{state.domainIsAvailable && (
						<Button
							size="md"
							onClick={handleDomainOrder}
							loading={state.isLoading}
							disabled={state.isLoading || state.couponIsLoading}
							fullWidth
						>
							Continue with {state.searchQuery}
						</Button>
					)}
				</GridCol>
			</Grid>
		</form>
	);
}
