// React Imports
import { useTransition } from "react";

// Next.js Imports
import { useRouter } from "next/navigation";

// Lower Order Components

// UI Components & Icons
import {
	LoadingOverlay,
	Tabs,
	TabsList,
	TabsTab,
	Tooltip,
} from "@mantine/core";
import { IconWand } from "@tabler/icons-react";
import { FormValues, Step } from "@okedia/shared/types/formTypes";
import { Profile } from "@okedia/shared/types/profileTypes";

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Navigation component for the website editor interface.
 * Displays a tabbed navigation with form steps and website actions.
 *
 * @component
 * @param {Object} props - Component props
 * @param {FormValues} props.website - Website form values data
 * @param {Step[]} props.formSteps - Array of form steps to display as tabs
 * @param {Number} props.currentStep - Current active step number
 *
 * @returns {JSX.Element} A tabbed navigation component with form steps and website actions
 */

export default function EditorNav({
	profile,
	formSteps,
	currentStep,
	canCreateWebsite,
}: {
	profile: Profile<unknown[]>;
	formSteps: Step[];
	currentStep: Number;
	canCreateWebsite: boolean;
}) {
	const router = useRouter();
	const [isPending, startTransition] = useTransition();

	return (
		<Tabs
			visibleFrom="sm"
			variant="pills"
			value={currentStep.toString()}
			onChange={(value) => {
				return router.push(`?step=${value}`);
			}}
		>
			<TabsList grow>
				{formSteps.map((step, index) => {
					const [isPending, startTransition] = useTransition();

					return (
						<TabsTab
							key={`editor_touch_link_${index}`}
							value={`${step.id}`}
							bd="1px solid branding.5"
							fw="bold"
							c={currentStep !== index ? "branding.5" : undefined}
							disabled={isPending}
							onClick={() => {
								startTransition(() => {
									router.push(`?step=${step.id}`);
								});
							}}
						>
							<LoadingOverlay visible={isPending} />
							{step.shortTitle}
						</TabsTab>
					);
				})}
				<Tooltip
					label="Add more information to preview your website"
					disabled={canCreateWebsite}
					position="top"
					arrowPosition="center"
					withArrow
					arrowSize={6}
					openDelay={200}
				>
					<TabsTab
						key={`editor_touch_link_websites`}
						value="manage-websites"
						bd={
							!profile?.websites?.length && canCreateWebsite
								? "1px solid branding.5"
								: profile.websites && profile?.websites?.length > 0
								? "1px solid branding.5"
								: "1px solid gray.3"
						}
						bg={!canCreateWebsite ? "gray.3" : undefined}
						leftSection={!profile.websites?.length ? <IconWand /> : null}
						disabled={!canCreateWebsite || isPending}
						h="50px"
						fw="bold"
						c="branding.5"
						onClick={() => {
							startTransition(() => {
								// Navigation for /?step=manage-websites is dealt with by a HOC
								setTimeout(() => {}, 10000);
							});
						}}
					>
						<LoadingOverlay visible={isPending} />
						{profile?.websites?.length ? "Website Settings" : "Launch Website"}
					</TabsTab>
				</Tooltip>
			</TabsList>
		</Tabs>
	);
}
