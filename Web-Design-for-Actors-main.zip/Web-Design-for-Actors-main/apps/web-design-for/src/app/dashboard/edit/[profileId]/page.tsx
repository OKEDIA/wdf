"use server";

// React Imports

// Next.js Imports

// Lower Order Components
import Editor from "./_components/Editor";

// UI Components & Icons
import { notFound } from "next/navigation";

// Context & Helpers
import { documentHelpers } from "@okedia/shared/database";
import { useGlobalQueryParams } from "@okedia/shared/hooks";

// Other libraries or utilities

// Types
import {
	CommonFormDataProps,
	Input,
	Step,
} from "@okedia/shared/types/formTypes";
import {
	Website,
	WebsiteFormConfiguration,
} from "@okedia/shared/types/websiteTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Page component for editing a website configuration.
 *
 * @param params - Object containing the website ID
 * @param params.websiteId - Unique identifier for the website being edited
 *
 * @throws {Error} When website data cannot be retrieved
 * @throws {Error} When form configuration cannot be retrieved
 * @throws {NotFoundError} When websiteId is undefined or invalid
 *
 * @returns JSX.Element - Editor component with website configuration, form fields and steps
 *
 * @async
 * @component
 */
export default async function Page(props: {
	params: Promise<{ profileId: string }>;
}) {
	const params = await props.params;
	const profileId = (await params).profileId;
	if (!profileId || profileId === "undefined") {
		return notFound();
	}

	const globalQuery = useGlobalQueryParams(new URLSearchParams());

	let websiteConfig = await documentHelpers.get<Website<unknown>>({
		collectionName: "profiles",
		documentName: profileId,
	});

	if (!websiteConfig) {
		throw new Error("Unable to retrieve website data.");
	}

	const formConfig: WebsiteFormConfiguration = await documentHelpers
		.find<WebsiteFormConfiguration>({
			collectionName: "forms",
			filter: { id: websiteConfig.type },
			paginition: {
				...globalQuery.defaultPaginition().paginition,
				limit: 1,
				startAfter: 0,
			},
		})
		.then((res) => res as WebsiteFormConfiguration);

	return (
		<Editor
			params={params}
			website={websiteConfig}
			formFields={formConfig.inputs as Input[]}
			formSteps={formConfig.editorSteps as Step[]}
			commonFormDataMap={formConfig.commonFormDataMap as CommonFormDataProps}
		/>
	);
}
