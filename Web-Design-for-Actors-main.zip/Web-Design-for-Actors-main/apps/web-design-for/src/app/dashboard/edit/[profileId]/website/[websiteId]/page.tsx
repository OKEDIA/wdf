"use server";
// React Imports

// Next.js Imports

// Lower Order Components
import { notFound } from "next/navigation";
import Editor from "./_components/Editor";

// UI Components & Icons

// Context & Helpers
import { documentHelpers } from "@okedia/shared/database";

// Other libraries or utilities

// Types
import { useGlobalQueryParams } from "@okedia/shared/hooks";
import { Input } from "@okedia/shared/types/formTypes";
import { WebsiteFormConfiguration } from "@okedia/shared/types/websiteTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //
// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

export default async function Page(props: {
	params: Promise<{ websiteId: string }>;
}) {
	const params = await props.params;
	if (!params.websiteId || params.websiteId === "undefined") {
		return notFound();
	}
	const globalQuery = useGlobalQueryParams(new URLSearchParams());
	const mongoQuery = globalQuery.mongoQuery();

	const formFields = (await documentHelpers.find<WebsiteFormConfiguration>({
		collectionName: "forms",
		...mongoQuery,
		filter: [
			mongoQuery?.filter ? { ...mongoQuery.filter } : undefined,
			{ id: "websites" }, // Ensure the current form is beign serached for
		],
		paginition: { ...mongoQuery.paginition, limit: 1 },
	})) as WebsiteFormConfiguration;

	return (
		<Editor
			formFields={formFields.inputs as Input[]}
			params={params}
		/>
	);
}
