"use server";

// React Imports
import { Suspense } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { Alert, Badge, Card, Grid, GridCol, Paper, Title } from "@mantine/core";
import { IconCircleCheckFilled } from "@tabler/icons-react";

// Context & Helpers

// Other libraries or utilities
import getServiceStatus from "@/app/api/_helpers/servicestatus/getAll";

// Types
import {
	CrispResult,
	FirebaseResult,
	ServiceStatusResult,
	ServiceStatus as ServiceStatusType,
	StripeResult,
} from "@okedia/shared/types/serviceStatusTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * A functional component that displays the service status as a badge.
 *
 * @param {Object} props - The component props.
 * @param {ServiceStatusResult} props.serviceInfo - The service information result.
 *
 * @returns {JSX.Element} A badge indicating whether the service is "Available" or "Not Available".
 */
function ServiceStatusTag({
	serviceInfo,
}: {
	serviceInfo: ServiceStatusResult;
}) {
	// Use a type guard to check if the result is of type ServiceStatus
	const isServiceStatus = (
		result: FirebaseResult | StripeResult | CrispResult
	): result is ServiceStatusType => {
		return (result as ServiceStatusType).status === "up";
	};

	const currentStatus: string = isServiceStatus(serviceInfo.result)
		? "Available"
		: "Not Available";

	return <Badge>{currentStatus}</Badge>;
}

/**
 * The `ServiceStatus` component fetches the current status of various services
 * and displays their status in a dashboard format. It checks if all services
 * are up and shows an alert if everything is functioning correctly.
 *
 * @async
 * @function ServiceStatus
 * @returns {JSX.Element} The rendered component displaying the service statuses.
 *
 * @remarks
 * - Uses `getServiceStatus` to fetch the current status of services.
 * - Utilizes a type guard `isServiceStatus` to determine if a service is up.
 * - Displays a loading message while the service statuses are being fetched.
 * - Shows an alert if all services are up.
 * - Renders a grid of cards, each representing the status of a service.
 */
export default async function ServiceStatus() {
	const currentStatus = await getServiceStatus();

	const isServiceStatus = (
		result: FirebaseResult | StripeResult | CrispResult
	): result is ServiceStatusType => {
		return (result as ServiceStatusType).status === "up";
	};

	const allServicesUp = currentStatus.every((service) =>
		isServiceStatus(service.result)
	);

	return (
		<Suspense fallback={<p>Loading</p>}>
			{allServicesUp && (
				<Paper mb="lg">
					<Alert
						variant="light"
						color="blue"
						withCloseButton
						title="Service Status: GOOD"
						icon={<IconCircleCheckFilled />}
					>
						Everything seems to be okay at the moment. Something not quite
						right?
					</Alert>
				</Paper>
			)}
			<Grid columns={24}>
				{currentStatus.map((service) => (
					<GridCol
						span={{ base: 24, md: 12 }}
						key={service.service}
					>
						<Card p="xl">
							<Title
								order={3}
								fw="bold"
							>
								{service.friendly_name}
							</Title>
							<Title
								order={5}
								mb="lg"
							>
								{service.description}
							</Title>
							<ServiceStatusTag serviceInfo={service} />
						</Card>
					</GridCol>
				))}
			</Grid>
		</Suspense>
	);
}
