"use client"; // Error components must be Client Components

// React Imports
import { useEffect, useState } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import {
	Alert,
	Button,
	Code,
	Flex,
	Group,
	Paper,
	Spoiler,
	Text,
	Title,
	UnstyledButton,
} from "@mantine/core";
import { IconAlertTriangleFilled } from "@tabler/icons-react";
import Link from "next/link";

// Context & Helpers
import { isProductionEnvironment } from "@okedia/shared/helpers/isProductionEnvironment";

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Error component to display an error message and provide options to retry or navigate back to the dashboard.
 *
 * @param {Object} props - The component props.
 * @param {Error & { digest?: string }} props.error - The error object containing the error details.
 * @param {() => void} props.reset - The function to reset the error state.
 *
 * @returns {JSX.Element} The rendered Error component.
 *
 * @example
 * <Error error={new Error("Something went wrong")} reset={() => {}} />
 */
export default function Error({
	error,
	reset,
}: {
	error: Error & { digest?: string };
	reset: () => void;
}) {
	useEffect(() => {
		console.error(error);
	}, [error]);

	const [stackSpoilerExtended, setStackSpoilerExtended] = useState(false);
	const [time, setTime] = useState<number>(5);
	const [viewError, setViewError] = useState<boolean>(!isProductionEnvironment);

	useEffect(() => {
		const intervalId = setInterval(() => {
			setTime((prevTime) => {
				if (prevTime < 1) {
					clearInterval(intervalId);
					return 0; // Ensure we return a number (0) here
				} else {
					return prevTime - 1;
				}
			});
		}, 1000);

		// Clear the interval when the component unmounts or when the time reaches 0
		return () => {
			clearInterval(intervalId);
		};
	}, []);

	function handleTryAgain() {
		setTime(10);
		reset();
	}

	return (
		<>
			<Paper>
				<Flex
					px="10vw"
					py="10vh"
					direction="column"
					justify="middle"
					align="center"
					gap="lg"
				>
					<IconAlertTriangleFilled size="10rem" />
					<Title style={{ textAlign: "center" }}>Something went wrong</Title>

					<Group
						justify="middle"
						align="center"
					>
						<Button
							variant="outline"
							fullWidth
							type="button"
							onClick={handleTryAgain}
							disabled={time > 0}
						>
							{`Try Again${time ? ` (${time})` : ""}`}
						</Button>
						<Button
							fullWidth
							type="button"
							component={Link}
							href="/dashboard"
						>
							Back to Dashboard
						</Button>
					</Group>
					<Group
						mt="xl"
						style={{ fontWeight: "100" }}
					>
						<Link href="/service-status">Service Status</Link> &bull;{" "}
						<UnstyledButton>Contact Support</UnstyledButton> &bull;{" "}
						<UnstyledButton onClick={() => setViewError(!viewError)}>
							{viewError ? "Hide Error" : "View Error"}
						</UnstyledButton>
					</Group>
				</Flex>
			</Paper>
			{viewError && (
				<Paper>
					<Alert
						title={`${error.name ?? "Unknown"}: ${
							error.message ?? "(No Error Message Available)"
						}`}
						mt="5vh"
					>
						{error.stack && (
							<Spoiler
								showLabel="More"
								hideLabel="Less"
								expanded={stackSpoilerExtended}
								onExpandedChange={setStackSpoilerExtended}
							>
								<b>Stack: </b>
								<Code>{error.stack}</Code>
							</Spoiler>
						)}

						{error.digest && (
							<Text>
								<b>Digest: </b>
								<Code>{error.digest ?? ""}</Code>
							</Text>
						)}
					</Alert>
				</Paper>
			)}
		</>
	);
}
