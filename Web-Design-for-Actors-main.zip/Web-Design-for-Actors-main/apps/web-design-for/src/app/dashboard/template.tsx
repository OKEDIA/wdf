"use client";

// React Imports
import { useContext, useEffect, useState } from "react";

// Next.js Imports

// Lower Order Components
import TouchNav from "./_template/TouchNav";

// UI Components & Icons
import {
	AppShell,
	AppShellMain,
	AppShellNavbar,
	Box,
	Flex,
	Grid,
	GridCol,
	LoadingOverlay,
} from "@mantine/core";

// Context & Helpers

// Other libraries or utilities
import { useViewportSize } from "@mantine/hooks";

// Types
import { Metadata } from "next";
import { checkIsEmpty } from "@okedia/shared/helpers";
import {
	AuthContextValues,
	WebsiteContextValues,
} from "@okedia/shared/types/contextTypes";
import {
	LinkProps,
	NavigationConfig,
	Steps,
} from "@okedia/shared/types/navigationTypes";
import { WebsiteFormConfiguration } from "@okedia/shared/types/websiteTypes";
import { UserContext } from "../_context/User";
import { WebsiteContext } from "../_context/Websites";
import { getMetadata } from "../_utilities/getMetadata";
import Sidebar from "./_template/Sidebar";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * DashboardLayout component provides the layout structure for the dashboard.
 * It includes a navigation sidebar and a main content area.
 *
 * @param {Object} props - The component props.
 * @param {React.ReactNode} props.children - The child components to be rendered within the layout.
 *
 * @returns {JSX.Element} The rendered DashboardLayout component.
 *
 * @remarks
 * This component uses several hooks:
 * - `useViewportSize` to get the current viewport size.
 * - `useContext` to access `WebsiteContext` and `UserContext`.
 * - `useState` to manage the state of website links.
 * - `useEffect` to fetch editor steps for each website when the component mounts or updates.
 *
 * The navigation configuration includes links for:
 * - Dashboard
 * - Service Status
 * - External link to Web Design for Actors
 * - User's websites with dynamically fetched editor steps
 * - Administration links for managing users, websites, and viewing logs
 *
 * The layout includes:
 * - An `AppShell` component with a collapsible navbar.
 * - A `LoadingOverlay` to indicate loading states.
 * - A `Sidebar` component for navigation.
 * - A `Grid` layout for the main content area.
 * - A `TouchNav` component for mobile navigation.
 */

export default function DashboardLayout({
	children,
}: {
	children: React.ReactNode;
}) {
	const viewport = useViewportSize();
	const websites = useContext(WebsiteContext) as WebsiteContextValues;
	const user = useContext(UserContext) as AuthContextValues;
	const [websiteLinks, setWebsiteLinks] = useState<LinkProps[]>([]);
	const isAdmin = user.states.userAuthData?.decodedToken?.isAdmin;

	async function getEditorSteps(profileType: string): Promise<Steps[]> {
		const form = (await websites.getTypeData(profileType)) as
			| WebsiteFormConfiguration
			| undefined;

		return form?.editorSteps as Steps[];
	}

	useEffect(() => {
		const fetchSteps = async () => {
			const linksWithSteps = websites.states.profiles?.map(async (profile) => {
				const steps = await getEditorSteps(profile.type); // Fetch steps for each profile
				return {
					label: !checkIsEmpty(profile.commonFormDataValues.title)
						? profile.commonFormDataValues
						: profile.id,
					to: `/dashboard/edit/${profile.id}`,
					steps,
				};
			});

			const resolvedLinksWithSteps = await Promise.all(linksWithSteps);

			setWebsiteLinks(resolvedLinksWithSteps as any); // Update state with fetched links
		};

		if (websites.states.profiles.length > 0) {
			fetchSteps(); // Fetch steps if profiles are available
		}
	}, [
		websites.states.isLoading,
		websites.states.typeData,
		websites.states.profiles,
	]); // Dependency array ensures this runs when websites change

	const navigation: NavigationConfig = [
		{
			config: { label: "Navigation", displayLabel: false },
			links: [
				{ label: "Dashboard", to: "/dashboard", icon: "IconHome", steps: [] },
				{
					label: "Service Status",
					to: "/dashboard/service-status",
					icon: "IconHeartbeat",
					steps: [],
				},
			],
		},
		...(isAdmin
			? [
					{
						config: { label: "Administration", displayLabel: true },
						links: [
							{
								label: "Manage Users",
								to: "/dashboard/users",
								icon: "IconUsersGroup" as "IconUsersGroup",
							},
							{
								label: "Manage Websites",
								to: "/dashboard/websites",
								icon: "IconTopologyStar3" as "IconTopologyStar3",
							},
						],
					},
			  ]
			: []),
	];

	const touchNavigation: NavigationConfig = [
		...navigation,
		{
			config: { label: "Your Websites", displayLabel: true },
			links: websiteLinks,
		},
	];

	return (
		<AppShell
			navbar={{
				width: 100,
				breakpoint: "lg",
				collapsed: { mobile: true },
			}}
			padding="md"
		>
			<AppShellNavbar>
				<Flex
					h="100%"
					w="100%"
					display="block"
					bg="gray.1"
				>
					<LoadingOverlay
						visible={websites.states.isLoading || user.states.authLoading}
					/>
					<Sidebar navConfig={navigation} />
				</Flex>
			</AppShellNavbar>

			<AppShellMain
				styles={{
					main: { maxHeight: viewport.height },
				}}
			>
				<Grid
					justify="middle"
					align="center"
					columns={24}
					pb="125px"
					grow
				>
					<Box
						hiddenFrom="lg"
						style={{
							position: "absolute",
							width: "100%",
							left: "0",
							display: "flex",
							alignItems: "center",
							justifyContent: "center",
							bottom: "80px",
						}}
					>
						<TouchNav navConfig={touchNavigation} />
					</Box>
					<GridCol
						span={24}
						pos="relative"
					>
						{children}
					</GridCol>
				</Grid>
			</AppShellMain>
		</AppShell>
	);
}

export async function generateMetadata(): Promise<Metadata> {
	return await getMetadata("Dashboard", false);
}
