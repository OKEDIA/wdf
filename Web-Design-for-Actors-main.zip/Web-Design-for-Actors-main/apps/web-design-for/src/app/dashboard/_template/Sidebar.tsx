"use client";

// React Imports
import { useTransition } from "react";

// Next.js Imports
import { usePathname, useRouter } from "next/navigation";

// Lower Order Components

// UI Components & Icons
import {
	ActionIcon,
	Flex,
	Stack,
	Title,
	Tooltip,
	useMantineTheme,
} from "@mantine/core";

// Context & Helpers

// Other libraries or utilities

// Types
import {
	Icon,
	IconExternalLink,
	IconHeartbeat,
	IconHome,
	IconList,
	IconTopologyStar3,
	IconUsersGroup,
} from "@tabler/icons-react";
import {
	NavComponentProps,
	NavigationConfig,
} from "@okedia/shared/types/navigationTypes";
import UserCard from "../_components/UserCard";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Sidebar component that renders a navigation sidebar with configurable links and icons.
 *
 * @param {NavComponentProps} props - The properties for the Sidebar component.
 * @param {Array} props.navConfig - The configuration for the navigation links and groups.
 *
 * @returns {JSX.Element} The rendered Sidebar component.
 *
 * @component
 *
 * @example
 * const navConfig = [
 *   {
 *     config: { displayLabel: true, label: "Group 1" },
 *     links: [
 *       { label: "Home", to: "/", icon: "IconHome" },
 *       { label: "About", to: "/about", icon: "IconUsersGroup" }
 *     ]
 *   }
 * ];
 *
 * return <Sidebar navConfig={navConfig} />;
 */
export default function Sidebar({
	navConfig,
}: {
	navConfig: NavigationConfig;
}): JSX.Element {
	const currentPath = usePathname();
	const theme = useMantineTheme();
	const router = useRouter();

	interface IconMapProps {
		[key: string]: Icon | undefined;
	}

	const icons: IconMapProps = {
		IconHome: IconHome,
		IconHeartbeat: IconHeartbeat,
		IconExternalLink: IconExternalLink,
		IconUsersGroup: IconUsersGroup,
		IconTopologyStar3: IconTopologyStar3,
		IconList: IconList,
	};

	function LogoIcon() {
		return (
			<Flex
				align="center"
				justify="center"
				gap={0}
				p="xl"
				style={{
					width: "100%",
					scale: "90%",
				}}
			>
				<Flex>
					<Stack
						gap={0}
						mr="xs"
						h="100%"
						styles={{
							root: {
								paddingRight: "5px",
								borderRight: `4px solid ${theme.colors.branding[5]}`,
							},
						}}
					>
						<Title
							c="dark"
							px="0"
							order={6}
							ta="right"
							fw="bold"
							styles={{
								root: {
									lineHeight: "100%",
								},
							}}
						>
							WEB
						</Title>

						<Title
							c="dark"
							px="0"
							order={6}
							ta="right"
							fw="bold"
							styles={{
								root: {
									lineHeight: "100%",
								},
							}}
						>
							DESIGN
						</Title>

						<Title
							c="dark"
							px="0"
							order={6}
							ta="right"
							fw="bold"
							styles={{
								root: {
									lineHeight: "100%",
								},
							}}
						>
							FOR
						</Title>
					</Stack>
				</Flex>
			</Flex>
		);
	}

	return (
		<Flex
			justify="flex-start"
			h="100%"
			direction="column"
		>
			<Flex
				p="sm"
				styles={{
					root: {
						cursor: "pointer",
						root: { borderBottom: `1px solid ${theme.colors.gray[4]}` },
					},
				}}
			>
				<Stack
					gap={0}
					p={0}
					align="center"
					h="100%"
					w="100%"
				>
					<LogoIcon />
				</Stack>
			</Flex>

			<Stack
				gap={0}
				h="100%"
			>
				<Flex
					align="center"
					direction="column"
					h="100%"
					p="lg"
					justify="space-between"
				>
					<Flex
						direction="column"
						gap="md"
						align="center"
						justify="space-evenly"
						h="100%"
					>
						{navConfig.map((group, index) => {
							return (
								<Stack key={`group_${index}`}>
									{group.links.map((link, index) => {
										const [isPending, startTransition] = useTransition();

										const active = currentPath === link.to;
										const IconComponent = icons[link.icon ?? ""];

										return (
											<Tooltip
												label={link.label as string}
												key={`group_name_${index}`}
												position="right"
												offset={15}
											>
												<ActionIcon
													key={`group_name_${index}`}
													size="xl"
													variant={active ? "filled" : "subtle"}
													loading={isPending}
													onClick={() => {
														if (active) return;

														startTransition(() => router.push(link.to));
													}}
												>
													{IconComponent ? <IconComponent stroke={2} /> : null}
												</ActionIcon>
											</Tooltip>
										);
									})}
								</Stack>
							);
						})}
					</Flex>
					<Stack py="xl">
						<UserCard />
					</Stack>
				</Flex>
			</Stack>
		</Flex>
	);
}
