"use client";

// React Imports
import { useContext, useTransition } from "react";

// Next.js Imports
import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";

// Lower Order Components

// UI Components & Icons
import {
	LoadingOverlay,
	Menu,
	MenuDropdown,
	MenuItem,
	MenuLabel,
	MenuTarget,
	rem,
	Skeleton,
	Tabs,
	TabsList,
	TabsTab,
	UnstyledButton,
} from "@mantine/core";
import {
	IconArrowBack,
	IconDoorExit,
	IconDots,
	IconSettings,
} from "@tabler/icons-react";

// Context & Helpers

// Other libraries or utilities

// Types
import { UserContext } from "@/app/_context/User";
import { AuthContextValues } from "@okedia/shared/types/contextTypes";
import {
	icons,
	IconType,
	NavComponentProps,
} from "@okedia/shared/types/navigationTypes";
import { MenuItemAsButton } from "../_components/MenuItemAsButton";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * `TouchNav` is a navigation component designed for touch interfaces. It provides a tabbed navigation
 * system that adapts based on the current route and user context. The component displays different sets
 * of navigation links depending on whether the user is on an edit page or not.
 *
 * @param {NavComponentProps} navConfig - The configuration object for the navigation links.
 *
 * @returns {JSX.Element} The rendered navigation component.
 *
 * @component
 *
 * @example
 * // Example usage of TouchNav component
 * <TouchNav navConfig={navConfig} />
 *
 * @remarks
 * - The component uses `useRouter` for navigation and `usePathname` to determine the current route.
 * - It conditionally renders different sets of navigation links based on the current route.
 * - The `NavLinks` sub-component is used to render the navigation links for the edit page.
 * - The component uses various UI elements such as `Tabs`, `TabsList`, `TabsTab`, `Menu`, `MenuItem`, and `Skeleton`.
 * - The `user` context is used to handle user-specific actions like signing out.
 */
export default function TouchNav({ navConfig }: NavComponentProps) {
	const router = useRouter();
	const isEditPage = usePathname().includes("/edit/");
	const currentStep = useSearchParams().get("step") ?? 0;
	const user = useContext(UserContext) as AuthContextValues;
	const [isPending, startTransition] = useTransition();

	function NavLinks({ navConfig }: NavComponentProps) {
		if (!navConfig.length || !navConfig[1].links.length) {
			return (
				<>
					<Skeleton
						m="5px"
						w="100px"
						radius="lg"
					/>
					<Skeleton
						m="5px"
						w="80px"
						radius="lg"
					/>
					<Skeleton
						m="5px"
						w="100px"
						radius="lg"
					/>
					<Skeleton
						m="5px"
						w="120px"
						radius="lg"
					/>
				</>
			);
		}

		const websiteLinks = navConfig.find(
			(group) => group.config.label === "Your Websites"
		);

		return websiteLinks?.links.map((link) => {
			if (link.to !== usePathname()) {
				return;
			}

			return link.steps?.map((step, index) => {
				const [isPending, startTransition] = useTransition();

				return (
					<TabsTab
						key={`editor_touch_link_${index}`}
						value={`${link.to}?step=${step.id}`}
						bd="1px solid #efefef"
						defaultChecked={index === 0}
						m="5px"
						onClick={(e) => {
							e.preventDefault();

							startTransition(() => {
								router.push(`${link.to}?step=${step.id}`);
							});
						}}
					>
						<LoadingOverlay visible={isPending} />
						{step.shortTitle}
					</TabsTab>
				);
			});
		});
	}

	if (isEditPage) {
		const [isPending, startTransition] = useTransition();

		return (
			<Tabs
				variant="pills"
				radius="lg"
				defaultValue={`${usePathname()}?step=${currentStep}`}
				bg="gray.1"
				p="10px"
				mx="10px"
				h="100%"
				style={{
					borderRadius: "10px",
					overflowX: "scroll",
					zIndex: 10,
					boxShadow: "inset 0px 0px 3px 1px #dee2e6",
				}}
				styles={{
					root: { scrollbarWidth: "none" },
				}}
				onChange={(value) => {
					if (value === "popup") {
						return;
					}

					router.push(`${value}`);
				}}
			>
				<TabsList style={{ flexWrap: "nowrap" }}>
					<TabsTab
						key={`touchnav_main_dashboard`}
						value="/dashboard"
						leftSection={<IconArrowBack />}
						onClick={(e) => {
							e.preventDefault();
							startTransition(() => {
								router.push(`/dashboard`);
							});
						}}
					>
						<LoadingOverlay visible={isPending} />
						Leave Editor
					</TabsTab>
					<NavLinks navConfig={navConfig} />
				</TabsList>
			</Tabs>
		);
	}

	return (
		<Tabs
			variant="pills"
			radius="lg"
			defaultValue="dashboard"
			value={usePathname()}
			bg="gray.1"
			p="10px"
			mx="10px"
			h="100%"
			style={{
				borderRadius: "10px",
				overflowX: "scroll",
				zIndex: 10,
				boxShadow: "inset 0px 0px 3px 1px #dee2e6",
			}}
			styles={{
				root: { scrollbarWidth: "none" },
			}}
			onChange={(value) => {
				if (value === "popup") {
					return;
				}

				router.push(`${value}`);
			}}
		>
			<TabsList style={{ flexWrap: "nowrap" }}>
				{navConfig.map((group, index) => {
					if (index >= 1) {
						return;
					}

					return group.links.map((link, index) => {
						const IconComponent = link.icon
							? icons[link.icon as IconType]
							: undefined;
						const [isPending, startTransition] = useTransition();

						return (
							<TabsTab
								px="md"
								m="2px"
								py="0px"
								key={`touchnav_main_tab_${index}`}
								value={link.to}
								leftSection={
									IconComponent ? (
										<IconComponent
											size="1.3rem"
											stroke={2}
										/>
									) : undefined
								}
								onClick={(e) => {
									e.preventDefault();

									startTransition(() => {
										router.push(link.to);
									});
								}}
							>
								<LoadingOverlay visible={isPending} />
								{link.label as string}
							</TabsTab>
						);
					});
				})}

				<Menu
					width="25em"
					offset={30}
					position="top"
					radius="30px"
					trigger="click-hover"
					styles={{ dropdown: { minWidth: "300px" } }}
				>
					<MenuTarget>
						<TabsTab value="popup">
							<IconDots style={{ width: rem(20), height: rem(20) }} />
						</TabsTab>
					</MenuTarget>
					<MenuDropdown
						style={{ border: "unset" }}
						pb="sm"
					>
						<LoadingOverlay visible={isPending} />

						{navConfig.map((group, index) => {
							if (index < 1) {
								return;
							}
							const [isPending, startTransition] = useTransition();

							return (
								<div key={`touchnav_sub_${group.config.label}_${index}`}>
									{group.config.displayLabel && (
										<MenuLabel mt="sm">{group.config.label ?? ""}</MenuLabel>
									)}
									{group.links.map((link, index) => {
										const IconComponent = link.icon
											? icons[link.icon as IconType]
											: undefined;

										return (
											<MenuItem
												component={Link}
												key={`touchnav_sub_item_${group.config.label}_${index}`}
												href={link.to}
												onClick={(e) => {
													e.preventDefault();

													startTransition(() => {
														router.push(link.to);
													});
												}}
												leftSection={
													IconComponent ? (
														<IconComponent
															size="1.3rem"
															stroke={2}
														/>
													) : undefined
												}
											>
												<LoadingOverlay visible={isPending} />
												{typeof link.label === "object"
													? link.label.title
													: link.label}
											</MenuItem>
										);
									})}
								</div>
							);
						})}
						<MenuLabel mt="sm">Account</MenuLabel>
						<MenuItem
							component={Link}
							href="/dashboard/settings"
							leftSection={
								<IconSettings
									size="1.3rem"
									stroke={2}
								/>
							}
							onClick={(e) => {
								e.preventDefault();

								startTransition(() => {
									router.push("/dashboard/settings");
								});
							}}
						>
							Settings
						</MenuItem>
						<MenuItemAsButton
							p="sm"
							component={UnstyledButton}
							leftSection={
								<IconDoorExit
									size="1.3rem"
									stroke={2}
								/>
							}
							onClick={() =>
								startTransition(() =>
									user.signOut().then(() => router.push("/"))
								)
							}
						>
							Sign Out
						</MenuItemAsButton>
					</MenuDropdown>
				</Menu>
			</TabsList>
		</Tabs>
	);
}
