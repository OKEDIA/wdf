"use client"; // Error components must be Client Components

// React Imports
import { useEffect, useState } from "react";

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import {
	Button,
	Center,
	Container,
	GridCol,
	Group,
	Paper,
	Stack,
	Text,
	Title,
	useMantineTheme,
} from "@mantine/core";
import { IconExclamationCircleFilled } from "@tabler/icons-react";
import Link from "next/link";

// Context & Helpers
import { isProductionEnvironment } from "@okedia/shared/helpers/isProductionEnvironment";
import WdfLogo from "../(root)/_components/logos/WdfLogo";

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * Error component to display an error message and provide options to retry or navigate back to the dashboard.
 *
 * @param {Object} props - The component props.
 * @param {Error & { digest?: string }} props.error - The error object containing the error details.
 * @param {() => void} props.reset - The function to reset the error state.
 *
 * @returns {JSX.Element} The rendered Error component.
 *
 * @example
 * <Error error={new Error("Something went wrong")} reset={() => {}} />
 */
export default function Error({
	error,
	reset,
}: {
	error: Error & { digest?: string };
	reset: () => void;
}) {
	const theme = useMantineTheme().other;

	useEffect(() => {
		console.error(error);
	}, [error]);

	const [stackSpoilerExtended, setStackSpoilerExtended] = useState(false);
	const [time, setTime] = useState<number>(5);
	const [viewError, setViewError] = useState<boolean>(!isProductionEnvironment);

	useEffect(() => {
		const intervalId = setInterval(() => {
			setTime((prevTime) => {
				if (prevTime < 1) {
					clearInterval(intervalId);
					return 0; // Ensure we return a number (0) here
				} else {
					return prevTime - 1;
				}
			});
		}, 1000);

		// Clear the interval when the component unmounts or when the time reaches 0
		return () => {
			clearInterval(intervalId);
		};
	}, []);

	function handleTryAgain() {
		setTime(10);
		reset();
	}

	return (
		<Container fluid>
			<GridCol span={24}>
				<Center>
					<Stack
						align="center"
						justify="center"
					>
						<WdfLogo
							style={{ scale: 1 }}
							p={0}
							c="dark"
						>
							<Text
								tt="uppercase"
								fw="900"
								size="3em"
								lh="normal"
								c="branding"
							>
								{theme.id}
							</Text>
						</WdfLogo>
						<Text ta="center">
							Log in to create or update your website using the WDF Builder.
						</Text>
					</Stack>
				</Center>
			</GridCol>
			<GridCol
				span={24}
				mt="lg"
			>
				<Paper
					shadow="xs"
					p="xl"
				>
					<Group justify="space-evenly">
						<Stack
							gap="0"
							align="center"
							justify="middler"
						>
							<IconExclamationCircleFilled size="5em" />
							<Title
								order={1}
								ta="center"
							>
								Oops, something went wrong.
							</Title>
							<Title order={5}>{error.message}</Title>

							<Group
								mt="lg"
								justify="middle"
								align="center"
								gap="xs"
							>
								<Button
									variant="outline"
									fullWidth
									type="button"
									onClick={handleTryAgain}
									disabled={time > 0}
								>
									{`Try Again${time ? ` (${time})` : ""}`}
								</Button>
								<Button
									fullWidth
									type="button"
									component={Link}
									href="/"
								>
									Back to Homepage
								</Button>
							</Group>
						</Stack>
					</Group>
				</Paper>
			</GridCol>
		</Container>
	);
}
