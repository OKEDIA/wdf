"use client";

// React Imports
import { useContext, useEffect, useState, useTransition } from "react";

// Next.js Imports
import { useRouter, useSearchParams } from "next/navigation";

// Lower Order Components
import AlreadyAuthenticated from "./AlreadyAuthenticated";
import SignInBy3rdPartyProvider from "./AuthProviderForm";
import SignInByEmail from "./EmailForm";
import Loading from "./Loading";
import PasswordReset from "./PasswordReset";

// UI Components & Icons
import { Box, LoadingOverlay } from "@mantine/core";

// Context & Helpers
import { UserContext } from "@/app/_context/User";

// Other libraries or utilities
import { signInWithProvider } from "@/app/_utilities/authenticationFunctions";

// Types
import { AuthenticationComponent } from "@okedia/shared/types/authenticationTypes";
import { AuthContextValues } from "@okedia/shared/types/contextTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * LoginForm component handles the user authentication process.
 *
 * This component checks the current authentication status and redirects the user if they are already authenticated.
 * It provides options for signing in via email or third-party providers.
 *
 * @component
 * @returns {JSX.Element} The rendered LoginForm component.
 *
 * @remarks
 * - Uses `useContext` to access the `UserContext`.
 * - Uses `useEffect` to handle already authenticated users.
 * - Uses `useState` to manage the state of the sign-in method (email or third-party provider).
 * - Uses `useTransition` to manage the pending state during transitions.
 *
 * @example
 * ```tsx
 * import { LoginForm } from './LoginForm';
 *
 * function App() {
 *   return (
 *     <div>
 *       <LoginForm />
 *     </div>
 *   );
 * }
 * ```
 */
export function LoginForm() {
	const user = useContext(UserContext) as AuthContextValues;
	const params = Object.fromEntries(useSearchParams());

	/**
	 * Gets the current auth status and checks it against the api, redirects on successful auth.
	 * Outdated code
	 */
	useEffect(() => {
		async function handleAlreadyAuthenticated() {
			const authData = user.states.userAuthData;
			if (!authData) {
				return;
			}

			fetch("/api/auth/login", {
				method: "POST",
				headers: {
					Authorization: `Bearer ${authData.token}`,
				},
			});
		}

		handleAlreadyAuthenticated();
	}, [user]);

	const [byEmail, setByEmail] = useState<boolean>(false);
	const router = useRouter();
	const [isPending, startTransition] = useTransition();

	if (user.states.authLoading) {
		return <Loading />;
	}

	/**
	 * AuthComponent is a functional component that renders different authentication components
	 * based on the user's authentication state and the method of authentication.
	 *
	 * @param {AuthenticationComponent} props - The properties passed to the authentication components.
	 * @returns {JSX.Element} - Returns the appropriate authentication component based on the user's state.
	 *
	 * - If the user is already authenticated (`user.states.userAuthData` is true), it renders the `AlreadyAuthenticated` component.
	 * - If the authentication is by email (`byEmail` is true), it renders the `SignInByEmail` component.
	 * - Otherwise, it renders the `SignInBy3rdPartyProvider` component.
	 */
	function AuthComponent(props: AuthenticationComponent) {
		if (params.passwordreset === "true") {
			return <PasswordReset {...props} />;
		} else if (user.states.userAuthData) {
			return <AlreadyAuthenticated {...props} />;
		} else if (byEmail) {
			return <SignInByEmail {...props} />;
		} else {
			return <SignInBy3rdPartyProvider {...props} />;
		}
	}

	return (
		<Box pos="relative">
			<LoadingOverlay visible={isPending} />
			<AuthComponent
				state={{
					setByEmail,
					byEmail,
					router,
					signInWithProvider,
					isPending,
					startTransition,
					params,
				}}
				userContext={user}
			/>
		</Box>
	);
}
