// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import { Group, Skeleton, Stack } from "@mantine/core";
// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * A loading component that displays a skeleton placeholder for content.
 *
 * Renders a vertical stack containing:
 * - A circular skeleton (125px height)
 * - A rectangular skeleton (300px width, 50px height)
 * - A rectangular skeleton (300px width, 25px height)
 *
 * All skeleton elements are animated and centered within the component.
 *
 * @returns JSX element displaying animated loading skeletons
 */
export default function Loading() {
	return (
		<Group justify="space-evenly">
			<Stack
				gap="0"
				align="center"
				justify="middler"
			>
				<Skeleton
					height={125}
					circle
					mb="xl"
					animate
				/>
				<Skeleton
					height={50}
					width={300}
					mb="sm"
					animate
				/>
				<Skeleton
					height={25}
					width={300}
					mb="sm"
					animate
				/>
			</Stack>
		</Group>
	);
}
