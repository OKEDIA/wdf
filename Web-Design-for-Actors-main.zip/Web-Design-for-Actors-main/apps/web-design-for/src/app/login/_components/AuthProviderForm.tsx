// React Imports

// Next.js Imports
import { useRouter } from "next/navigation";

// Lower Order Components

// UI Components & Icons
import { Button, Divider, Stack } from "@mantine/core";

// Context & Helpers

// Other libraries or utilities

// Types
import { defaultNotificationProps } from "@/app/_utilities/notificationsConfig";
import { notifications } from "@mantine/notifications";
import { AuthenticationComponent } from "@okedia/shared/types/authenticationTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * A component that provides buttons for signing in with third-party providers
 * such as Google and Apple, or via email address.
 *
 * @param {Object} props - The component props.
 * @param {Object} props.state - The state object containing methods for authentication.
 * @param {Function} props.state.setByEmail - Function to set the authentication method to email.
 * @param {Function} props.state.signInWithProvider - Function to sign in with a third-party provider.
 * @param {Function} props.state.startTransition - Function to start a transition.
 * @param {Object} props.userContext - The user context object.
 *
 * @returns {JSX.Element} The rendered component.
 */
export default function SignInBy3rdPartyProvider({
	state,
	userContext,
}: AuthenticationComponent): JSX.Element {
	const { setByEmail, signInWithProvider, startTransition } = state;
	const user = userContext;
	const router = useRouter();

	return (
		<Stack>
			<Button
				onClick={() =>
					startTransition(async () => {
						return await signInWithProvider({
							provider: "google",
							user,
						})
							.catch((err) => {
								notifications.show({
									...defaultNotificationProps,
									color: "red",
									message: err.message,
									title: "Could not sign in",
								});
							})
							.finally(() => router.refresh());
					})
				}
			>
				Continue with Google
			</Button>
			<Button
				onClick={() =>
					startTransition(async () => {
						return await signInWithProvider({
							provider: "apple",
							user,
						})
							.catch((err) => {
								notifications.show({
									...defaultNotificationProps,
									color: "red",
									message: err.message,
									title: "Could not sign in",
								});
							})
							.finally(() => router.refresh());
					})
				}
			>
				Continue with Apple
			</Button>
			<Divider
				my="xs"
				label="Don't have any of those?"
				labelPosition="center"
			/>
			<Button
				onClick={() => {
					setByEmail(true);
				}}
				variant="light"
			>
				Continue with Email Address
			</Button>
		</Stack>
	);
}
