// React Imports
import { useEffect } from "react";

// Next.js Imports
import { useRouter } from "next/navigation";

// Lower Order Components

// UI Components & Icons
import { Button, Divider, Group } from "@mantine/core";
import { IconProgressCheck, IconRefreshAlert } from "@tabler/icons-react";
import Form from "@okedia/shared/form/Form";

// Context & Helpers

// Other libraries or utilities
import { notifications } from "@mantine/notifications";
import { confirmPasswordReset, verifyPasswordResetCode } from "firebase/auth";
import { checkIsEmpty } from "@okedia/shared/helpers";
import { generateInitialFormValues } from "@okedia/shared/helpers/form";
import { SubmitHandler, useForm, useWatch } from "react-hook-form";

// Types
import { firebaseAuthErrorsMap } from "@/app/_utilities/authenticationFunctions";
import { defaultNotificationProps } from "@/app/_utilities/notificationsConfig";
import { AuthenticationComponent } from "@okedia/shared/types/authenticationTypes";
import { FormValues, Input } from "@okedia/shared/types/formTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

const loginFormConfig: Input[] = [
	{
		inputGroup: "login",
		id: "credentials",
		label: "Reset your pasword",
		helpText: "Enter a new password below to reset your password.",
		fieldComponents: [
			{
				component: "text",
				id: "email",
				inputWeight: 0,
				attributes: {
					label: "Email Address",
					placeholder: "Enter an Email Address",
					width: "100%",
					required: true,
				},

				validators: {
					required: true,
					pattern: "email",
				},
			},
			{
				component: "password",
				id: "password",
				inputWeight: 1,
				attributes: {
					label: "New Password",
					placeholder: "Enter a new password",
					width: "100%",
					required: true,
				},
				validators: {
					required: true,
					pattern: "password",
					min: 8,
					max: 50,
				},
			},
			{
				component: "password",
				id: "password_match",
				inputWeight: 1,
				attributes: {
					label: "Confirm Password",
					placeholder: "Confirm the password",
					width: "100%",
				},
				validators: {
					required: true,
					pattern: "password",
					min: 8,
					max: 50,
				},
			},
		],
	},
];

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * SignInByEmail component handles the email sign-in process.
 * It renders a form for users to input their email and password,
 * and provides options to sign in with Google or Apple.
 *
 * @param {Object} props - The component props.
 * @param {Object} props.state - The state object containing signInWithProvider and startTransition functions.
 * @param {Object} props.userContext - The user context object.
 *
 * @returns {JSX.Element} The rendered SignInByEmail component.
 */
export default function PasswordReset({
	state,
	userContext,
}: AuthenticationComponent): JSX.Element {
	const { signInWithProvider, startTransition } = state;
	const user = userContext;
	const router = useRouter();

	const form = useForm({
		defaultValues: generateInitialFormValues({
			formFields: loginFormConfig,
			generateEmpty: true,
		}),
	});

	const passwordMatch = useWatch({
		control: form.control,
		name: "login.credentials[0].password_match",
	});

	useEffect(() => {
		if (!checkIsEmpty(passwordMatch)) {
			if (form.getValues("login.credentials[0].password") !== passwordMatch) {
				form.setError("login.credentials[0].password_match", {
					type: "custom",
					message: "Passwords do not match",
				});
			} else {
				form.clearErrors("login.credentials[0].password_match");
			}
		}
	}, [passwordMatch]);

	useEffect(() => {
		if (state.params?.email) {
			form.setValue("login.credentials[0].email", state.params.email);
		}
	}, [state.params?.email]);

	const validateAndSubmit: SubmitHandler<FormValues> = async (data, e) => {
		e?.preventDefault();

		const email = data.login.credentials[0].email;
		const password = data.login.credentials[0].password;

		notifications.show({
			...defaultNotificationProps,
			message:
				"Hang tight, we're resetting your password! This shouldn't take long.",
			title: "Resetting password",
			loading: true,
			id: "resetting-password",
		});

		startTransition(async () => {
			if (!state.params?.oobCode) {
				notifications.update({
					...defaultNotificationProps,
					color: "red",
					message:
						"There seems to be a problem with the password reset link. Please try again or contact support.",
					title: "Resetting password",
					id: "resetting-password",
					loading: false,
					icon: <IconRefreshAlert />,
				});
				return;
			}

			const matchingEmailAddressForCode = await verifyPasswordResetCode(
				user.authForClientSide,
				state.params?.oobCode
			)
				.then((res) => {
					// Verify the password reset code
					if (email && res !== email) {
						notifications.update({
							...defaultNotificationProps,
							color: "red",
							message:
								"Unable to verify the password reset code. Please try again or contact support.",
							title: "Resetting password",
							id: "resetting-password",
							loading: false,
							icon: <IconRefreshAlert />,
						});
					} else {
						return res;
					}
				})
				.catch((err) => {
					const userFriendlyError =
						err?.code in firebaseAuthErrorsMap
							? firebaseAuthErrorsMap[
									err?.code as keyof typeof firebaseAuthErrorsMap
							  ]
							: undefined;
					if (err?.code && userFriendlyError) {
						notifications.update({
							...defaultNotificationProps,
							color: "red",
							message: userFriendlyError,
							title: "Resetting password",
							id: "resetting-password",
							loading: false,
							icon: <IconRefreshAlert />,
						});
					} else {
						throw err;
					}
				});

			if (matchingEmailAddressForCode) {
				notifications.update({
					message: "Nearly there, just saving your new password.",
					id: "resetting-password",
				});

				await confirmPasswordReset(
					user.authForClientSide,
					state.params?.oobCode,
					password
				)
					.then(async () => {
						notifications.update({
							...defaultNotificationProps,
							message: "All done! You can now log in with your new password.",
							title: "Resetting password",
							id: "resetting-password",
							loading: false,
							icon: <IconProgressCheck />,
						});

						notifications.show({
							...defaultNotificationProps,
							message: "Signing you into your account with your new password.",
							title: "Signing into your account",
							loading: true,
							id: "pwd-reset-signin",
						});

						await signInWithProvider({
							provider: "email",
							email,
							password,
							user,
						})
							.then(() => {
								notifications.update({
									message: "All done! Welcome back to your account.",
									id: "pwd-reset-signin",
									loading: false,
									icon: <IconProgressCheck />,
								});
							})
							.catch((err) => {
								const userFriendlyError =
									err?.code in firebaseAuthErrorsMap
										? firebaseAuthErrorsMap[
												err?.code as keyof typeof firebaseAuthErrorsMap
										  ]
										: undefined;
								if (err?.code && userFriendlyError) {
									notifications.update({
										...defaultNotificationProps,
										color: "red",
										message: userFriendlyError,
										loading: false,
										id: "pwd-reset-signin",
										icon: <IconRefreshAlert />,
									});
								} else {
									throw err;
								}
							})
							.finally(() => router.refresh());
					})
					.catch((err) => {
						const userFriendlyError =
							err?.code in firebaseAuthErrorsMap
								? firebaseAuthErrorsMap[
										err?.code as keyof typeof firebaseAuthErrorsMap
								  ]
								: undefined;
						if (err?.code && userFriendlyError) {
							notifications.update({
								...defaultNotificationProps,
								color: "red",
								message: userFriendlyError,
								title: "Resetting password",
								id: "resetting-password",
								loading: false,
								icon: <IconRefreshAlert />,
							});
						} else {
							throw err;
						}
					});
			}

			// 	await signInWithProvider({
			// 		provider: "email",
			// 		email,
			// 		password,
			// 		user,
			// 	})
			// 		.catch((err) =>
			// 			notifications.show({
			// 				...defaultNotificationProps,
			// 				color: "red",
			// 				message: err.message,
			// 				title: "Could not sign in",
			// 			})
			// 		)
			// 		.finally(() => router.refresh());
		});
	};

	return (
		<form onSubmit={form.handleSubmit(validateAndSubmit)}>
			<Form
				formFields={loginFormConfig}
				formInstance={form}
			/>

			<Button
				fullWidth
				type="submit"
			>
				Reset Password
			</Button>
			<Divider
				my="xs"
				label="not what you're looking for?"
				labelPosition="center"
			/>
			<Group grow>
				<Button
					variant="light"
					onClick={() =>
						startTransition(async () => {
							return router.replace("/login");
						})
					}
				>
					Back to Login
				</Button>
			</Group>
		</form>
	);
}
