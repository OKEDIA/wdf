// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import {
	Avatar,
	Button,
	ButtonGroup,
	Group,
	Stack,
	Title,
} from "@mantine/core";

// Context & Helpers

// Other libraries or utilities
import { removeAfterFirstWhitespace } from "@okedia/shared/helpers/string";

// Types
import { AuthenticationComponent } from "@okedia/shared/types/authenticationTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * A React component that displays a welcome message and user information
 * for an already authenticated user. It provides options to continue to
 * the dashboard or sign out.
 *
 * @param {Object} props - The component props.
 * @param {Object} props.userContext - The user context containing authentication data and methods.
 * @param {Object} props.state - The state object containing router and transition functions.
 * @param {Object} props.state.router - The router object used for navigation.
 * @param {Function} props.state.startTransition - The function to start a transition.
 * @param {Object} props.userContext.states.userAuthData - The authenticated user data.
 * @param {Object} props.userContext.states.userAuthData.claims - The claims object containing user information.
 * @param {string} props.userContext.states.userAuthData.claims.picture - The URL of the user's profile picture.
 * @param {string} props.userContext.states.userAuthData.claims.name - The name of the authenticated user.
 * @param {string} props.userContext.states.userAuthData.claims.email - The email of the authenticated user.
 *
 * @returns {JSX.Element} The rendered component.
 */
export default function AlreadyAuthenticated({
	userContext,
	state,
}: AuthenticationComponent): JSX.Element {
	const { router, startTransition } = state;
	const user = userContext?.states.userAuthData;

	return (
		<Group justify="space-evenly">
			<Stack
				gap="0"
				align="center"
				justify="middler"
			>
				<Avatar
					src={(user?.decodedToken?.picture as string) ?? undefined}
					alt={`Profile Photo for ${user?.decodedToken?.name ?? "user"}`}
					size="100"
					bd="8px solid branding.5"
					mb={20}
				/>
				<Title order={1}>
					Welcome Back,{" "}
					{removeAfterFirstWhitespace(
						(user?.decodedToken?.name as string) ?? ""
					)}
				</Title>
				<Title order={5}>{(user?.decodedToken?.email as string) ?? ""}</Title>

				<ButtonGroup mt="xl">
					<Button
						component="a"
						onClick={() => {
							startTransition(() => router.push("/dashboard"));
						}}
					>
						Continue to Dashboard
					</Button>
					<Button
						onClick={async () => {
							return await userContext
								.signOut()
								.finally(() => router.push("/login"));
						}}
						variant="light"
					>
						Sign Out
					</Button>
				</ButtonGroup>
			</Stack>
		</Group>
	);
}
