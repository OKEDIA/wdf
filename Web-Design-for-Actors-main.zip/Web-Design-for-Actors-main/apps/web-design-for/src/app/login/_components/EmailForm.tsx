// React Imports

// Next.js Imports
import { useRouter } from "next/navigation";

// Lower Order Components

// UI Components & Icons
import {
	Box,
	Button,
	Divider,
	Flex,
	Group,
	Text,
	TextInput,
	UnstyledButton,
	useMantineTheme,
} from "@mantine/core";
import { IconProgressCheck, IconRefreshAlert } from "@tabler/icons-react";
import Form from "@okedia/shared/form/Form";

// Context & Helpers

// Other libraries or utilities
import { sendPasswordResetLink } from "@/app/_utilities/serverAuthFunctions";
import { modals } from "@mantine/modals";
import { notifications } from "@mantine/notifications";
import { checkIsEmpty } from "@okedia/shared/helpers";
import { generateInitialFormValues } from "@okedia/shared/helpers/form";
import { SubmitHandler, useForm, UseFormReturn } from "react-hook-form";

// Types
import { defaultNotificationProps } from "@/app/_utilities/notificationsConfig";
import { AuthenticationComponent } from "@okedia/shared/types/authenticationTypes";
import { FormValues, Input } from "@okedia/shared/types/formTypes";

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

const loginFormConfig: Input[] = [
	{
		inputGroup: "login",
		id: "credentials",
		label: "Continue with Email",
		helpText: "Use an Email Address and Password",
		fieldComponents: [
			{
				component: "text",
				id: "email",
				inputWeight: 0,
				attributes: {
					label: "Email Address",
					placeholder: "Enter an Email Address",
					width: "100%",
				},
				validators: {
					required: true,
					pattern: "email",
				},
			},
			{
				component: "password",
				id: "password",
				inputWeight: 1,
				attributes: {
					label: "Password",
					placeholder: "Enter a Password",
					width: "100%",
				},
				validators: {
					required: true,
					pattern: "password",
					min: 8,
					max: 50,
				},
			},
		],
	},
];

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

function PasswordReset({
	formInstance,
}: {
	formInstance: UseFormReturn<FormValues>;
}) {
	const field = formInstance.register("login.credentials[0].email", {
		required: true,
	});

	return (
		<Box>
			<Text>
				Please enter your email address to receive a password reset link.
			</Text>
			<TextInput
				label="Email Address"
				placeholder="my@email.com"
				{...field}
			/>
		</Box>
	);
}

/**
 * SignInByEmail component handles the email sign-in process.
 * It renders a form for users to input their email and password,
 * and provides options to sign in with Google or Apple.
 *
 * @param {Object} props - The component props.
 * @param {Object} props.state - The state object containing signInWithProvider and startTransition functions.
 * @param {Object} props.userContext - The user context object.
 *
 * @returns {JSX.Element} The rendered SignInByEmail component.
 */
export default function SignInByEmail({
	state,
	userContext,
}: AuthenticationComponent): JSX.Element {
	const { signInWithProvider, startTransition } = state;
	const user = userContext;
	const router = useRouter();
	const theme = useMantineTheme();

	const form = useForm({
		defaultValues: generateInitialFormValues({
			formFields: loginFormConfig,
			generateEmpty: true,
		}),
	});

	const validateAndSubmit: SubmitHandler<FormValues> = async (data, e) => {
		e?.preventDefault();

		const email = data.login.credentials[0].email;
		const password = data.login.credentials[0].password;

		startTransition(async () => {
			await signInWithProvider({
				provider: "email",
				email,
				password,
				user,
			})
				.catch((err) =>
					notifications.show({
						...defaultNotificationProps,
						color: "red",
						message: err.message,
						title: "Could not sign in",
					})
				)
				.finally(() => router.refresh());
		});
	};

	return (
		<form onSubmit={form.handleSubmit(validateAndSubmit)}>
			<Form
				formFields={loginFormConfig}
				formInstance={form}
			/>

			<Flex justify="flex-end">
				<UnstyledButton
					variant="transparent"
					pr={0}
					mb="sm"
					onClick={() => {
						modals.openConfirmModal({
							title: "Reset Password",
							children: <PasswordReset formInstance={form} />,
							labels: {
								cancel: "Cancel",
								confirm: "Send Reset Link",
							},
							onConfirm: async () => {
								notifications.show({
									...defaultNotificationProps,
									message: "Generating Password Reset Link",
									title: "Sending...",
									id: "sending-password-reset",
									loading: true,
								});
								const emailField = form.getFieldState(
									"login.credentials[0].email",
									form.formState
								);

								const value = form.getValues("login.credentials[0].email");

								if (
									emailField.invalid ||
									(!emailField.isDirty && checkIsEmpty(value))
								) {
									return notifications.update({
										id: "sending-password-reset",
										color: "red",
										message: "Please enter a valid email address",
										title: "Generating Password Reset Link",
										icon: <IconRefreshAlert />,

										loading: false,
									});
								}

								return await sendPasswordResetLink({
									to: form.getValues("login.credentials[0].email"),
									brand: theme.other.id,
								})
									.then((res) => {
										return notifications.update({
											id: "sending-password-reset",
											color: "green",
											message:
												"Password Reset Link Sent. It may take a few minutes to arrive.",
											title: "Generating Password Reset Link",
											icon: <IconProgressCheck />,
											loading: false,
										});
									})
									.catch((err) => {
										console.warn(
											"Unacaught Error sending password reset link",
											err
										);

										return notifications.update({
											id: "sending-password-reset",
											color: "red",
											message: err.message,
											title: "Generating Password Reset Link",
											icon: <IconRefreshAlert />,
											loading: false,
										});
									});
							},
						});
					}}
				>
					Forgot your Password?
				</UnstyledButton>
			</Flex>
			<Button
				fullWidth
				type="submit"
			>
				Submit
			</Button>
			<Divider
				my="xs"
				label="make signing in easier..."
				labelPosition="center"
			/>
			<Group grow>
				<Button
					variant="light"
					onClick={() =>
						startTransition(async () => {
							await signInWithProvider({
								provider: "google",
								user,
							})
								.catch((err) =>
									notifications.show({
										...defaultNotificationProps,
										color: "red",
										message: err.message,
										title: "Could not sign in",
									})
								)
								.finally(() => router.refresh());
						})
					}
				>
					Continue with Google
				</Button>
				<Button
					variant="light"
					onClick={() =>
						startTransition(async () => {
							await signInWithProvider({
								provider: "apple",
								user,
							})
								.catch((err) =>
									notifications.show({
										...defaultNotificationProps,
										color: "red",
										message: err.message,
										title: "Could not sign in",
									})
								)
								.finally(() => router.refresh());
						})
					}
				>
					Continue with Apple
				</Button>
			</Group>
		</form>
	);
}
