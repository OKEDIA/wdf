"use client";

// React Imports

// Next.js Imports

// Lower Order Components

// UI Components & Icons
import {
	Center,
	Container,
	GridCol,
	Paper,
	Stack,
	Text,
	useMantineTheme,
} from "@mantine/core";
import WdfLogo from "../(root)/_components/logos/WdfLogo";
import { LoginForm } from "./_components/LoginForm";

// Context & Helpers

// Other libraries or utilities

// Types

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

// **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** // **** //

/**
 * The `Login` component renders the login page for the application.
 * It includes a logo, a brief description, and a login form.
 *
 * @returns {JSX.Element} The rendered login page component.
 */
export default function Login(): JSX.Element {
	const l10n = useMantineTheme().other.l10n;
	const theme = useMantineTheme().other;

	return (
		<Container fluid>
			<GridCol span={24}>
				<Center>
					<Stack
						align="center"
						justify="center"
					>
						<WdfLogo
							style={{ scale: 1 }}
							p={0}
							c="dark"
						>
							<Text
								tt="uppercase"
								fw="900"
								size="3em"
								lh="normal"
								c="branding"
							>
								{theme.id}
							</Text>
						</WdfLogo>
						<Text ta="center">
							Log in to create or update your website using the WDF Builder.
						</Text>
					</Stack>
				</Center>
			</GridCol>
			<GridCol
				span={24}
				mt="lg"
			>
				<Paper
					shadow="xs"
					p="xl"
				>
					<LoginForm />
				</Paper>
			</GridCol>
		</Container>
	);
}
