import { isProductionEnvironment } from "@okedia/shared/helpers/isProductionEnvironment";
import { formatPrivateKey } from "@okedia/shared/helpers/string";
import { useServersideDatabase } from "@okedia/shared/hooks/database/useServersideDatabase";
import { LocalUser } from "@okedia/shared/types/authenticationTypes";
import {
	InternalApiResponse,
	UnpaginitedMongoResponse,
} from "@okedia/shared/types/documentResponses";
import { DecodedIdToken } from "firebase-admin/auth";
import {
	authMiddleware,
	redirectToLogin,
	redirectToPath,
} from "next-firebase-auth-edge";
import {
	refreshCredentials,
	refreshServerCookies,
} from "next-firebase-auth-edge/next/cookies";
import { NextRequest, NextResponse } from "next/server";
import createNewCustomer from "./app/api/_helpers/billing/createNewCustomer";
import findCustomer from "./app/api/_helpers/billing/findACustomer";
import { getServerBrand } from "./app/api/_helpers/branding";
import {
	getUser,
	setCustomUserClaims,
} from "./app/api/_helpers/firebase_auth/admin";

const PUBLIC_PATHS = ["/login", "/", "/terms", "/privacy"];
const API_PATHS = ["/api/"];

/**
 * Middleware function to handle authentication, authorization, and request processing.
 *
 * @param request - The incoming `NextRequest` object containing request details.
 * @param response - The `NextResponse` object used to modify the response.
 * @returns A `Promise` resolving to a `NextResponse` object after processing the request.
 *
 * ### Features:
 * - **API Path Detection**: Determines if the request is targeting an API path.
 * - **Authentication Middleware**: Handles token validation, user setup, and credential refresh.
 * - **Custom Claims Handling**: Checks and sets custom claims for new users.
 * - **Public Route Restriction**: Redirects authenticated users away from public routes in production.
 * - **Redirect Handling**: Redirects users based on the `redirect` query parameter.
 * - **Error Handling**: Handles invalid tokens and errors by redirecting to the login page.
 * - **Brand Context**: Sets the current brand in cookies and headers for non-API paths.
 *
 * ### Options:
 * - `debug`: Enables debug mode in non-production environments.
 * - `loginPath`: Path for user login.
 * - `logoutPath`: Path for user logout.
 * - `refreshTokenPath`: Path for refreshing tokens.
 * - `checkRevoked`: Checks if the token has been revoked.
 *
 * ### Handlers:
 * - `handleValidToken`: Processes valid tokens, sets up new users, and handles redirects.
 * - `handleInvalidToken`: Redirects to the login page for invalid tokens.
 * - `handleError`: Logs errors and redirects to the login page.
 *
 * ### Side Effects:
 * - Sets cookies for the current brand.
 * - Adds headers for server-side components to access the current URL.
 *
 * ### Example Usage:
 * This middleware is designed to be used in a Next.js application to handle authentication
 * and route protection seamlessly.
 */
export async function middleware(request: NextRequest, response: NextResponse) {
	const isApiPath = API_PATHS.some((path) =>
		request.nextUrl.pathname.startsWith(path)
	);

	const responseToReturn = await authMiddleware(request, {
		...commonOptions,
		loginPath: "/api/auth/login",
		logoutPath: "/api/auth/logout",
		refreshTokenPath: "/api/auth/refresh-token",
		handleValidToken: async ({ token, decodedToken }, headers) => {
			// Extract custom claims from the decoded token
			// Check if localUid is missing in custom claims and set it if necessary
			const isNewUser = !(await getUser(decodedToken?.uid))?.customClaims
				?.localUID;

			if (isNewUser) {
				// If localUID is missing, set it to the UID from the token
				await setupNewUser(request, decodedToken);

				// Refresh both server and client credentials after setting up the new user
				await refreshServerCookies(
					request.cookies,
					request.headers,
					commonOptions
				);
				return refreshCredentials(
					request,
					commonOptions,
					({ headers, tokens }) => {
						return NextResponse.next({
							request: {
								headers,
							},
						});
					}
				);
			}

			if (request.nextUrl.pathname === "/login") {
				return redirectToPath(request, "/dashboard", {
					shouldClearSearchParams: true,
				});
			}

			if (!PUBLIC_PATHS.includes(request.nextUrl.pathname)) {
				// Check that the user is not trying to access the dashboard without a brand
				// If the user does not have a brand, redirect them to the homepage to select one.

				if (isProductionEnvironment) {
					// Check there is a subdomain in the url
					const { hostname } = request.nextUrl;
					const domainParts = hostname.split(".");
					if (domainParts.length === 2) {
						return redirectToPath(request, "/");
					}
				} else {
					// Dev environments get theme url param instead of a subdomain
					if (!request.nextUrl.searchParams.has("theme")) {
						const themeFromCookie = request.cookies.get("brand")?.value;
						if (themeFromCookie) {
							const modifiedUrl = new URL(request.url);
							modifiedUrl.searchParams.set("theme", themeFromCookie);
							return NextResponse.redirect(modifiedUrl);
						}
					}
				}
			}

			const redirectUrl = request.nextUrl.searchParams.get("redirect");
			if (redirectUrl) {
				return redirectToPath(request, redirectUrl, {
					shouldClearSearchParams: true,
				});
			}

			return NextResponse.next({
				request: {
					headers,
				},
			});
		},
		handleInvalidToken: async (reason) => {
			console.error("Invalid token:", reason);
			return redirectToLogin(request, {
				path: "/login",
				publicPaths: PUBLIC_PATHS,
			});
		},
		handleError: async (error) => {
			console.error(error);
			// Refresh both server and client credentials after setting up the new user
			return redirectToLogin(request, {
				path: "/login",
				publicPaths: PUBLIC_PATHS,
			});
		},
	});

	if (!isApiPath) {
		// If the current path is NOT an API Path, set the current brand in the cookies.
		const { id: brandId } = await getServerBrand(request.url);
		responseToReturn.cookies?.set("brand", brandId);

		// Set the header - required so Server Components can get the URL for the getServerBrand function
		responseToReturn.headers.set("x-current-url", request.url);
	}

	return responseToReturn;
}

export const commonOptions = {
	enableCustomToken: true,
	debug: true,
	checkRevoked: true,
	experimental_enableTokenRefreshOnExpiredKidHeader: true,
	enableMultipleCookies: true,
	apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY as string,
	cookieName: process.env.NEXT_PUBLIC_FIREBASE_COOKIE_NAME as string,
	cookieSignatureKeys: [
		process.env.NEXT_PUBLIC_FIREBASE_COOKIE_KEY_1 as string,
		process.env.NEXT_PUBLIC_FIREBASE_COOKIE_KEY_2 as string,
	],
	cookieSerializeOptions: {
		domain: "." + process.env.VERCEL_PROJECT_PRODUCTION_URL, // Set cookie for all subdomains
		path: "/",
		httpOnly: !isProductionEnvironment,
		secure: isProductionEnvironment, // Set this to true on HTTPS environments
		sameSite: "lax" as const,
		maxAge: 12 * 60 * 60 * 24, // twelve days
	},
	serviceAccount: {
		projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID as string,
		clientEmail: process.env.NEXT_PUBLIC_FIREBASE_CLIENT_EMAIL as string,
		privateKey: formatPrivateKey(process.env.FIREBASE_PRIVATE_KEY as string),
	},
	dynamicCustomClaimsKeys: [
		"isAdmin",
		"isDeveloper",
		"localUID",
		"profiles",
		"websites",
	],
};

/**
 * Sets up a new user in the system by performing the following steps:
 * 1. Checks if the user already exists in Stripe using their email.
 * 2. If the user does not exist, creates a new local user in the database.
 * 3. Creates a new customer in Stripe with the user's details.
 * 4. Merges and updates custom claims for the user in Firebase Authentication.
 *
 * @param req - The incoming HTTP request object, containing details such as cookies and the request URL.
 * @param userData - The decoded Firebase ID token containing user information such as email, UID, and custom claims.
 *
 * @throws Will throw an error if there is an issue with database operations, Stripe customer creation,
 *         or setting custom user claims in Firebase.
 */
async function setupNewUser(req: NextRequest, userData: DecodedIdToken) {
	console.log("Initializing setupNewUser for user:", userData.email);
	try {
		console.log("Searching for existing customer in Stripe...");
		const foundCustomer = await findCustomer({
			query: `email:\"${userData.email}\"`,
		});
		console.log("Stripe customer search result:", foundCustomer);

		if (
			(foundCustomer?.total_count ?? 0) > 0 ||
			!!foundCustomer?.data?.[0]?.metadata?.firebaseUID
		) {
			console.warn(
				`Customer ${userData.email} already exists in Stripe, skipping creation`
			);
			return;
		}

		const apiUrl = `${req.nextUrl.origin}${process.env.NEXT_PUBLIC_API_BASE_URL}`;
		console.log("Using API URL:", apiUrl);
		const db = useServersideDatabase(
			apiUrl,
			"",
			"application/json",
			req.cookies
		);

		console.log("Creating new local user in the database...");
		const newLocalUser = await db
			.post<InternalApiResponse<UnpaginitedMongoResponse<LocalUser>>>({
				url: "/auth/user",
				body: {
					uid: userData.uid,
				},
			})
			.then((res) => {
				if (res.success) {
					console.log("New local user created successfully:", res.response);
					return res.response;
				} else {
					throw new Error(res.message);
				}
			});

		console.log("Creating new customer in Stripe...");
		await createNewCustomer({
			name: userData?.name,
			email: userData?.email,
			metadata: { firebaseUID: userData.uid },
		});
		console.log("Stripe customer created successfully.");

		const mergedClaims = {
			...(userData?.customClaims || {}),
			localUID: newLocalUser._id.toString(),
			profiles: [],
			websites: [],
		};
		console.log("Updating Firebase custom claims with:", mergedClaims);
		await setCustomUserClaims(userData.uid, { ...mergedClaims });
		console.log("Firebase custom claims updated successfully.");
	} catch (error) {
		console.error("Error in setupNewUser:", error);
		throw new Error(
			"Middleware encountered an error setting up a new user in MongoDB and/or Stripe. " +
				error
		);
	}
}

export const config = {
	matcher: [
		"/api/auth/login",
		"/api/auth/logout",
		"/api/auth/refresh-token",
		"/",
		"/((?!_next|favicon.ico|api|.*\\.).*)",
	],
};
