import {
	Dirent,
	mkdirSync,
	readFileSync,
	readdirSync,
	writeFileSync,
} from "fs";
import mjml2html from "mjml";
import path from "path";

// Define the source and output directories
const srcDir = path.join(process.cwd(), "src/emails");
const outDir = path.join(process.cwd(), "src/emails/compiled");

// Check if the '--debug' flag is passed as a command-line argument
const isDebugMode = process.argv.includes("--debug");
isDebugMode && console.log("Debug mode is enabled.");

// Create the output folder if it doesn't exist
mkdirSync(outDir, { recursive: true });

/**
 * This function compiles all MJML files in the source directory (src/emails)
 * into HTML files and saves them in the compiled folder (src/emails/compiled).
 * It will skip dotfiles, dot directories, and files in the 'template' folder.
 */
const compileAll = () => {
	// Read all items (files and directories) in the source directory
	const files: Dirent[] = readdirSync(srcDir, { withFileTypes: true });

	files.forEach((dirent: Dirent) => {
		// Skip any dotfiles or dot directories (e.g., .DS_Store, .git, .vscode)
		// Also, skip the "template" directory entirely
		if (dirent.name.startsWith(".") || dirent.name === "template") {
			isDebugMode &&
				console.log(`Skipping dotfile or template directory: ${dirent.name}`);
			return;
		}

		// Process each directory in the source folder
		if (dirent.isDirectory()) {
			// Read all files within this directory
			const subFiles: string[] = readdirSync(path.join(srcDir, dirent.name));

			subFiles.forEach((file: string) => {
				// Skip any dotfiles in the subdirectory
				if (file.startsWith(".")) {
					isDebugMode && console.log(`Skipping dotfile: ${file}`);
					return;
				}

				// If the file is an MJML file, process it
				if (file.endsWith(".mjml")) {
					const inputPath = path.join(srcDir, dirent.name, file);
					const outputPath = path.join(
						outDir,
						`${file.replace(".mjml", ".html")}`
					);

					// Read the MJML content from the file
					const mjmlContent = readFileSync(inputPath, "utf8");

					// Compile MJML to HTML
					const { html, errors } = mjml2html(mjmlContent, {
						filePath: path.dirname(inputPath), // Use the directory of the current MJML file
					});

					// If errors exist, log them
					if (isDebugMode && errors.length > 0) {
						console.warn(`❌ MJML errors in ${inputPath}:`);
						console.warn(errors);
					} else if (!isDebugMode && errors.length > 0) {
						console.warn(
							"‼️ Template conversion warnings detected, run again with --debug flag to display the errors."
						);
					}

					// Save the compiled HTML to the output folder
					writeFileSync(outputPath, html, "utf8");

					// Log the successful compilation
					console.log(`✅ Successfully compiled ${file} to HTML.`);
				}
			});
		}
	});
};

// Start the compilation process
console.log("Starting MJML compilation...");
compileAll();
console.log("MJML compilation completed.");
