import { expect, test } from "@playwright/test";
import path from "path";

const authFile = path.join(__dirname, "../../playwright/.auth/user.json");

test("Email Login Works", async ({ page }) => {
	console.log(authFile, __dirname);
	test.slow(); // Triple the default timeout

	await page.goto("http://app.localhost:3000/login");
	await expect(
		page.getByRole("button", { name: "Continue with Email Address" })
	).toBeVisible();
	await page
		.getByRole("button", { name: "Continue with Email Address" })
		.click();
	await expect(
		page.getByRole("textbox", { name: "Email Address" })
	).toBeVisible();
	await expect(page.getByRole("textbox", { name: "Password" })).toBeVisible();
	await page.getByRole("textbox", { name: "Email Address" }).click();
	await page
		.getByRole("textbox", { name: "Email Address" })
		.fill("endtoendtesting@localhost");
	await page.getByRole("button", { name: "Submit" }).click();
	await expect(page.getByText("Please enter a valid email")).toBeVisible();
	await expect(page.getByText("Please complete this")).toBeVisible();
	await page.getByRole("textbox", { name: "Email Address" }).click();
	await page
		.getByRole("textbox", { name: "Email Address" })
		.fill("endtoendtesting@localhost.dev");
	await page.getByRole("textbox", { name: "Password" }).click();
	await page
		.getByRole("textbox", { name: "Password" })
		.fill("endtoendtestingpassword");
	await page.getByRole("button", { name: "Submit" }).click();
	await page.waitForLoadState("networkidle");
	await page.waitForURL(/\/dashboard/);
	await expect(
		page.getByRole("heading", { name: "Your Websites" })
	).toBeVisible();
	// Store authentication state
	await page.context().storageState({ path: authFile, indexedDB: true });
});
