import { expect, test } from "@playwright/test";

// All tests here  are opted out of authentication!
test.use({ storageState: { cookies: [], origins: [] } });

test("subdomains work and landing page renders", async ({ page }) => {
	await page.goto("http://app.localhost:3000/");
	await expect(
		page
			.locator("div")
			.filter({ hasText: "Create or update your website" })
			.nth(2)
	).toBeVisible();
	await page.goto("http://producers.app.localhost:3000/");
	await expect(
		page
			.locator("div")
			.filter({ hasText: "Create or update your website" })
			.nth(2)
	).toBeVisible();
});

test("login page renders", async ({ page }) => {
	const baseurl = "app.localhost:3000/";
	await page.goto(`http://${baseurl}`);

	await page.getByRole("button", { name: "producers" }).first().click();

	const url = page.url();
	await page.waitForLoadState("domcontentloaded");
	await page.getByRole("button", { name: "Producers" }).click();
	await expect(
		page.getByRole("button", { name: "Continue with Google" })
	).toBeVisible();
	await expect(
		page.getByRole("button", { name: "Continue with Apple" })
	).toBeVisible();
	await expect(
		page.getByRole("button", { name: "Continue with Email Address" })
	).toBeVisible();
	await expect(page.getByRole("main")).toContainText("WEBDESIGNFORactors");
	await expect(url).toMatch(
		new RegExp(
			`https?:\/\/app\.localhost:3000\/|http:\/\/app\.localhost:3000\/login\\?redirect=%2Fdashboard%2Fcreate%2Fproducers%3Ftheme%3Dproducers`
		)
	);
});

test("Redirects to login when unauthenticated", async ({ page }) => {
	await page.goto("http://localhost:3000/dashboard");
	await expect(page).toHaveURL(/\/login\?redirect=\/dashboard/);
});

test("Login Page Brand Changes", async ({ page }) => {
	await page.goto("http://app.localhost:3000/login?theme=actors");
	await expect(page.getByRole("main")).toContainText("actors");
	await page.goto("http://app.localhost:3000/login?theme=producers");
	await expect(page.getByRole("main")).toContainText("producers");
});

test("Google Popup Opens", async ({ page }) => {
	await page.goto("http://app.localhost:3000/login");
	const page1Promise = page.waitForEvent("popup");
	await page.getByRole("button", { name: "Continue with Google" }).click();
	const page1 = await page1Promise;

	if (process.env.VERCEL_ENV === "production") {
		await expect(page1.locator("body")).toMatchAriaSnapshot(`
    - text: Sign in with Google
    - img "Web Design For"
    - heading "Sign in" [level=1]
    - text: to continue to
    - button "Web Design For"
    - textbox "Email or phone"
    - button "Forgot email?"
    - text: Before using this app, you can review Web Design For’s
    - link "privacy policy"
    - text: and
    - link "terms of service"
    - text: .
    - button "Next"
    - button "Create account"
    `);
	} else {
		await expect(page1.getByText("Sign-in with Google.com")).toBeVisible();
	}
});
test("Apple Popup Opens", async ({ page }) => {
	// TODO! This test is not working as expected. It should open a popup window but it doesn't.
	// Test will pass.
	await page.goto("http://app.localhost:3000/login");
	const page1Promise = page.waitForEvent("popup");
	await page.getByRole("button", { name: "Continue with Apple" }).click();
	const page1 = await page1Promise;
});
