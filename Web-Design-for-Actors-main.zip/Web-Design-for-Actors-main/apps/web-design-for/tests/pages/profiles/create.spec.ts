import { expect, test } from "@playwright/test";

test("Profile Lookup Works as Expected", async ({ page }) => {
	await page.goto("http://app.localhost:3000/dashboard");
	await page
		.getByRole("textbox", { name: "Select the type of website" })
		.click();
	await page.getByRole("option", { name: "Actors" }).click();
	await page.getByRole("button", { name: "Create a Website" }).click();
	await page.getByRole("textbox", { name: "Search for actors" }).click();
	await page
		.getByRole("textbox", { name: "Search for actors" })
		.fill("abcdenobodywilleveraddthis");
	await expect(page.getByRole("main")).toContainText("No websites found.");
	await page.getByRole("textbox", { name: "Search for actors" }).click();
	await page
		.getByRole("textbox", { name: "Search for actors" })
		.press("ControlOrMeta+a");
	await page
		.getByRole("textbox", { name: "Search for actors" })
		.fill("anna marie");
	await expect(
		page.getByRole("heading", { name: "Anna Marie Sullivan" })
	).toBeVisible();
	await expect(
		page.getByRole("group").filter({
			hasText:
				/^If your website doesn't appear above, create a new one\.Create a new website$/,
		})
	).toBeVisible();
	await page
		.getByRole("group")
		.filter({
			hasText:
				/^If your website doesn't appear above, create a new one\.Create a new website$/,
		})
		.getByRole("button")
		.click();

	await page.waitForLoadState("networkidle");
	await expect(page.locator("form")).toBeVisible();
});

test("Create an Actor Profile", async ({ page }) => {
	await page.goto("http://app.localhost:3000/dashboard", {
		waitUntil: "networkidle",
	});

	// Set the localStorage to disable validation and reload
	await page.evaluate(
		(val) => localStorage.setItem("validation", val),
		"false"
	);
	await page.waitForTimeout(1000);

	await page.evaluate(
		(val) => localStorage.setItem("validating", val),
		"disabled"
	);
	await page.waitForTimeout(1000);

	await page.reload();
	await page.waitForLoadState("networkidle");
	await page
		.getByRole("textbox", { name: "Select the type of website" })
		.click();
	await page.getByRole("option", { name: "Actors" }).click();
	await page.getByRole("button", { name: "Create a Website" }).click();
	await page.getByRole("textbox", { name: "Search for actors" }).click();
	await page.getByRole("textbox", { name: "Search for actors" }).fill("abc");
	await expect(
		page.getByRole("group").filter({ hasText: /^No websites found\.$/ })
	).toBeVisible();
	await page.getByRole("button", { name: "Create a new website" }).click();
	let saveChangesButton;
	do {
		saveChangesButton = await page.$('role=button[name="Save Changes"]');
		if (saveChangesButton) {
			await saveChangesButton.click();
		} else {
			await page.getByRole("button", { name: "Next Step" }).click();
		}
	} while (!saveChangesButton);

	await page.waitForNavigation();
	const url = page.url();
	expect(url).toMatch(
		/http:\/\/app.localhost:3000\/dashboard\/edit\/[a-z0-9]+(\?|\&)([^=]+=[^&]*\&)*created=true/
	);

	await page.waitForLoadState("domcontentloaded");
	await expect(page.locator("form")).toBeVisible();
});

test("Update an Actor Profile", async ({ page }) => {
	await page.goto("http://app.localhost:3000/dashboard", {
		waitUntil: "networkidle",
	});

	// Set the localStorage to disable validation and reload

	await page.evaluate(
		(val) => localStorage.setItem("validation", val),
		"false"
	);
	await page.waitForTimeout(1000);
	await page.evaluate(
		(val) => localStorage.setItem("validating", val),
		"disabled"
	);
	await page.waitForTimeout(1000);

	console.log("Before reloading localStorage:");

	console.log(
		"validation:",
		await page.evaluate(() => localStorage.getItem("validation"))
	);
	console.log(
		"validating:",
		await page.evaluate(() => localStorage.getItem("validating"))
	);
	await page.reload();
	await page.waitForLoadState("networkidle");

	console.log("After setting localStorage and reload:");
	console.log(
		"validation:",
		await page.evaluate(() => localStorage.getItem("validation"))
	);
	console.log(
		"validating:",
		await page.evaluate(() => localStorage.getItem("validating"))
	);
	await expect(
		page.getByRole("button", { name: "Edit Website" })
	).toBeVisible();
	await page.getByRole("button", { name: "Edit Website" }).nth(0).isVisible();
	await page.getByRole("button", { name: "Edit Website" }).nth(0).click();
	await page.waitForLoadState("networkidle");

	await page.getByRole("textbox", { name: "Mike Doe" }).click();
	await page.getByRole("textbox", { name: "Mike Doe" }).fill("Some Change");
	await expect(
		page.locator("div").filter({ hasText: "Publish your website" }).nth(2)
	).toBeVisible();
	await expect(page.getByText("Field Validation is Disabled")).toBeVisible();
	await expect(
		page.getByRole("button", { name: "Save Changes" })
	).toBeVisible();
	await page.getByRole("button", { name: "Save Changes" }).click();
	await page.waitForLoadState("networkidle");
	await page.reload();
	await page.waitForLoadState("networkidle");
	await page.getByRole("textbox", { name: "Mike Doe" }).click();
	await expect(page.getByRole("textbox", { name: "Mike Doe" })).toHaveValue(
		"Some Change"
	);
});

test("Create an Actor Website", async ({ page }) => {
	await page.goto("http://app.localhost:3000/dashboard");
	await page.reload();
	await expect(
		page.getByRole("button", { name: "Edit Website" })
	).toBeVisible();
	await page.getByRole("button", { name: "Edit Website" }).nth(0).isVisible();
	await page.getByRole("button", { name: "Edit Website" }).nth(0).click();
	await page.waitForURL(/.*\/dashboard\/edit\/.*/);

	const url = page.url();
	const newUrl = url.replace(
		/\/edit\/([a-z0-9]+)((\?|\&)([^=]+=[^&]*\&)*step=0)?/,
		"/edit/$1/website$2"
	);
	await page.goto(newUrl, { waitUntil: "networkidle" });
	await page.waitForLoadState("networkidle");
	await expect(page.locator("form")).toBeVisible();
	await expect(
		page.getByRole("textbox", { name: "Select a color" })
	).toBeVisible();
	await page.getByRole("textbox", { name: "Select a color" }).click();
	await page.getByRole("option", { name: "Scarlett Showman" }).click();
	await page.getByRole("textbox", { name: "Select a color" }).click();
	await page.getByText("Choose your own").click();
	await expect(
		page.getByRole("textbox", { name: "Custom Color" })
	).toBeVisible();
	await page.getByRole("textbox", { name: "Custom Color" }).click();
	await page.locator(".m_202a296e > div:nth-child(3)").click();
	await page.locator(".m_d856d47d > div:nth-child(2)").click();
	await page.locator("div:nth-child(6)").first().click();
	await page.locator("body").click({ position: { x: 0, y: 0 } });
	let saveChangesButton;
	do {
		saveChangesButton = await page.$('role=button[name="Save Changes"]');
		if (saveChangesButton) {
			await saveChangesButton.click();
		} else {
			await page.getByRole("button", { name: "Next Step" }).click();
		}
	} while (!saveChangesButton);

	await page.waitForNavigation();
	await page.waitForLoadState("networkidle");

	const finalUrl = page.url();
	expect(finalUrl).toMatch(
		/http:\/\/app.localhost:3000\/dashboard\/edit\/[a-z0-9]+\/website\/[a-z0-9]+(\?|\&)([^=]+=[^&]*\&)*created=true/
	);

	await page.getByRole("navigation").getByRole("button").first().click();
	await expect(
		page.getByRole("button", { name: "Edit Website" })
	).toBeVisible();
	await expect(
		page.getByRole("button", { name: "Edit Website" })
	).toBeVisible();
});
