import { expect, test } from "@playwright/test";

test("Dashboard does not show admin links", async ({ page }) => {
	await page.goto("http://app.localhost:3000/dashboard", {
		waitUntil: "networkidle",
	});

	const adminUsersPageLink = await page.$("svg.tabler-icons-users-group");
	expect(adminUsersPageLink).toBeNull();

	const adminWebsitesPageLink = await page.$("svg.tabler-icon-topology-star-3");
	expect(adminWebsitesPageLink).toBeNull();

	const adminLogsPageLink = await page.$("tabler-icon-list");
	expect(adminLogsPageLink).toBeNull();

	const userActionsMenu = await page.locator(
		".m_6d731127 > div > div:nth-child(2)"
	);

	await userActionsMenu.click();
	await expect(
		page.getByRole("menuitem", { name: "Sign Out of Account" })
	).toBeVisible();

	const isAdminOptionVisible = await userActionsMenu
		.locator("text=Administration")
		.isVisible();
	expect(isAdminOptionVisible).toBeFalsy();
});

test("Sign out button works", async ({ page }) => {
	await page.goto("http://app.localhost:3000/dashboard", {
		waitUntil: "networkidle",
	});
	await page.locator(".m_6d731127 > div > div:nth-child(2)").click();
	await page.getByRole("menuitem", { name: "Sign Out of Account" }).click();
	await page.waitForLoadState("networkidle");
	await expect(
		page.getByRole("button", { name: "Continue with Email Address" })
	).toBeVisible();
});

test("Can start a new website", async ({ page }) => {
	await page.goto("http://app.localhost:3000/dashboard");
	await page
		.getByRole("textbox", { name: "Select the type of website" })
		.click();
	await page.getByRole("option", { name: "Producers" }).click();
	await expect(page).toHaveURL(/.*\/create\/producers/);
	await page.waitForLoadState("networkidle");
	await page.getByRole("button", { name: "Get Started", exact: true }).click();
	await page.waitForLoadState("networkidle");
	await page.goto("http://app.localhost:3000/login?redirect=/dashboard");
});

test("Can navigate to Serivce Status", async ({ page }) => {
	await page.goto("http://app.localhost:3000/dashboard");
	await page.getByRole("button").nth(1).click();
	await expect(page).toHaveURL(/.*\/dashboard\/service-status/);
	await expect(page.locator(".m_96bdd299").first()).toBeVisible();
	await page.waitForLoadState("networkidle");
});

test("Can navigate to Settings", async ({ page }) => {
	await page.goto("http://app.localhost:3000/dashboard");
	await page.locator(".m_6d731127 > div > div:nth-child(2)").click();
	await page.getByRole("menuitem", { name: "Settings & Billing" }).click();
	await page.waitForLoadState("networkidle");
	await expect(page).toHaveURL(/.*\/dashboard\/settings/);

	await expect(
		page.getByRole("heading", { name: "Your Profile" })
	).toBeVisible();

	await expect(
		page.getByRole("textbox", { name: "Email Address" })
	).toBeVisible();
});

// test("Support software displays", async ({ page }) => {
// 	await page.goto("http://app.localhost:3000/dashboard", {
// 		waitUntil: "domcontentloaded",
// 	});
// 	await page.getByRole("button", { name: "Help" }).click();
// 	await page
// 		.getByText(
// 			"How can we help you today?KnowledgebaseBrowse articles to find answers your"
// 		)
// 		.click();
// 	await page.locator("supportpal-widget svg").nth(1).click();
// });
